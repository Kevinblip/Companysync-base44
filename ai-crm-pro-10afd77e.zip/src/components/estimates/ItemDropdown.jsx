
import React, { useState, useRef, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Star, StarOff, Plus } from "lucide-react";

export default function ItemDropdown({ value, onSelect, formatFilter = "all", placeholder = "Search items...", allowMultiple = false }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(0);
  const [selectedItems, setSelectedItems] = useState([]);
  const dropdownRef = useRef(null);
  const inputRef = useRef(null);
  const queryClient = useQueryClient();

  const { data: allItems = [] } = useQuery({
    queryKey: ['price-list-items'],
    queryFn: () => base44.entities.PriceListItem.list("-created_date", 10000),
    initialData: [],
  });

  const toggleFavoriteMutation = useMutation({
    mutationFn: ({ id, isFavorite }) => 
      base44.entities.PriceListItem.update(id, { is_favorite: !isFavorite }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-list-items'] });
    },
  });

  // Filter by format and search term
  const filteredItems = allItems.filter(item => {
    const matchesSearch = 
      item.code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    let matchesFormat = true;
    if (formatFilter !== "all") {
      if (formatFilter === "favorites") {
        matchesFormat = item.is_favorite === true;
      } else if (formatFilter === "xactimate") {
        matchesFormat = item.source === "Xactimate";
      } else if (formatFilter === "symbility") {
        matchesFormat = item.source === "Symbility";
      } else if (formatFilter === "custom") {
        matchesFormat = item.source === "Custom" || !item.source;
      }
    }
    
    return matchesSearch && matchesFormat;
  }).slice(0, 100);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
        setSearchTerm("");
        setSelectedItems([]);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (item) => {
    if (allowMultiple) {
      // Toggle selection
      if (selectedItems.includes(item.id)) {
        setSelectedItems(selectedItems.filter(id => id !== item.id));
      } else {
        setSelectedItems([...selectedItems, item.id]);
      }
    } else {
      // Single select
      onSelect({
        code: item.code,
        description: item.description,
        unit: item.unit || "EA",
        rate: item.price,
        category: item.category
      });
      setSearchTerm("");
      setShowDropdown(false);
    }
  };

  const handleAddSelected = () => {
    const items = allItems.filter(item => selectedItems.includes(item.id));
    
    // Pass ALL items as an array to onSelect (not one at a time)
    const itemsToAdd = items.map(item => ({
      code: item.code,
      description: item.description,
      unit: item.unit || "EA",
      rate: item.price,
      category: item.category
    }));
    
    // Send array of all selected items
    onSelect(itemsToAdd);
    
    setSelectedItems([]);
    setSearchTerm("");
    setShowDropdown(false);
  };

  const handleKeyDown = (e) => {
    if (!showDropdown) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightedIndex(prev => Math.min(prev + 1, filteredItems.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightedIndex(prev => Math.max(prev - 1, 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (!allowMultiple && filteredItems[highlightedIndex]) {
        handleSelect(filteredItems[highlightedIndex]);
      }
    } else if (e.key === 'Escape') {
      setShowDropdown(false);
      setSearchTerm("");
      setSelectedItems([]);
    }
  };

  const getCategoryColor = (category) => {
    const colors = {
      'Roofing': 'bg-blue-100 text-blue-700',
      'Siding': 'bg-green-100 text-green-700',
      'Windows': 'bg-purple-100 text-purple-700',
      'Doors': 'bg-orange-100 text-orange-700',
      'Interior': 'bg-pink-100 text-pink-700',
      'Exterior': 'bg-teal-100 text-teal-700',
      'HVAC': 'bg-red-100 text-red-700',
      'Plumbing': 'bg-indigo-100 text-indigo-700',
      'Electrical': 'bg-yellow-100 text-yellow-700',
      'Other': 'bg-gray-100 text-gray-700'
    };
    return colors[category] || colors.Other;
  };

  const displayValue = showDropdown ? searchTerm : (value || "");

  return (
    <div className="relative w-full" ref={dropdownRef}>
      <Input
        ref={inputRef}
        value={displayValue}
        onChange={(e) => {
          setSearchTerm(e.target.value);
          if (!showDropdown) setShowDropdown(true);
          setHighlightedIndex(0);
        }}
        onClick={() => {
          setShowDropdown(true);
          setSearchTerm("");
        }}
        onFocus={() => {
          setShowDropdown(true);
          setSearchTerm("");
        }}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        className="border-gray-300 focus:ring-2 focus:ring-blue-500 cursor-pointer"
      />

      {showDropdown && filteredItems.length > 0 && (
        <div className="absolute z-50 w-[120%] left-0 mt-1 bg-white border rounded-lg shadow-xl max-h-[600px] overflow-y-auto">
          {allowMultiple && selectedItems.length > 0 && (
            <div className="sticky top-0 bg-white border-b p-3 flex items-center justify-between z-10">
              <span className="text-sm font-medium">{selectedItems.length} items selected</span>
              <Button 
                size="sm" 
                onClick={handleAddSelected}
                className="bg-green-600 hover:bg-green-700"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Selected
              </Button>
            </div>
          )}

          <div className="p-2 space-y-1">
            {filteredItems.map((item, index) => (
              <div
                key={item.id}
                className={`p-3 rounded hover:bg-blue-50 cursor-pointer transition-colors ${
                  index === highlightedIndex ? 'bg-blue-50' : ''
                }`}
                onClick={() => handleSelect(item)}
                onMouseEnter={() => setHighlightedIndex(index)}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 flex-1 min-w-0">
                    {allowMultiple && (
                      <Checkbox
                        checked={selectedItems.includes(item.id)}
                        onCheckedChange={() => handleSelect(item)}
                        onClick={(e) => e.stopPropagation()}
                        className="mt-1"
                      />
                    )}

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavoriteMutation.mutate({ 
                          id: item.id, 
                          isFavorite: item.is_favorite 
                        });
                      }}
                      className="flex-shrink-0 mt-1 hover:scale-110 transition-transform"
                    >
                      {item.is_favorite ? (
                        <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                      ) : (
                        <StarOff className="w-4 h-4 text-gray-400" />
                      )}
                    </button>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <code className="text-xs font-mono font-semibold text-blue-600">
                          {item.code}
                        </code>
                        <Badge variant="outline" className="text-xs">
                          {item.source || "Custom"}
                        </Badge>
                        {item.category && (
                          <Badge className={`${getCategoryColor(item.category)} text-xs`}>
                            {item.category}
                          </Badge>
                        )}
                      </div>
                      <div className="text-sm text-gray-900 line-clamp-2">
                        {item.description}
                      </div>
                    </div>
                  </div>

                  <div className="flex-shrink-0 text-right min-w-[80px]">
                    <div className="text-base font-bold text-green-600">
                      ${item.price?.toFixed(2)}
                    </div>
                    <div className="text-xs text-gray-500 whitespace-nowrap">
                      per {item.unit || "EA"}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredItems.length === 0 && (
            <div className="p-8 text-center text-gray-500">
              <p className="text-sm">No items found</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
