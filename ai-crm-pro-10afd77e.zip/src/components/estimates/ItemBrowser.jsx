import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Star, StarOff } from "lucide-react";

export default function ItemBrowser({ open, onClose, onSelect }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [activeTab, setActiveTab] = useState("all");

  const { data: allItems = [] } = useQuery({
    queryKey: ['price-list-items'],
    queryFn: () => base44.entities.PriceListItem.list("-created_date", 10000),
    initialData: [],
  });

  // Filter by tab
  let tabFilteredItems = allItems;
  if (activeTab === "company_sync") {
    tabFilteredItems = allItems.filter(item => item.source === "Custom" || !item.source);
  } else if (activeTab === "xactimate") {
    tabFilteredItems = allItems.filter(item => item.source === "Xactimate");
  } else if (activeTab === "symbility") {
    tabFilteredItems = allItems.filter(item => item.source === "Symbility");
  }

  // Apply additional filters
  const filteredItems = tabFilteredItems.filter(item => {
    const matchesSearch = 
      item.code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
    const matchesFavorites = !favoritesOnly || item.is_favorite;
    
    return matchesSearch && matchesCategory && matchesFavorites;
  });

  const displayedItems = filteredItems.slice(0, 100);

  const companySyncCount = allItems.filter(item => item.source === "Custom" || !item.source).length;
  const xactimateCount = allItems.filter(item => item.source === "Xactimate").length;
  const symbilityCount = allItems.filter(item => item.source === "Symbility").length;

  const categories = ["all", "Roofing", "Siding", "Windows", "Doors", "Interior", "Exterior", "HVAC", "Plumbing", "Electrical", "Other"];

  const getCategoryColor = (category) => {
    const colors = {
      'Roofing': 'bg-blue-100 text-blue-700',
      'Siding': 'bg-green-100 text-green-700',
      'Windows': 'bg-purple-100 text-purple-700',
      'Doors': 'bg-orange-100 text-orange-700',
      'Interior': 'bg-pink-100 text-pink-700',
      'Exterior': 'bg-teal-100 text-teal-700',
      'HVAC': 'bg-red-100 text-red-700',
      'Plumbing': 'bg-indigo-100 text-indigo-700',
      'Electrical': 'bg-yellow-100 text-yellow-700',
      'Other': 'bg-gray-100 text-gray-700'
    };
    return colors[category] || colors.Other;
  };

  const handleSelectItem = (item) => {
    onSelect({
      code: item.code,
      description: item.description,
      unit: item.unit || "EA",
      rate: item.price
    });
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Select Item from Price List</DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
          <TabsList className="w-full justify-start border-b rounded-none bg-transparent p-0 h-auto">
            <TabsTrigger value="all" className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600">
              All ({allItems.length})
            </TabsTrigger>
            <TabsTrigger value="company_sync" className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600">
              CompanySync ({companySyncCount})
            </TabsTrigger>
            <TabsTrigger value="xactimate" className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600">
              Xactimate ({xactimateCount})
            </TabsTrigger>
            <TabsTrigger value="symbility" className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600">
              Symbility ({symbilityCount})
            </TabsTrigger>
          </TabsList>

          <div className="p-4 space-y-4 flex-1 flex flex-col overflow-hidden">
            <div className="flex items-center gap-3 flex-wrap">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(cat => (
                    <SelectItem key={cat} value={cat}>
                      {cat === "all" ? "All Categories" : cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                variant={favoritesOnly ? "default" : "outline"}
                onClick={() => setFavoritesOnly(!favoritesOnly)}
                className="flex items-center gap-2"
              >
                <Star className="w-4 h-4" />
                Favorites Only
              </Button>

              <div className="relative flex-1 min-w-[300px]">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search items..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto border rounded-lg">
              <table className="w-full">
                <thead className="bg-gray-50 sticky top-0">
                  <tr className="border-b text-left text-sm text-gray-600">
                    <th className="p-3 font-medium">Code</th>
                    <th className="p-3 font-medium">Description</th>
                    <th className="p-3 font-medium">Source</th>
                    <th className="p-3 font-medium">Price</th>
                    <th className="p-3 font-medium">Unit</th>
                    <th className="p-3 font-medium">Category</th>
                    <th className="p-3 font-medium">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {displayedItems.map((item) => (
                    <tr 
                      key={item.id} 
                      className="border-b hover:bg-blue-50 cursor-pointer"
                      onClick={() => handleSelectItem(item)}
                    >
                      <td className="p-3">
                        <code className="text-sm font-mono font-semibold text-blue-600">
                          {item.code}
                        </code>
                      </td>
                      <td className="p-3">
                        <div className="text-sm text-gray-900">
                          {item.description}
                        </div>
                      </td>
                      <td className="p-3">
                        <Badge variant="outline" className="text-xs">
                          {item.source || "Custom"}
                        </Badge>
                      </td>
                      <td className="p-3 font-semibold text-green-600">
                        ${item.price?.toFixed(2)}
                      </td>
                      <td className="p-3 text-sm text-gray-600">
                        {item.unit || "EA"}
                      </td>
                      <td className="p-3">
                        <Badge className={`${getCategoryColor(item.category)} text-xs`}>
                          {item.category}
                        </Badge>
                      </td>
                      <td className="p-3">
                        <Button
                          size="sm"
                          onClick={() => handleSelectItem(item)}
                          className="bg-blue-600 hover:bg-blue-700"
                        >
                          Select
                        </Button>
                      </td>
                    </tr>
                  ))}
                  {displayedItems.length === 0 && (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-gray-500">
                        <p className="text-lg font-medium mb-2">No items found</p>
                        <p className="text-sm">Try adjusting your search or filters</p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {filteredItems.length > 100 && (
              <div className="text-sm text-gray-500 text-center">
                Showing first 100 of {filteredItems.length} items
              </div>
            )}
          </div>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}