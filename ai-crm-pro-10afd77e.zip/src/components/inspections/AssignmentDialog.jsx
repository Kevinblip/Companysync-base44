
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Send, CheckCircle, UserPlus } from 'lucide-react';
import { Alert, AlertDescription } from "@/components/ui/alert";
import GooglePlacesAutocomplete from '../common/GooglePlacesAutocomplete';
import { Checkbox } from '@/components/ui/checkbox';

const SectionTitle = ({ children }) => (
    <h3 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">{children}</h3>
);

export default function AssignmentDialog({ isOpen, onOpenChange, existingJob = null, onAssignmentSent }) {
    const [formData, setFormData] = useState({
        property_address: '',
        property_type: 'Residential',
        inspection_type: 'Property Damage Assessment',
        access_instructions: '',
        client_name: '',
        client_phone: '',
        client_email: '',
        assigned_to_email: '',
        priority: 'Normal',
        scheduled_date: '',
        inspection_time: '',
        damage_type: '',
        date_of_loss: '',
        insurance_claim_number: '',
        special_instructions: '',
        notes: '',
        status: 'assigned',
        lead_source: 'direct_call',
    });

    const [googleMapsApiKey, setGoogleMapsApiKey] = useState('');
    const [createLead, setCreateLead] = useState(true);
    const [createCalendarEvent, setCreateCalendarEvent] = useState(true);

    useEffect(() => {
        const fetchSecrets = async () => {
            try {
                const response = await base44.functions.invoke('getGoogleMapsApiKey');
                if (response.data && response.data.apiKey) {
                    setGoogleMapsApiKey(response.data.apiKey);
                }
            } catch (error) {
                console.error("Could not fetch Google Maps API Key:", error);
            }
        };
        fetchSecrets();
    }, []);

    useEffect(() => {
        if (existingJob) {
            setFormData({
                property_address: existingJob.property_address || '',
                property_type: existingJob.property_type || 'Residential',
                inspection_type: existingJob.inspection_type || 'Property Damage Assessment',
                access_instructions: existingJob.access_instructions || '',
                client_name: existingJob.client_name || '',
                client_phone: existingJob.client_phone || '',
                client_email: existingJob.client_email || '',
                assigned_to_email: existingJob.assigned_to_email || '',
                priority: existingJob.priority || 'Normal',
                scheduled_date: existingJob.scheduled_date || '',
                inspection_time: existingJob.inspection_time || '',
                damage_type: existingJob.damage_type || '',
                date_of_loss: existingJob.date_of_loss || '',
                insurance_claim_number: existingJob.insurance_claim_number || '',
                special_instructions: existingJob.special_instructions || '',
                notes: existingJob.notes || '',
                status: existingJob.status || 'assigned',
                lead_source: existingJob.lead_source || 'direct_call',
            });
        } else {
            setFormData({
                property_address: '',
                property_type: 'Residential',
                inspection_type: 'Property Damage Assessment',
                access_instructions: '',
                client_name: '',
                client_phone: '',
                client_email: '',
                assigned_to_email: '',
                priority: 'Normal',
                scheduled_date: '',
                inspection_time: '',
                damage_type: '',
                date_of_loss: '',
                insurance_claim_number: '',
                special_instructions: '',
                notes: '',
                status: 'assigned',
                lead_source: 'direct_call',
            });
        }
    }, [existingJob, isOpen]);

    const { data: users = [] } = useQuery({
        queryKey: ['staffUsers'],
        queryFn: () => base44.entities.User.list(),
    });

    const { data: myCompany } = useQuery({
        queryKey: ['myCompany'],
        queryFn: async () => {
            const user = await base44.auth.me();
            const companies = await base44.entities.Company.filter({ created_by: user.email });
            return companies[0] || null;
        },
        staleTime: Infinity,
    });

    const createJobMutation = useMutation({
        mutationFn: async (newJobData) => {
            let job;
            let leadId = null;
            let calendarEventId = null;

            try {
                // Step 1: Create or update the inspection job
                if (existingJob) {
                    job = await base44.entities.InspectionJob.update(existingJob.id, newJobData);
                } else {
                    job = await base44.entities.InspectionJob.create(newJobData);
                }

                // Step 2: Create Lead if checked
                if (createLead && !existingJob) {
                    try {
                        const user = await base44.auth.me();
                        let companyId = myCompany?.id;

                        // If no company from query, fetch it more robustly
                        if (!companyId) {
                            const staffProfiles = await base44.entities.StaffProfile.filter({ user_email: user.email });
                            if (staffProfiles && staffProfiles.length > 0) {
                                companyId = staffProfiles[0].company_id;
                            } else {
                                const companies = await base44.entities.Company.filter({ created_by: user.email });
                                if (companies && companies.length > 0) {
                                    companyId = companies[0].id;
                                }
                            }
                        }

                        if (companyId) {
                            const addressParts = newJobData.property_address.split(',').map(s => s.trim());
                            const street = addressParts[0] || '';
                            const city = addressParts[1] || '';
                            const stateZip = addressParts[2] || '';
                            const [state, zip] = stateZip.split(' ').filter(Boolean);

                            const lead = await base44.entities.Lead.create({
                                company_id: companyId,
                                name: newJobData.client_name,
                                email: newJobData.client_email || '',
                                phone: newJobData.client_phone || '',
                                street: street || newJobData.property_address,
                                city: city || '',
                                state: state || '',
                                zip: zip || '',
                                status: 'new',
                                source: newJobData.lead_source || 'other',
                                lead_source: `Inspection: ${newJobData.inspection_type}`,
                                notes: `Inspection scheduled for ${newJobData.scheduled_date || 'TBD'}.\nDamage Type: ${newJobData.damage_type || 'TBD'}\nPriority: ${newJobData.priority}`,
                                value: 0,
                                is_active: true,
                            });
                            leadId = lead.id;

                            // Link lead to job
                            await base44.entities.InspectionJob.update(job.id, {
                                related_lead_id: leadId
                            });
                        } else {
                            console.warn('Could not create lead: No company found for user.');
                        }
                    } catch (leadError) {
                        console.error('Failed to create lead (non-critical):', leadError);
                        // Don't fail the whole operation if lead creation fails
                    }
                }

                // Step 3: Create Calendar Event if checked
                if (createCalendarEvent && newJobData.scheduled_date && newJobData.inspection_time) {
                    try {
                        const [hours, minutes] = newJobData.inspection_time.split(':');
                        const startDate = new Date(newJobData.scheduled_date);
                        startDate.setHours(parseInt(hours), parseInt(minutes), 0, 0); // Set seconds and milliseconds to 0
                        
                        const endDate = new Date(startDate);
                        endDate.setHours(startDate.getHours() + 2); // 2 hour inspection

                        const calendarEvent = await base44.entities.CalendarEvent.create({
                            title: `Inspection: ${newJobData.client_name}`,
                            description: `📍 ${newJobData.property_address}\n\n👤 Client: ${newJobData.client_name}\n📞 ${newJobData.client_phone}\n\n🔍 Damage: ${newJobData.damage_type || 'Assessment'}\n⚡ Priority: ${newJobData.priority}\n\n${newJobData.special_instructions ? '📝 Special Instructions:\n' + newJobData.special_instructions : ''}`,
                            start_time: startDate.toISOString(),
                            end_time: endDate.toISOString(),
                            event_type: 'inspection',
                            assigned_to: newJobData.assigned_to_email,
                            related_customer: newJobData.client_name,
                            status: 'scheduled',
                            color: '#10b981',
                            send_email_notification: true,
                            send_sms_notification: false,
                        });
                        calendarEventId = calendarEvent.id;

                        // Link calendar event to job
                        await base44.entities.InspectionJob.update(job.id, {
                            calendar_event_id: calendarEventId
                        });
                    } catch (calendarError) {
                        console.error('Failed to create calendar event (non-critical):', calendarError);
                        // Don't fail the whole operation if calendar creation fails
                    }
                }

                // Step 4: Send assignment email
                try {
                    await base44.functions.invoke('sendInspectionAssignment', {
                        jobId: job.id,
                        inspectorEmail: newJobData.assigned_to_email
                    });
                } catch (emailError) {
                    console.error('Failed to send assignment email (non-critical):', emailError);
                }

                return { job, leadId, calendarEventId };
            } catch (error) {
                console.error('Error creating inspection job:', error);
                throw error; // Re-throw to be caught by onError
            }
        },
        onSuccess: (data) => {
            const messages = ['✅ Inspection assigned successfully!'];
            if (data.leadId) messages.push('✅ Lead created in CRM');
            if (data.calendarEventId) messages.push('✅ Added to calendar');
            alert(messages.join('\n'));
            onAssignmentSent(data.job);
        },
        onError: (error) => {
            console.error('Assignment error:', error);
            alert('❌ Failed to create assignment: ' + (error.message || 'Unknown error'));
        }
    });

    const handleSubmit = (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (!formData.assigned_to_email) {
            alert('Please select an inspector to assign.');
            return;
        }
        createJobMutation.mutate(formData);
    };

    const handleInputChange = (e) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
    };

    const handleSelectChange = (id, value) => {
        setFormData(prev => ({...prev, [id]: value}));
    };
    
    const handlePlaceSelected = (address) => {
        setFormData(prev => ({ ...prev, property_address: address }));
    };

    const handleInteractOutside = (e) => {
        const target = e.target;
        if (target.closest('.pac-container')) {
            e.preventDefault();
        }
    };

    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange} modal={true}>
            <DialogContent 
                className="max-w-3xl max-h-[90vh] flex flex-col"
                onInteractOutside={handleInteractOutside}
            >
                <DialogHeader>
                    <DialogTitle>{existingJob ? 'Edit' : 'Send'} Inspector Assignment</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-6 overflow-y-auto px-1">
                    <div>
                        <SectionTitle>Site Information</SectionTitle>
                        <div className="space-y-4">
                            <div className="grid grid-cols-1 gap-4">
                                <div>
                                    <Label htmlFor="property_address">Site Address *</Label>
                                    {googleMapsApiKey ? (
                                        <>
                                            <GooglePlacesAutocomplete
                                                apiKey={googleMapsApiKey}
                                                value={formData.property_address}
                                                onPlaceSelected={handlePlaceSelected}
                                                onChange={(e) => {
                                                    setFormData({...formData, property_address: e.target.value});
                                                }}
                                            />
                                            <Alert className="mt-2 border-green-300 bg-green-50 text-green-800">
                                                <CheckCircle className="h-4 w-4 text-green-600" />
                                                <AlertDescription>
                                                    Google Places API Status: Production Ready
                                                </AlertDescription>
                                            </Alert>
                                        </>
                                    ) : (
                                        <Input 
                                            id="property_address" 
                                            placeholder="Enter the inspection site address..." 
                                            value={formData.property_address} 
                                            onChange={handleInputChange} 
                                            required 
                                        />
                                    )}
                                </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <Label htmlFor="property_type">Property Type</Label>
                                    <Select value={formData.property_type} onValueChange={(v) => handleSelectChange('property_type', v)}>
                                        <SelectTrigger><SelectValue /></SelectTrigger>
                                        <SelectContent>
                                            <SelectItem value="Residential">Residential</SelectItem>
                                            <SelectItem value="Commercial">Commercial</SelectItem>
                                            <SelectItem value="Multi-Family">Multi-Family</SelectItem>
                                            <SelectItem value="Industrial">Industrial</SelectItem>
                                            <SelectItem value="Other">Other</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div>
                                    <Label htmlFor="inspection_type">Inspection Type *</Label>
                                    <Input id="inspection_type" value={formData.inspection_type} onChange={handleInputChange} required />
                                </div>
                            </div>
                             <div>
                                <Label htmlFor="access_instructions">Access Instructions</Label>
                                <Textarea id="access_instructions" placeholder="Gate codes, key location, contact for access, parking instructions..." value={formData.access_instructions} onChange={handleInputChange} />
                            </div>
                        </div>
                    </div>

                    <div>
                        <SectionTitle>Property Contact Information</SectionTitle>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <Label htmlFor="client_name">Contact Name *</Label>
                                <Input id="client_name" placeholder="Property owner/manager name" value={formData.client_name} onChange={handleInputChange} required />
                            </div>
                            <div>
                                <Label htmlFor="client_phone">Contact Phone *</Label>
                                <Input id="client_phone" type="tel" placeholder="(555) 123-4567" value={formData.client_phone} onChange={handleInputChange} required />
                            </div>
                            <div>
                                <Label htmlFor="client_email">Contact Email</Label>
                                <Input id="client_email" type="email" placeholder="contact@example.com" value={formData.client_email} onChange={handleInputChange} />
                            </div>
                        </div>
                    </div>

                    <div>
                        <SectionTitle>Inspector Assignment</SectionTitle>
                        <Label htmlFor="assigned_to_email">Select Vetted Inspector</Label>
                        <Select value={formData.assigned_to_email} onValueChange={(v) => handleSelectChange('assigned_to_email', v)}>
                            <SelectTrigger><SelectValue placeholder="Choose an inspector..." /></SelectTrigger>
                            <SelectContent>
                                {users.map(user => <SelectItem key={user.id} value={user.email}>{user.full_name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>

                     <div>
                        <SectionTitle>Assignment Details</SectionTitle>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <Label htmlFor="priority">Priority Level</Label>
                                <Select value={formData.priority} onValueChange={(v) => handleSelectChange('priority', v)}>
                                    <SelectTrigger><SelectValue/></SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="Low">Low</SelectItem>
                                        <SelectItem value="Normal">Normal</SelectItem>
                                        <SelectItem value="High">High</SelectItem>
                                        <SelectItem value="Urgent">Urgent</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                             <div>
                                <Label htmlFor="scheduled_date">Scheduled Date</Label>
                                <Input id="scheduled_date" type="date" value={formData.scheduled_date} onChange={handleInputChange} />
                            </div>
                            <div>
                                <Label htmlFor="inspection_time">Inspection Time</Label>
                                <Input id="inspection_time" type="time" value={formData.inspection_time} onChange={handleInputChange} />
                            </div>
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
                            <div>
                                <Label htmlFor="damage_type">Damage Type</Label>
                                <Input id="damage_type" placeholder="Wind, Hail, Water, Fire, etc." value={formData.damage_type} onChange={handleInputChange} />
                            </div>
                            <div>
                                <Label htmlFor="date_of_loss">Date of Loss</Label>
                                <Input id="date_of_loss" type="date" value={formData.date_of_loss} onChange={handleInputChange} />
                            </div>
                             <div>
                                <Label htmlFor="insurance_claim_number">Insurance Claim Number</Label>
                                <Input id="insurance_claim_number" placeholder="Claim reference number" value={formData.insurance_claim_number} onChange={handleInputChange} />
                            </div>
                        </div>
                        <div className="mt-4">
                            <Label htmlFor="lead_source">Lead Source</Label>
                            <Select value={formData.lead_source} onValueChange={(v) => handleSelectChange('lead_source', v)}>
                                <SelectTrigger><SelectValue /></SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="website">Website</SelectItem>
                                    <SelectItem value="referral">Referral</SelectItem>
                                    <SelectItem value="social_media">Social Media</SelectItem>
                                    <SelectItem value="storm_tracker">Storm Tracker</SelectItem>
                                    <SelectItem value="property_importer">Property Importer</SelectItem>
                                    <SelectItem value="direct_call">Direct Call</SelectItem>
                                    <SelectItem value="walk_in">Walk-in</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                        <div className="mt-4">
                            <Label htmlFor="special_instructions">Special Instructions</Label>
                            <Textarea id="special_instructions" placeholder="Specific areas to focus on, safety concerns, equipment needed..." value={formData.special_instructions} onChange={handleInputChange} />
                        </div>
                    </div>
                    
                     <div>
                        <SectionTitle>Additional Notes</SectionTitle>
                         <Textarea id="notes" placeholder="Any additional information, context, or requirements for this inspection..." value={formData.notes} onChange={handleInputChange} />
                    </div>

                    {!existingJob && (
                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                            <h4 className="font-semibold text-blue-900 mb-3 flex items-center gap-2">
                                <UserPlus className="w-5 h-5" />
                                CRM Integration
                            </h4>
                            <div className="space-y-3">
                                <div className="flex items-center space-x-2">
                                    <Checkbox 
                                        id="createLead" 
                                        checked={createLead}
                                        onCheckedChange={setCreateLead}
                                    />
                                    <label
                                        htmlFor="createLead"
                                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                    >
                                        Create Lead in CRM (recommended)
                                    </label>
                                </div>
                                <div className="flex items-center space-x-2">
                                    <Checkbox 
                                        id="createCalendarEvent" 
                                        checked={createCalendarEvent}
                                        onCheckedChange={setCreateCalendarEvent}
                                        disabled={!formData.scheduled_date || !formData.inspection_time}
                                    />
                                    <label
                                        htmlFor="createCalendarEvent"
                                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                    >
                                        Add to Calendar (prevents double-booking)
                                    </label>
                                </div>
                                {(!formData.scheduled_date || !formData.inspection_time) && (
                                    <p className="text-xs text-gray-500 ml-6">⚠️ Add date & time to enable calendar sync</p>
                                )}
                            </div>
                        </div>
                    )}

                </form>
                <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button type="button" onClick={handleSubmit} disabled={createJobMutation.isLoading}>
                        {createJobMutation.isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                        {existingJob ? 'Update' : 'Send'} Assignment
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}
