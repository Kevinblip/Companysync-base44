
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Phone, Delete, PhoneCall, X, CheckCircle, Loader2, PhoneOff, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function Dialer({ open, onOpenChange, defaultNumber, defaultName }) {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [contactName, setContactName] = useState("");
  const [calling, setCalling] = useState(false);
  const [callStatus, setCallStatus] = useState(""); // For showing status messages
  const [showNotes, setShowNotes] = useState(false);
  const [callNotes, setCallNotes] = useState("");
  const [duration, setDuration] = useState(0);
  const [user, setUser] = useState(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: twilioConfig } = useQuery({
    queryKey: ['twilio-settings', user?.email],
    queryFn: async () => {
      if (!user) return null;
      let companyId = null;

      // First, check if user is a staff member
      const staffProfiles = await base44.entities.StaffProfile.filter({ user_email: user.email });
      if (staffProfiles && staffProfiles.length > 0) {
        companyId = staffProfiles[0].company_id;
      } else {
        // If not a staff member, check if they are a company owner
        const companies = await base44.entities.Company.filter({ created_by: user.email });
        if (companies && companies.length > 0) {
          companyId = companies[0].id;
        }
      }

      if (!companyId) {
        console.error("Could not determine company for user:", user.email);
        return null;
      }
      
      const settings = await base44.entities.TwilioSettings.filter({ company_id: companyId });
      return settings[0] || null;
    },
    enabled: !!user,
  });

  const companyId = twilioConfig?.company_id;

  useEffect(() => {
    if (defaultNumber && open) {
      setPhoneNumber(defaultNumber.replace(/\D/g, ''));
    }
    if (defaultName && open) {
      setContactName(defaultName);
    }
  }, [defaultNumber, defaultName, open]);

  const makeCallMutation = useMutation({
    mutationFn: async (data) => {
      const response = await base44.functions.invoke('makeCall', data);
      return response.data;
    },
    onSuccess: (data) => {
      setCalling(false);
      setCallStatus(data.message || 'Call initiated successfully');

      // Show call notes dialog after a delay
      setTimeout(() => {
        setShowNotes(true);
        setCallStatus("");
      }, 3000);
    },
    onError: (error) => {
      setCalling(false);
      setCallStatus('');
      const errorMessage = error.response?.data?.error || error.message;
      alert('Failed to make call: ' + errorMessage);
    }
  });

  const logCallMutation = useMutation({
    mutationFn: (data) => base44.entities.Communication.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['communications'] });
      setShowNotes(false);
      setCallNotes("");
      setDuration(0);
      setPhoneNumber("");
      setContactName("");
      setCallStatus("");
      onOpenChange(false);
    },
  });

  const handleNumberClick = (num) => {
    setPhoneNumber(prev => (prev + num).slice(0, 15)); // Limit length
  };

  const handleBackspace = () => {
    setPhoneNumber(prev => prev.slice(0, -1));
  };

  const handleCall = () => {
    if (phoneNumber.length >= 10 && companyId) {
      setCalling(true);
      setCallStatus("Initiating call...");

      // Format phone number to E.164 with +1 prefix for US numbers
      let formattedNumber = phoneNumber.replace(/\D/g, '');

      // If it's a 10-digit number, add +1 prefix (US)
      if (formattedNumber.length === 10) {
        formattedNumber = '+1' + formattedNumber;
      } else if (formattedNumber.length === 11 && formattedNumber.startsWith('1')) {
        // If it's 11 digits starting with 1, just add +
        formattedNumber = '+' + formattedNumber;
      } else if (!formattedNumber.startsWith('+')) {
        // Otherwise, add + prefix
        formattedNumber = '+' + formattedNumber;
      }

      makeCallMutation.mutate({
        to: formattedNumber,
        contactName: contactName || 'Unknown',
        companyId: companyId
      });
    } else if (!companyId) {
      alert("Please set up your company profile and Twilio settings first!");
    } else if (phoneNumber.length < 10) {
      alert("Please enter a valid phone number (at least 10 digits).");
    }
  };

  const handleSaveNotes = () => {
    if (!companyId) {
      alert("Please set up your company profile and Twilio settings first");
      return;
    }

    logCallMutation.mutate({
      company_id: companyId,
      contact_name: contactName || "Unknown",
      contact_phone: formatPhoneNumber(phoneNumber),
      communication_type: "call",
      direction: "outbound",
      subject: "Outbound Call",
      message: callNotes || "Call completed",
      duration_minutes: duration,
      status: "completed",
      outcome: "successful"
    });
  };

  const formatPhoneNumber = (value) => {
    const cleaned = value.replace(/\D/g, '');

    // If it's a 10-digit number, format as (555) 123-4567
    if (cleaned.length === 10) {
      const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
      if (match) {
        return `(${match[1]}) ${match[2]}-${match[3]}`;
      }
    }

    // If it's 11 digits starting with 1, format as +1 (555) 123-4567
    if (cleaned.length === 11 && cleaned.startsWith('1')) {
      const match = cleaned.match(/^1(\d{3})(\d{3})(\d{4})$/);
      if (match) {
        return `+1 (${match[1]}) ${match[2]}-${match[3]}`;
      }
    }

    return value;
  };

  const handleInputChange = (e) => {
    const sanitized = e.target.value.replace(/\D/g, ''); // Remove all non-digits
    setPhoneNumber(sanitized.slice(0, 15)); // Limit length to 15 digits
  };

  const displayPhoneNumber = () => {
    const cleaned = phoneNumber.replace(/\D/g, '');

    if (cleaned.length === 0) return '';
    if (cleaned.length <= 3) return cleaned;
    if (cleaned.length <= 6) return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3)}`;
    if (cleaned.length <= 10) return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;

    // For numbers longer than 10 digits, specifically format assuming a +1 country code if the number starts with '1' and is 11 digits, or just follow the outline's slice logic.
    // This assumes `cleaned` will have the '1' as its first digit if it's an 11-digit US number.
    return `+1 (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7, 11)}`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Phone className="w-5 h-5 text-green-600" />
            {showNotes ? "Call Notes" : "Click-to-Call"}
          </DialogTitle>
        </DialogHeader>

        {!showNotes ? (
          <div className="space-y-6">
            {callStatus && (
              <Alert className="bg-blue-50 border-blue-200">
                <Phone className="w-4 h-4 text-blue-600" />
                <AlertDescription className="text-blue-900">
                  {callStatus}
                </AlertDescription>
              </Alert>
            )}

            {defaultName && (
              <div className="text-center p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600">Calling</p>
                <p className="font-semibold text-lg">{defaultName}</p>
              </div>
            )}

            <Alert className="bg-yellow-50 border-yellow-200">
              <Phone className="w-4 h-4 text-yellow-600" />
              <AlertDescription className="text-yellow-900 text-sm">
                📞 <strong>How it works:</strong>
                <ol className="mt-2 ml-4 space-y-1 text-xs">
                  <li>1. Your phone will ring</li>
                  <li>2. Answer the call</li>
                  <li>3. System dials {contactName || 'the contact'}</li>
                  <li>4. Direct conversation - No AI!</li>
                </ol>
              </AlertDescription>
            </Alert>

            <div className="relative">
              <Input
                value={displayPhoneNumber()}
                onChange={handleInputChange} // Enable keyboard input
                className="text-2xl text-center font-semibold h-14 pr-10"
                placeholder="(555) 123-4567" // Updated placeholder
              />
              {phoneNumber && (
                <button
                  onClick={handleBackspace}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <Delete className="w-5 h-5" />
                </button>
              )}
            </div>

            <div className="grid grid-cols-3 gap-3">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((num) => (
                <Button
                  key={num}
                  variant="outline"
                  className="h-16 text-2xl font-semibold hover:bg-green-50"
                  onClick={() => handleNumberClick(num)}
                  disabled={calling}
                >
                  {num}
                </Button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setPhoneNumber("");
                  setContactName("");
                  setCallStatus("");
                  onOpenChange(false);
                }}
                className="h-12"
                disabled={calling}
              >
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button
                onClick={handleCall}
                disabled={phoneNumber.length < 10 || calling || !companyId}
                className="h-12 bg-green-600 hover:bg-green-700 text-white"
              >
                {calling ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Calling...
                  </>
                ) : (
                  <>
                    <PhoneCall className="w-4 h-4 mr-2" />
                    Call Now
                  </>
                )}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg text-center">
              <CheckCircle className="w-12 h-12 mx-auto text-green-600 mb-2" />
              <p className="font-semibold">Call Completed</p>
              <p className="text-sm text-gray-600">How did it go? Add notes below.</p>
            </div>

            <div>
              <Label>Contact Name</Label>
              <Input
                value={contactName}
                onChange={(e) => setContactName(e.target.value)}
                placeholder="Enter contact name"
              />
            </div>

            <div>
              <Label>Call Duration (minutes)</Label>
              <Input
                type="number"
                value={duration}
                onChange={(e) => setDuration(parseInt(e.target.value) || 0)}
                placeholder="0"
              />
            </div>

            <div>
              <Label>Call Notes</Label>
              <Textarea
                value={callNotes}
                onChange={(e) => setCallNotes(e.target.value)}
                placeholder="What did you discuss? Any follow-ups needed?"
                rows={4}
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowNotes(false);
                  setPhoneNumber("");
                  setContactName("");
                  setCallNotes("");
                  setCallStatus("");
                  onOpenChange(false);
                }}
              >
                Skip
              </Button>
              <Button
                onClick={handleSaveNotes}
                className="bg-green-600 hover:bg-green-700"
                disabled={logCallMutation.isLoading}
              >
                {logCallMutation.isLoading ? 'Saving...' : 'Save Notes'}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
