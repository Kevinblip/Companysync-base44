
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, CheckCircle, FileSignature, Eye, X } from "lucide-react";

export default function SignContractCustomer() {
  const [signingToken, setSigningToken] = useState(null);
  const [formValues, setFormValues] = useState({});
  const [signatureData, setSignatureData] = useState(null);
  const [completed, setCompleted] = useState(false);
  const [showPdfPreview, setShowPdfPreview] = useState(false);
  const canvasRef = React.useRef(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setSigningToken(params.get('token'));
  }, []);

  const { data: sessions = [] } = useQuery({
    queryKey: ['signing-session-by-token', signingToken],
    queryFn: () => base44.asServiceRole.entities.ContractSigningSession.filter({ signing_token: signingToken }),
    enabled: !!signingToken,
  });

  const session = sessions[0];

  const { data: template } = useQuery({
    queryKey: ['contract-template', session?.template_id],
    queryFn: () => base44.asServiceRole.entities.ContractTemplate.get(session.template_id),
    enabled: !!session?.template_id,
  });

  const signMutation = useMutation({
    mutationFn: async ({ fields, signature }) => {
      await base44.asServiceRole.entities.ContractSigningSession.update(session.id, {
        customer_fields: fields,
        customer_signature_url: signature,
        customer_signed_at: new Date().toISOString(),
        status: 'customer_signed'
      });

      await base44.functions.invoke('generateSignedPDF', {
        sessionId: session.id
      });
    },
    onSuccess: () => {
      setCompleted(true);
    },
  });

  // Signature canvas setup - FIXED
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.width = canvas.offsetWidth;
    canvas.height = 150;

    const ctx = canvas.getContext('2d');
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    let isDrawing = false;
    let lastX = 0;
    let lastY = 0;

    const getPos = (e) => {
      const rect = canvas.getBoundingClientRect();
      if (e.touches && e.touches[0]) {
        return {
          x: e.touches[0].clientX - rect.left,
          y: e.touches[0].clientY - rect.top
        };
      }
      return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      };
    };

    const startDrawing = (e) => {
      e.preventDefault();
      isDrawing = true;
      const pos = getPos(e);
      lastX = pos.x;
      lastY = pos.y;
    };

    const draw = (e) => {
      if (!isDrawing) return;
      e.preventDefault();
      
      const pos = getPos(e);
      ctx.beginPath();
      ctx.moveTo(lastX, lastY);
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
      
      lastX = pos.x;
      lastY = pos.y;
    };

    const stopDrawing = () => {
      if (isDrawing) {
        isDrawing = false;
        setSignatureData(canvas.toDataURL());
      }
    };

    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseleave', stopDrawing);
    canvas.addEventListener('touchstart', startDrawing, { passive: false });
    canvas.addEventListener('touchmove', draw, { passive: false });
    canvas.addEventListener('touchend', stopDrawing);

    return () => {
      canvas.removeEventListener('mousedown', startDrawing);
      canvas.removeEventListener('mousemove', draw);
      canvas.removeEventListener('mouseup', stopDrawing);
      canvas.removeEventListener('mouseleave', stopDrawing);
      canvas.removeEventListener('touchstart', startDrawing);
      canvas.removeEventListener('touchmove', draw);
      canvas.removeEventListener('touchend', stopDrawing);
    };
  }, []);

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureData(null);
  };

  const handleSign = async () => {
    const customerFields = template.fillable_fields.filter(f => f.filled_by === 'customer');
    const missingRequired = customerFields.filter(f => f.required && !formValues[f.field_name]);

    if (missingRequired.length > 0) {
      alert(`Please fill in required fields: ${missingRequired.map(f => f.field_label).join(', ')}`);
      return;
    }

    if (!signatureData) {
      alert('Please sign the document first');
      return;
    }

    try {
      await signMutation.mutateAsync({
        fields: formValues,
        signature: signatureData
      });
    } catch (error) {
      alert('Error: ' + error.message);
    }
  };

  if (completed) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-green-100 flex items-center justify-center p-6">
        <Card className="max-w-lg text-center">
          <CardContent className="p-12">
            <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Contract Signed!</h2>
            <p className="text-gray-600 mb-4">
              Thank you for signing. You'll receive a copy of the signed contract via email shortly.
            </p>
            <Badge className="bg-green-100 text-green-700">
              Completed
            </Badge>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!session || !template) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  const customerFields = template.fillable_fields?.filter(f => f.filled_by === 'customer') || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 text-center">
          <h1 className="text-3xl font-bold text-gray-900">Contract Signature Request</h1>
          <p className="text-gray-500 mt-1">From: {session.rep_name}</p>
          <Badge className="mt-2 bg-blue-100 text-blue-700">
            {template.template_name}
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Form Side */}
          <Card>
            <CardHeader>
              <CardTitle>Fill Your Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Alert className="bg-blue-50 border-blue-200">
                <AlertDescription>
                  <strong>Customer:</strong> {session.customer_name}
                  <br />
                  {session.delivery_method === 'email' && <>📧 {session.customer_email}</>}
                  {session.delivery_method === 'sms' && <>📱 {session.customer_phone}</>}
                </AlertDescription>
              </Alert>

              {customerFields.map((field) => {
                if (field.field_type === 'signature') return null;

                return (
                  <div key={field.field_name}>
                    <Label htmlFor={field.field_name}>
                      {field.field_label}
                      {field.required && <span className="text-red-500"> *</span>}
                    </Label>
                    {field.field_type === 'date' ? (
                      <Input
                        id={field.field_name}
                        type="date"
                        value={formValues[field.field_name] || ''}
                        onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                        required={field.required}
                      />
                    ) : field.field_type === 'email' ? (
                      <Input
                        id={field.field_name}
                        type="email"
                        value={formValues[field.field_name] || ''}
                        onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                        placeholder={field.placeholder}
                        required={field.required}
                      />
                    ) : field.field_type === 'phone' ? (
                      <Input
                        id={field.field_name}
                        type="tel"
                        value={formValues[field.field_name] || ''}
                        onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                        placeholder={field.placeholder || "(XXX) XXX-XXXX"}
                        required={field.required}
                      />
                    ) : (
                      <Input
                        id={field.field_name}
                        type="text"
                        value={formValues[field.field_name] || ''}
                        onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                        placeholder={field.placeholder}
                        required={field.required}
                      />
                    )}
                  </div>
                );
              })}

              {/* Customer Signature - WITH GRAY BACKGROUND */}
              <div>
                <Label className="text-base font-semibold">Your Signature *</Label>
                <p className="text-sm text-gray-500 mb-2">Sign using your mouse or finger</p>
                <div className="border-2 border-gray-300 rounded-lg bg-gray-50 p-2">
                  <canvas
                    ref={canvasRef}
                    className="w-full touch-none bg-white rounded border border-gray-200"
                    style={{ height: '150px' }}
                  />
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={clearSignature}
                  className="mt-2"
                >
                  Clear Signature
                </Button>
                {signatureData && (
                  <div className="mt-2 flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle className="w-4 h-4" />
                    Signature captured
                  </div>
                )}
              </div>

              <Button
                onClick={handleSign}
                disabled={signMutation.isLoading || !signatureData}
                className="w-full bg-green-600 hover:bg-green-700"
              >
                {signMutation.isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Signing...
                  </>
                ) : (
                  <>
                    <FileSignature className="w-4 h-4 mr-2" />
                    Sign Contract
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* PDF Preview Side */}
          <div className="sticky top-6">
            <Card className="h-[800px]">
              <CardHeader className="border-b bg-gray-50">
                <div className="flex items-center justify-between">
                  <CardTitle>Contract Preview</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowPdfPreview(true)}
                    className="text-blue-600 hover:text-blue-700"
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    Full Screen
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-0 h-[720px]">
                <iframe
                  src={`https://docs.google.com/viewer?url=${encodeURIComponent(template.original_file_url)}&embedded=true`}
                  className="w-full h-full border-0"
                  title="Contract Preview"
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Full Screen PDF Preview Modal */}
      {showPdfPreview && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-6xl h-[95vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b bg-gray-50">
              <h2 className="text-xl font-bold">Contract Preview</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowPdfPreview(false)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <div className="flex-1 overflow-hidden">
              <iframe
                src={`https://docs.google.com/viewer?url=${encodeURIComponent(template.original_file_url)}&embedded=true`}
                className="w-full h-full border-0"
                title="Contract Full Preview"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
