import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Camera, Users, FileText, Settings, Video, Loader2, Eye, Send, Trash2 } from 'lucide-react';
import AssignmentDialog from '../components/inspections/AssignmentDialog';

const StatCard = ({ title, value, icon: Icon, linkTo, linkText }) => (
  <Card className="hover:shadow-lg transition-shadow">
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <Icon className="h-4 w-4 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      {linkTo ? (
        <Button asChild variant="link" className="p-0 h-auto text-2xl font-bold">
            <Link to={linkTo}>{value}</Link>
        </Button>
      ) : (
        <div className="text-2xl font-bold">{value}</div>
      )}
      {linkText && <p className="text-xs text-muted-foreground">{linkText}</p>}
    </CardContent>
  </Card>
);

const ActionCard = ({ title, description, icon: Icon, linkTo }) => {
    const navigate = useNavigate();
    return (
        <Card onClick={() => navigate(linkTo)} className="cursor-pointer hover:bg-gray-50 transition-colors flex flex-col items-center justify-center text-center p-6">
            <Icon className="w-8 h-8 text-blue-600 mb-2" />
            <h3 className="font-semibold">{title}</h3>
            <p className="text-sm text-gray-500">{description}</p>
        </Card>
    );
};

export default function InspectionsDashboard() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isAssignmentDialogOpen, setIsAssignmentDialogOpen] = useState(false);
  const [editingJob, setEditingJob] = useState(null);

  const { data: jobs = [], isLoading: isLoadingJobs } = useQuery({
    queryKey: ['inspectionJobs'],
    queryFn: () => base44.entities.InspectionJob.list('-created_date', 100),
    initialData: [],
  });

  const { data: media = [], isLoading: isLoadingMedia } = useQuery({
    queryKey: ['inspectionMedia'],
    queryFn: () => base44.entities.JobMedia.filter({ related_entity_type: 'InspectionJob' }, '-created_date', 5000),
    initialData: [],
  });

  const deleteJobMutation = useMutation({
    mutationFn: (jobId) => base44.entities.InspectionJob.delete(jobId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['inspectionJobs'] });
    },
  });

  const completedJobs = jobs.filter(j => j.status === 'completed').length;
  const totalPhotos = media.filter(m => m.file_type === 'photo').length;
  const totalVideos = media.filter(m => m.file_type === 'video').length;

  const recentJobs = jobs.slice(0, 5);

  const handleAssign = (job) => {
    setEditingJob(job);
    setIsAssignmentDialogOpen(true);
  };

  const handleDelete = (job) => {
    if (window.confirm(`Delete inspection for ${job.property_address}?`)) {
      deleteJobMutation.mutate(job.id);
    }
  };

  return (
    <div className="p-2 md:p-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-gray-800">Inspections Dashboard</h1>
            <Button asChild>
                <Link to={createPageUrl('InspectionCapture')}>
                    <Plus className="mr-2 h-4 w-4" /> Start Blank Inspection
                </Link>
            </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <ActionCard title="New Inspection Job" description="Create and assign a new job" icon={Plus} linkTo={createPageUrl('NewInspection')} />
            <ActionCard title="Manage Inspectors" description="Manage your certified team" icon={Users} linkTo={createPageUrl('Inspectors')} />
            <ActionCard title="View AI Reports" description="See AI-analyzed damage reports" icon={FileText} linkTo={createPageUrl('DroneInspections')} />
            <ActionCard title="Inspection Settings" description="Configure inspection details" icon={Settings} linkTo={createPageUrl('Settings')} />
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard title="Total Jobs" value={isLoadingJobs ? <Loader2 className="animate-spin" /> : jobs.length} icon={FileText} />
          <StatCard title="Completed" value={isLoadingJobs ? <Loader2 className="animate-spin" /> : completedJobs} icon={FileText} />
          <StatCard title="Total Photos" value={isLoadingMedia ? <Loader2 className="animate-spin" /> : totalPhotos} icon={Camera} />
          <StatCard title="Total Videos" value={isLoadingMedia ? <Loader2 className="animate-spin" /> : totalVideos} icon={Video} />
        </div>

        <Card>
            <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Recent Inspection Jobs</CardTitle>
                <Button onClick={() => { setEditingJob(null); setIsAssignmentDialogOpen(true); }} className="bg-green-600 hover:bg-green-700">
                    <Send className="mr-2 h-4 w-4" /> Send Assignment
                </Button>
            </CardHeader>
            <CardContent>
                {isLoadingJobs ? (
                    <div className="text-center"><Loader2 className="animate-spin inline-block"/></div>
                ) : (
                    <ul className="space-y-4">
                        {recentJobs.map(job => (
                            <li key={job.id} className="flex justify-between items-center p-3 bg-white rounded-md shadow-sm border">
                                <div>
                                    <p className="font-semibold">{job.property_address}</p>
                                    <p className="text-sm text-gray-500">{job.client_name || 'No client specified'}</p>
                                    <p className="text-xs text-gray-400">Created: {new Date(job.created_date).toLocaleDateString()}</p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${job.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{job.status}</span>
                                    <Button variant="outline" size="sm" onClick={() => navigate(createPageUrl(`InspectionCapture?id=${job.id}`))}>
                                        <Eye className="w-4 h-4 mr-1" /> View
                                    </Button>
                                    <Button variant="default" size="sm" onClick={() => navigate(createPageUrl(`InspectionCapture?id=${job.id}`))}>
                                        Continue
                                    </Button>
                                    <Button variant="outline" size="sm" className="bg-green-50" onClick={() => handleAssign(job)}>
                                        <Send className="w-4 h-4 mr-1" /> Assign
                                    </Button>
                                    <Button variant="ghost" size="sm" onClick={() => handleDelete(job)}>
                                        <Trash2 className="w-4 h-4 text-red-500" />
                                    </Button>
                                </div>
                            </li>
                        ))}
                         {recentJobs.length === 0 && (
                            <p className="text-center text-gray-500 py-4">No inspection jobs created yet.</p>
                         )}
                    </ul>
                )}
            </CardContent>
        </Card>
      </div>

      <AssignmentDialog
        isOpen={isAssignmentDialogOpen}
        onOpenChange={setIsAssignmentDialogOpen}
        existingJob={editingJob}
        onAssignmentSent={() => {
          setIsAssignmentDialogOpen(false);
          setEditingJob(null);
          queryClient.invalidateQueries({ queryKey: ['inspectionJobs'] });
        }}
      />
    </div>
  );
}