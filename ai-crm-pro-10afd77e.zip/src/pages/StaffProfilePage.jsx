
import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Save, Camera, Loader2, ArrowLeft, AlertCircle, Trash2, Mail } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const ONBOARDING_CHECKLIST = {
  'Claims Specialist Onboarding': [
    '1099 Form', 'Independent contract agreement', '2 shirts 1 sweatshirt',
    'Business Cards', 'Tablet', 'Safety training acknowledgement', 'Waiver release form',
    'Copy of Drivers license and proof of insurance', 'Social security number/EIN',
    'ID badge', 'lanyard and clipboard', 'YICN CRM app training', 'SVGU TRaining',
    'Field Training', 'Ladder', 'Drone', 'Roof/Siding Picture App', 'Certification Award'
  ]
};

const DEPARTMENTS = [
  'Punch Out', 'Free Inspection (Insurance)', 'Free Inspection (Retail)', 'Interior',
  'Gutter', 'Roof Repair', 'Roof Replacement', 'Insurance Claims Specialist',
  'Siding', 'Sales', 'Roof Inspection(Accuserve)'
];

const PERMISSIONS_CONFIG = [
  { feature: "Estimates", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Invoices", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Proposals", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Payments", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Items", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Customers", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Leads", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Projects", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Tasks", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Contracts", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Staff", capabilities: ["view", "create", "edit", "delete"] },
  { feature: "Settings", capabilities: ["view", "edit"] },
  { feature: "Reports", capabilities: ["view"] },
];

export default function StaffProfilePage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const userEmail = urlParams.get("email");
  const isNewUser = userEmail === 'new';

  const [currentUser, setCurrentUser] = useState(null);
  const [profile, setProfile] = useState({});
  const [isUploading, setIsUploading] = useState(false);
  const avatarFileRef = useRef(null);

  useEffect(() => {
    base44.auth.me().then(setCurrentUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['current-user-profile', currentUser?.email],
    queryFn: () => currentUser ? base44.entities.StaffProfile.filter({ user_email: currentUser.email }) : [],
    enabled: !!currentUser,
    initialData: [],
  });

  const myCompany = React.useMemo(() => {
    if (!currentUser) return null;
    const ownedCompany = companies.find(c => c.created_by === currentUser.email);
    if (ownedCompany) return ownedCompany;
    const staffProfile = staffProfiles[0];
    if (staffProfile?.company_id) {
      return companies.find(c => c.id === staffProfile.company_id);
    }
    return null;
  }, [currentUser, companies, staffProfiles]);

  const { data: profileData, isLoading: isLoadingProfile } = useQuery({
    queryKey: ['staff-profile', userEmail],
    queryFn: async () => {
        if (isNewUser) return null;
        const profiles = await base44.entities.StaffProfile.filter({ user_email: userEmail });
        return profiles[0];
    },
    enabled: !!userEmail && !isNewUser,
  });

  useEffect(() => {
    if (isNewUser) {
      setProfile({
        full_name: '',
        email: '',
        is_administrator: false,
        position: '',
        phone: '',
        hourly_rate: 0,
        twilio_number: '',
        whatsapp_enabled: false,
        social_facebook: '',
        social_linkedin: '',
        social_skype: '',
        email_signature: '',
        departments: [],
        onboarding_checklist: {},
        avatar_url: '',
        permissions: {},
        invite_sent: false,
        invite_sent_at: null,
      });
    } else if (profileData) {
      setProfile({
        profile_id: profileData.id,
        full_name: profileData.full_name || '',
        email: profileData.user_email || '',
        is_administrator: profileData.is_administrator || false,
        position: profileData.position || '',
        phone: profileData.phone || '',
        hourly_rate: profileData.hourly_rate || 0,
        twilio_number: profileData.twilio_number || '',
        whatsapp_enabled: profileData.whatsapp_enabled || false,
        social_facebook: profileData.social_facebook || '',
        social_linkedin: profileData.social_linkedin || '',
        social_skype: profileData.social_skype || '',
        email_signature: profileData.email_signature || '',
        departments: profileData.departments || [],
        onboarding_checklist: profileData.onboarding_checklist || {},
        avatar_url: profileData.avatar_url || '',
        permissions: profileData.permissions || {},
        invite_sent: profileData.invite_sent || false,
        invite_sent_at: profileData.invite_sent_at,
      });
    }
  }, [profileData, isNewUser]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (!myCompany?.id) {
        throw new Error("Company setup required");
      }

      const profilePayload = {
        user_email: data.email,
        company_id: myCompany.id,
        full_name: data.full_name,
        is_administrator: data.is_administrator,
        position: data.position,
        phone: data.phone,
        hourly_rate: data.hourly_rate,
        twilio_number: data.twilio_number,
        whatsapp_enabled: data.whatsapp_enabled,
        social_facebook: data.social_facebook,
        social_linkedin: data.social_linkedin,
        social_skype: data.social_skype,
        email_signature: data.email_signature,
        departments: data.departments,
        onboarding_checklist: data.onboarding_checklist,
        avatar_url: data.avatar_url,
        is_active: true,
        permissions: data.permissions,
      };

      if (data.profile_id) {
        return base44.entities.StaffProfile.update(data.profile_id, profilePayload);
      } else {
        return base44.entities.StaffProfile.create(profilePayload);
      }
    },
    onSuccess: (savedProfile) => {
      queryClient.invalidateQueries({ queryKey: ['company-staff-profiles'] });
      queryClient.invalidateQueries({ queryKey: ['staff-profile', userEmail] }); // Invalidate specific profile query

      const wasNewUserCreation = !profile.profile_id; // Check if it was a new creation before state update

      setProfile(prev => ({
        ...prev,
        profile_id: savedProfile.id,
        // Update invite status if it was changed during the save operation, or if it's new
        invite_sent: savedProfile.invite_sent || prev.invite_sent,
        invite_sent_at: savedProfile.invite_sent_at || prev.invite_sent_at,
      }));
      
      alert("✅ Profile saved successfully!");
      
      // If this was a new profile, prompt to send invite
      if (wasNewUserCreation) {
        if (window.confirm("✅ Profile saved!\n\nWould you like to send an invite email to this staff member now?")) {
          sendInviteMutation.mutate();
        }
      }
    },
  });

  const sendInviteMutation = useMutation({
    mutationFn: async () => {
      // The user will navigate to the base URL to log in.
      // They can then use "Forgot Password" if they don't have one.
      const inviteUrl = `${window.location.origin}`; 
      
      await base44.integrations.Core.SendEmail({
        to: profile.email,
        subject: `You're invited to join ${myCompany?.company_name || 'our team'}!`,
        body: `
          <h2>Welcome to the team!</h2>
          <p>Hi ${profile.full_name},</p>
          <p>You've been added as a staff member to ${myCompany?.company_name || 'our CRM system'}.</p>
          <p><strong>Your login email:</strong> ${profile.email}</p>
          <p>Click the link below to log in and set up your account:</p>
          <p><a href="${inviteUrl}" style="background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">Log In to CRM</a></p>
          <p>Or copy this link: ${inviteUrl}</p>
          <p>If you don't have a password yet, click "Forgot Password" on the login page to set one up.</p>
        `
      });

      if (profile.profile_id) {
        const updatedProfile = await base44.entities.StaffProfile.update(profile.profile_id, {
          invite_sent: true,
          invite_sent_at: new Date().toISOString()
        });
        // Update local state to reflect the change immediately
        setProfile(prev => ({
          ...prev,
          invite_sent: updatedProfile.invite_sent,
          invite_sent_at: updatedProfile.invite_sent_at,
        }));
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-profile', userEmail] }); // Invalidate specific profile query
      alert("✅ Invite email sent successfully!");
    },
    onError: (error) => {
      alert("❌ Failed to send invite: " + error.message);
    }
  });

  const deleteProfileMutation = useMutation({
    mutationFn: (id) => base44.entities.StaffProfile.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-staff-profiles'] });
      alert("✅ Staff member deleted");
      navigate(createPageUrl('StaffManagement'));
    },
  });

  const handleFieldChange = (field, value) => {
    setProfile(p => ({ ...p, [field]: value }));
  };

  const handlePermissionChange = (feature, capability) => {
    setProfile(p => {
      const newPermissions = { ...(p.permissions || {}) };
      if (!newPermissions[feature]) newPermissions[feature] = {};
      newPermissions[feature][capability] = !newPermissions[feature][capability];
      return { ...p, permissions: newPermissions };
    });
  };

  const handleSave = () => {
    if (!profile.full_name || !profile.email) {
      alert("Name and email are required");
      return;
    }
    saveMutation.mutate(profile);
  };

  const handleAvatarUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setIsUploading(true);
    try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        handleFieldChange('avatar_url', file_url);
    } catch(err) {
        alert('Upload failed: ' + err.message);
    } finally {
        setIsUploading(false);
    }
  };

  const handleChecklistChange = (checklistName, item) => {
    setProfile(p => {
        const currentChecklist = { ...(p.onboarding_checklist?.[checklistName] || {}) };
        currentChecklist[item] = !currentChecklist[item];
        const newOnboarding = { ...(p.onboarding_checklist || {}), [checklistName]: currentChecklist };
        return { ...p, onboarding_checklist: newOnboarding };
    });
  };

  const handleDepartmentChange = (department) => {
      setProfile(p => {
          const currentDepartments = p.departments || [];
          const newDepartments = currentDepartments.includes(department)
              ? currentDepartments.filter(d => d !== department)
              : [...currentDepartments, department];
          return { ...p, departments: newDepartments };
      });
  };

  const handleDelete = () => {
    if (window.confirm(`⚠️ Delete ${profile.full_name}?\n\nThis will remove their profile. Are you sure?`)) {
      deleteProfileMutation.mutate(profile.profile_id);
    }
  };

  if (isLoadingProfile) return <div className="p-6">Loading...</div>;

  const fullNameParts = profile.full_name?.split(' ') || [];
  const firstName = fullNameParts[0] || '';
  const lastName = fullNameParts.slice(1).join(' ') || '';

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon" onClick={() => navigate(createPageUrl('StaffManagement'))}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{isNewUser ? 'Add New Staff Member' : profile.full_name}</h1>
            <p className="text-gray-500 mt-1">{isNewUser ? 'Set up their profile' : profile.email}</p>
          </div>
        </div>
        <div className="flex gap-2">
          {/* Send Invite button shows for existing profiles that have been saved, allowing resend */}
          {profile.profile_id && (
            <>
              <Button 
                variant="outline"
                onClick={() => sendInviteMutation.mutate()}
                disabled={sendInviteMutation.isLoading}
                className="text-blue-600 hover:text-blue-700"
              >
                {sendInviteMutation.isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Mail className="w-4 h-4 mr-2" />}
                Send Invite
              </Button>
              <Button 
                variant="outline" 
                onClick={handleDelete}
                disabled={deleteProfileMutation.isLoading}
                className="text-red-600 hover:text-red-700"
              >
                {deleteProfileMutation.isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Trash2 className="w-4 h-4 mr-2" />}
                Delete
              </Button>
            </>
          )}
        </div>
      </div>

      {isNewUser && (
        <Alert className="bg-blue-50 border-blue-200">
          <AlertCircle className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-900">
            <strong>Note:</strong> After saving, you'll be prompted to send an invite email so they can log in.
          </AlertDescription>
        </Alert>
      )}

      {profile.invite_sent && profile.invite_sent_at && (
        <Alert className="bg-green-50 border-green-200">
          <Mail className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-900">
            ✅ Invite email sent on {new Date(profile.invite_sent_at).toLocaleDateString()}
          </AlertDescription>
        </Alert>
      )}

      <Tabs defaultValue="profile" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="permissions">Permissions</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6 mt-6">
          <Card>
            <CardHeader><CardTitle>Profile Information</CardTitle></CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center gap-4">
                <Avatar className="w-20 h-20">
                  <AvatarImage src={profile.avatar_url} />
                  <AvatarFallback>{profile.full_name?.charAt(0).toUpperCase()}</AvatarFallback>
                </Avatar>
                <input type="file" ref={avatarFileRef} onChange={handleAvatarUpload} className="hidden" accept="image/*" />
                <Button variant="outline" onClick={() => avatarFileRef.current?.click()} disabled={isUploading}>
                    {isUploading ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Camera className="w-4 h-4 mr-2" />}
                    Upload Photo
                </Button>
              </div>

              <div className="flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <Checkbox 
                  id="is-admin"
                  checked={profile.is_administrator || false}
                  onCheckedChange={(checked) => handleFieldChange('is_administrator', checked)}
                />
                <Label htmlFor="is-admin" className="text-sm font-semibold cursor-pointer">
                  Administrator (Full Access)
                </Label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label>First Name *</Label>
                  <Input 
                    value={firstName} 
                    onChange={(e) => handleFieldChange('full_name', `${e.target.value} ${lastName}`.trim())} 
                  />
                </div>
                <div>
                  <Label>Last Name *</Label>
                  <Input 
                    value={lastName} 
                    onChange={(e) => handleFieldChange('full_name', `${firstName} ${e.target.value}`.trim())} 
                  />
                </div>
                <div>
                  <Label>Email *</Label>
                  <Input 
                    type="email"
                    value={profile.email || ''} 
                    onChange={(e) => handleFieldChange('email', e.target.value)} 
                    disabled={!isNewUser}
                  />
                  {!isNewUser && <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>}
                </div>
                <div>
                  <Label>Position</Label>
                  <Input 
                    value={profile.position || ''} 
                    onChange={(e) => handleFieldChange('position', e.target.value)}
                  />
                </div>
                <div>
                  <Label>Phone</Label>
                  <Input 
                    value={profile.phone || ''} 
                    onChange={(e) => handleFieldChange('phone', e.target.value)}
                  />
                </div>
                <div>
                  <Label>Hourly Rate</Label>
                  <Input 
                    type="number" 
                    value={profile.hourly_rate || 0} 
                    onChange={(e) => handleFieldChange('hourly_rate', parseFloat(e.target.value) || 0)} 
                  />
                </div>
              </div>

              <div className="border-t pt-6">
                <h3 className="font-semibold text-lg mb-4">Twilio Phone Number</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label>Twilio Number</Label>
                    <Input
                      value={profile.twilio_number || ''}
                      onChange={(e) => handleFieldChange('twilio_number', e.target.value)}
                    />
                    <p className="text-xs text-gray-500 mt-1">This number will show as caller ID</p>
                  </div>
                  <div className="flex items-center gap-2 pt-6">
                    <Checkbox
                      id="whatsapp-enabled"
                      checked={profile.whatsapp_enabled || false}
                      onCheckedChange={(checked) => handleFieldChange('whatsapp_enabled', checked)}
                    />
                    <Label htmlFor="whatsapp-enabled">WhatsApp Enabled</Label>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>Facebook</Label>
                  <Input value={profile.social_facebook || ''} onChange={(e) => handleFieldChange('social_facebook', e.target.value)} />
                </div>
                <div>
                  <Label>LinkedIn</Label>
                  <Input value={profile.social_linkedin || ''} onChange={(e) => handleFieldChange('social_linkedin', e.target.value)} />
                </div>
                <div>
                  <Label>Skype</Label>
                  <Input value={profile.social_skype || ''} onChange={(e) => handleFieldChange('social_skype', e.target.value)} />
                </div>
              </div>

              <div>
                <Label>Email Signature</Label>
                <Textarea value={profile.email_signature || ''} onChange={e => handleFieldChange('email_signature', e.target.value)} />
              </div>

              <div>
                <h3 className="font-semibold text-lg mb-2">Member Departments</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {DEPARTMENTS.map(dept => (
                    <div key={dept} className="flex items-center gap-2">
                      <Checkbox
                        id={`dept-${dept}`}
                        checked={profile.departments?.includes(dept) || false}
                        onCheckedChange={() => handleDepartmentChange(dept)}
                      />
                      <Label htmlFor={`dept-${dept}`} className="font-normal">{dept}</Label>
                    </div>
                  ))}
                </div>
              </div>

              {Object.entries(ONBOARDING_CHECKLIST).map(([listName, items]) => (
                <div key={listName}>
                  <h3 className="font-semibold text-lg mb-2">{listName}</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {items.map(item => (
                      <div key={item} className="flex items-center gap-2">
                        <Checkbox
                          id={`onboard-${listName}-${item}`}
                          checked={profile.onboarding_checklist?.[listName]?.[item] || false}
                          onCheckedChange={() => handleChecklistChange(listName, item)}
                        />
                        <Label htmlFor={`onboard-${listName}-${item}`} className="font-normal text-sm">{item}</Label>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="permissions" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Permissions</CardTitle>
              <p className="text-sm text-gray-500">Configure what this staff member can access (ignored if Administrator)</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {PERMISSIONS_CONFIG.map(({ feature, capabilities }) => (
                  <div key={feature} className="border-b pb-4 last:border-0">
                    <h4 className="font-semibold mb-3">{feature}</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {capabilities.map(capability => (
                        <div key={capability} className="flex items-center gap-2">
                          <Checkbox
                            id={`${feature}-${capability}`}
                            checked={profile.permissions?.[feature]?.[capability] || false}
                            onCheckedChange={() => handlePermissionChange(feature, capability)}
                            disabled={profile.is_administrator}
                          />
                          <Label 
                            htmlFor={`${feature}-${capability}`} 
                            className={`font-normal text-sm ${profile.is_administrator ? 'text-gray-400' : ''}`}
                          >
                            {capability.charAt(0).toUpperCase() + capability.slice(1)}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          disabled={saveMutation.isLoading}
          className="bg-blue-600 hover:bg-blue-700"
        >
          {saveMutation.isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
          Save Profile
        </Button>
      </div>
    </div>
  );
}
