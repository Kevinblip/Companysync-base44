
import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Star, Briefcase, Mail, Phone, CheckCircle, Edit, Trash2, MoreVertical, UserX, UserCheck } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const InspectorCard = ({ inspector, onEdit, onToggleActive, onDelete }) => {
    return (
        <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col">
            <CardHeader className="flex flex-row items-start gap-4 p-4">
                <img src={inspector.avatar_url || `https://avatar.vercel.sh/${inspector.user_email}.png`} alt={inspector.user_email} className="w-16 h-16 rounded-full border-2 border-white shadow-md" />
                <div className="flex-1">
                    <CardTitle className="text-xl">{inspector.user_full_name || inspector.user_email}</CardTitle>
                    <p className="text-sm text-gray-500">{inspector.position}</p>
                    <div className="flex items-center gap-1 text-yellow-500 mt-1">
                        <Star className="w-4 h-4 fill-current" />
                        <span className="text-sm font-semibold">{inspector.rating || 'N/A'} ({inspector.inspection_count || 0} inspections)</span>
                    </div>
                </div>
            </CardHeader>
            <CardContent className="p-4 flex-grow space-y-3">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Briefcase className="w-4 h-4" />
                    <span>{inspector.experience_years || 'N/A'}+ Years</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Mail className="w-4 h-4" />
                    <a href={`mailto:${inspector.user_email}`} className="truncate hover:underline">{inspector.user_email}</a>
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone className="w-4 h-4" />
                    <span>{inspector.phone || 'Not available'}</span>
                </div>
                <p className="text-sm text-gray-700 pt-2 border-t border-gray-100 line-clamp-3">
                    {inspector.social_facebook || 'Experienced property inspector specializing in storm damage assessment.'}
                </p>
                <div className="flex flex-wrap gap-2 pt-2">
                    {inspector.tags?.map(tag => <Badge key={tag} variant="secondary">{tag}</Badge>)}
                </div>
            </CardContent>
            <CardFooter className="flex justify-between items-center bg-gray-50 p-4">
                <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span className="text-sm font-medium text-green-700">Verified</span>
                </div>

                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="outline" size="sm">
                            Actions <MoreVertical className="w-4 h-4 ml-2" />
                        </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onEdit(inspector)}>
                            <Edit className="w-4 h-4 mr-2" />
                            Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onToggleActive(inspector)}>
                            {inspector.is_active ? <UserX className="w-4 h-4 mr-2" /> : <UserCheck className="w-4 h-4 mr-2" />}
                            {inspector.is_active ? 'Set as Inactive' : 'Set as Active'}
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600" onClick={() => onDelete(inspector)}>
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>

            </CardFooter>
        </Card>
    );
};

export default function Inspectors() {
    const [showDialog, setShowDialog] = useState(false);
    const [editingInspector, setEditingInspector] = useState(null);
    const [formData, setFormData] = useState({
        user_email: '',
        position: '',
        phone: '',
        avatar_url: '',
        experience_years: 0,
        tags: [],
        social_facebook: '', // Using as bio
        inspection_count: 0,
    });
    const queryClient = useQueryClient();
    const navigate = useNavigate();

    const { data: staffProfiles = [], isLoading: isLoadingStaff } = useQuery({
        queryKey: ['staffProfiles'],
        queryFn: () => base44.entities.StaffProfile.list(),
        initialData: []
    });
    
    const { data: users = [], isLoading: isLoadingUsers } = useQuery({
        queryKey: ['users'],
        queryFn: () => base44.entities.User.list(),
        initialData: []
    });

    const createStaffProfileMutation = useMutation({
        mutationFn: (data) => base44.entities.StaffProfile.create(data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['staffProfiles'] });
            setShowDialog(false);
        },
    });

    const updateStaffProfileMutation = useMutation({
        mutationFn: ({ id, data }) => base44.entities.StaffProfile.update(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['staffProfiles'] });
            setShowDialog(false);
        },
    });
    
    const deleteStaffProfileMutation = useMutation({
        mutationFn: (id) => base44.entities.StaffProfile.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['staffProfiles'] });
        },
    });
    
    const deleteUserMutation = useMutation({
        mutationFn: (id) => base44.asServiceRole.entities.User.delete(id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['users'] });
        },
    });


    const inspectors = staffProfiles.map(profile => {
        const user = users.find(u => u.email === profile.user_email);
        return { ...profile, user_full_name: user?.full_name };
    });

    const handleEdit = (inspector) => {
        setEditingInspector(inspector);
        setFormData({
            user_email: inspector.user_email,
            position: inspector.position || '',
            phone: inspector.phone || '',
            avatar_url: inspector.avatar_url || '',
            experience_years: inspector.experience_years || 0,
            tags: inspector.tags || [],
            social_facebook: inspector.social_facebook || '',
            inspection_count: inspector.inspection_count || 0,
        });
        setShowDialog(true);
    };

    const handleCloseDialog = () => {
        setShowDialog(false);
        setEditingInspector(null);
        setFormData({
            user_email: '',
            position: '',
            phone: '',
            avatar_url: '',
            experience_years: 0,
            tags: [],
            social_facebook: '',
            inspection_count: 0,
        });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const dataToSave = {
            ...formData,
            tags: typeof formData.tags === 'string' ? formData.tags.split(',').map(t => t.trim()) : formData.tags
        };
        
        if (editingInspector) {
            updateStaffProfileMutation.mutate({ id: editingInspector.id, data: dataToSave });
        } else {
            createStaffProfileMutation.mutate(dataToSave);
        }
    };

    const handleToggleActive = (inspector) => {
        updateStaffProfileMutation.mutate({
            id: inspector.id,
            data: { is_active: !inspector.is_active }
        });
    };
    
    const handleDelete = async (inspector) => {
        if (window.confirm(`Are you sure you want to delete inspector "${inspector.user_full_name || inspector.user_email}"? This action cannot be undone.`)) {
            try {
                // Find the user associated with the profile
                const userToDelete = users.find(u => u.email === inspector.user_email);
                
                // Delete the profile first
                await deleteStaffProfileMutation.mutateAsync(inspector.id);

                // If user exists, delete them too
                if (userToDelete) {
                    await deleteUserMutation.mutateAsync(userToDelete.id);
                }

                alert('Inspector deleted successfully.');
            } catch (error) {
                console.error("Failed to delete inspector:", error);
                alert('An error occurred while deleting the inspector. Please try again.');
            }
        }
    };

    if (isLoadingStaff || isLoadingUsers) {
        return <div className="p-6">Loading inspectors...</div>;
    }

    return (
        <div className="p-2 md:p-6 bg-gray-50 min-h-screen">
            <div className="max-w-7xl mx-auto">
                <div className="flex justify-between items-center mb-6">
                    <h1 className="text-3xl font-bold text-gray-800">Vetted Inspectors</h1>
                    <Button onClick={() => setShowDialog(true)}>
                        <Plus className="mr-2 h-4 w-4" /> Add Inspector
                    </Button>
                </div>

                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                    {inspectors.map(inspector => (
                        <InspectorCard key={inspector.id} inspector={inspector} onEdit={handleEdit} onToggleActive={handleToggleActive} onDelete={handleDelete} />
                    ))}
                </div>
            </div>

            <Dialog open={showDialog} onOpenChange={handleCloseDialog}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>{editingInspector ? 'Edit' : 'Add'} Inspector</DialogTitle>
                    </DialogHeader>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <p className="text-sm text-gray-500">To add a new inspector, they must first be a user in the system. Add them via Staff Management if they don't appear in the list.</p>
                        <div>
                            <Label>Inspector Email</Label>
                            <Select
                                value={formData.user_email}
                                onValueChange={(val) => setFormData(prev => ({...prev, user_email: val}))}
                                disabled={!!editingInspector}
                                required
                            >
                                <SelectTrigger>
                                    <SelectValue placeholder="Select an existing user" />
                                </SelectTrigger>
                                <SelectContent>
                                    {users.filter(u => u.role !== 'admin').map(user => (
                                        <SelectItem key={user.id} value={user.email} disabled={inspectors.some(i => i.user_email === user.email && i.user_email !== editingInspector?.user_email)}>
                                            {user.full_name} ({user.email})
                                        </SelectItem>
                                    ))}
                                </SelectContent>
                            </Select>
                        </div>
                         <div>
                            <Label>Position / Title</Label>
                            <Input value={formData.position} onChange={(e) => setFormData(prev => ({ ...prev, position: e.target.value }))} placeholder="e.g., Senior Inspector" />
                        </div>
                        <div>
                            <Label>Phone Number</Label>
                            <Input value={formData.phone} onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))} placeholder="+12163318323" />
                        </div>
                        <div>
                            <Label>Years of Experience</Label>
                            <Input type="number" value={formData.experience_years} onChange={(e) => setFormData(prev => ({ ...prev, experience_years: parseInt(e.target.value, 10) || 0 }))} />
                        </div>
                        <div>
                            <Label>Bio / Description</Label>
                            <Textarea value={formData.social_facebook} onChange={(e) => setFormData(prev => ({ ...prev, social_facebook: e.target.value }))} placeholder="Briefly describe their experience..." />
                        </div>
                        <div>
                            <Label>Tags (comma-separated)</Label>
                            <Input value={Array.isArray(formData.tags) ? formData.tags.join(', ') : formData.tags} onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))} placeholder="HAAG Certified, Licensed, etc." />
                        </div>
                        <div>
                            <Label>Completed Inspections</Label>
                            <Input type="number" value={formData.inspection_count} onChange={(e) => setFormData(prev => ({ ...prev, inspection_count: parseInt(e.target.value, 10) || 0 }))} placeholder="0" />
                        </div>
                         <DialogFooter>
                            <Button type="button" variant="outline" onClick={handleCloseDialog}>Cancel</Button>
                            <Button type="submit">{editingInspector ? 'Save Changes' : 'Create Profile'}</Button>
                        </DialogFooter>
                    </form>
                </DialogContent>
            </Dialog>
        </div>
    );
}
