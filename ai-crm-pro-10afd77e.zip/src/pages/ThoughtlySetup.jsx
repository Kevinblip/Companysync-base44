import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Phone,
  Mic,
  Users,
  CheckCircle2,
  AlertCircle,
  Copy,
  ExternalLink,
  Sparkles
} from "lucide-react";

export default function ThoughtlySetup() {
  const [user, setUser] = useState(null);
  const [alexAgentId, setAlexAgentId] = useState("");
  const [lexiAgentId, setLexiAgentId] = useState("");
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  const { data: twilioSettings = [] } = useQuery({
    queryKey: ['twilio-settings', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.TwilioSettings.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const currentSettings = twilioSettings[0];

  useEffect(() => {
    if (currentSettings) {
      setAlexAgentId(currentSettings.thoughtly_agent_id || "");
      setLexiAgentId(currentSettings.voice_lexi_agent_id || "");
    }
  }, [currentSettings]);

  const linkAgentsMutation = useMutation({
    mutationFn: async ({ alexId, lexiId }) => {
      if (currentSettings) {
        return base44.entities.TwilioSettings.update(currentSettings.id, {
          thoughtly_agent_id: alexId || null,
          voice_lexi_agent_id: lexiId || null,
          use_thoughtly_ai: !!(alexId || lexiId)
        });
      } else {
        return base44.entities.TwilioSettings.create({
          company_id: myCompany.id,
          thoughtly_agent_id: alexId || null,
          voice_lexi_agent_id: lexiId || null,
          use_thoughtly_ai: true
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['twilio-settings'] });
      alert('✅ Thoughtly agents linked successfully!');
    },
  });

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert('✅ Copied to clipboard!');
  };

  const alexWebhookUrl = typeof window !== 'undefined' 
    ? `${window.location.origin}/api/functions/thoughtlyWebhook`
    : '';

  const lexiWebhookUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/api/functions/lexiVoiceWebhook`
    : '';

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
          <Mic className="w-7 h-7 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Thoughtly AI Setup</h1>
          <p className="text-gray-500 mt-1">Connect your AI agents to the CRM</p>
        </div>
      </div>

      <Alert className="bg-blue-50 border-blue-200">
        <Sparkles className="w-4 h-4 text-blue-600" />
        <AlertDescription className="text-blue-900">
          <strong>2 Agents, 2 Purposes:</strong>
          <ul className="list-disc list-inside mt-2 space-y-1">
            <li><strong>Alex</strong> (Customer-facing) → Answers calls from customers, creates leads, qualifies prospects</li>
            <li><strong>Voice Lexi</strong> (Internal staff) → Staff calls Lexi to manage CRM hands-free while driving/working</li>
          </ul>
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ALEX - Customer-Facing */}
        <Card className="bg-gradient-to-br from-green-50 to-blue-50 border-2 border-green-200">
          <CardHeader className="bg-white/70">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                  <Phone className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle className="flex items-center gap-2">
                    Alex - Customer AI
                    {currentSettings?.thoughtly_agent_id && (
                      <Badge className="bg-green-100 text-green-700">Active</Badge>
                    )}
                  </CardTitle>
                  <p className="text-sm text-gray-600">Handles incoming customer calls</p>
                </div>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-6 space-y-4">
            <Alert className="bg-white border-green-200">
              <Users className="w-4 h-4 text-green-600" />
              <AlertDescription>
                <strong>What Alex Does:</strong>
                <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                  <li>Answers all incoming calls to your main number</li>
                  <li>Qualifies leads and extracts info</li>
                  <li>Creates leads in CRM automatically</li>
                  <li>Triggers follow-up workflows</li>
                  <li>Transfers to staff when needed</li>
                </ul>
              </AlertDescription>
            </Alert>

            <div>
              <Label>Alex Agent ID</Label>
              <Input
                placeholder="Enter your Thoughtly agent ID (e.g., xlHlPjRc)"
                value={alexAgentId}
                onChange={(e) => setAlexAgentId(e.target.value)}
                className="mt-1"
              />
              <p className="text-xs text-gray-500 mt-1">
                Find in Thoughtly URL: https://app.thoughtly.com/agent/<strong>YOUR_AGENT_ID</strong>
              </p>
            </div>

            <div>
              <Label className="flex items-center justify-between">
                <span>Webhook URL for Alex</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(alexWebhookUrl)}
                >
                  <Copy className="w-3 h-3 mr-1" />
                  Copy
                </Button>
              </Label>
              <div className="bg-white p-3 rounded border text-xs break-all font-mono mt-1">
                {alexWebhookUrl}
              </div>
            </div>

            <Alert className="bg-yellow-50 border-yellow-200">
              <AlertCircle className="w-4 h-4 text-yellow-600" />
              <AlertDescription className="text-sm">
                <strong>Setup in Thoughtly:</strong>
                <ol className="list-decimal list-inside mt-2 space-y-1">
                  <li>Create Alex agent with friendly voice</li>
                  <li>Train on: greeting customers, qualifying leads, gathering info</li>
                  <li>Connect your Twilio number</li>
                  <li>Add webhook URL above to Integrations</li>
                  <li>Enable events: call.completed, call.started</li>
                </ol>
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* VOICE LEXI - Internal Staff */}
        <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-2 border-purple-200">
          <CardHeader className="bg-white/70">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                  <Mic className="w-6 h-6 text-white" />
                </div>
                <div>
                  <CardTitle className="flex items-center gap-2">
                    Voice Lexi - Staff AI
                    {currentSettings?.voice_lexi_agent_id && (
                      <Badge className="bg-purple-100 text-purple-700">Active</Badge>
                    )}
                  </CardTitle>
                  <p className="text-sm text-gray-600">Staff call Lexi for CRM actions</p>
                </div>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="p-6 space-y-4">
            <Alert className="bg-white border-purple-200">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <AlertDescription>
                <strong>What Voice Lexi Does:</strong>
                <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                  <li>Staff calls Lexi while driving/working</li>
                  <li>Voice commands: "Create lead for John Smith"</li>
                  <li>"Schedule appointment with Jane tomorrow at 2pm"</li>
                  <li>"Remind me to call Mike next week"</li>
                  <li>"Find customer John Doe"</li>
                </ul>
              </AlertDescription>
            </Alert>

            <div>
              <Label>Voice Lexi Agent ID</Label>
              <Input
                placeholder="Enter your Thoughtly agent ID"
                value={lexiAgentId}
                onChange={(e) => setLexiAgentId(e.target.value)}
                className="mt-1"
              />
            </div>

            <div>
              <Label className="flex items-center justify-between">
                <span>Webhook URL for Voice Lexi</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(lexiWebhookUrl)}
                >
                  <Copy className="w-3 h-3 mr-1" />
                  Copy
                </Button>
              </Label>
              <div className="bg-white p-3 rounded border text-xs break-all font-mono mt-1">
                {lexiWebhookUrl}
              </div>
            </div>

            <Alert className="bg-yellow-50 border-yellow-200">
              <AlertCircle className="w-4 h-4 text-yellow-600" />
              <AlertDescription className="text-sm">
                <strong>Setup in Thoughtly:</strong>
                <ol className="list-decimal list-inside mt-2 space-y-1">
                  <li>Create Voice Lexi agent (friendly, efficient)</li>
                  <li>Train on: CRM commands, recognizing staff</li>
                  <li>Get a separate Twilio number for staff</li>
                  <li>Add webhook URL above to Integrations</li>
                  <li>Staff saves this number as "Lexi" in contacts</li>
                </ol>
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button
          onClick={() => linkAgentsMutation.mutate({
            alexId: alexAgentId.trim() || null,
            lexiId: lexiAgentId.trim() || null
          })}
          disabled={linkAgentsMutation.isLoading || (!alexAgentId.trim() && !lexiAgentId.trim())}
          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8"
        >
          {linkAgentsMutation.isLoading ? 'Saving...' : 'Save Agent IDs'}
        </Button>
      </div>

      {/* Architecture Diagram */}
      <Card>
        <CardHeader>
          <CardTitle>How It All Works Together</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-green-50 p-4 rounded-lg border-2 border-green-200">
              <h3 className="font-semibold text-green-900 mb-3 flex items-center gap-2">
                <Phone className="w-5 h-5" />
                Customer Flow (Alex)
              </h3>
              <div className="space-y-2 text-sm text-gray-700">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>Customer calls your business number</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>Alex answers with natural voice</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>Extracts: name, phone, service needed</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>Webhook → CRM creates lead</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>Triggers follow-up workflow</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                  <span>Lexi (text AI) processes & scores lead</span>
                </div>
              </div>
            </div>

            <div className="bg-purple-50 p-4 rounded-lg border-2 border-purple-200">
              <h3 className="font-semibold text-purple-900 mb-3 flex items-center gap-2">
                <Mic className="w-5 h-5" />
                Staff Flow (Voice Lexi)
              </h3>
              <div className="space-y-2 text-sm text-gray-700">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                  <span>Staff calls Voice Lexi's number</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                  <span>Lexi recognizes staff by phone number</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                  <span>Staff: "Create lead for John Smith"</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                  <span>Webhook → CRM executes action</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                  <span>Lexi confirms: "Lead created!"</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-600" />
                  <span>Staff continues working hands-free</span>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Test Section */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardHeader>
          <CardTitle>🧪 Testing Your Setup</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Test Alex (Customer AI):</h3>
            <ol className="list-decimal list-inside space-y-1 text-sm text-gray-700">
              <li>Call your main business number</li>
              <li>Alex should answer: "Hi! Thanks for calling..."</li>
              <li>Say: "I need a roof inspection"</li>
              <li>Provide name and phone when asked</li>
              <li>Check CRM → Leads → New lead should appear!</li>
              <li>Check Communication Hub → Call should be logged</li>
            </ol>
          </div>

          <div>
            <h3 className="font-semibold mb-2">Test Voice Lexi (Staff AI):</h3>
            <ol className="list-decimal list-inside space-y-1 text-sm text-gray-700">
              <li>Call Voice Lexi's number</li>
              <li>Say: "Create a lead for Mike Johnson, phone 555-1234"</li>
              <li>Lexi: "Lead created for Mike Johnson!"</li>
              <li>Check CRM → Leads → Mike Johnson should appear</li>
              <li>Try: "Schedule appointment with Jane tomorrow at 2pm"</li>
              <li>Check Calendar → Appointment should be there!</li>
            </ol>
          </div>

          <Alert>
            <Sparkles className="w-4 h-4 text-purple-600" />
            <AlertDescription>
              <strong>Pro Tip:</strong> Save Voice Lexi's number as "Lexi" in your phone contacts. Now you can just say "Hey Siri, call Lexi" → "Create lead for..." while driving! 🚗
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}