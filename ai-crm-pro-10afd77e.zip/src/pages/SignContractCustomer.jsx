
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, FileSignature, CheckCircle, XCircle } from "lucide-react";

export default function SignContractCustomer() {
  const [token, setToken] = useState(null);
  const [formValues, setFormValues] = useState({});
  const [signatureData, setSignatureData] = useState(null);
  const [completed, setCompleted] = useState(false);
  const canvasRef = React.useRef(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setToken(params.get('token'));
  }, []);

  const { data: sessions = [] } = useQuery({
    queryKey: ['signing-sessions-by-token', token],
    queryFn: () => base44.asServiceRole.entities.ContractSigningSession.filter({ signing_token: token }),
    enabled: !!token,
  });

  const session = sessions[0];

  const { data: template } = useQuery({
    queryKey: ['contract-template', session?.template_id],
    queryFn: () => base44.asServiceRole.entities.ContractTemplate.get(session.template_id),
    enabled: !!session?.template_id,
  });

  const completeSigningMutation = useMutation({
    mutationFn: async ({ fields, signature }) => {
      // Upload signature
      const blob = await (await fetch(signature)).blob();
      const file = new File([blob], 'customer_signature.png', { type: 'image/png' });
      const { file_url } = await base44.integrations.Core.UploadFile({ file });

      // Update session
      await base44.asServiceRole.entities.ContractSigningSession.update(session.id, {
        customer_fields: fields,
        customer_signature_url: file_url,
        customer_signed_at: new Date().toISOString(),
        status: 'customer_signed',
        customer_viewed_at: new Date().toISOString()
      });

      // Generate final PDF
      await base44.functions.invoke('generateSignedPDF', {
        sessionId: session.id
      });
    },
    onSuccess: () => {
      setCompleted(true);
    },
  });

  // Signature canvas setup (same as rep page)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';

    let drawing = false;
    let lastX = 0;
    let lastY = 0;

    const startDrawing = (e) => {
      drawing = true;
      const rect = canvas.getBoundingClientRect();
      lastX = e.clientX - rect.left;
      lastY = e.clientY - rect.top;
    };

    const draw = (e) => {
      if (!drawing) return;
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      ctx.beginPath();
      ctx.moveTo(lastX, lastY);
      ctx.lineTo(x, y);
      ctx.stroke();

      lastX = x;
      lastY = y;
    };

    const stopDrawing = () => {
      drawing = false;
      setSignatureData(canvas.toDataURL());
    };

    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseleave', stopDrawing);

    return () => {
      canvas.removeEventListener('mousedown', startDrawing);
      canvas.removeEventListener('mousemove', draw);
      canvas.removeEventListener('mouseup', stopDrawing);
      canvas.removeEventListener('mouseleave', stopDrawing);
    };
  }, []);

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureData(null);
  };

  const handleComplete = async () => {
    if (!signatureData) {
      alert('❌ Please sign the document first');
      return;
    }

    await completeSigningMutation.mutateAsync({
      fields: formValues,
      signature: signatureData
    });
  };

  if (completed) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-green-50 to-blue-50">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-500" />
            <h2 className="text-2xl font-bold mb-2">Contract Signed!</h2>
            <p className="text-gray-600">Thank you for signing. You'll receive a copy via email shortly.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!session || !template) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  const customerFields = template.fillable_fields?.filter(f => f.filled_by === 'customer') || [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 text-center">
          <h1 className="text-3xl font-bold text-gray-900">Contract Signature Request</h1>
          <p className="text-gray-500 mt-1">From: {session.rep_name}</p>
          <Badge className="mt-2 bg-blue-100 text-blue-700">
            {template.template_name}
          </Badge>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Form Side */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileSignature className="w-5 h-5" />
                  Your Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {customerFields.filter(f => f.field_type !== 'signature').map((field) => (
                  <div key={field.field_name}>
                    <Label>{field.field_label} {field.required && <span className="text-red-500">*</span>}</Label>
                    <Input
                      type={field.field_type === 'date' ? 'date' : field.field_type === 'email' ? 'email' : field.field_type === 'phone' ? 'tel' : 'text'}
                      value={formValues[field.field_name] || ''}
                      onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                      placeholder={field.placeholder}
                      required={field.required}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Your Signature</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Alert>
                  <AlertDescription>
                    By signing below, you agree to the terms of this contract.
                  </AlertDescription>
                </Alert>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-2 bg-white">
                  <canvas
                    ref={canvasRef}
                    width={400}
                    height={150}
                    className="w-full cursor-crosshair bg-white"
                  />
                </div>
                <div className="flex gap-2">
                  <Button type="button" variant="outline" onClick={clearSignature} className="flex-1">
                    Clear
                  </Button>
                  <Button
                    onClick={handleComplete}
                    disabled={!signatureData || completeSigningMutation.isLoading}
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    {completeSigningMutation.isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Completing...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Complete Signing
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* PDF Preview Side - FIXED WITH GOOGLE VIEWER */}
          <div className="sticky top-6">
            <Card className="h-[800px]">
              <CardHeader className="border-b bg-gray-50">
                <div className="flex items-center justify-between">
                  <CardTitle>Contract Preview</CardTitle>
                  <a
                    href={template.original_file_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-blue-600 hover:underline"
                  >
                    Open in new tab
                  </a>
                </div>
              </CardHeader>
              <CardContent className="p-0 h-[720px]">
                <iframe
                  src={`https://docs.google.com/viewer?url=${encodeURIComponent(template.original_file_url)}&embedded=true`}
                  className="w-full h-full border-0"
                  title="Contract Preview"
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
