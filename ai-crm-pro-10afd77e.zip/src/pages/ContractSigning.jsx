import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  FileSignature,
  Plus,
  Send,
  Eye,
  CheckCircle,
  Clock,
  XCircle,
  Mail,
  Download,
  Edit
} from "lucide-react";
import { format } from "date-fns";

export default function ContractSigning() {
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [selectedSignature, setSelectedSignature] = useState(null);
  const [user, setUser] = useState(null);
  const [formData, setFormData] = useState({
    document_type: "contract",
    document_number: "",
    signer_name: "",
    signer_email: "",
    expires_at: ""
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: signatures = [] } = useQuery({
    queryKey: ['signatures'],
    queryFn: () => base44.entities.Signature.list("-created_date", 500),
    initialData: [],
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list("-created_date", 500),
    initialData: [],
  });

  const { data: estimates = [] } = useQuery({
    queryKey: ['estimates'],
    queryFn: () => base44.entities.Estimate.list("-created_date", 500),
    initialData: [],
  });

  const { data: contracts = [] } = useQuery({
    queryKey: ['contracts'],
    queryFn: () => base44.entities.Contract.list("-created_date", 500),
    initialData: [],
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const signatureData = {
        ...data,
        company_id: myCompany?.id,
        status: 'pending'
      };
      console.log('Creating signature request:', signatureData);
      return await base44.entities.Signature.create(signatureData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['signatures'] });
      setShowCreateDialog(false);
      setFormData({
        document_type: "contract",
        document_number: "",
        signer_name: "",
        signer_email: "",
        expires_at: ""
      });
      alert('✅ Signature request created successfully!');
    },
    onError: (error) => {
      console.error('Error creating signature:', error);
      alert('❌ Error: ' + error.message);
    }
  });

  const sendRequestMutation = useMutation({
    mutationFn: async (signatureId) => {
      return await base44.entities.Signature.update(signatureId, {
        status: 'pending',
        signature_request_sent_at: new Date().toISOString()
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['signatures'] });
      alert('✅ Signature request sent to customer!');
    },
    onError: (error) => {
      alert('❌ Error sending request: ' + error.message);
    }
  });

  const handleSubmit = (e) => {
    if (e) e.preventDefault();
    
    if (!formData.document_number || !formData.signer_name || !formData.signer_email) {
      alert('Please fill in all required fields');
      return;
    }

    createMutation.mutate(formData);
  };

  const handleCustomerSelect = (customerId) => {
    const customer = customers.find(c => c.id === customerId);
    if (customer) {
      setFormData({
        ...formData,
        signer_name: customer.name,
        signer_email: customer.email || ''
      });
    }
  };

  const getStatusBadge = (status) => {
    const config = {
      pending: { color: "bg-yellow-100 text-yellow-700", icon: Clock },
      signed: { color: "bg-green-100 text-green-700", icon: CheckCircle },
      declined: { color: "bg-red-100 text-red-700", icon: XCircle },
      expired: { color: "bg-gray-100 text-gray-700", icon: Clock }
    };

    const { color, icon: Icon } = config[status] || config.pending;

    return (
      <Badge variant="outline" className={`${color} flex items-center gap-1`}>
        <Icon className="w-3 h-3" />
        {status}
      </Badge>
    );
  };

  const stats = {
    total: signatures.length,
    pending: signatures.filter(s => s.status === 'pending').length,
    signed: signatures.filter(s => s.status === 'signed').length,
    declined: signatures.filter(s => s.status === 'declined').length
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">E-Signature Requests</h1>
          <p className="text-gray-500 mt-1">Send documents for electronic signature</p>
        </div>

        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Signature Request
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create Signature Request</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Document Type *</Label>
                <Select
                  value={formData.document_type}
                  onValueChange={(v) => setFormData({...formData, document_type: v})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="estimate">Estimate</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                    <SelectItem value="proposal">Proposal</SelectItem>
                    <SelectItem value="agreement">Agreement</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Document/Reference Number *</Label>
                <Input
                  value={formData.document_number}
                  onChange={(e) => setFormData({...formData, document_number: e.target.value})}
                  placeholder="e.g., EST-1234 or CON-5678"
                  required
                />
              </div>

              <div>
                <Label>Quick Select Customer (Optional)</Label>
                <Select onValueChange={handleCustomerSelect}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select a customer..." />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map(customer => (
                      <SelectItem key={customer.id} value={customer.id}>
                        {customer.name} {customer.email ? `(${customer.email})` : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Signer Name *</Label>
                  <Input
                    value={formData.signer_name}
                    onChange={(e) => setFormData({...formData, signer_name: e.target.value})}
                    placeholder="John Smith"
                    required
                  />
                </div>

                <div>
                  <Label>Signer Email *</Label>
                  <Input
                    type="email"
                    value={formData.signer_email}
                    onChange={(e) => setFormData({...formData, signer_email: e.target.value})}
                    placeholder="john@example.com"
                    required
                  />
                </div>
              </div>

              <div>
                <Label>Expires On (Optional)</Label>
                <Input
                  type="date"
                  value={formData.expires_at}
                  onChange={(e) => setFormData({...formData, expires_at: e.target.value})}
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowCreateDialog(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isLoading || !formData.document_number || !formData.signer_name || !formData.signer_email}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {createMutation.isLoading ? 'Creating...' : 'Create Request'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Requests</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <FileSignature className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pending</p>
                <p className="text-2xl font-bold">{stats.pending}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Signed</p>
                <p className="text-2xl font-bold">{stats.signed}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Declined</p>
                <p className="text-2xl font-bold">{stats.declined}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Signatures List */}
      <Card>
        <CardHeader>
          <CardTitle>Signature Requests ({signatures.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Document</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Signer</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sent</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Signed</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {signatures.map((sig) => (
                  <tr key={sig.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-medium text-gray-900 capitalize">{sig.document_type}</p>
                        <p className="text-sm text-gray-500">{sig.document_number}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div>
                        <p className="font-medium text-gray-900">{sig.signer_name}</p>
                        <p className="text-sm text-gray-500">{sig.signer_email}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {getStatusBadge(sig.status)}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {sig.signature_request_sent_at 
                        ? format(new Date(sig.signature_request_sent_at), 'MMM d, yyyy')
                        : '-'
                      }
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {sig.signed_at 
                        ? format(new Date(sig.signed_at), 'MMM d, yyyy')
                        : '-'
                      }
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        {sig.status === 'pending' && !sig.signature_request_sent_at && (
                          <Button
                            size="sm"
                            onClick={() => sendRequestMutation.mutate(sig.id)}
                            className="bg-blue-600 hover:bg-blue-700"
                            disabled={sendRequestMutation.isLoading}
                          >
                            <Send className="w-4 h-4 mr-1" />
                            Send
                          </Button>
                        )}
                        {sig.signed_document_url && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => window.open(sig.signed_document_url, '_blank')}
                          >
                            <Download className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedSignature(sig)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
                {signatures.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                      <FileSignature className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                      <p className="font-medium">No signature requests yet</p>
                      <p className="text-sm mt-1">Click "New Signature Request" above to get started</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* View Signature Dialog */}
      {selectedSignature && (
        <Dialog open={!!selectedSignature} onOpenChange={() => setSelectedSignature(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle className="flex items-center justify-between">
                <span>Signature Request Details</span>
                {getStatusBadge(selectedSignature.status)}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded text-sm">
                <div>
                  <p className="text-gray-500">Document Type</p>
                  <p className="font-medium capitalize">{selectedSignature.document_type}</p>
                </div>
                <div>
                  <p className="text-gray-500">Document Number</p>
                  <p className="font-medium">{selectedSignature.document_number}</p>
                </div>
                <div>
                  <p className="text-gray-500">Signer Name</p>
                  <p className="font-medium">{selectedSignature.signer_name}</p>
                </div>
                <div>
                  <p className="text-gray-500">Signer Email</p>
                  <p className="font-medium">{selectedSignature.signer_email}</p>
                </div>
                <div>
                  <p className="text-gray-500">Sent Date</p>
                  <p className="font-medium">
                    {selectedSignature.signature_request_sent_at
                      ? format(new Date(selectedSignature.signature_request_sent_at), 'PPP')
                      : 'Not sent yet'
                    }
                  </p>
                </div>
                <div>
                  <p className="text-gray-500">Signed Date</p>
                  <p className="font-medium">
                    {selectedSignature.signed_at
                      ? format(new Date(selectedSignature.signed_at), 'PPP')
                      : 'Not signed yet'
                    }
                  </p>
                </div>
              </div>

              {selectedSignature.signature_data && (
                <div className="border-t pt-4">
                  <p className="text-sm font-medium mb-2">Signature:</p>
                  <div className="border rounded p-4 bg-white">
                    <img 
                      src={selectedSignature.signature_data} 
                      alt="Signature" 
                      className="max-w-full h-auto"
                    />
                  </div>
                </div>
              )}

              {selectedSignature.ip_address && (
                <div className="text-xs text-gray-500">
                  Signed from IP: {selectedSignature.ip_address}
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}