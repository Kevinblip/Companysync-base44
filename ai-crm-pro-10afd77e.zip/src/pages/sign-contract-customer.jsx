import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, CheckCircle, X, Eye } from "lucide-react";
import SignaturePad from "../components/SignaturePad";

export default function SignContractCustomer() {
  const [token, setToken] = useState(null);
  const [formValues, setFormValues] = useState({});
  const [signatureData, setSignatureData] = useState(null);
  const [showPdfPreview, setShowPdfPreview] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setToken(params.get('token'));
  }, []);

  const { data: session } = useQuery({
    queryKey: ['signing-session-token', token],
    queryFn: async () => {
      const sessions = await base44.asServiceRole.entities.ContractSigningSession.filter({ signing_token: token });
      return sessions[0];
    },
    enabled: !!token,
  });

  const { data: template } = useQuery({
    queryKey: ['contract-template', session?.template_id],
    queryFn: () => base44.entities.ContractTemplate.get(session.template_id),
    enabled: !!session?.template_id,
  });

  const signContractMutation = useMutation({
    mutationFn: async ({ fields, signature }) => {
      return await base44.entities.ContractSigningSession.update(session.id, {
        customer_fields: fields,
        customer_signature_url: signature,
        customer_signed_at: new Date().toISOString(),
        status: 'completed'
      });
    },
    onSuccess: () => {
      alert('✅ Contract signed successfully!\nThank you!');
    },
  });

  const handleSubmit = async () => {
    if (!signatureData) {
      alert('❌ Please sign the document first');
      return;
    }

    const customerFields = template.fillable_fields.filter(f => f.filled_by === 'customer' && f.field_type !== 'signature');
    const missingRequired = customerFields.filter(f => f.required && !formValues[f.field_name]);
    
    if (missingRequired.length > 0) {
      alert(`❌ Please fill in required fields: ${missingRequired.map(f => f.field_label).join(', ')}`);
      return;
    }

    await signContractMutation.mutateAsync({
      fields: formValues,
      signature: signatureData
    });
  };

  if (!session || !template) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (session.status === 'completed') {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Card className="max-w-md">
          <CardContent className="p-12 text-center">
            <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-600" />
            <h2 className="text-2xl font-bold mb-2">Contract Already Signed</h2>
            <p className="text-gray-600">This contract has already been completed.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const customerFields = template.fillable_fields?.filter(f => f.filled_by === 'customer') || [];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Sign Contract</h1>
        <p className="text-gray-500 mt-1">{template.template_name}</p>
        <Badge className="mt-2 bg-green-100 text-green-700">
          Customer Signature
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form Side */}
        <Card>
          <CardHeader>
            <CardTitle>Complete Your Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <AlertDescription>
                <strong>From:</strong> {session.rep_name}
                <br />
                <strong>Contract:</strong> {session.contract_name}
              </AlertDescription>
            </Alert>

            {customerFields.map((field) => {
              if (field.field_type === 'signature') return null;

              return (
                <div key={field.field_name}>
                  <Label>
                    {field.field_label}
                    {field.required && <span className="text-red-500"> *</span>}
                  </Label>
                  {field.field_type === 'date' ? (
                    <Input
                      type="date"
                      value={formValues[field.field_name] || ''}
                      onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                      required={field.required}
                    />
                  ) : field.field_type === 'email' ? (
                    <Input
                      type="email"
                      value={formValues[field.field_name] || ''}
                      onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                      placeholder={field.placeholder}
                      required={field.required}
                    />
                  ) : field.field_type === 'phone' ? (
                    <Input
                      type="tel"
                      value={formValues[field.field_name] || ''}
                      onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                      placeholder={field.placeholder || "(XXX) XXX-XXXX"}
                      required={field.required}
                    />
                  ) : (
                    <Input
                      type="text"
                      value={formValues[field.field_name] || ''}
                      onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                      placeholder={field.placeholder}
                      required={field.required}
                    />
                  )}
                </div>
              );
            })}

            <div className="border-t pt-4 mt-4">
              <Label className="text-lg font-bold text-gray-900 block mb-2">
                Your Signature *
              </Label>
              <p className="text-sm text-gray-600 mb-3">
                Draw your signature using your mouse or finger
              </p>
              <SignaturePad onSignatureChange={setSignatureData} />
            </div>

            <Button
              onClick={handleSubmit}
              disabled={signContractMutation.isLoading || !signatureData}
              className="w-full bg-green-600 hover:bg-green-700 text-lg py-6"
            >
              {signContractMutation.isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <CheckCircle className="w-5 h-5 mr-2" />
                  Sign Contract
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* PDF Preview Side */}
        <div className="sticky top-6">
          <Card className="h-[800px]">
            <CardHeader className="border-b bg-gray-50">
              <div className="flex items-center justify-between">
                <CardTitle>Contract Preview</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowPdfPreview(true)}
                  className="text-blue-600 hover:text-blue-700"
                >
                  <Eye className="w-4 h-4 mr-1" />
                  Full Screen
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0 h-[720px]">
              <iframe
                src={`https://docs.google.com/viewer?url=${encodeURIComponent(template.original_file_url)}&embedded=true`}
                className="w-full h-full border-0"
                title="Contract Preview"
              />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Full Screen Preview */}
      {showPdfPreview && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-6xl h-[95vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b bg-gray-50">
              <h2 className="text-xl font-bold">Contract Preview</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowPdfPreview(false)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            <div className="flex-1 overflow-hidden">
              <iframe
                src={`https://docs.google.com/viewer?url=${encodeURIComponent(template.original_file_url)}&embedded=true`}
                className="w-full h-full border-0"
                title="Contract Full Preview"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}