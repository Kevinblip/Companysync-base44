import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { 
  Plus, 
  Upload, 
  Loader2,
  MapPin,
  Camera,
  AlertTriangle,
  Wind,
  CloudHail,
  CheckCircle2,
  FileText,
  Sparkles,
  Eye,
  Trash2,
  DollarSign,
  Download
} from "lucide-react";
import { format } from "date-fns";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function DroneInspections() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [showDialog, setShowDialog] = useState(false);
  const [showInstructions, setShowInstructions] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(null);
  const [selectedPhotos, setSelectedPhotos] = useState([]);
  const [formData, setFormData] = useState({
    property_address: "",
    customer_name: "",
    inspection_date: new Date().toISOString().split('T')[0],
    weather_conditions: "",
    notes: ""
  });

  const queryClient = useQueryClient();

  const { data: inspections = [] } = useQuery({
    queryKey: ['drone-inspections'],
    queryFn: () => base44.entities.DroneInspection.list("-created_date"),
    initialData: [],
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.DroneInspection.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['drone-inspections'] });
      setShowDialog(false);
      setSelectedPhotos([]);
      setFormData({
        property_address: "",
        customer_name: "",
        inspection_date: new Date().toISOString().split('T')[0],
        weather_conditions: "",
        notes: ""
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.DroneInspection.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['drone-inspections'] });
    },
  });

  const handlePhotoSelect = (e) => {
    const files = Array.from(e.target.files);
    setSelectedPhotos(files);
  };

  const analyzeDronePhotos = async () => {
    if (selectedPhotos.length === 0) {
      setUploadStatus({ type: 'error', message: 'Please select drone photos to analyze' });
      return;
    }

    setUploading(true);
    setAnalyzing(true);
    setUploadStatus({ type: 'info', message: 'Uploading and analyzing drone photos...' });

    try {
      const photoResults = [];
      let hailDetected = false;
      let windDetected = false;
      let totalEstimatedCost = 0;

      // Upload and analyze each photo
      for (let i = 0; i < selectedPhotos.length; i++) {
        const file = selectedPhotos[i];
        setUploadStatus({ 
          type: 'info', 
          message: `Analyzing drone image ${i + 1} of ${selectedPhotos.length}...` 
        });

        // Normalize file
        const fileNameParts = file.name.split('.');
        const originalExtension = fileNameParts.length > 1 ? fileNameParts[fileNameParts.length - 1] : '';
        const lowercaseExtension = originalExtension.toLowerCase();
        const baseName = fileNameParts.slice(0, -1).join('.');
        const normalizedFileName = originalExtension ? `${baseName}.${lowercaseExtension}` : file.name;
        
        let mimeType = file.type;
        if (!mimeType || mimeType === 'application/octet-stream') {
          const mimeTypes = {
            'pdf': 'application/pdf',
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png'
          };
          mimeType = mimeTypes[lowercaseExtension] || 'application/octet-stream';
        }
        
        const normalizedFile = new File([file], normalizedFileName, { type: mimeType });

        // Upload photo
        const { file_url } = await base44.integrations.Core.UploadFile({ file: normalizedFile });

        // AI Analysis
        const analysisPrompt = `You are an expert roofing inspector analyzing drone inspection photos for storm damage.

Analyze this drone roof photo and identify:

1. **Hail Damage**: Look for:
   - Impact marks or dents on shingles
   - Granule loss (bare spots on shingles)
   - Bruising or circular impact patterns
   - Damaged ridge caps or valleys

2. **Wind Damage**: Look for:
   - Missing or lifted shingles
   - Curled or torn shingles
   - Damaged or missing flashing
   - Debris or foreign objects
   - Exposed underlayment

3. **Other Damage**: 
   - Structural issues
   - Water damage
   - Age-related wear
   - Improper installation

Provide:
- Damage types detected (hail, wind, structural, etc.)
- Severity level (none, minor, moderate, severe)
- Specific damage descriptions
- Estimated repair cost in dollars
- Whether insurance claim is recommended
- Roof section (if identifiable: front slope, back slope, ridge, valley, etc.)

Be thorough and specific about what you see in this drone image.`;

        const analysis = await base44.integrations.Core.InvokeLLM({
          prompt: analysisPrompt,
          file_urls: [file_url],
          response_json_schema: {
            type: "object",
            properties: {
              damage_types: { type: "array", items: { type: "string" } },
              severity: { type: "string", enum: ["none", "minor", "moderate", "severe"] },
              has_hail_damage: { type: "boolean" },
              has_wind_damage: { type: "boolean" },
              description: { type: "string" },
              estimated_cost: { type: "number" },
              insurance_recommended: { type: "boolean" },
              roof_section: { type: "string" }
            }
          }
        });

        if (analysis.has_hail_damage) hailDetected = true;
        if (analysis.has_wind_damage) windDetected = true;
        totalEstimatedCost += analysis.estimated_cost || 0;

        photoResults.push({
          url: file_url,
          caption: file.name,
          damage_detected: analysis.damage_types.length > 0,
          damage_type: analysis.damage_types,
          severity: analysis.severity,
          ai_analysis: analysis.description,
          roof_section: analysis.roof_section || "unknown"
        });
      }

      // Determine overall condition
      const maxSeverity = photoResults.reduce((max, photo) => {
        const severityLevels = { none: 0, minor: 1, moderate: 2, severe: 3 };
        const photoLevel = severityLevels[photo.severity] || 0;
        return photoLevel > max ? photoLevel : max;
      }, 0);

      const overallCondition = 
        maxSeverity === 0 ? 'excellent' :
        maxSeverity === 1 ? 'good' :
        maxSeverity === 2 ? 'fair' : 'poor';

      // Create inspection record
      const inspectionData = {
        inspection_number: `DRONE-${Date.now().toString().slice(-8)}`,
        property_address: formData.property_address,
        customer_name: formData.customer_name,
        inspection_date: formData.inspection_date,
        weather_conditions: formData.weather_conditions,
        photos: photoResults,
        overall_condition: overallCondition,
        hail_damage_detected: hailDetected,
        wind_damage_detected: windDetected,
        estimated_repair_cost: totalEstimatedCost,
        notes: formData.notes,
        status: 'analyzed'
      };

      await createMutation.mutateAsync(inspectionData);

      setUploadStatus({ 
        type: 'success', 
        message: `Drone analysis complete! ${hailDetected || windDetected ? 'Storm damage detected!' : 'No significant damage found.'}` 
      });

    } catch (error) {
      console.error('Drone analysis error:', error);
      setUploadStatus({ type: 'error', message: `Analysis failed: ${error.message}` });
    }

    setUploading(false);
    setAnalyzing(false);
  };

  const handleDownloadReport = async (inspection) => {
    try {
      const response = await base44.functions.invoke('generateDroneReport', {
        inspectionId: inspection.id
      });
      
      // Download PDF
      const link = document.createElement('a');
      link.href = response.data.pdf_url;
      link.download = `Drone-Report-${inspection.inspection_number}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      alert('Failed to generate report: ' + error.message);
    }
  };

  const handleCreateEstimate = (inspection) => {
    // Navigate to Estimates page with pre-filled data
    const params = new URLSearchParams({
      create_new: 'true',
      prefill: 'true',
      customer_name: inspection.customer_name,
      property_address: inspection.property_address,
      drone_inspection_id: inspection.id
    });
    navigate(createPageUrl('Estimates') + '?' + params.toString());
  };

  const handleDelete = (inspectionId) => {
    if (window.confirm("Are you sure you want to delete this drone inspection?")) {
      deleteMutation.mutate(inspectionId);
    }
  };

  const getSeverityColor = (severity) => {
    const colors = {
      'none': 'bg-green-100 text-green-700 border-green-200',
      'minor': 'bg-yellow-100 text-yellow-700 border-yellow-200',
      'moderate': 'bg-orange-100 text-orange-700 border-orange-200',
      'severe': 'bg-red-100 text-red-700 border-red-200'
    };
    return colors[severity] || colors.none;
  };

  const getConditionColor = (condition) => {
    const colors = {
      'excellent': 'bg-green-100 text-green-700 border-green-200',
      'good': 'bg-blue-100 text-blue-700 border-blue-200',
      'fair': 'bg-yellow-100 text-yellow-700 border-yellow-200',
      'poor': 'bg-orange-100 text-orange-700 border-orange-200',
      'critical': 'bg-red-100 text-red-700 border-red-200'
    };
    return colors[condition] || colors.good;
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <Camera className="w-8 h-8 text-blue-600" />
            AI Damage Analysis
          </h1>
          <p className="text-gray-500 mt-1">AI-powered storm damage detection from drone & inspection photos</p>
        </div>

        <div className="flex gap-3">
          <Button 
            variant="outline"
            onClick={() => setShowInstructions(!showInstructions)}
          >
            <Eye className="w-4 h-4 mr-2" />
            How It Works
          </Button>
          <Dialog open={showDialog} onOpenChange={setShowDialog}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                <Plus className="w-4 h-4 mr-2" />
                New Drone Analysis
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-blue-600" />
                  New Drone Inspection Analysis
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-4">
                {uploadStatus && (
                  <Alert variant={uploadStatus.type === 'error' ? 'destructive' : 'default'} 
                         className={uploadStatus.type === 'success' ? 'bg-green-50 border-green-200' : ''}>
                    <AlertDescription className={uploadStatus.type === 'success' ? 'text-green-800' : ''}>
                      {uploadStatus.type === 'success' && <CheckCircle2 className="w-4 h-4 inline mr-2" />}
                      {uploadStatus.message}
                    </AlertDescription>
                  </Alert>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Property Address *</Label>
                    <Input
                      value={formData.property_address}
                      onChange={(e) => setFormData({...formData, property_address: e.target.value})}
                      placeholder="123 Main St, City, State"
                      required
                    />
                  </div>
                  <div>
                    <Label>Customer Name</Label>
                    <Input
                      value={formData.customer_name}
                      onChange={(e) => setFormData({...formData, customer_name: e.target.value})}
                      placeholder="Select or enter name"
                      list="customers-list"
                    />
                    <datalist id="customers-list">
                      {customers.map((customer) => (
                        <option key={customer.id} value={customer.name} />
                      ))}
                    </datalist>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Inspection Date</Label>
                    <Input
                      type="date"
                      value={formData.inspection_date}
                      onChange={(e) => setFormData({...formData, inspection_date: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label>Weather Conditions</Label>
                    <Input
                      value={formData.weather_conditions}
                      onChange={(e) => setFormData({...formData, weather_conditions: e.target.value})}
                      placeholder="Sunny, clear visibility"
                    />
                  </div>
                </div>

                <div>
                  <Label>Notes</Label>
                  <Textarea
                    value={formData.notes}
                    onChange={(e) => setFormData({...formData, notes: e.target.value})}
                    rows={2}
                    placeholder="Additional inspection notes..."
                  />
                </div>

                <div className="border-2 border-dashed border-blue-300 rounded-lg p-6 bg-blue-50">
                  <div className="text-center mb-4">
                    <Upload className="w-12 h-12 mx-auto mb-2 text-blue-600" />
                    <h3 className="font-semibold text-lg mb-1">Upload Drone/Inspection Photos</h3>
                    <p className="text-sm text-gray-600">Select multiple photos for AI damage analysis</p>
                  </div>

                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handlePhotoSelect}
                    className="hidden"
                    id="drone-photos"
                    disabled={uploading}
                  />

                  <Button
                    type="button"
                    variant="outline"
                    className="w-full mb-3"
                    onClick={() => document.getElementById('drone-photos')?.click()}
                    disabled={uploading}
                  >
                    <Camera className="w-4 h-4 mr-2" />
                    Select Photos
                  </Button>

                  {selectedPhotos.length > 0 && (
                    <div className="bg-white rounded-lg p-4 space-y-2">
                      <p className="font-medium text-sm text-gray-700">
                        Selected: {selectedPhotos.length} photo{selectedPhotos.length > 1 ? 's' : ''}
                      </p>
                      <div className="grid grid-cols-4 gap-2">
                        {selectedPhotos.map((photo, idx) => (
                          <div key={idx} className="relative aspect-square rounded overflow-hidden bg-gray-100">
                            <img 
                              src={URL.createObjectURL(photo)} 
                              alt={photo.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-4 border border-purple-200">
                  <h4 className="font-semibold flex items-center gap-2 mb-2">
                    <Sparkles className="w-4 h-4 text-purple-600" />
                    AI Analysis Features
                  </h4>
                  <ul className="text-sm text-gray-700 space-y-1">
                    <li className="flex items-center gap-2">
                      <CloudHail className="w-4 h-4 text-blue-600" />
                      Hail damage detection (impact marks, granule loss)
                    </li>
                    <li className="flex items-center gap-2">
                      <Wind className="w-4 h-4 text-green-600" />
                      Wind damage detection (missing/lifted shingles)
                    </li>
                    <li className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-orange-600" />
                      Severity assessment & cost estimation
                    </li>
                    <li className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-indigo-600" />
                      Downloadable PDF reports
                    </li>
                    <li className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-green-600" />
                      One-click estimate creation
                    </li>
                  </ul>
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      setShowDialog(false);
                      setSelectedPhotos([]);
                      setUploadStatus(null);
                    }}
                    disabled={uploading}
                  >
                    Cancel
                  </Button>
                  <Button 
                    onClick={analyzeDronePhotos}
                    disabled={uploading || selectedPhotos.length === 0 || !formData.property_address}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    {uploading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Analyze with AI
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {showInstructions && (
        <Card className="bg-gradient-to-r from-blue-50 via-purple-50 to-pink-50 border-2 border-blue-300">
          <CardHeader className="border-b bg-white/50">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="w-6 h-6 text-blue-600" />
                How Drone Analysis Works
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setShowInstructions(false)}>
                ✕
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
                  <span className="flex items-center justify-center w-8 h-8 bg-blue-600 text-white rounded-full text-sm">1</span>
                  Capture Photos
                </h3>
                <ul className="text-sm text-gray-700 space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>Fly your drone over property at 30-50 feet altitude</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>OR use phone/camera for ground-level inspection</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>Take clear, high-resolution photos from multiple angles</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>Cover all roof sections and damaged areas</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
                  <span className="flex items-center justify-center w-8 h-8 bg-purple-600 text-white rounded-full text-sm">2</span>
                  Upload & Analyze
                </h3>
                <ul className="text-sm text-gray-700 space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>Click "New Drone Analysis" and enter property details</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>Upload multiple photos at once (JPG, PNG)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>AI analyzes each photo automatically</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>Wait 30-60 seconds for complete analysis</span>
                  </li>
                </ul>
              </div>

              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
                  <span className="flex items-center justify-center w-8 h-8 bg-orange-600 text-white rounded-full text-sm">3</span>
                  AI Damage Detection
                </h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-2 text-sm">
                    <CloudHail className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">Hail Damage:</p>
                      <p className="text-gray-600">Impact marks, granule loss, bruising, dents</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <Wind className="w-5 h-5 text-green-600 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">Wind Damage:</p>
                      <p className="text-gray-600">Missing shingles, lifted edges, torn sections</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5" />
                    <div>
                      <p className="font-semibold text-gray-900">Severity Rating:</p>
                      <p className="text-gray-600">None, Minor, Moderate, or Severe</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg p-4 shadow-sm">
                <h3 className="font-bold text-lg mb-3 flex items-center gap-2">
                  <span className="flex items-center justify-center w-8 h-8 bg-green-600 text-white rounded-full text-sm">4</span>
                  Report & Estimate
                </h3>
                <ul className="text-sm text-gray-700 space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>View detailed damage analysis for each photo</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>Download professional PDF report</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>Get automatic repair cost estimates</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-green-600 mt-0.5" />
                    <span>Create estimate with one click</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="bg-yellow-50 border-2 border-yellow-300 rounded-lg p-4">
              <h4 className="font-bold text-yellow-900 mb-2 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" />
                Pro Tips for Best Results
              </h4>
              <ul className="text-sm text-yellow-900 space-y-1">
                <li>✓ Fly in good lighting conditions (morning or late afternoon)</li>
                <li>✓ Avoid shadows and glare on the roof surface</li>
                <li>✓ Take photos perpendicular to the roof, not at extreme angles</li>
                <li>✓ Capture at least 8-12 photos for comprehensive coverage</li>
                <li>✓ Include close-ups of any visible damage areas</li>
                <li>✓ Document the entire roof, not just problem spots</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-700">Total Inspections</p>
                <p className="text-3xl font-bold text-blue-900">{inspections.length}</p>
              </div>
              <Camera className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-orange-700">Hail Damage Found</p>
                <p className="text-3xl font-bold text-orange-900">
                  {inspections.filter(i => i.hail_damage_detected).length}
                </p>
              </div>
              <CloudHail className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-700">Wind Damage Found</p>
                <p className="text-3xl font-bold text-green-900">
                  {inspections.filter(i => i.wind_damage_detected).length}
                </p>
              </div>
              <Wind className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {inspections.map((inspection) => (
          <Card key={inspection.id} className="bg-white shadow-md hover:shadow-lg transition-shadow">
            <CardHeader className="border-b bg-gradient-to-r from-gray-50 to-blue-50">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <MapPin className="w-5 h-5 text-blue-600" />
                    <CardTitle className="text-xl">{inspection.property_address}</CardTitle>
                    <Badge variant="outline" className={getConditionColor(inspection.overall_condition)}>
                      {inspection.overall_condition}
                    </Badge>
                  </div>
                  <div className="flex gap-4 text-sm text-gray-600">
                    <span>{inspection.inspection_number}</span>
                    {inspection.customer_name && <span>• {inspection.customer_name}</span>}
                    <span>• {format(new Date(inspection.inspection_date), 'MMM d, yyyy')}</span>
                    {inspection.photos && <span>• {inspection.photos.length} photos</span>}
                  </div>
                </div>
                <div className="flex gap-2">
                  {inspection.hail_damage_detected && (
                    <Badge className="bg-orange-100 text-orange-700 flex items-center gap-1">
                      <CloudHail className="w-3 h-3" />
                      Hail
                    </Badge>
                  )}
                  {inspection.wind_damage_detected && (
                    <Badge className="bg-green-100 text-green-700 flex items-center gap-1">
                      <Wind className="w-3 h-3" />
                      Wind
                    </Badge>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              {inspection.photos && inspection.photos.length > 0 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {inspection.photos.map((photo, idx) => (
                      <div key={idx} className="relative group">
                        <div className="relative aspect-video rounded-lg overflow-hidden bg-gray-100">
                          <img 
                            src={photo.url} 
                            alt={photo.caption}
                            className="w-full h-full object-cover"
                          />
                          {photo.damage_detected && (
                            <div className="absolute top-2 right-2">
                              <Badge variant="outline" className={getSeverityColor(photo.severity)}>
                                {photo.severity}
                              </Badge>
                            </div>
                          )}
                        </div>
                        {photo.ai_analysis && (
                          <div className="mt-2 p-2 bg-gray-50 rounded text-xs">
                            <p className="text-gray-700 line-clamp-2">{photo.ai_analysis}</p>
                            {photo.damage_type && photo.damage_type.length > 0 && (
                              <div className="flex gap-1 mt-1 flex-wrap">
                                {photo.damage_type.map((type, i) => (
                                  <Badge key={i} variant="outline" className="text-xs">
                                    {type}
                                  </Badge>
                                ))}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {inspection.estimated_repair_cost > 0 && (
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg p-4 border border-green-200">
                      <div className="flex items-center justify-between flex-wrap gap-3">
                        <div>
                          <p className="text-sm font-medium text-green-700">Estimated Repair Cost</p>
                          <p className="text-2xl font-bold text-green-900">
                            ${inspection.estimated_repair_cost.toLocaleString()}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button 
                            variant="outline"
                            onClick={() => handleDownloadReport(inspection)}
                            className="bg-white"
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Download Report
                          </Button>
                          <Button 
                            onClick={() => handleCreateEstimate(inspection)}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <DollarSign className="w-4 h-4 mr-2" />
                            Create Estimate
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  {inspection.notes && (
                    <div className="bg-gray-50 rounded-lg p-4">
                      <p className="text-sm font-medium text-gray-700 mb-1">Inspector Notes:</p>
                      <p className="text-sm text-gray-600">{inspection.notes}</p>
                    </div>
                  )}

                  <div className="flex justify-end">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(inspection.id)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                    >
                      <Trash2 className="w-4 h-4 mr-1" />
                      Delete
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}

        {inspections.length === 0 && (
          <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-dashed border-blue-300">
            <CardContent className="p-12 text-center">
              <Camera className="w-16 h-16 mx-auto mb-4 text-blue-400" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Drone Inspections Yet</h3>
              <p className="text-gray-600 mb-4">
                Upload drone or inspection photos to detect storm damage with AI
              </p>
              <Button 
                onClick={() => setShowDialog(true)}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Start First Analysis
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}