import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import AIEstimator from "./AIEstimator";

import Leads from "./Leads";

import Customers from "./Customers";

import Tasks from "./Tasks";

import Settings from "./Settings";

import Calendar from "./Calendar";

import Invoices from "./Invoices";

import Projects from "./Projects";

import AIAssistant from "./AIAssistant";

import IntegrationManager from "./IntegrationManager";

import Items from "./Items";

import Activity from "./Activity";

import SalesDashboard from "./SalesDashboard";

import Communication from "./Communication";

import Billing from "./Billing";

import Estimates from "./Estimates";

import Payments from "./Payments";

import SalesTracking from "./SalesTracking";

import Proposals from "./Proposals";

import Subscriptions from "./Subscriptions";

import DroneInspections from "./DroneInspections";

import AIStaff from "./AIStaff";

import ZoomMeeting from "./ZoomMeeting";

import HRManagement from "./HRManagement";

import Payroll from "./Payroll";

import Accounting from "./Accounting";

import Mailbox from "./Mailbox";

import Expenses from "./Expenses";

import PageBuilder from "./PageBuilder";

import Contracts from "./Contracts";

import Map from "./Map";

import Support from "./Support";

import KnowledgeBase from "./KnowledgeBase";

import Utilities from "./Utilities";

import Reports from "./Reports";

import LeadFinder from "./LeadFinder";

import CustomFormats from "./CustomFormats";

import CompanySetup from "./CompanySetup";

import StormTracking from "./StormTracking";

import StormAlertSettings from "./StormAlertSettings";

import PropertyDataImporter from "./PropertyDataImporter";

import MenuSetup from "./MenuSetup";

import CustomFields from "./CustomFields";

import DataImport from "./DataImport";

import CustomerProfile from "./CustomerProfile";

import customer-profile from "./customer-profile";

import EstimateImporter from "./EstimateImporter";

import StaffManagement from "./StaffManagement";

import EmailTemplates from "./EmailTemplates";

import SMSTemplates from "./SMSTemplates";

import Workflows from "./Workflows";

import CustomerPortal from "./CustomerPortal";

import Documents from "./Documents";

import ContractSigning from "./ContractSigning";

import Messages from "./Messages";

import Analytics from "./Analytics";

import ReportBuilder from "./ReportBuilder";

import settings from "./settings";

import AITraining from "./AITraining";

import ContractTemplates from "./ContractTemplates";

import SignContractRep from "./SignContractRep";

import SignContractCustomer from "./SignContractCustomer";

import sign-contract-rep from "./sign-contract-rep";

import sign-contract from "./sign-contract";

import sign-contract-customer from "./sign-contract-customer";

import CommunicationDashboard from "./CommunicationDashboard";

import ThoughtlySetup from "./ThoughtlySetup";

import StaffProfilePage from "./StaffProfilePage";

import RolesManagement from "./RolesManagement";

import InspectionsDashboard from "./InspectionsDashboard";

import NewInspection from "./NewInspection";

import InspectionCapture from "./InspectionCapture";

import InspectionReports from "./InspectionReports";

import Inspectors from "./Inspectors";

import ConversationHistory from "./ConversationHistory";

import LeadInspections from "./LeadInspections";

import SetupWizard from "./SetupWizard";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    AIEstimator: AIEstimator,
    
    Leads: Leads,
    
    Customers: Customers,
    
    Tasks: Tasks,
    
    Settings: Settings,
    
    Calendar: Calendar,
    
    Invoices: Invoices,
    
    Projects: Projects,
    
    AIAssistant: AIAssistant,
    
    IntegrationManager: IntegrationManager,
    
    Items: Items,
    
    Activity: Activity,
    
    SalesDashboard: SalesDashboard,
    
    Communication: Communication,
    
    Billing: Billing,
    
    Estimates: Estimates,
    
    Payments: Payments,
    
    SalesTracking: SalesTracking,
    
    Proposals: Proposals,
    
    Subscriptions: Subscriptions,
    
    DroneInspections: DroneInspections,
    
    AIStaff: AIStaff,
    
    ZoomMeeting: ZoomMeeting,
    
    HRManagement: HRManagement,
    
    Payroll: Payroll,
    
    Accounting: Accounting,
    
    Mailbox: Mailbox,
    
    Expenses: Expenses,
    
    PageBuilder: PageBuilder,
    
    Contracts: Contracts,
    
    Map: Map,
    
    Support: Support,
    
    KnowledgeBase: KnowledgeBase,
    
    Utilities: Utilities,
    
    Reports: Reports,
    
    LeadFinder: LeadFinder,
    
    CustomFormats: CustomFormats,
    
    CompanySetup: CompanySetup,
    
    StormTracking: StormTracking,
    
    StormAlertSettings: StormAlertSettings,
    
    PropertyDataImporter: PropertyDataImporter,
    
    MenuSetup: MenuSetup,
    
    CustomFields: CustomFields,
    
    DataImport: DataImport,
    
    CustomerProfile: CustomerProfile,
    
    customer-profile: customer-profile,
    
    EstimateImporter: EstimateImporter,
    
    StaffManagement: StaffManagement,
    
    EmailTemplates: EmailTemplates,
    
    SMSTemplates: SMSTemplates,
    
    Workflows: Workflows,
    
    CustomerPortal: CustomerPortal,
    
    Documents: Documents,
    
    ContractSigning: ContractSigning,
    
    Messages: Messages,
    
    Analytics: Analytics,
    
    ReportBuilder: ReportBuilder,
    
    settings: settings,
    
    AITraining: AITraining,
    
    ContractTemplates: ContractTemplates,
    
    SignContractRep: SignContractRep,
    
    SignContractCustomer: SignContractCustomer,
    
    sign-contract-rep: sign-contract-rep,
    
    sign-contract: sign-contract,
    
    sign-contract-customer: sign-contract-customer,
    
    CommunicationDashboard: CommunicationDashboard,
    
    ThoughtlySetup: ThoughtlySetup,
    
    StaffProfilePage: StaffProfilePage,
    
    RolesManagement: RolesManagement,
    
    InspectionsDashboard: InspectionsDashboard,
    
    NewInspection: NewInspection,
    
    InspectionCapture: InspectionCapture,
    
    InspectionReports: InspectionReports,
    
    Inspectors: Inspectors,
    
    ConversationHistory: ConversationHistory,
    
    LeadInspections: LeadInspections,
    
    SetupWizard: SetupWizard,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/AIEstimator" element={<AIEstimator />} />
                
                <Route path="/Leads" element={<Leads />} />
                
                <Route path="/Customers" element={<Customers />} />
                
                <Route path="/Tasks" element={<Tasks />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Calendar" element={<Calendar />} />
                
                <Route path="/Invoices" element={<Invoices />} />
                
                <Route path="/Projects" element={<Projects />} />
                
                <Route path="/AIAssistant" element={<AIAssistant />} />
                
                <Route path="/IntegrationManager" element={<IntegrationManager />} />
                
                <Route path="/Items" element={<Items />} />
                
                <Route path="/Activity" element={<Activity />} />
                
                <Route path="/SalesDashboard" element={<SalesDashboard />} />
                
                <Route path="/Communication" element={<Communication />} />
                
                <Route path="/Billing" element={<Billing />} />
                
                <Route path="/Estimates" element={<Estimates />} />
                
                <Route path="/Payments" element={<Payments />} />
                
                <Route path="/SalesTracking" element={<SalesTracking />} />
                
                <Route path="/Proposals" element={<Proposals />} />
                
                <Route path="/Subscriptions" element={<Subscriptions />} />
                
                <Route path="/DroneInspections" element={<DroneInspections />} />
                
                <Route path="/AIStaff" element={<AIStaff />} />
                
                <Route path="/ZoomMeeting" element={<ZoomMeeting />} />
                
                <Route path="/HRManagement" element={<HRManagement />} />
                
                <Route path="/Payroll" element={<Payroll />} />
                
                <Route path="/Accounting" element={<Accounting />} />
                
                <Route path="/Mailbox" element={<Mailbox />} />
                
                <Route path="/Expenses" element={<Expenses />} />
                
                <Route path="/PageBuilder" element={<PageBuilder />} />
                
                <Route path="/Contracts" element={<Contracts />} />
                
                <Route path="/Map" element={<Map />} />
                
                <Route path="/Support" element={<Support />} />
                
                <Route path="/KnowledgeBase" element={<KnowledgeBase />} />
                
                <Route path="/Utilities" element={<Utilities />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/LeadFinder" element={<LeadFinder />} />
                
                <Route path="/CustomFormats" element={<CustomFormats />} />
                
                <Route path="/CompanySetup" element={<CompanySetup />} />
                
                <Route path="/StormTracking" element={<StormTracking />} />
                
                <Route path="/StormAlertSettings" element={<StormAlertSettings />} />
                
                <Route path="/PropertyDataImporter" element={<PropertyDataImporter />} />
                
                <Route path="/MenuSetup" element={<MenuSetup />} />
                
                <Route path="/CustomFields" element={<CustomFields />} />
                
                <Route path="/DataImport" element={<DataImport />} />
                
                <Route path="/CustomerProfile" element={<CustomerProfile />} />
                
                <Route path="/customer-profile" element={<customer-profile />} />
                
                <Route path="/EstimateImporter" element={<EstimateImporter />} />
                
                <Route path="/StaffManagement" element={<StaffManagement />} />
                
                <Route path="/EmailTemplates" element={<EmailTemplates />} />
                
                <Route path="/SMSTemplates" element={<SMSTemplates />} />
                
                <Route path="/Workflows" element={<Workflows />} />
                
                <Route path="/CustomerPortal" element={<CustomerPortal />} />
                
                <Route path="/Documents" element={<Documents />} />
                
                <Route path="/ContractSigning" element={<ContractSigning />} />
                
                <Route path="/Messages" element={<Messages />} />
                
                <Route path="/Analytics" element={<Analytics />} />
                
                <Route path="/ReportBuilder" element={<ReportBuilder />} />
                
                <Route path="/settings" element={<settings />} />
                
                <Route path="/AITraining" element={<AITraining />} />
                
                <Route path="/ContractTemplates" element={<ContractTemplates />} />
                
                <Route path="/SignContractRep" element={<SignContractRep />} />
                
                <Route path="/SignContractCustomer" element={<SignContractCustomer />} />
                
                <Route path="/sign-contract-rep" element={<sign-contract-rep />} />
                
                <Route path="/sign-contract" element={<sign-contract />} />
                
                <Route path="/sign-contract-customer" element={<sign-contract-customer />} />
                
                <Route path="/CommunicationDashboard" element={<CommunicationDashboard />} />
                
                <Route path="/ThoughtlySetup" element={<ThoughtlySetup />} />
                
                <Route path="/StaffProfilePage" element={<StaffProfilePage />} />
                
                <Route path="/RolesManagement" element={<RolesManagement />} />
                
                <Route path="/InspectionsDashboard" element={<InspectionsDashboard />} />
                
                <Route path="/NewInspection" element={<NewInspection />} />
                
                <Route path="/InspectionCapture" element={<InspectionCapture />} />
                
                <Route path="/InspectionReports" element={<InspectionReports />} />
                
                <Route path="/Inspectors" element={<Inspectors />} />
                
                <Route path="/ConversationHistory" element={<ConversationHistory />} />
                
                <Route path="/LeadInspections" element={<LeadInspections />} />
                
                <Route path="/SetupWizard" element={<SetupWizard />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}