
import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { MapContainer, TileLayer, Circle, Popup, Marker } from 'react-leaflet';
import {
  Cloud,
  CloudRain,
  Wind,
  AlertTriangle,
  RefreshCw,
  MapPin,
  Users,
  Search
} from "lucide-react";
import { format } from "date-fns";
import 'leaflet/dist/leaflet.css';

// Helper function to calculate distance between two lat/lng points in miles
function getDistanceInMiles(lat1, lon1, lat2, lon2) {
  if (lat1 === null || lon1 === null || lat2 === null || lon2 === null || isNaN(lat1) || isNaN(lon1) || isNaN(lat2) || isNaN(lon2)) return Infinity;
  const R = 3959; // Radius of the Earth in miles
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Helper function to geocode address string to coordinates
const geocodeAddress = async (address) => {
  if (!address) return null;
  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}&limit=1&countrycodes=us`
    );
    const data = await response.json();
    if (data && data[0]) {
      return {
        lat: parseFloat(data[0].lat),
        lng: parseFloat(data[0].lon)
      };
    }
  } catch (error) {
    console.error('Geocoding error:', error);
  }
  return null;
};


export default function StormTracking() {
  const [selectedStorm, setSelectedStorm] = useState(null);
  const [filterType, setFilterType] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [mapCenter, setMapCenter] = useState([39.8283, -98.5795]); // Center of USA
  const [mapZoom, setMapZoom] = useState(4);
  const [generatingLeads, setGeneratingLeads] = useState(false);
  const [serviceCenterCoords, setServiceCenterCoords] = useState(null);
  const [isGeocoding, setIsGeocoding] = useState(true);
  const [showAllStorms, setShowAllStorms] = useState(false); // NEW: Toggle for showing all storms

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: storms = [], isLoading: isLoadingStorms } = useQuery({
    queryKey: ['storm-events'],
    queryFn: () => base44.entities.StormEvent.filter({ status: 'active' }, '-created_date', 1000),
    initialData: [],
    refetchInterval: 300000, // Refresh every 5 minutes
  });

  const { data: alertSettingsData = [] } = useQuery({
    queryKey: ['storm-alert-settings', user?.id],
    queryFn: () => base44.entities.StormAlertSettings.list(),
    enabled: !!user,
  });

  const companySettings = alertSettingsData[0];

  useEffect(() => {
    if (companySettings) {
        if (companySettings.service_center_location) {
            setIsGeocoding(true);
            geocodeAddress(companySettings.service_center_location).then(coords => {
                if (coords) {
                    console.log('✅ Geocoded service center:', coords);
                    setServiceCenterCoords(coords);
                    setMapCenter([coords.lat, coords.lng]);
                    setMapZoom(7);
                } else {
                    console.warn('⚠️ Geocoding failed for:', companySettings.service_center_location);
                    setServiceCenterCoords(null); // Explicitly set to null if geocoding fails
                }
                setIsGeocoding(false);
            });
        } else {
            console.warn('⚠️ No service center location set in settings');
            setServiceCenterCoords(null); // No location, so no coords
            setIsGeocoding(false);
        }
    } else {
        console.warn('⚠️ No company settings found for storm alerts');
        setServiceCenterCoords(null); // No settings, so no coords
        setIsGeocoding(false);
    }
  }, [companySettings]);

  const fetchStormsMutation = useMutation({
    mutationFn: () => base44.functions.invoke('fetchStormData'),
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ['storm-events'] });
      alert(`✅ Updated! Found ${response.data.newEvents} new storm events`);
    },
    onError: (error) => {
      alert('Failed to fetch storm data: ' + error.message);
    }
  });

  const generateLeadsMutation = useMutation({
    mutationFn: (stormId) => base44.functions.invoke('generateStormLeads', { stormId }),
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ['storm-events'] });
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      alert(`✅ Generated ${response.data.leadsGenerated} leads from ${response.data.stormTitle}!`);
      setGeneratingLeads(false);
    },
    onError: (error) => {
      alert('Failed to generate leads: ' + error.message);
      setGeneratingLeads(false);
    }
  });

  const handleGenerateLeads = (storm) => {
    if (confirm(`Generate leads for properties affected by "${storm.title}"?\n\nThis will create potential customer leads in the affected areas.`)) {
      setGeneratingLeads(true);
      generateLeadsMutation.mutate(storm.id);
    }
  };

  const getStormIcon = (type) => {
    const icons = {
      hail: Cloud,
      tornado: Wind,
      thunderstorm: CloudRain,
      high_wind: Wind,
      flood: CloudRain,
      winter_storm: Cloud
    };
    return icons[type] || AlertTriangle;
  };

  const getSeverityColor = (severity) => {
    const colors = {
      minor: 'bg-blue-100 text-blue-700 border-blue-200',
      moderate: 'bg-yellow-100 text-yellow-700 border-yellow-200',
      severe: 'bg-orange-100 text-orange-700 border-orange-200',
      extreme: 'bg-red-100 text-red-700 border-red-200'
    };
    return colors[severity] || colors.moderate;
  };

  const getCircleColor = (severity) => {
    const colors = {
      minor: '#3b82f6',
      moderate: '#f59e0b',
      severe: '#f97316',
      extreme: '#ef4444'
    };
    return colors[severity] || colors.moderate;
  };

  // Filter storms based on service area OR show all
  const stormsInServiceArea = useMemo(() => {
    console.log('🔍 Filtering storms...');
    console.log('Total storms from API:', storms.length);
    console.log('Show all storms toggle:', showAllStorms);
    console.log('Is geocoding:', isGeocoding);
    console.log('Company settings:', companySettings);
    console.log('Service center coords:', serviceCenterCoords);

    if (isGeocoding) {
      console.log('⏳ Still geocoding, returning empty array for now.');
      return [];
    }
    
    if (!storms.length) {
      console.log('⚠️ No storms in database, returning empty array.');
      return [];
    }

    // If "Show All" is enabled, return all storms
    if (showAllStorms) {
      console.log('✅ "Show All Storms" is ON, returning all storms.');
      return storms;
    }
    
    // If no settings or no valid location, act as if "show all" is on because filtering criteria are missing.
    if (!companySettings || !companySettings.service_center_location || !serviceCenterCoords) {
      console.log('⚠️ No service settings or service center coords available, defaulting to show all storms.');
      return storms;
    }

    const { service_radius_miles = 50, service_areas = [] } = companySettings;
    console.log('Service radius:', service_radius_miles, 'miles');
    console.log('Service areas:', service_areas);

    const filtered = storms.filter(storm => {
      // Check if storm has valid coordinates, essential for distance calculation
      if (storm.latitude === null || storm.longitude === null || isNaN(storm.latitude) || isNaN(storm.longitude)) {
        console.log(`⚠️ Storm "${storm.title}" (ID: ${storm.id}) has invalid coordinates, excluding from service area filter.`);
        return false;
      }

      // Check 1: Is the storm within the service radius?
      const distance = getDistanceInMiles(
        serviceCenterCoords.lat,
        serviceCenterCoords.lng,
        storm.latitude,
        storm.longitude
      );
      
      console.log(`📍 Storm "${storm.title}" (ID: ${storm.id}) is ${distance.toFixed(1)} miles away from service center.`);
      
      if (distance <= service_radius_miles) {
        console.log(`✅ Storm "${storm.title}" (ID: ${storm.id}) is within service radius.`);
        return true;
      }

      // Check 2: Does the storm affect a specifically monitored area?
      const affectsMonitoredArea = (storm.affected_areas || []).some(stormArea =>
        service_areas.some(serviceArea =>
          stormArea.toLowerCase().includes(serviceArea.toLowerCase()) ||
          serviceArea.toLowerCase().includes(stormArea.toLowerCase())
        )
      );
      
      if (affectsMonitoredArea) {
        console.log(`✅ Storm "${storm.title}" (ID: ${storm.id}) affects a monitored area.`);
        return true;
      }

      return false;
    });

    console.log(`✅ Filtered to ${filtered.length} storms in service area.`);
    return filtered;
  }, [storms, companySettings, serviceCenterCoords, isGeocoding, showAllStorms]);


  const filteredStorms = stormsInServiceArea.filter(storm => {
    const matchesType = filterType === 'all' || storm.event_type === filterType;
    const matchesSearch = storm.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         storm.affected_areas?.some(area => area.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesType && matchesSearch;
  });

  const activeStorms = filteredStorms.filter(s => s.status === 'active').length; // Changed to use filteredStorms for metric
  const severeStorms = filteredStorms.filter(s => s.severity === 'severe' || s.severity === 'extreme').length; // Changed to use filteredStorms for metric
  const totalAffectedAreas = new Set(filteredStorms.flatMap(s => s.affected_areas || [])).size; // Changed to use filteredStorms for metric
  const totalLeadsGenerated = filteredStorms.reduce((sum, s) => sum + (s.leads_generated || 0), 0); // Changed to use filteredStorms for metric

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Storm Tracking</h1>
          <p className="text-gray-500 mt-1">Real-time severe weather monitoring powered by NOAA</p>
        </div>
        <Button
          onClick={() => fetchStormsMutation.mutate()}
          disabled={fetchStormsMutation.isLoading}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${fetchStormsMutation.isLoading ? 'animate-spin' : ''}`} />
          {fetchStormsMutation.isLoading ? 'Updating...' : 'Refresh Data'}
        </Button>
      </div>

      {/* Show All Storms Toggle */}
      <Card className="bg-blue-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-blue-900">Show All Storms (Nationwide)</p>
              <p className="text-sm text-blue-700">
                {showAllStorms 
                  ? `Currently showing all ${storms.length} storms across the US.` 
                  : companySettings?.service_center_location && serviceCenterCoords
                    ? `Currently showing storms within ${companySettings.service_radius_miles || 50} miles of ${companySettings.service_center_location} or in monitored areas.`
                    : 'Configure your service area in Storm Alert Settings to filter storms.'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Label htmlFor="show-all">Show All</Label>
              <Switch
                id="show-all"
                checked={showAllStorms}
                onCheckedChange={setShowAllStorms}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-700">
                  {showAllStorms ? 'Active Storms (All)' : 'Active in Service Area'}
                </p>
                <p className="text-3xl font-bold text-blue-900">{activeStorms}</p>
              </div>
              <CloudRain className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-red-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-orange-700">Severe Events</p>
                <p className="text-3xl font-bold text-orange-900">{severeStorms}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-pink-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-700">Affected Areas</p>
                <p className="text-3xl font-bold text-purple-900">{totalAffectedAreas}</p>
              </div>
              <MapPin className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        {/* New Leads Generated Metric Card */}
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-700">Leads Generated</p>
                <p className="text-3xl font-bold text-green-900">
                  {totalLeadsGenerated}
                </p>
              </div>
              <Users className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Map and List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Storm List */}
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Storm Events</CardTitle>
              <div className="flex gap-2 mt-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search storms..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent className="max-h-[600px] overflow-y-auto space-y-3">
              {isLoadingStorms || isGeocoding ? (
                <div className="text-center py-12 text-gray-500">
                  <RefreshCw className="w-8 h-8 mx-auto mb-3 animate-spin text-gray-400" />
                  <p>{isGeocoding ? 'Locating your service area...' : 'Loading Storms...'}</p>
                </div>
              ) : filteredStorms.length > 0 ? (
                filteredStorms.map((storm) => {
                  const StormIcon = getStormIcon(storm.event_type);
                  return (
                    <Card
                      key={storm.id}
                      className={`cursor-pointer transition-all hover:shadow-md ${
                        selectedStorm?.id === storm.id ? 'ring-2 ring-blue-500' : ''
                      }`}
                      onClick={() => {
                        setSelectedStorm(storm);
                        if (storm.latitude && storm.longitude) {
                          setMapCenter([storm.latitude, storm.longitude]);
                          setMapZoom(8);
                        }
                      }}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-lg ${getSeverityColor(storm.severity)}`}>
                            <StormIcon className="w-5 h-5" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-start justify-between">
                              <h3 className="font-semibold text-sm">{storm.title}</h3>
                              <Badge variant="outline" className={getSeverityColor(storm.severity)}>
                                {storm.severity}
                              </Badge>
                            </div>
                            <p className="text-xs text-gray-600 mt-1 line-clamp-2">
                              {storm.affected_areas?.join(', ')}
                            </p>
                            {storm.hail_size_inches && (
                              <p className="text-xs font-medium text-orange-600 mt-1">
                                🧊 Hail: {storm.hail_size_inches}" diameter
                              </p>
                            )}
                            {storm.wind_speed_mph && (
                              <p className="text-xs font-medium text-blue-600 mt-1">
                                💨 Winds: {storm.wind_speed_mph} mph
                              </p>
                            )}
                            {storm.leads_generated > 0 && (
                              <p className="text-xs font-medium text-green-600 mt-1">
                                👥 {storm.leads_generated} leads generated
                              </p>
                            )}
                            <p className="text-xs text-gray-500 mt-2">
                              {storm.start_time ? format(new Date(storm.start_time), 'MMM d, h:mm a') : 'Time unknown'}
                            </p>

                            <Button
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleGenerateLeads(storm);
                              }}
                              disabled={generatingLeads}
                              className="w-full mt-3 bg-green-600 hover:bg-green-700 text-xs"
                            >
                              <Users className="w-3 h-3 mr-1" />
                              {generatingLeads ? 'Generating...' : 'Generate Leads'}
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              ) : (
                <div className="text-center py-12 text-gray-500">
                  <CloudRain className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>No active storms found {showAllStorms ? 'matching your search' : 'in your service area'}</p>
                  {!showAllStorms && (companySettings?.service_center_location && serviceCenterCoords) && (
                    <p className="text-sm mt-1">
                      <button 
                        onClick={() => setShowAllStorms(true)}
                        className="text-blue-600 underline"
                      >
                        Show all storms
                      </button> or adjust your Storm Alert Settings.
                    </p>
                  )}
                  {!showAllStorms && (!companySettings?.service_center_location || !serviceCenterCoords) && (
                    <p className="text-sm mt-1">
                      Configure your service area in Storm Alert Settings to filter storms, or <button onClick={() => setShowAllStorms(true)} className="text-blue-600 underline">show all storms</button>.
                    </p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Map */}
        <div className="lg:col-span-2">
          <Card>
            <CardContent className="p-0">
              <div className="h-[600px] rounded-lg overflow-hidden">
                <MapContainer
                  center={mapCenter}
                  zoom={mapZoom}
                  style={{ height: '100%', width: '100%' }}
                >
                  <TileLayer
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    attribution='&copy; OpenStreetMap contributors'
                  />
                  {filteredStorms.map((storm) => {
                    if (!storm.latitude || !storm.longitude) return null;
                    return (
                      <Circle
                        key={storm.id}
                        center={[storm.latitude, storm.longitude]}
                        radius={storm.radius_miles * 1609.34} // Convert miles to meters
                        pathOptions={{
                          color: getCircleColor(storm.severity),
                          fillColor: getCircleColor(storm.severity),
                          fillOpacity: 0.2
                        }}
                      >
                        <Popup>
                          <div className="p-2">
                            <h3 className="font-bold">{storm.title}</h3>
                            <Badge className={getSeverityColor(storm.severity)}>{storm.severity}</Badge>
                            <p className="text-sm mt-2">{storm.affected_areas?.join(', ')}</p>
                            {storm.hail_size_inches && (
                              <p className="text-sm mt-1">🧊 Hail: {storm.hail_size_inches}"</p>
                            )}
                            {storm.wind_speed_mph && (
                              <p className="text-sm">💨 Winds: {storm.wind_speed_mph} mph</p>
                            )}
                            {storm.leads_generated > 0 && (
                              <p className="text-sm font-medium text-green-600 mt-2">
                                👥 {storm.leads_generated} leads generated
                              </p>
                            )}
                            <Button
                              size="sm"
                              onClick={() => handleGenerateLeads(storm)}
                              disabled={generatingLeads}
                              className="w-full mt-3 bg-green-600 hover:bg-green-700 text-xs"
                            >
                              Generate Leads
                            </Button>
                          </div>
                        </Popup>
                      </Circle>
                    );
                  })}
                  {serviceCenterCoords && !showAllStorms && ( // Only show service center marker if not showing all storms
                    <Marker position={[serviceCenterCoords.lat, serviceCenterCoords.lng]}>
                      <Popup>
                        Your Service Center Location<br/>
                        Radius: {companySettings?.service_radius_miles || 50} miles
                      </Popup>
                    </Marker>
                  )}
                </MapContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
