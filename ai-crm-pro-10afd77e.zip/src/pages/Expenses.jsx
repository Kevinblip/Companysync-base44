import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Receipt, TrendingDown, Calendar, DollarSign } from "lucide-react";

export default function Expenses() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Expenses</h1>
          <p className="text-gray-500 mt-1">Track and manage business expenses</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Add Expense
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white">
          <CardContent className="p-6">
            <DollarSign className="w-8 h-8 mb-2" />
            <h3 className="text-2xl font-bold">$0.00</h3>
            <p className="text-sm opacity-80">Total Expenses</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardContent className="p-6">
            <Calendar className="w-8 h-8 mb-2" />
            <h3 className="text-2xl font-bold">$0.00</h3>
            <p className="text-sm opacity-80">This Month</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <TrendingDown className="w-8 h-8 mb-2" />
            <h3 className="text-2xl font-bold">$0.00</h3>
            <p className="text-sm opacity-80">This Week</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <Receipt className="w-8 h-8 mb-2" />
            <h3 className="text-2xl font-bold">0</h3>
            <p className="text-sm opacity-80">Total Records</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Expenses</CardTitle>
        </CardHeader>
        <CardContent className="text-center py-12 text-gray-500">
          <Receipt className="w-16 h-16 mx-auto mb-4 text-gray-300" />
          <p>No expenses recorded yet</p>
        </CardContent>
      </Card>
    </div>
  );
}