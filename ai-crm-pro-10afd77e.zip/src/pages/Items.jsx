import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search, Star, StarOff, Plus, Download, Trash2, ChevronLeft, ChevronRight, Check } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Items() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [itemsPerPage, setItemsPerPage] = useState("100");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedItems, setSelectedItems] = useState([]);
  const [activeTab, setActiveTab] = useState("all");

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
    initialData: null,
  });

  const { data: allItems = [] } = useQuery({
    queryKey: ['price-list-items'],
    queryFn: () => base44.entities.PriceListItem.list("-created_date", 10000),
    initialData: [],
  });

  const toggleFavoriteMutation = useMutation({
    mutationFn: ({ id, isFavorite }) => 
      base44.entities.PriceListItem.update(id, { is_favorite: !isFavorite }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-list-items'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.PriceListItem.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['price-list-items'] });
    },
  });

  let tabFilteredItems = allItems;
  if (activeTab === "company_sync") {
    tabFilteredItems = allItems.filter(item => item.source === "Custom" || !item.source);
  } else if (activeTab === "xactimate") {
    tabFilteredItems = allItems.filter(item => item.source === "Xactimate");
  } else if (activeTab === "symbility") {
    tabFilteredItems = allItems.filter(item => item.source === "Symbility");
  }

  const filteredItems = tabFilteredItems.filter(item => {
    const matchesSearch = 
      item.code?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
    const matchesFavorites = !favoritesOnly || item.is_favorite;
    
    return matchesSearch && matchesCategory && matchesFavorites;
  });

  const itemsPerPageNum = parseInt(itemsPerPage);
  const totalPages = Math.ceil(filteredItems.length / itemsPerPageNum);
  const startIndex = (currentPage - 1) * itemsPerPageNum;
  const endIndex = startIndex + itemsPerPageNum;
  const displayedItems = filteredItems.slice(startIndex, endIndex);

  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, selectedCategory, favoritesOnly, activeTab, itemsPerPage]);

  const companySyncCount = allItems.filter(item => item.source === "Custom" || !item.source).length;
  const xactimateCount = allItems.filter(item => item.source === "Xactimate").length;
  const symbilityCount = allItems.filter(item => item.source === "Symbility").length;

  const categories = ["all", "Roofing", "Siding", "Windows", "Doors", "Interior", "Exterior", "HVAC", "Plumbing", "Electrical", "Other"];

  const getCategoryColor = (category) => {
    const colors = {
      'Roofing': 'bg-blue-100 text-blue-700',
      'Siding': 'bg-green-100 text-green-700',
      'Windows': 'bg-purple-100 text-purple-700',
      'Doors': 'bg-orange-100 text-orange-700',
      'Interior': 'bg-pink-100 text-pink-700',
      'Exterior': 'bg-teal-100 text-teal-700',
      'HVAC': 'bg-red-100 text-red-700',
      'Plumbing': 'bg-indigo-100 text-indigo-700',
      'Electrical': 'bg-yellow-100 text-yellow-700',
      'Other': 'bg-gray-100 text-gray-700'
    };
    return colors[category] || colors.Other;
  };

  const handleSelectAll = () => {
    if (selectedItems.length === displayedItems.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(displayedItems.map(item => item.id));
    }
  };

  const handleSelectItem = (id) => {
    if (selectedItems.includes(id)) {
      setSelectedItems(selectedItems.filter(itemId => itemId !== id));
    } else {
      setSelectedItems([...selectedItems, id]);
    }
  };

  const handleBulkDelete = async () => {
    if (!window.confirm(`Delete ${selectedItems.length} selected items?`)) return;
    
    for (const id of selectedItems) {
      await deleteMutation.mutateAsync(id);
    }
    setSelectedItems([]);
  };

  const handleAddToEstimate = () => {
    const itemsToAdd = allItems.filter(item => selectedItems.includes(item.id));
    
    localStorage.setItem('pendingEstimateItems', JSON.stringify(itemsToAdd.map(item => ({
      code: item.code,
      description: item.description,
      quantity: 1,
      unit: item.unit || "EA",
      rate: item.price,
      category: item.category,
      source: item.source,
      amount: item.price
    }))));
    
    window.location.href = createPageUrl('Estimates') + '?add_items=true';
  };

  const handleExport = () => {
    const headers = ["Code", "Description", "Unit", "Price", "Category", "Source"];
    const csvRows = [headers.join(',')];
    
    for (const item of filteredItems) {
      const row = [
        `"${item.code}"`,
        `"${(item.description || '').replace(/"/g, '""')}"`,
        `"${item.unit}"`,
        item.price,
        `"${item.category}"`,
        `"${item.source || ''}"`
      ];
      csvRows.push(row.join(','));
    }
    
    const csvString = csvRows.join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'items_export.csv';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getPageNumbers = () => {
    const pages = [];
    const maxVisible = 5;
    
    if (totalPages <= maxVisible + 2) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      if (currentPage <= 3) {
        for (let i = 1; i <= maxVisible; i++) {
          pages.push(i);
        }
        pages.push('...');
        pages.push(totalPages);
      } else if (currentPage >= totalPages - 2) {
        pages.push(1);
        pages.push('...');
        for (let i = totalPages - maxVisible + 1; i <= totalPages; i++) {
          pages.push(i);
        }
      } else {
        pages.push(1);
        pages.push('...');
        for (let i = currentPage - 1; i <= currentPage + 1; i++) {
          pages.push(i);
        }
        pages.push('...');
        pages.push(totalPages);
      }
    }
    
    return pages;
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Items</h1>
        <Link to={createPageUrl("IntegrationManager")}>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            New Item
          </Button>
        </Link>
      </div>

      <Card className="bg-white">
        <CardContent className="p-0">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-full justify-start border-b rounded-none bg-transparent p-0 h-auto">
              <TabsTrigger 
                value="all" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent"
              >
                All ({allItems.length})
              </TabsTrigger>
              <TabsTrigger 
                value="company_sync" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent"
              >
                CompanySync ({companySyncCount})
              </TabsTrigger>
              <TabsTrigger 
                value="xactimate" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent"
              >
                Xactimate ({xactimateCount})
              </TabsTrigger>
              <TabsTrigger 
                value="symbility" 
                className="rounded-none border-b-2 border-transparent data-[state=active]:border-blue-600 data-[state=active]:bg-transparent"
              >
                Symbility ({symbilityCount})
              </TabsTrigger>
            </TabsList>

            <div className="p-4 space-y-4">
              <div className="flex items-center gap-3 flex-wrap">
                <Select value={itemsPerPage} onValueChange={(v) => { setItemsPerPage(v); setCurrentPage(1); }}>
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                    <SelectItem value="250">250</SelectItem>
                    <SelectItem value="500">500</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat} value={cat}>
                        {cat === "all" ? "All Categories" : cat}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Button
                  variant={favoritesOnly ? "default" : "outline"}
                  onClick={() => setFavoritesOnly(!favoritesOnly)}
                  className="flex items-center gap-2"
                >
                  <Star className="w-4 h-4" />
                  Favorites Only
                </Button>

                <Button variant="outline" onClick={handleExport}>
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>

                {selectedItems.length > 0 && (
                  <>
                    <Button 
                      onClick={handleAddToEstimate}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Check className="w-4 h-4 mr-2" />
                      Add {selectedItems.length} to Estimate
                    </Button>
                    <Button variant="outline" onClick={handleBulkDelete}>
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete ({selectedItems.length})
                    </Button>
                  </>
                )}

                <div className="relative flex-1 min-w-[300px] ml-auto">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search items..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b text-left text-sm text-gray-600">
                      <th className="pb-3 pr-4">
                        <Checkbox
                          checked={selectedItems.length === displayedItems.length && displayedItems.length > 0}
                          onCheckedChange={handleSelectAll}
                        />
                      </th>
                      <th className="pb-3 font-medium w-12">Fav</th>
                      <th className="pb-3 font-medium">Code</th>
                      <th className="pb-3 font-medium">Description</th>
                      <th className="pb-3 font-medium">Source</th>
                      <th className="pb-3 font-medium">Price</th>
                      <th className="pb-3 font-medium">Unit</th>
                      <th className="pb-3 font-medium">Category</th>
                      <th className="pb-3 font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {displayedItems.map((item) => (
                      <tr key={item.id} className="border-b hover:bg-gray-50">
                        <td className="py-3 pr-4">
                          <Checkbox
                            checked={selectedItems.includes(item.id)}
                            onCheckedChange={() => handleSelectItem(item.id)}
                          />
                        </td>
                        <td className="py-3">
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => toggleFavoriteMutation.mutate({ 
                              id: item.id, 
                              isFavorite: item.is_favorite 
                            })}
                          >
                            {item.is_favorite ? (
                              <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                            ) : (
                              <StarOff className="w-4 h-4 text-gray-400" />
                            )}
                          </Button>
                        </td>
                        <td className="py-3">
                          <code className="text-sm font-mono font-semibold text-blue-600">
                            {item.code}
                          </code>
                        </td>
                        <td className="py-3 max-w-md">
                          <div className="text-sm text-gray-900 truncate">
                            {item.description}
                          </div>
                        </td>
                        <td className="py-3">
                          <Badge variant="outline" className="text-xs">
                            {item.source || "Custom"}
                          </Badge>
                        </td>
                        <td className="py-3 font-semibold text-green-600">
                          ${item.price?.toFixed(2)}
                        </td>
                        <td className="py-3 text-sm text-gray-600">
                          {item.unit || "EA"}
                        </td>
                        <td className="py-3">
                          <Badge className={`${getCategoryColor(item.category)} text-xs`}>
                            {item.category}
                          </Badge>
                        </td>
                        <td className="py-3">
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => {
                              if (window.confirm('Delete this item?')) {
                                deleteMutation.mutate(item.id);
                              }
                            }}
                          >
                            <Trash2 className="w-4 h-4 text-red-600" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                    {displayedItems.length === 0 && (
                      <tr>
                        <td colSpan={9} className="py-12 text-center text-gray-500">
                          <p className="text-lg font-medium mb-2">No items found</p>
                          <p className="text-sm">Upload items via Integration Manager to get started</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {filteredItems.length > 0 && (
                <div className="flex items-center justify-between pt-4 border-t">
                  <div className="text-sm text-gray-500">
                    Showing {startIndex + 1}-{Math.min(endIndex, filteredItems.length)} of {filteredItems.length} items
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="w-4 h-4" />
                      Previous
                    </Button>

                    {getPageNumbers().map((page, index) => (
                      page === '...' ? (
                        <span key={`ellipsis-${index}`} className="px-2 text-gray-400">...</span>
                      ) : (
                        <Button
                          key={page}
                          variant={currentPage === page ? "default" : "outline"}
                          size="sm"
                          onClick={() => setCurrentPage(page)}
                          className="min-w-[40px]"
                        >
                          {page}
                        </Button>
                      )
                    ))}

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                    >
                      Next
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}