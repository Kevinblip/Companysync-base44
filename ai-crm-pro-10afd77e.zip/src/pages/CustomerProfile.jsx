
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectSeparator } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  User,
  Building,
  Phone,
  Mail,
  MapPin,
  FileText,
  DollarSign,
  CreditCard,
  Briefcase,
  CheckSquare,
  MessageSquare,
  Calendar,
  FileSignature,
  Folder,
  Bell,
  Receipt,
  Save,
  ArrowLeft,
  Plus,
  Loader2,
  Upload,
  Eye,
  Trash2,
  Image, // Added for image error fallback
  Download, // Added for download functionality
  Pencil // Added for file editing
} from "lucide-react";
import { format } from "date-fns";
import { useNavigate, useLocation } from "react-router-dom"; // Added useLocation
import { createPageUrl } from "@/utils";
import Dialer from "../components/communication/Dialer";
import EmailDialog from "../components/communication/EmailDialog";
import SMSDialog from "../components/communication/SMSDialog";

export default function CustomerProfile() {
  const location = useLocation(); // Added from outline
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(location.search); // Added from outline
  const customerNameFromUrl = urlParams.get('name'); // This variable is specifically for quick actions, customerId state is still primary for lookup

  const [customerId, setCustomerId] = useState(null);
  const [activeSection, setActiveSection] = useState("profile");
  const [showDialer, setShowDialer] = useState(false);
  const [showEmailDialog, setShowEmailDialog] = useState(false);
  const [showSMSDialog, setShowSMSDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState(null);

  const [showFileUpload, setShowFileUpload] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [fileForm, setFileForm] = useState({
    label: "",
    category: "", // Changed to support custom categories
    notes: "",
    files: [] // Changed to support multiple files
  });
  const [customCategories, setCustomCategories] = useState([]);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [showAddCategory, setShowAddCategory] = useState(false);
  const [imageErrors, setImageErrors] = useState({}); // New state for image error handling
  const [viewingFile, setViewingFile] = useState(null); // New state for file viewer modal

  const [editingFile, setEditingFile] = useState(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [editForm, setEditForm] = useState({
    document_name: "",
    category: "",
    description: ""
  });

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');
    const name = urlParams.get('name');
    
    if (id) {
      setCustomerId(id);
    } else if (name) {
      // Find customer by name
      setCustomerId(name);
    }
  }, [location.search]); // Depend on location.search to re-run if URL changes

  const { data: customers = [], isLoading: isLoadingCustomers } = useQuery({ // Added isLoadingCustomers
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
    initialData: [],
  });

  const { data: myCompany } = useQuery({
    queryKey: ['myCompany'],
    queryFn: () => base44.entities.Company.list().then(res => res[0]), // Assuming the user's company is the first one
    staleTime: Infinity,
  });

  const customer = customers.find(c => c.id === customerId || c.name === customerId);

  useEffect(() => {
    if (customer) {
      setFormData(customer);
    }
  }, [customer]);

  // Load custom categories from company settings or local storage
  useEffect(() => {
    if (myCompany?.id) {
      const savedCategories = localStorage.getItem(`custom_categories_${myCompany.id}`);
      if (savedCategories) {
        setCustomCategories(JSON.parse(savedCategories));
      }
    }
  }, [myCompany]);

  const { data: estimates = [] } = useQuery({
    queryKey: ['customer-estimates', customer?.name],
    queryFn: () => customer ? base44.entities.Estimate.filter({ customer_name: customer.name }) : [],
    enabled: !!customer,
    initialData: [],
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ['customer-invoices', customer?.name],
    queryFn: () => customer ? base44.entities.Invoice.filter({ customer_name: customer.name }) : [],
    enabled: !!customer,
    initialData: [],
  });

  const { data: payments = [] } = useQuery({
    queryKey: ['customer-payments', customer?.name],
    queryFn: () => customer ? base44.entities.Payment.filter({ customer_name: customer.name }) : [],
    enabled: !!customer,
    initialData: [],
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['customer-projects', customer?.name],
    queryFn: () => customer ? base44.entities.Project.filter({ customer_name: customer.name }) : [],
    enabled: !!customer,
    initialData: [],
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['customer-tasks', customer?.name],
    queryFn: () => customer ? base44.entities.Task.filter({ related_to: customer.name }) : [],
    enabled: !!customer,
    initialData: [],
  });

  const { data: communications = [] } = useQuery({
    queryKey: ['customer-communications', customer?.name],
    queryFn: () => customer ? base44.entities.Communication.filter({ contact_name: customer.name }) : [],
    enabled: !!customer,
    initialData: [],
  });

  const { data: proposals = [] } = useQuery({
    queryKey: ['customer-proposals', customer?.name],
    queryFn: () => customer ? base44.entities.Proposal.filter({ customer_name: customer.name }) : [],
    enabled: !!customer,
    initialData: [],
  });

  const { data: contracts = [] } = useQuery({
    queryKey: ['customer-contracts', customer?.name],
    queryFn: () => customer ? base44.entities.Contract.filter({ customer_name: customer.name }) : [],
    enabled: !!customer,
    initialData: [],
  });

  const { data: calendarEvents = [] } = useQuery({
    queryKey: ['customer-events', customer?.name],
    queryFn: () => customer ? base44.entities.CalendarEvent.filter({ related_customer: customer.name }) : [],
    enabled: !!customer,
    initialData: [],
  });

  const { data: files = [] } = useQuery({
    queryKey: ['customer-files', customer?.name],
    queryFn: () => customer ? base44.entities.Document.filter({ related_customer: customer.name }) : [],
    enabled: !!customer,
    initialData: [],
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Customer.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      setIsEditing(false);
    },
  });

  const isHeicFile = (filename) => {
    return filename?.toLowerCase().endsWith('.heic') || filename?.toLowerCase().endsWith('.heif');
  };

  const uploadFileMutation = useMutation({
    mutationFn: async (data) => {
      if (!myCompany?.id) {
        throw new Error("Company ID not available for file upload.");
      }
      if (!data.files || data.files.length === 0) {
        throw new Error("No files selected for upload.");
      }
      
      // Check for HEIC files
      const heicFiles = Array.from(data.files).filter(f => isHeicFile(f.name));
      if (heicFiles.length > 0) {
        const heicNames = heicFiles.map(f => f.name).join(', ');
        alert(`⚠️ Warning: HEIC files detected (${heicNames}).\n\nHEIC is Apple's format and won't display in browsers.\n\nPlease convert to JPG/PNG first, or they will show as broken images.`);
      }
      
      const uploadPromises = data.files.map(async (file, index) => {
        // Upload to PUBLIC storage
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        
        console.log('File uploaded:', { file_url, fileName: file.name, fileType: file.type });
        
        return base44.entities.Document.create({
          company_id: myCompany.id,
          document_name: data.label ? `${data.label} ${data.files.length > 1 ? index + 1 : ''}`.trim() : file.name,
          file_url: file_url,
          file_size: file.size,
          file_type: file.type,
          category: data.category || "other",
          related_customer: customer.name,
          description: data.notes,
          is_customer_visible: true
        });
      });
      return Promise.all(uploadPromises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customer-files'] });
      setShowFileUpload(false);
      setFileForm({ label: "", category: "", notes: "", files: [] });
    },
    onError: (error) => {
      console.error("File upload failed:", error);
      alert("File upload failed: " + error.message);
    }
  });

  const deleteFileMutation = useMutation({
    mutationFn: (id) => base44.entities.Document.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customer-files'] });
    },
    onError: (error) => {
      console.error("File deletion failed:", error);
      alert("File deletion failed: " + error.message);
    }
  });

  const updateFileMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Document.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customer-files'] });
      setShowEditDialog(false);
      setEditingFile(null);
    },
    onError: (error) => {
      console.error("File update failed:", error);
      alert("File update failed: " + error.message);
    }
  });

  const handleSave = () => {
    if (customer && formData) {
      updateMutation.mutate({ id: customer.id, data: formData });
    }
  };

  const handleFileUpload = async () => {
    if (!fileForm.files || fileForm.files.length === 0) {
      alert("Please select at least one file.");
      return;
    }
    if (!fileForm.category) {
      alert("Please select a category for the files.");
      return;
    }
    if (!myCompany?.id) {
      alert("Company information is not loaded yet. Please try again.");
      return;
    }
    setUploadingFile(true);
    try {
      await uploadFileMutation.mutateAsync(fileForm);
    } catch (error) {
      // Error is already logged in mutation's onError
    } finally {
      setUploadingFile(false);
    }
  };

  const handleAddCategory = () => {
    if (!newCategoryName.trim()) return;
    
    const newCategoryValue = newCategoryName.toLowerCase().replace(/\s+/g, '_');
    if (allCategories.some(cat => cat.value === newCategoryValue)) {
      alert("A category with this name already exists.");
      return;
    }

    const newCategory = {
      value: newCategoryValue,
      label: newCategoryName.trim(),
      icon: "📁", // Default icon for custom categories
      custom: true
    };
    
    const updated = [...customCategories, newCategory];
    setCustomCategories(updated);
    if (myCompany?.id) {
      localStorage.setItem(`custom_categories_${myCompany.id}`, JSON.stringify(updated));
    }
    setNewCategoryName("");
  };

  const handleDeleteCategory = (categoryValue) => {
    if (!window.confirm('Are you sure you want to delete this custom category? Files assigned to this category will remain, but will effectively become uncategorized until re-assigned.')) return;
    
    const updated = customCategories.filter(c => c.value !== categoryValue);
    setCustomCategories(updated);
    if (myCompany?.id) {
      localStorage.setItem(`custom_categories_${myCompany.id}`, JSON.stringify(updated));
    }
  };

  const handleImageError = (fileId, fileUrl) => {
    console.error('Image failed to load:', { 
      fileId, 
      fileUrl: typeof fileUrl === 'string' ? fileUrl : JSON.stringify(fileUrl) 
    });
    setImageErrors(prev => ({ ...prev, [fileId]: true }));
  };

  const handleDownload = async (file) => {
    try {
      const response = await fetch(file.file_url);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.document_name;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
    } catch (error) {
      console.error('Download failed:', error);
      alert('Download failed');
    }
  };

  const handleEditFile = (file) => {
    setEditingFile(file);
    setEditForm({
      document_name: file.document_name || "",
      category: file.category || "",
      description: file.description || ""
    });
    setShowEditDialog(true);
  };

  const handleUpdateFile = () => {
    if (!editForm.document_name) {
      alert("Please enter a file name.");
      return;
    }
    if (!editForm.category) {
      alert("Please select a category for the file.");
      return;
    }
    updateFileMutation.mutate({
      id: editingFile.id,
      data: {
        document_name: editForm.document_name,
        category: editForm.category,
        description: editForm.description
      }
    });
  };

  // --- New functions from outline ---
  const handleCreateEstimate = () => {
    if (!customer) return;
    
    // Navigate to Estimates page with pre-filled customer data
    const params = new URLSearchParams({
      prefill: 'true',
      customer_name: customer.name,
      customer_email: customer.email || '',
      customer_phone: customer.phone || '',
      create_new: 'true'
    });
    
    navigate(createPageUrl('Estimates') + '?' + params.toString());
  };

  const handleCreateInvoice = () => {
    if (!customer) return;
    
    const params = new URLSearchParams({
      prefill: 'true',
      customer_name: customer.name,
      customer_email: customer.email || '',
      create_new: 'true'
    });
    
    navigate(createPageUrl('Invoices') + '?' + params.toString());
  };

  const handleCreateProject = () => {
    if (!customer) return;
    
    const params = new URLSearchParams({
      prefill: 'true',
      customer_name: customer.name,
      create_new: 'true'
    });
    
    navigate(createPageUrl('Projects') + '?' + params.toString());
  };
  // --- End new functions ---

  // Group files by category
  const filesByCategory = files.reduce((acc, file) => {
    const cat = file.category || 'other';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(file);
    return acc;
  }, {});

  const defaultCategories = [
    { value: "front", label: "Front View", icon: "🏠" },
    { value: "rear", label: "Rear View", icon: "🏡" },
    { value: "left_slope", label: "Left Slope", icon: "📐" },
    { value: "right_slope", label: "Right Slope", icon: "📐" },
    { value: "left_elevation", label: "Left Elevation", icon: "🏢" },
    { value: "right_elevation", label: "Right Elevation", icon: "🏢" },
    { value: "roof_detail", label: "Roof Detail", icon: "🔍" },
    { value: "damage", label: "Damage Photo", icon: "⚠️" },
    { value: "contract", label: "Contract", icon: "📄" },
    { value: "invoice", label: "Invoice", icon: "🧾" },
    { value: "other", label: "Other", icon: "📸" }
  ];

  const allCategories = [...defaultCategories, ...customCategories];

  // Modified loading state to use isLoadingCustomers
  if (isLoadingCustomers) {
    return (
      <div className="p-6">
        <Card className="p-12 text-center flex flex-col items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-gray-400 mb-4" />
          <p className="text-gray-500">Loading customer profile...</p>
        </Card>
      </div>
    );
  }

  if (!customer || !formData) { // formData will also be null if customer is null
    return (
      <div className="p-6">
        <div className="flex items-center gap-3 mb-6">
          <Button variant="outline" onClick={() => navigate(createPageUrl('Customers'))}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Customers
          </Button>
        </div>
        <Card className="p-12 text-center">
          <p className="text-gray-500">Customer not found</p>
        </Card>
      </div>
    );
  }

  const sections = [
    { id: "profile", label: "Profile", icon: User },
    { id: "notes", label: "Notes", icon: FileText, count: 0 },
    { id: "invoices", label: "Invoices", icon: Receipt, count: invoices.length },
    { id: "payments", label: "Payments", icon: DollarSign, count: payments.length },
    { id: "proposals", label: "Proposals", icon: FileSignature, count: proposals.length },
    { id: "estimates", label: "Estimates", icon: FileText, count: estimates.length },
    { id: "contracts", label: "Contracts", icon: FileSignature, count: contracts.length },
    { id: "projects", label: "Projects", icon: Briefcase, count: projects.length },
    { id: "tasks", label: "Tasks", icon: CheckSquare, count: tasks.length },
    { id: "communications", label: "Communications", icon: MessageSquare, count: communications.length },
    { id: "calendar", label: "Calendar", icon: Calendar, count: calendarEvents.length },
    { id: "files", label: "Files", icon: Folder, count: files.length },
    { id: "reminders", label: "Reminders", icon: Bell, count: 0 },
  ];

  const totalRevenue = [...payments.filter(p => p.status === 'received'), ...invoices.filter(i => i.status === 'paid')].reduce((sum, item) => sum + (item.amount || 0), 0);
  const openEstimates = estimates.filter(e => ['draft', 'sent', 'viewed'].includes(e.status)).reduce((sum, e) => sum + (e.amount || 0), 0);
  const unpaidInvoices = invoices.filter(i => ['sent', 'overdue', 'partially_paid'].includes(i.status)).reduce((sum, i) => sum + (i.amount || 0), 0);

  return (
    // Replaced main div and header as per outline
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header with Quick Actions */}
      <Card className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center">
                <User className="w-10 h-10 text-blue-600" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">{customer.name}</h1>
                {customer.company && (
                  <p className="text-blue-100 text-lg">{customer.company}</p>
                )}
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="secondary" className={customer.is_active ? "bg-green-500" : "bg-gray-500"}>
                    {customer.is_active ? "Active" : "Inactive"}
                  </Badge>
                  {customer.customer_type && ( // Assuming customer_type exists on customer object
                    <Badge variant="secondary" className="bg-purple-500">
                      {customer.customer_type}
                    </Badge>
                  )}
                </div>
              </div>
            </div>

            {/* Quick Action Buttons - Responsive Layout */}
            <div className="grid grid-cols-2 lg:flex lg:flex-row gap-2">
              <Button 
                onClick={handleCreateEstimate}
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                <FileText className="w-4 h-4 mr-2" />
                New Estimate
              </Button>
              <Button 
                onClick={handleCreateInvoice}
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                <DollarSign className="w-4 h-4 mr-2" />
                New Invoice
              </Button>
              <Button 
                onClick={handleCreateProject}
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                <Briefcase className="w-4 h-4 mr-2" />
                New Project
              </Button>
              <Button 
                onClick={() => setShowDialer(true)}
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                <Phone className="w-4 h-4 mr-2" />
                Call
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content using Tabs */}
      <Tabs defaultValue="profile" className="w-full">
        <div className="flex"> {/* This flex container was previously the root of the main content */}
          {/* Left Sidebar */}
          <div className="w-64 bg-white border-r min-h-screen">
            <ScrollArea className="h-full">
              <div className="p-4 space-y-1">
                {sections.map((section) => {
                  const Icon = section.icon;
                  return (
                    <button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-colors ${
                        activeSection === section.id
                          ? 'bg-blue-50 text-blue-700 font-medium'
                          : 'text-gray-700 hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4" />
                        <span>{section.label}</span>
                      </div>
                      {section.count !== undefined && section.count > 0 && (
                        <Badge variant="secondary" className="text-xs">
                          {section.count}
                        </Badge>
                      )}
                    </button>
                  );
                })}
              </div>
            </ScrollArea>
          </div>

          {/* Right Content */}
          <div className="flex-1 p-6">
            {activeSection === "profile" && (
              <Card>
                <CardContent className="p-6">
                  <Tabs defaultValue="details">
                    <div className="flex items-center justify-between mb-4">
                      <TabsList>
                        <TabsTrigger value="details">Customer Details</TabsTrigger>
                        <TabsTrigger value="billing">Billing & Shipping</TabsTrigger>
                      </TabsList>
                      {isEditing ? (
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" onClick={() => {
                            setIsEditing(false);
                            setFormData(customer);
                          }}>
                            Cancel
                          </Button>
                          <Button size="sm" onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
                            <Save className="w-4 h-4 mr-2" />
                            Save
                          </Button>
                        </div>
                      ) : (
                        <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                          Edit
                        </Button>
                      )}
                    </div>

                    <TabsContent value="details" className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Primary Contact Name</Label>
                          <Input
                            value={formData.name}
                            onChange={(e) => setFormData({...formData, name: e.target.value})}
                            disabled={!isEditing}
                          />
                        </div>
                        <div>
                          <Label>Company</Label>
                          <Input
                            value={formData.company || ""}
                            onChange={(e) => setFormData({...formData, company: e.target.value})}
                            disabled={!isEditing}
                          />
                        </div>
                        <div>
                          <Label>Phone</Label>
                          <Input
                            value={formData.phone || ""}
                            onChange={(e) => setFormData({...formData, phone: e.target.value})}
                            disabled={!isEditing}
                          />
                        </div>
                        <div>
                          <Label>Phone 2</Label>
                          <Input
                            value={formData.phone_2 || ""}
                            onChange={(e) => setFormData({...formData, phone_2: e.target.value})}
                            disabled={!isEditing}
                          />
                        </div>
                        <div className="col-span-2">
                          <Label>Email</Label>
                          <Input
                            type="email"
                            value={formData.email || ""}
                            onChange={(e) => setFormData({...formData, email: e.target.value})}
                            disabled={!isEditing}
                          />
                        </div>
                        <div>
                          <Label>Group</Label>
                          <Input
                            value={formData.group || ""}
                            onChange={(e) => setFormData({...formData, group: e.target.value})}
                            disabled={!isEditing}
                            placeholder="e.g., VIP, Retail Sales"
                          />
                        </div>
                        <div className="flex items-center gap-3 pt-6">
                          <Switch
                            checked={formData.is_active}
                            onCheckedChange={(checked) => setFormData({...formData, is_active: checked})}
                            disabled={!isEditing}
                          />
                          <Label>Active</Label>
                        </div>
                      </div>

                      <div className="border-t pt-4 mt-4">
                        <h3 className="font-semibold mb-3">Insurance Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Insurance Company</Label>
                            <Input
                              value={formData.insurance_company || ""}
                              onChange={(e) => setFormData({...formData, insurance_company: e.target.value})}
                              disabled={!isEditing}
                              placeholder="e.g., State Farm"
                            />
                          </div>
                          <div>
                            <Label>Adjuster Name</Label>
                            <Input
                              value={formData.adjuster_name || ""}
                              onChange={(e) => setFormData({...formData, adjuster_name: e.target.value})}
                              disabled={!isEditing}
                            />
                          </div>
                          <div>
                            <Label>Adjuster Phone</Label>
                            <Input
                              value={formData.adjuster_phone || ""}
                              onChange={(e) => setFormData({...formData, adjuster_phone: e.target.value})}
                              disabled={!isEditing}
                            />
                          </div>
                        </div>
                      </div>

                      <div>
                        <Label>Notes</Label>
                        <Textarea
                          value={formData.notes || ""}
                          onChange={(e) => setFormData({...formData, notes: e.target.value})}
                          disabled={!isEditing}
                          rows={4}
                          placeholder="Internal notes about this customer..."
                        />
                      </div>
                    </TabsContent>

                    <TabsContent value="billing" className="space-y-4">
                      <div>
                        <Label>Address</Label>
                        <Textarea
                          value={formData.address || ""}
                          onChange={(e) => setFormData({...formData, address: e.target.value})}
                          disabled={!isEditing}
                          rows={3}
                          placeholder="Street address, city, state, zip"
                        />
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            )}

            {activeSection === "estimates" && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Estimates ({estimates.length})</h2>
                    {/* Removed redundant "New Estimate" button, now in the quick actions header */}
                  </div>
                  <div className="space-y-3">
                    {estimates.map((estimate) => (
                      <div key={estimate.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer" onClick={() => navigate(createPageUrl('Estimates'))}>
                        <div>
                          <div className="font-medium">{estimate.estimate_number}</div>
                          <div className="text-sm text-gray-500">
                            {estimate.created_date ? format(new Date(estimate.created_date), 'MMM d, yyyy') : ''}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-green-600">${estimate.amount?.toFixed(2)}</div>
                          <Badge variant="outline" className={
                            estimate.status === 'accepted' ? 'bg-green-100 text-green-700' :
                            estimate.status === 'sent' ? 'bg-blue-100 text-blue-700' :
                            estimate.status === 'declined' ? 'bg-red-100 text-red-700' :
                            'bg-gray-100 text-gray-700'
                          }>
                            {estimate.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {estimates.length === 0 && (
                      <div className="text-center py-12 text-gray-500">
                        No estimates yet
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "invoices" && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Invoices ({invoices.length})</h2>
                    {/* Removed redundant "New Invoice" button, now in the quick actions header */}
                  </div>
                  <div className="space-y-3">
                    {invoices.map((invoice) => (
                      <div key={invoice.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer" onClick={() => navigate(createPageUrl('Invoices'))}>
                        <div>
                          <div className="font-medium">{invoice.invoice_number}</div>
                          <div className="text-sm text-gray-500">
                            Due: {invoice.due_date ? format(new Date(invoice.due_date), 'MMM d, yyyy') : 'No due date'}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-green-600">${invoice.amount?.toFixed(2)}</div>
                          <Badge variant="outline" className={
                            invoice.status === 'paid' ? 'bg-green-100 text-green-700' :
                            invoice.status === 'overdue' ? 'bg-red-100 text-red-700' :
                            'bg-blue-100 text-blue-700'
                          }>
                            {invoice.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {invoices.length === 0 && (
                      <div className="text-center py-12 text-gray-500">
                        No invoices yet
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "payments" && (
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold mb-4">Payments ({payments.length})</h2>
                  <div className="space-y-3">
                    {payments.map((payment) => (
                      <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                        <div>
                          <div className="font-medium">{payment.payment_number}</div>
                          <div className="text-sm text-gray-500">
                            {payment.payment_date ? format(new Date(payment.payment_date), 'MMM d, yyyy') : ''}
                          </div>
                          <div className="text-xs text-gray-400">{payment.payment_method}</div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-green-600">${payment.amount?.toFixed(2)}</div>
                          <Badge variant="outline" className="bg-green-100 text-green-700">
                            {payment.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {payments.length === 0 && (
                      <div className="text-center py-12 text-gray-500">
                        No payments yet
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "projects" && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Projects ({projects.length})</h2>
                    {/* Removed redundant "New Project" button, now in the quick actions header */}
                  </div>
                  <div className="space-y-3">
                    {projects.map((project) => (
                      <div key={project.id} className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer" onClick={() => navigate(createPageUrl('Projects'))}>
                        <div className="flex items-center justify-between">
                          <div className="font-medium">{project.name}</div>
                          <Badge variant="outline">
                            {project.status}
                          </Badge>
                        </div>
                        {project.description && (
                          <div className="text-sm text-gray-500 mt-2">{project.description}</div>
                        )}
                        <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
                          {project.start_date && <span>Start: {format(new Date(project.start_date), 'MMM d, yyyy')}</span>}
                          {project.deadline && <span>Deadline: {format(new Date(project.deadline), 'MMM d, yyyy')}</span>}
                          {project.budget && <span>Budget: ${project.budget.toFixed(2)}</span>}
                        </div>
                      </div>
                    ))}
                    {projects.length === 0 && (
                      <div className="text-center py-12 text-gray-500">
                        No projects yet
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "tasks" && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Tasks ({tasks.length})</h2>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={() => navigate(createPageUrl('Tasks'))}>
                      <Plus className="w-4 h-4 mr-2" />
                      New Task
                    </Button>
                  </div>
                  <div className="space-y-3">
                    {tasks.map((task) => (
                      <div key={task.id} className="flex items-center gap-3 p-4 border rounded-lg hover:bg-gray-50">
                        <input type="checkbox" checked={task.status === 'job_completed'} readOnly className="w-4 h-4" />
                        <div className="flex-1">
                          <div className="font-medium">{task.name}</div>
                          {task.description && <div className="text-sm text-gray-500">{task.description}</div>}
                          {task.due_date && (
                            <div className="text-xs text-gray-400 mt-1">
                              Due: {format(new Date(task.due_date), 'MMM d, yyyy')}
                            </div>
                          )}
                        </div>
                        <Badge variant="outline">
                          {task.status}
                        </Badge>
                      </div>
                    ))}
                    {tasks.length === 0 && (
                      <div className="text-center py-12 text-gray-500">
                        No tasks yet
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "communications" && (
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-bold mb-4">Communication History ({communications.length})</h2>
                  <div className="space-y-3">
                    {communications.map((comm) => (
                      <div key={comm.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            {comm.communication_type === 'call' && <Phone className="w-4 h-4 text-blue-600" />}
                            {comm.communication_type === 'email' && <Mail className="w-4 h-4 text-purple-600" />}
                            {comm.communication_type === 'sms' && <MessageSquare className="w-4 h-4 text-green-600" />}
                            <span className="font-medium capitalize">{comm.communication_type}</span>
                          </div>
                          <span className="text-sm text-gray-500">
                            {format(new Date(comm.created_date), 'MMM d, yyyy h:mm a')}
                          </span>
                        </div>
                        {comm.subject && <div className="font-medium mb-1">{comm.subject}</div>}
                        {comm.message && <div className="text-sm text-gray-600">{comm.message}</div>}
                        {comm.duration_minutes && (
                          <div className="text-xs text-gray-400 mt-2">Duration: {comm.duration_minutes} minutes</div>
                        )}
                      </div>
                    ))}
                    {communications.length === 0 && (
                      <div className="text-center py-12 text-gray-500">
                        No communications yet
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "proposals" && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Proposals ({proposals.length})</h2>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={() => navigate(createPageUrl('Proposals'))}>
                      <Plus className="w-4 h-4 mr-2" />
                      New Proposal
                    </Button>
                  </div>
                  <div className="space-y-3">
                    {proposals.map((proposal) => (
                      <div key={proposal.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                        <div>
                          <div className="font-medium">{proposal.proposal_number}</div>
                          <div className="text-sm text-gray-600">{proposal.title}</div>
                          <div className="text-xs text-gray-400 mt-1">
                            {proposal.created_date ? format(new Date(proposal.created_date), 'MMM d, yyyy') : ''}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold text-green-600">${proposal.amount?.toFixed(2)}</div>
                          <Badge variant="outline">
                            {proposal.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {proposals.length === 0 && (
                      <div className="text-center py-12 text-gray-500">
                        No proposals yet
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "contracts" && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Contracts ({contracts.length})</h2>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={() => navigate(createPageUrl('Contracts'))}>
                      <Plus className="w-4 h-4 mr-2" />
                      New Contract
                    </Button>
                  </div>
                  <div className="space-y-3">
                    {contracts.map((contract) => (
                      <div key={contract.id} className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer">
                        <div className="flex items-center justify-between">
                          <div className="font-medium">{contract.contract_name}</div>
                          <Badge variant="outline">
                            {contract.status}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
                          <span>Type: {contract.contract_type}</span>
                          {contract.start_date && <span>Start: {format(new Date(contract.start_date), 'MMM d, yyyy')}</span>}
                          {contract.end_date && <span>End: {format(new Date(contract.end_date), 'MMM d, yyyy')}</span>}
                          {contract.value && <span>Value: ${contract.value.toFixed(2)}</span>}
                        </div>
                      </div>
                    ))}
                    {contracts.length === 0 && (
                      <div className="text-center py-12 text-gray-500">
                        No contracts yet
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "calendar" && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-xl font-bold">Calendar Events ({calendarEvents.length})</h2>
                    <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={() => navigate(createPageUrl('Calendar'))}>
                      <Plus className="w-4 h-4 mr-2" />
                      Schedule Event
                    </Button>
                  </div>
                  <div className="space-y-3">
                    {calendarEvents.map((event) => (
                      <div key={event.id} className="p-4 border rounded-lg hover:bg-gray-50">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium">{event.title}</div>
                            <div className="text-sm text-gray-600 mt-1">
                              {format(new Date(event.start_time), 'MMM d, yyyy h:mm a')}
                            </div>
                            {event.location && <div className="text-xs text-gray-400 mt-1">📍 {event.location}</div>}
                          </div>
                          <Badge variant="outline">
                            {event.event_type}
                          </Badge>
                        </div>
                      </div>
                    ))}
                    {calendarEvents.length === 0 && (
                      <div className="text-center py-12 text-gray-500">
                        No calendar events yet
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            {activeSection === "files" && (
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-bold flex items-center gap-2">
                      <Folder className="w-5 h-5 text-blue-600" />
                      Files & Photos ({files.length})
                    </h2>
                    <Button onClick={() => setShowFileUpload(true)} className="bg-blue-600 hover:bg-blue-700">
                      <Plus className="w-4 h-4 mr-2" />
                      Upload Files
                    </Button>
                  </div>

                  {/* Upload Dialog */}
                  {showFileUpload && (
                    <div className="mb-6 p-6 bg-blue-50 border-2 border-blue-200 rounded-lg">
                      <h3 className="font-semibold mb-4">Upload Files (Batch Upload)</h3>
                      <div className="space-y-4">
                        <div>
                          <Label>Select Files * (you can select multiple)</Label>
                          <Input
                            type="file"
                            accept="image/jpeg,image/jpg,image/png,image/gif,image/webp,.pdf,.doc,.docx,.xlsx,.pptx,.txt"
                            multiple
                            onChange={(e) => setFileForm({...fileForm, files: Array.from(e.target.files)})}
                          />
                          {fileForm.files.length > 0 && (
                            <div className="mt-2 text-sm text-gray-600">
                              <p className="font-medium">{fileForm.files.length} file(s) selected:</p>
                              <ul className="list-disc list-inside max-h-20 overflow-y-auto">
                                {Array.from(fileForm.files).map((file, idx) => (
                                  <li key={idx} className={isHeicFile(file.name) ? 'text-red-600 font-semibold' : ''}>
                                    {file.name} {isHeicFile(file.name) && '⚠️ HEIC - Won\'t display!'}
                                  </li>
                                ))}
                              </ul>
                              {Array.from(fileForm.files).some(f => isHeicFile(f.name)) && (
                                <p className="text-red-600 text-xs mt-2">
                                  ⚠️ HEIC files won't display in browsers. Please convert to JPG/PNG first!
                                </p>
                              )}
                            </div>
                          )}
                          <p className="text-xs text-gray-500 mt-1">
                            Supported: JPG, PNG, GIF, WebP, PDF, DOC, DOCX, XLSX, TXT (NOT HEIC)
                          </p>
                        </div>

                        <div>
                          <Label>Category *</Label>
                          <div className="flex gap-2 items-start">
                            <Select
                              value={fileForm.category}
                              onValueChange={(v) => {
                                  setFileForm({...fileForm, category: v});
                                  setShowAddCategory(false); // Close add category section if user selects an existing one
                              }}
                            >
                              <SelectTrigger className="flex-1">
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                              <SelectContent>
                                <div className="px-2 py-1.5 border-b sticky top-0 bg-white z-10">
                                  <p className="text-xs font-semibold text-gray-500 uppercase">Default Categories</p>
                                </div>
                                {defaultCategories.map(cat => (
                                  <SelectItem key={cat.value} value={cat.value}>
                                    <div className="flex items-center gap-2">
                                      {cat.icon} {cat.label}
                                    </div>
                                  </SelectItem>
                                ))}
                                {customCategories.length > 0 && (
                                  <>
                                    <SelectSeparator />
                                    <div className="px-2 py-1.5 border-b sticky top-0 bg-white z-10">
                                      <p className="text-xs font-semibold text-gray-500 uppercase">Custom Categories</p>
                                    </div>
                                    {customCategories.map(cat => (
                                      <SelectItem key={cat.value} value={cat.value}>
                                        <div className="flex items-center gap-2">
                                          {cat.icon} {cat.label}
                                        </div>
                                      </SelectItem>
                                    ))}
                                  </>
                                )}
                              </SelectContent>
                            </Select>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => setShowAddCategory(!showAddCategory)}
                              title="Add or manage custom categories"
                            >
                              <Plus className="w-4 h-4" />
                            </Button>
                          </div>

                          {showAddCategory && (
                            <div className="flex flex-col gap-2 mt-2 p-3 border rounded-md bg-gray-50">
                              <div className="flex gap-2">
                                <Input
                                  placeholder="New category name"
                                  value={newCategoryName}
                                  onChange={(e) => setNewCategoryName(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      e.preventDefault();
                                      handleAddCategory();
                                    }
                                  }}
                                />
                                <Button onClick={handleAddCategory} size="sm">
                                  Add
                                </Button>
                              </div>
                              {customCategories.length > 0 && (
                                <div className="mt-2 space-y-1">
                                  <p className="text-xs font-semibold text-gray-500">Existing Custom Categories:</p>
                                  {customCategories.map(cat => (
                                    <div key={cat.value} className="flex items-center justify-between p-1 pl-2 text-sm bg-white rounded-md border">
                                      <span className="flex items-center gap-2">
                                        {cat.icon} {cat.label}
                                      </span>
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        onClick={() => handleDeleteCategory(cat.value)}
                                        className="h-6 w-6 p-0 text-red-600"
                                        title={`Delete ${cat.label} category`}
                                      >
                                        <Trash2 className="w-3 h-3" />
                                      </Button>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          )}
                        </div>

                        <div>
                          <Label>Label / Title (optional)</Label>
                          <Input
                            value={fileForm.label}
                            onChange={(e) => setFileForm({...fileForm, label: e.target.value})}
                            placeholder="e.g., Left Elevation - will add numbers if multiple files"
                          />
                        </div>

                        <div>
                          <Label>Notes (optional)</Label>
                          <Textarea
                            value={fileForm.notes}
                            onChange={(e) => setFileForm({...fileForm, notes: e.target.value})}
                            placeholder="Add any notes about these files..."
                            rows={3}
                          />
                        </div>

                        <div className="flex gap-3 justify-end">
                          <Button 
                            variant="outline" 
                            onClick={() => {
                              setShowFileUpload(false);
                              setFileForm({ label: "", category: "", notes: "", files: [] });
                              setShowAddCategory(false);
                            }}
                            disabled={uploadingFile}
                          >
                            Cancel
                          </Button>
                          <Button 
                            onClick={handleFileUpload}
                            disabled={fileForm.files.length === 0 || !fileForm.category || uploadingFile}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            {uploadingFile ? (
                              <>
                                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                Uploading {fileForm.files.length} file(s)...
                              </>
                            ) : (
                              <>
                                <Upload className="w-4 h-4 mr-2" />
                                Upload {fileForm.files.length > 0 && `(${fileForm.files.length})`}
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Edit File Dialog */}
                  {showEditDialog && editingFile && (
                    <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
                      <DialogContent className="max-w-lg">
                        <DialogHeader>
                          <DialogTitle>Edit File Details</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 pt-4">
                          <div>
                            <Label>File Name *</Label>
                            <Input
                              value={editForm.document_name}
                              onChange={(e) => setEditForm({...editForm, document_name: e.target.value})}
                              placeholder="e.g., Front Elevation 1"
                            />
                          </div>
                          <div>
                            <Label>Category *</Label>
                            <Select
                              value={editForm.category}
                              onValueChange={(v) => setEditForm({...editForm, category: v})}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                              <SelectContent>
                                <div className="px-2 py-1.5 border-b sticky top-0 bg-white z-10">
                                  <p className="text-xs font-semibold text-gray-500 uppercase">Default Categories</p>
                                </div>
                                {defaultCategories.map(cat => (
                                  <SelectItem key={cat.value} value={cat.value}>
                                    <div className="flex items-center gap-2">
                                      {cat.icon} {cat.label}
                                    </div>
                                  </SelectItem>
                                ))}
                                {customCategories.length > 0 && (
                                  <>
                                    <SelectSeparator />
                                    <div className="px-2 py-1.5 border-b sticky top-0 bg-white z-10">
                                      <p className="text-xs font-semibold text-gray-500 uppercase">Custom Categories</p>
                                    </div>
                                    {customCategories.map(cat => (
                                      <SelectItem key={cat.value} value={cat.value}>
                                        <div className="flex items-center gap-2">
                                          {cat.icon} {cat.label}
                                        </div>
                                      </SelectItem>
                                    ))}
                                  </>
                                )}
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label>Notes</Label>
                            <Textarea
                              value={editForm.description}
                              onChange={(e) => setEditForm({...editForm, description: e.target.value})}
                              placeholder="Add notes about this file..."
                              rows={4}
                            />
                          </div>
                          <div className="flex justify-end gap-3">
                            <Button
                              variant="outline"
                              onClick={() => {
                                setShowEditDialog(false);
                                setEditingFile(null);
                              }}
                            >
                              Cancel
                            </Button>
                            <Button
                              onClick={handleUpdateFile}
                              disabled={updateFileMutation.isLoading}
                              className="bg-blue-600 hover:bg-blue-700"
                            >
                              {updateFileMutation.isLoading ? (
                                <>
                                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                                  Saving...
                                </>
                              ) : (
                                <>
                                  <Save className="w-4 h-4 mr-2" />
                                  Save Changes
                                </>
                              )}
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}

                  {/* Files Grid by Category */}
                  {Object.keys(filesByCategory).length === 0 ? (
                    <div className="text-center py-12 text-gray-500">
                      <Folder className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                      <p>No files uploaded yet</p>
                      <p className="text-xs mt-2">Click "Upload Files" to add documents or photos.</p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {Object.entries(filesByCategory).sort(([catA], [catB]) => {
                        if (catA === 'other') return 1;
                        if (catB === 'other') return -1;
                        const labelA = allCategories.find(c => c.value === catA)?.label || catA.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
                        const labelB = allCategories.find(c => c.value === catB)?.label || catB.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
                        return labelA.localeCompare(labelB);
                      }).map(([category, categoryFiles]) => {
                        const catInfo = allCategories.find(c => c.value === category) || { 
                          label: category.replace(/_/g, ' ').replace(/\b\w/g, char => char.toUpperCase()), 
                          icon: "📁",
                          custom: false
                        };
                        return (
                          <div key={category} className="border rounded-lg p-4 bg-white">
                            <div className="flex items-center justify-between mb-3">
                              <h3 className="font-semibold flex items-center gap-2 text-gray-800">
                                <span>{catInfo.icon}</span>
                                <span>{catInfo.label}</span>
                                <Badge variant="secondary">{categoryFiles.length}</Badge>
                              </h3>
                              {catInfo.custom && (
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleDeleteCategory(category)}
                                  className="text-red-600 hover:text-red-700"
                                  title={`Delete ${catInfo.label} category`}
                                >
                                  <Trash2 className="w-4 h-4 mr-1" />
                                  Delete Category
                                </Button>
                              )}
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                              {categoryFiles.map((file) => {
                                const isHeic = isHeicFile(file.document_name);
                                
                                return (
                                  <div 
                                    key={file.id} 
                                    className="group relative border rounded-lg overflow-hidden bg-gray-50 hover:shadow-lg transition-shadow duration-200 cursor-pointer"
                                    onClick={() => setViewingFile(file)}
                                  >
                                    {file.file_type?.startsWith('image/') && !isHeic ? (
                                      imageErrors[file.id] ? (
                                        <div className="w-full h-40 bg-gray-200 flex flex-col items-center justify-center text-gray-500 p-2">
                                          <Image className="w-12 h-12 mb-2" />
                                          <p className="text-xs font-semibold mb-1">Image failed to load</p>
                                          <p className="text-xs text-gray-400 break-all px-2 text-center">
                                            {file.file_url || 'No URL'}
                                          </p>
                                        </div>
                                      ) : (
                                        <img 
                                          src={file.file_url} 
                                          alt={file.document_name}
                                          className="w-full h-40 object-cover"
                                          onError={() => handleImageError(file.id, file.file_url)}
                                          loading="lazy"
                                        />
                                      )
                                    ) : isHeic ? (
                                      <div className="w-full h-40 bg-yellow-100 flex flex-col items-center justify-center text-yellow-800 p-3">
                                        <Image className="w-12 h-12 mb-2" />
                                        <p className="text-xs font-semibold text-center">HEIC Format</p>
                                        <p className="text-xs text-center mt-1">Can't display in browser</p>
                                        <p className="text-xs text-center mt-1">Click to download</p>
                                      </div>
                                    ) : (
                                      <div className="w-full h-40 bg-gray-100 flex items-center justify-center">
                                        <FileText className="w-12 h-12 text-gray-400" />
                                      </div>
                                    )}
                                    <div className="p-3">
                                      <p className="font-medium text-sm truncate">{file.document_name}</p>
                                      {file.description && (
                                        <p className="text-xs text-gray-500 mt-1 line-clamp-2">{file.description}</p>
                                      )}
                                      <p className="text-xs text-gray-400 mt-1">
                                        {file.created_date ? format(new Date(file.created_date), 'MMM d, yyyy') : ''}
                                      </p>
                                    </div>
                                    <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                      <Button
                                        size="icon"
                                        variant="outline"
                                        className="bg-white h-7 w-7 p-0"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleEditFile(file);
                                        }}
                                        title="Edit file details"
                                      >
                                        <Pencil className="w-4 h-4" />
                                      </Button>
                                      <Button
                                        size="icon"
                                        variant="outline"
                                        className="bg-white h-7 w-7 p-0"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          handleDownload(file);
                                        }}
                                        title="Download File"
                                      >
                                        <Download className="w-4 h-4" />
                                      </Button>
                                      <Button
                                        size="icon"
                                        variant="outline"
                                        className="bg-white text-red-600 h-7 w-7 p-0"
                                        onClick={(e) => {
                                          e.stopPropagation();
                                          if (window.confirm('Are you sure you want to delete this file?')) {
                                            deleteFileMutation.mutate(file.id);
                                          }
                                        }}
                                        title="Delete File"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </Button>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {(activeSection === "notes" || activeSection === "reminders") && (
              <Card>
                <CardContent className="p-12 text-center text-gray-500">
                  <p>This section is coming soon!</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </Tabs> {/* End of Tabs component */}

      {/* File Viewer Modal */}
      {viewingFile && (
        <Dialog open={!!viewingFile} onOpenChange={() => setViewingFile(null)}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center justify-between">
                <span>{viewingFile.document_name}</span>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleDownload(viewingFile)}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              {isHeicFile(viewingFile.document_name) ? (
                <div className="text-center py-12 bg-yellow-50 rounded-lg border-2 border-yellow-200">
                  <Image className="w-16 h-16 mx-auto mb-4 text-yellow-600" />
                  <p className="text-yellow-800 font-semibold mb-2">⚠️ HEIC Format Not Supported</p>
                  <p className="text-sm text-yellow-700 mb-4">
                    HEIC is Apple's format and can't be displayed in web browsers.
                  </p>
                  <p className="text-sm text-yellow-700 mb-4">
                    Please convert to JPG or PNG to view in browser.
                  </p>
                  <Button onClick={() => handleDownload(viewingFile)} className="bg-yellow-600 hover:bg-yellow-700">
                    <Download className="w-4 h-4 mr-2" />
                    Download HEIC File
                  </Button>
                </div>
              ) : viewingFile.file_type?.startsWith('image/') ? (
                <>
                  <img 
                    src={viewingFile.file_url} 
                    alt={viewingFile.document_name}
                    className="w-full h-auto rounded-lg"
                    onError={(e) => {
                      console.error('Modal image failed to load:', {
                        fileUrl: typeof viewingFile.file_url === 'string' ? viewingFile.file_url : JSON.stringify(viewingFile.file_url)
                      });
                      e.target.style.display = 'none';
                      e.target.nextSibling.style.display = 'block';
                    }}
                  />
                  <div style={{display: 'none'}} className="text-center py-12 bg-gray-100 rounded-lg">
                    <p className="text-red-600 mb-2">⚠️ Image failed to load</p>
                    <p className="text-xs text-gray-500 mb-4 break-all px-4">URL: {viewingFile.file_url}</p>
                    <Button onClick={() => handleDownload(viewingFile)}>
                      <Download className="w-4 h-4 mr-2" />
                      Download Instead
                    </Button>
                  </div>
                </>
              ) : viewingFile.file_type === 'application/pdf' ? (
                <iframe 
                  src={viewingFile.file_url} 
                  className="w-full h-[600px] rounded-lg border"
                  title={viewingFile.document_name}
                />
              ) : (
                <div className="text-center py-12">
                  <FileText className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-600 mb-4">Preview not available for this file type</p>
                  <Button onClick={() => handleDownload(viewingFile)}>
                    <Download className="w-4 h-4 mr-2" />
                    Download File
                  </Button>
                </div>
              )}
              {viewingFile.description && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <p className="text-sm font-medium text-gray-700 mb-1">Notes:</p>
                  <p className="text-sm text-gray-600">{viewingFile.description}</p>
                </div>
              )}
              <div className="text-xs text-gray-500">
                Uploaded: {viewingFile.created_date ? format(new Date(viewingFile.created_date), 'PPP') : 'Unknown'}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* Communication Dialogs */}
      <Dialer 
        open={showDialer} 
        onOpenChange={setShowDialer}
        defaultNumber={customer.phone || customer.phone_2}
        defaultName={customer.name} // Added defaultName
      />
      <EmailDialog 
        open={showEmailDialog} 
        onOpenChange={setShowEmailDialog}
        defaultTo={customer.email}
        defaultName={customer.name}
        companyId={myCompany?.id} // Added companyId
      />
      <SMSDialog 
        open={showSMSDialog} 
        onOpenChange={setShowSMSDialog}
        defaultTo={customer.phone || customer.phone_2}
        defaultName={customer.name} // Added defaultName for consistency
      />
    </div>
  );
}
