import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, Briefcase, MessageSquare, Phone, Mail, FileText } from "lucide-react";

export default function AIStaff() {
  const aiStaff = [
    {
      name: "Sarah - Sales Assistant",
      role: "Lead Qualifier & Follow-up",
      icon: Phone,
      status: "Active",
      tasks: ["Qualify inbound leads", "Schedule appointments", "Send follow-up emails"],
      color: "from-blue-500 to-blue-600"
    },
    {
      name: "Mike - Estimator",
      role: "Cost Estimation & Proposals",
      icon: FileText,
      status: "Active",
      tasks: ["Generate estimates", "Create proposals", "Calculate material costs"],
      color: "from-green-500 to-green-600"
    },
    {
      name: "Emma - Customer Support",
      role: "Customer Communication",
      icon: MessageSquare,
      status: "Active",
      tasks: ["Answer customer questions", "Provide updates", "Handle service requests"],
      color: "from-purple-500 to-purple-600"
    },
    {
      name: "Alex - Project Manager",
      role: "Project Coordination",
      icon: Briefcase,
      status: "Active",
      tasks: ["Track project progress", "Coordinate teams", "Send status updates"],
      color: "from-orange-500 to-orange-600"
    }
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
          <Bot className="w-8 h-8 text-purple-600" />
          AI Staff Team
        </h1>
        <p className="text-gray-500 mt-1">Your AI-powered team members working 24/7</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {aiStaff.map((staff, idx) => {
          const Icon = staff.icon;
          return (
            <Card key={idx} className="bg-white shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className={`bg-gradient-to-r ${staff.color} text-white`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <CardTitle className="text-white">{staff.name}</CardTitle>
                      <p className="text-sm text-white/80">{staff.role}</p>
                    </div>
                  </div>
                  <Badge className="bg-white/20 text-white border-white/30">
                    {staff.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <h4 className="font-semibold mb-3">Key Responsibilities:</h4>
                <ul className="space-y-2">
                  {staff.tasks.map((task, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                      <span className="text-green-600 mt-0.5">✓</span>
                      {task}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}