
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronLeft, ChevronRight, Plus, Trash2, Edit, Filter, GripVertical, Copy, Download, Link as LinkIcon, Calendar as CalendarIcon, RefreshCw } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { format } from "date-fns"; // Import date-fns format function
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox"; // Import Checkbox

export default function Calendar() {
  const navigate = useNavigate();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [showDialog, setShowDialog] = useState(false);
  const [showEventDetail, setShowEventDetail] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [filterStaff, setFilterStaff] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [showFilters, setShowFilters] = useState(false);

  // New state for day events dialog
  const [showDayEventsDialog, setShowDayEventsDialog] = useState(false);
  const [selectedDayEvents, setSelectedDayEvents] = useState([]);
  const [selectedDayDate, setSelectedDayDate] = useState(null);

  const [showSyncDialog, setShowSyncDialog] = useState(false);
  const [syncUrl, setSyncUrl] = useState("");

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    start_time: "", // This will hold a local datetime string (e.g., YYYY-MM-DDTHH:mm)
    end_time: "",   // This will hold a local datetime string (e.g., YYYY-MM-DDTHH:mm)
    assigned_to: "",
    attendees: [],
    location: "",
    event_type: "meeting",
    color: "#2563eb", // Updated default color to match new meeting color
    related_customer: "",
    related_lead: "",
    related_project: "",
    send_sms_notification: false // Add new field
  });

  const queryClient = useQueryClient();

  const { data: events = [] } = useQuery({
    queryKey: ['calendar-events'],
    queryFn: () => base44.entities.CalendarEvent.list("-start_time", 1000),
    initialData: [],
  });

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
  });

  useEffect(() => {
    if (user) {
      // Generate the calendar feed URL
      const feedUrl = `${window.location.origin}/api/functions/calendarFeed`;
      setSyncUrl(feedUrl);
    }
  }, [user]);

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
    initialData: [],
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list(),
    initialData: [],
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list(),
    initialData: [],
  });

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      start_time: "",
      end_time: "",
      assigned_to: "",
      attendees: [],
      location: "",
      event_type: "meeting",
      color: "#2563eb", // Updated default color to match new meeting color
      related_customer: "",
      related_lead: "",
      related_project: "",
      send_sms_notification: false // Reset new field
    });
  };

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.CalendarEvent.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
      queryClient.invalidateQueries({ queryKey: ['reminders'] });
      setShowDialog(false);
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      const oldEvent = events.find(e => e.id === id); // Get the event's state BEFORE the update
      const updatedEvent = await base44.entities.CalendarEvent.update(id, data);
      
      // 🔥 TRIGGER WORKFLOW: appointment_completed (if status changed to completed)
      // This trigger assumes CalendarEvent entities have a 'status' field that can be set to 'completed'.
      // If 'status' is not part of the `data` object for the update, `updatedEvent.status` will reflect its value from the database.
      if (oldEvent?.status !== 'completed' && updatedEvent.status === 'completed') {
        try {
          await base44.functions.invoke('executeWorkflow', {
            triggerType: 'appointment_completed',
            entityType: 'CalendarEvent',
            entityId: updatedEvent.id,
            entityData: updatedEvent
          });
          console.log('✅ Appointment completed workflows triggered for event ID:', updatedEvent.id);
        } catch (error) {
          console.error('⚠️ Workflow trigger failed for event ID:', updatedEvent.id, error);
        }
      }
      
      return updatedEvent;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
      queryClient.invalidateQueries({ queryKey: ['reminders'] });
      setShowEventDetail(false);
      setSelectedEvent(null);
      // The `events` query will refetch automatically after invalidation.
      // The `selectedDayEvents` will naturally update when `events` updates and the component re-renders.
      // No explicit update to selectedDayEvents needed here, as it might lead to stale data if called before query refetch completes.
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.CalendarEvent.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
      queryClient.invalidateQueries({ queryKey: ['reminders'] });
      setShowEventDetail(false);
      setSelectedEvent(null);
      // The `events` query will refetch automatically after invalidation.
      // The `selectedDayEvents` will naturally update when `events` updates and the component re-renders.
      // No explicit update to selectedDayEvents needed here, as it might lead to stale data if called before query refetch completes.
    },
  });

  // Helper function to convert UTC to local time for display in datetime-local input
  const toLocalDateTime = (utcDateString) => {
    if (!utcDateString) return '';
    const date = new Date(utcDateString); // Date object created from UTC string will be in local timezone internally
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}`;
  };

  // Helper function to convert local time from datetime-local input to UTC for storage
  const toUTC = (localDateString) => {
    if (!localDateString) return '';
    // new Date(localDateString) when localDateString is 'YYYY-MM-DDTHH:mm' is parsed as local time.
    // .toISOString() then converts this local time to UTC and formats it as an ISO string.
    const date = new Date(localDateString);
    return date.toISOString();
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Convert local times to UTC before saving
    createMutation.mutate({
      ...formData,
      start_time: toUTC(formData.start_time),
      end_time: formData.end_time ? toUTC(formData.end_time) : ''
    });
  };

  const handleEventClick = (event, e) => {
    e.stopPropagation();

    // Navigate to related page if applicable
    if (event.related_customer) {
      navigate(createPageUrl("Customers")); // Assuming Customers list page URL
    } else if (event.related_lead) {
      navigate(createPageUrl("Leads"));     // Assuming Leads list page URL
    } else if (event.related_project) {
      navigate(createPageUrl("Projects"));  // Assuming Projects list page URL
    } else if (event.event_type === "estimate") {
      navigate(createPageUrl("Estimates")); // Assuming Estimates list page URL
    } else {
      // Open detail dialog if no navigation target
      setSelectedEvent({
        ...event,
        start_time: toLocalDateTime(event.start_time),
        end_time: event.end_time ? toLocalDateTime(event.end_time) : '',
        send_sms_notification: event.send_sms_notification || false // Ensure boolean
      });
      setShowEventDetail(true);
    }
  };

  const handleEventEdit = (event, e) => {
    e.stopPropagation();
    setSelectedEvent({
      ...event,
      start_time: toLocalDateTime(event.start_time),
      end_time: event.end_time ? toLocalDateTime(event.end_time) : '',
      send_sms_notification: event.send_sms_notification || false // Ensure boolean
    });
    setShowEventDetail(true);
  };

  const handleDeleteEvent = () => {
    if (selectedEvent && window.confirm('Are you sure you want to delete this event?')) {
      deleteMutation.mutate(selectedEvent.id);
    }
  };

  const handleUpdateEvent = () => {
    if (selectedEvent) {
      updateMutation.mutate({
        id: selectedEvent.id,
        data: {
          ...selectedEvent,
          start_time: toUTC(selectedEvent.start_time),
          end_time: selectedEvent.end_time ? toUTC(selectedEvent.end_time) : ''
        }
      });
    }
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const eventId = result.draggableId;
    const destinationDateStr = result.destination.droppableId;

    // Ignore drag from non-date cells
    if (destinationDateStr.startsWith("empty-")) return;

    const event = events.find(e => e.id === eventId);
    if (!event) return;

    // Parse the new date from droppableId (format: YYYY-MM-DD, where MM is 0-indexed)
    // Note: The month in destinationDateStr is 0-indexed from the droppableId construction: `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`
    const [year, month, day] = destinationDateStr.split('-').map(Number);

    const oldStart = new Date(event.start_time); // This will be interpreted in local time from UTC ISO string
    const oldEnd = event.end_time ? new Date(event.end_time) : null;

    // Create new start time with same time but new date, in local timezone
    const newStart = new Date(year, month, day, oldStart.getHours(), oldStart.getMinutes(), oldStart.getSeconds(), oldStart.getMilliseconds());

    // Calculate new end time maintaining duration
    let newEnd = null;
    if (oldEnd) {
      const duration = oldEnd.getTime() - oldStart.getTime();
      newEnd = new Date(newStart.getTime() + duration);
    }

    updateMutation.mutate({
      id: event.id,
      data: {
        ...event,
        start_time: newStart.toISOString(), // Convert local date object back to UTC ISO string
        end_time: newEnd ? newEnd.toISOString() : event.end_time // Convert local date object back to UTC ISO string
      }
    });
  };

  const getDaysInMonth = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];

    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }

    return days;
  };

  const getEventsForDay = (date) => {
    if (!date) return [];
    let dayEvents = events.filter(event => {
      const eventDate = new Date(event.start_time); // This date object will represent the time in local timezone
      return eventDate.toDateString() === date.toDateString();
    });

    // Apply filters
    if (filterStaff !== "all") {
      dayEvents = dayEvents.filter(e => e.assigned_to === filterStaff || e.created_by === filterStaff);
    }
    if (filterType !== "all") {
      dayEvents = dayEvents.filter(e => e.event_type === filterType);
    }

    // Sort events by start time for consistent display
    dayEvents.sort((a, b) => new Date(a.start_time).getTime() - new Date(b.start_time).getTime());

    return dayEvents;
  };

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"];

  const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const days = getDaysInMonth(currentDate);
  const isToday = (date) => {
    if (!date) return false;
    const today = new Date();
    return date.toDateString() === today.toDateString();
  };

  // Vibrant, distinct colors for better visual separation
  const eventTypeColors = {
    'meeting': '#2563eb',           // Bright Blue
    'inspection': '#059669',        // Emerald Green
    'call': '#7c3aed',              // Violet
    'appointment': '#d97706',       // Amber
    'reminder': '#f59e0b',          // Gold
    'estimate': '#ea580c',          // Orange Red
    'roofing_contractor': '#0891b2',// Cyan
    'follow_up': '#db2777',         // Fuchsia
    'check_pickup': '#ca8a04',      // Dark Gold - Moved to here from reminder's old color
    'other': '#64748b'              // Slate Gray
  };

  const getEventColor = (event) => {
    return event.color || eventTypeColors[event.event_type] || '#64748b'; // Updated default 'other' color
  };

  const getEventTooltip = (event) => {
    const parts = [
      event.title,
      event.description ? `Description: ${event.description}` : null,
      `Time: ${new Date(event.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      event.location ? `Location: ${event.location}` : null,
      event.assigned_to ? `Assigned: ${event.assigned_to}` : null,
      event.related_customer ? `Customer: ${event.related_customer}` : null,
      event.related_lead ? `Lead: ${event.related_lead}` : null,
      event.related_project ? `Project: ${event.related_project}` : null,
    ].filter(Boolean);

    return parts.join('\n');
  };

  // Get unique staff members from events
  const staffMembers = [...new Set(events.map(e => e.assigned_to || e.created_by).filter(Boolean))];

  // Handler for "X more events" click
  const handleShowMoreEvents = (date, events) => {
    setSelectedDayDate(date);
    setSelectedDayEvents(events);
    setShowDayEventsDialog(true);
  };

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(syncUrl);
    alert("✅ Calendar feed URL copied to clipboard!");
  };

  const handleDownloadICS = async () => {
    try {
      const response = await base44.functions.invoke('calendarFeed', {});
      const icsContent = response.data;
      
      const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'crm-calendar.ics';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      a.remove();
      
      alert("✅ Calendar file downloaded! Import it into your calendar app.");
    } catch (error) {
      console.error('Download failed:', error);
      alert("❌ Failed to download calendar: " + (error.message || "Unknown error"));
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Calendar</h1>
          <p className="text-gray-500 mt-1">Manage your schedule and appointments</p>
        </div>

        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={() => setShowSyncDialog(true)}
            className="flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Sync Calendar
          </Button>

          <Popover open={showFilters} onOpenChange={setShowFilters}>
            <PopoverTrigger asChild>
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Filters
                {(filterStaff !== "all" || filterType !== "all") && (
                  <Badge className="ml-2 bg-blue-100 text-blue-700">Active</Badge>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80">
              <div className="space-y-4">
                <div>
                  <Label>Filter by Staff</Label>
                  <Select value={filterStaff} onValueChange={setFilterStaff}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Staff</SelectItem>
                      {staffMembers.map((email) => (
                        <SelectItem key={email} value={email}>{email}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Filter by Type</Label>
                    <Select value={filterType} onValueChange={setFilterType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="meeting">Meeting</SelectItem>
                      <SelectItem value="inspection">Inspection</SelectItem>
                      <SelectItem value="call">Call</SelectItem>
                      <SelectItem value="appointment">Appointment</SelectItem>
                      <SelectItem value="estimate">Estimate</SelectItem>
                      <SelectItem value="roofing_contractor">Roofing Contractor</SelectItem>
                      <SelectItem value="follow_up">Follow Up</SelectItem>
                      <SelectItem value="reminder">Reminder</SelectItem>
                      <SelectItem value="check_pickup">Check Pickup</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setFilterStaff("all");
                    setFilterType("all");
                  }}
                >
                  Clear Filters
                </Button>
              </div>
            </PopoverContent>
          </Popover>

          <Dialog open={showDialog} onOpenChange={(open) => {
            setShowDialog(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Event
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create Calendar Event</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label>Event Title *</Label>
                  <Input
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    required
                    placeholder="Meeting with customer"
                  />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    rows={2}
                    placeholder="Discuss roof inspection results"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Start Time * (Your Local Time)</Label>
                    <Input
                      type="datetime-local"
                      value={formData.start_time}
                      onChange={(e) => setFormData({...formData, start_time: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <Label>End Time (Your Local Time)</Label>
                    <Input
                      type="datetime-local"
                      value={formData.end_time}
                      onChange={(e) => setFormData({...formData, end_time: e.target.value})}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Event Type</Label>
                    <Select value={formData.event_type} onValueChange={(v) => {
                      setFormData({...formData, event_type: v, color: eventTypeColors[v] || '#64748b'}); // Updated default 'other' color
                    }}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="meeting">Meeting</SelectItem>
                        <SelectItem value="inspection">Inspection</SelectItem>
                        <SelectItem value="call">Call</SelectItem>
                        <SelectItem value="appointment">Appointment</SelectItem>
                        <SelectItem value="estimate">Estimate</SelectItem>
                        <SelectItem value="roofing_contractor">Roofing Contractor</SelectItem>
                        <SelectItem value="follow_up">Follow Up</SelectItem>
                        <SelectItem value="reminder">Reminder</SelectItem>
                        <SelectItem value="check_pickup">Check Pickup</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Color</Label>
                    <Input
                      type="color"
                      value={formData.color}
                      onChange={(e) => setFormData({...formData, color: e.target.value})}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Assign To</Label>
                    <Input
                      value={formData.assigned_to}
                      onChange={(e) => setFormData({...formData, assigned_to: e.target.value})}
                      placeholder="Staff email"
                      list="staff-list"
                    />
                    <datalist id="staff-list">
                      {staffMembers.map((email) => (
                        <option key={email} value={email} />
                      ))}
                    </datalist>
                  </div>
                  <div>
                    <Label>Location</Label>
                    <Input
                      value={formData.location}
                      onChange={(e) => setFormData({...formData, location: e.target.value})}
                      placeholder="Office, Zoom, Customer site"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label>Related Customer</Label>
                    <Select
                      value={formData.related_customer}
                      onValueChange={(v) => setFormData({...formData, related_customer: v})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select customer" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>None</SelectItem>
                        {customers.map((c) => (
                          <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Related Lead</Label>
                    <Select
                      value={formData.related_lead}
                      onValueChange={(v) => setFormData({...formData, related_lead: v})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select lead" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>None</SelectItem>
                        {leads.map((l) => (
                          <SelectItem key={l.id} value={l.name}>{l.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Related Project</Label>
                    <Select
                      value={formData.related_project}
                      onValueChange={(v) => setFormData({...formData, related_project: v})}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select project" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>None</SelectItem>
                        {projects.map((p) => (
                          <SelectItem key={p.id} value={p.name}>{p.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* New SMS Notification Checkbox */}
                <div className="flex items-center space-x-2 pt-2">
                  <Checkbox
                    id="send-sms-notification"
                    checked={formData.send_sms_notification}
                    onCheckedChange={(checked) => setFormData({ ...formData, send_sms_notification: checked })}
                  />
                  <Label htmlFor="send-sms-notification" className="cursor-pointer">
                    Send SMS reminder 10 minutes before event
                  </Label>
                </div>

                <div className="flex justify-end gap-3">
                  <Button type="button" variant="outline" onClick={() => setShowDialog(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    Create Event
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Sync Dialog */}
      <Dialog open={showSyncDialog} onOpenChange={setShowSyncDialog}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarIcon className="w-5 h-5 text-blue-600" />
              Sync Calendar with Your Devices
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6 pt-4">
            {/* One-Time Download */}
            <div className="border rounded-lg p-4 bg-blue-50">
              <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                <Download className="w-5 h-5 text-blue-600" />
                Option 1: One-Time Download
              </h3>
              <p className="text-sm text-gray-600 mb-3">
                Download your calendar events as an .ics file and import into any calendar app.
                Good for one-time imports.
              </p>
              <Button onClick={handleDownloadICS} className="bg-blue-600 hover:bg-blue-700">
                <Download className="w-4 h-4 mr-2" />
                Download Calendar File
              </Button>
            </div>

            {/* Live Subscription */}
            <div className="border rounded-lg p-4 bg-green-50">
              <h3 className="font-semibold text-lg mb-2 flex items-center gap-2">
                <LinkIcon className="w-5 h-5 text-green-600" />
                Option 2: Live Calendar Subscription (Recommended)
              </h3>
              <p className="text-sm text-gray-600 mb-3">
                Subscribe to your calendar feed for automatic updates. Changes sync automatically!
              </p>
              
              <div className="bg-white border rounded p-3 mb-3">
                <Label className="text-xs text-gray-500 mb-1 block">Your Calendar Feed URL:</Label>
                <div className="flex items-center gap-2">
                  <Input
                    value={syncUrl}
                    readOnly
                    className="flex-1 font-mono text-sm"
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleCopyUrl}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <Alert>
                <AlertDescription>
                  <p className="font-semibold mb-2">📱 How to subscribe:</p>
                  <ul className="text-sm space-y-1 ml-4 list-disc">
                    <li><strong>iPhone/iPad:</strong> Settings → Calendar → Accounts → Add Account → Other → Add Subscribed Calendar → Paste URL</li>
                    <li><strong>Google Calendar:</strong> Settings → Add calendar → From URL → Paste URL</li>
                    <li><strong>Outlook:</strong> File → Account Settings → Internet Calendars → New → Paste URL</li>
                    <li><strong>Mac Calendar:</strong> File → New Calendar Subscription → Paste URL</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </div>

            <div className="flex justify-end">
              <Button variant="outline" onClick={() => setShowSyncDialog(false)}>
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Card className="bg-white shadow-lg">
          <CardHeader className="border-b bg-gradient-to-r from-blue-900 to-blue-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button variant="ghost" size="icon" onClick={previousMonth} className="text-white hover:bg-white/10">
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <CardTitle className="text-2xl font-bold text-white">
                  {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
                </CardTitle>
                <Button variant="ghost" size="icon" onClick={() => setCurrentDate(new Date())} className="bg-white text-blue-900 hover:bg-blue-50">
                  Today
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="grid grid-cols-7 border-b bg-gradient-to-r from-gray-100 to-gray-50">
              {dayNames.map((day) => (
                <div key={day} className="p-3 text-center text-sm font-semibold text-gray-800 border-r last:border-r-0">
                  {day}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7">
              {days.map((date, index) => {
                const dayEvents = date ? getEventsForDay(date) : [];
                const dateKey = date ? `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}` : `empty-${index}`;

                return (
                  <Droppable key={dateKey} droppableId={dateKey}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.droppableProps}
                        className={`min-h-[140px] p-2 border-r border-b last:border-r-0 transition-colors ${
                          !date ? 'bg-gray-50' : isToday(date) ? 'bg-blue-50' : 'bg-white hover:bg-gray-50'
                        } ${snapshot.isDraggingOver ? 'bg-blue-100 ring-2 ring-blue-400' : ''}`}
                      >
                        {date && (
                          <>
                            <div className={`text-sm mb-2 font-medium ${isToday(date) ? 'font-bold text-blue-700' : 'text-gray-700'}`}>
                              {date.getDate()}
                              {isToday(date) && (
                                <span className="ml-2 inline-block w-2 h-2 bg-blue-600 rounded-full animate-pulse"></span>
                              )}
                            </div>
                            <div className="space-y-1">
                              {dayEvents.slice(0, 3).map((event, eventIndex) => (
                                <Draggable key={event.id} draggableId={event.id} index={eventIndex}>
                                  {(provided, snapshot) => (
                                    <div
                                      ref={provided.innerRef}
                                      {...provided.draggableProps}
                                      className={`relative group text-xs p-1.5 rounded-md cursor-pointer transition-all shadow-sm hover:shadow-md ${
                                        snapshot.isDragging ? 'shadow-xl opacity-90 z-50 ring-2 ring-blue-500' : ''
                                      }`}
                                      style={{
                                        backgroundColor: getEventColor(event) + '30',
                                        borderLeft: `3px solid ${getEventColor(event)}`,
                                        ...provided.draggableProps.style
                                      }}
                                      onClick={(e) => handleEventClick(event, e)}
                                      title={getEventTooltip(event)}
                                    >
                                      <div className="absolute bottom-full left-0 mb-2 hidden group-hover:block z-50 w-64 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-xl">
                                        <div className="font-semibold mb-2 text-sm">{event.title}</div>
                                        {event.description && (
                                          <div className="mb-2 text-gray-300">{event.description}</div>
                                        )}
                                        <div className="space-y-1 text-gray-300">
                                          <div>🕐 {new Date(event.start_time).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</div>
                                          {event.location && <div>📍 {event.location}</div>}
                                          {event.assigned_to && <div>👤 {event.assigned_to.split('@')[0]}</div>}
                                          {event.related_customer && <div>🏢 Customer: {event.related_customer}</div>}
                                          {event.related_lead && <div>🎯 Lead: {event.related_lead}</div>}
                                          {event.related_project && <div>📁 Project: {event.related_project}</div>}
                                        </div>
                                        <div className="mt-2 pt-2 border-t border-gray-700 text-xs text-gray-400">
                                          Click to {event.related_customer || event.related_lead || event.related_project || event.event_type === 'estimate' ? 'view details' : 'edit'}
                                        </div>
                                      </div>

                                      <div className="flex items-start gap-1">
                                        <div
                                          {...provided.dragHandleProps}
                                          className="cursor-grab active:cursor-grabbing pt-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                                          onClick={(e) => e.stopPropagation()}
                                        >
                                          <GripVertical className="w-3 h-3 text-gray-500" />
                                        </div>
                                        <div className="flex-1 min-w-0">
                                          <div className="font-semibold truncate" style={{ color: getEventColor(event) }}>
                                            {event.title}
                                          </div>
                                          <div className="text-xs opacity-90 flex items-center gap-1 flex-wrap">
                                            <span>{new Date(event.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                            {event.assigned_to && (
                                              <>
                                                <span className="opacity-50">•</span>
                                                <span className="truncate max-w-[80px]">{event.assigned_to.split('@')[0]}</span>
                                              </>
                                            )}
                                          </div>
                                          {(event.related_customer || event.related_lead || event.related_project) && (
                                            <Badge variant="outline" className="text-[10px] mt-1 px-1 py-0" style={{ borderColor: getEventColor(event), color: getEventColor(event) }}>
                                              {event.related_customer || event.related_lead || event.related_project}
                                            </Badge>
                                          )}
                                        </div>
                                        <button
                                          onClick={(e) => handleEventEdit(event, e)}
                                          className="opacity-0 group-hover:opacity-100 transition-opacity p-0.5 hover:bg-white/50 rounded"
                                        >
                                          <Edit className="w-3 h-3" style={{ color: getEventColor(event) }} />
                                        </button>
                                      </div>
                                    </div>
                                  )}
                                </Draggable>
                              ))}
                              {dayEvents.length > 3 && (
                                <button
                                  onClick={() => handleShowMoreEvents(date, dayEvents)}
                                  className="text-xs text-blue-600 hover:text-blue-800 font-medium pl-1.5 hover:underline cursor-pointer w-full text-left"
                                >
                                  +{dayEvents.length - 3} more events
                                </button>
                              )}
                            </div>
                          </>
                        )}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </DragDropContext>

      {/* Day Events Dialog - Shows all events for a specific day */}
      <Dialog open={showDayEventsDialog} onOpenChange={setShowDayEventsDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Events for {selectedDayDate && format(selectedDayDate, 'MMMM d, yyyy')}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {selectedDayEvents.map((event) => (
              <Card key={event.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => {
                setShowDayEventsDialog(false); // Close day events dialog
                // Convert to local time format strings before setting to selectedEvent for display in datetime-local inputs
                setSelectedEvent({
                  ...event,
                  start_time: toLocalDateTime(event.start_time),
                  end_time: event.end_time ? toLocalDateTime(event.end_time) : '',
                  send_sms_notification: event.send_sms_notification || false // Ensure boolean
                });
                setShowEventDetail(true);
              }}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h4 className="font-semibold text-lg">{event.title}</h4>
                        <Badge
                          className="text-xs"
                          style={{
                            backgroundColor: getEventColor(event) + '30',
                            color: getEventColor(event),
                            borderColor: getEventColor(event)
                          }}
                        >
                          {event.event_type.replace(/_/g, ' ')}
                        </Badge>
                      </div>
                      {event.description && (
                        <p className="text-sm text-gray-600 mb-2">{event.description}</p>
                      )}
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div className="flex items-center gap-2 text-gray-700">
                          <span className="font-medium">Time:</span>
                          <span>{format(new Date(event.start_time), 'h:mm a')}</span>
                          {event.end_time && (
                            <span> - {format(new Date(event.end_time), 'h:mm a')}</span>
                          )}
                        </div>
                        {event.location && (
                          <div className="flex items-center gap-2 text-gray-700">
                            <span className="font-medium">Location:</span>
                            <span>{event.location}</span>
                          </div>
                        )}
                        {event.assigned_to && (
                          <div className="flex items-center gap-2 text-gray-700">
                            <span className="font-medium">Assigned:</span>
                            <span>{event.assigned_to.split('@')[0]}</span>
                          </div>
                        )}
                        {event.related_customer && (
                          <div className="flex items-center gap-2 text-gray-700">
                            <span className="font-medium">Customer:</span>
                            <span>{event.related_customer}</span>
                          </div>
                        )}
                        {event.related_lead && (
                          <div className="flex items-center gap-2 text-gray-700">
                            <span className="font-medium">Lead:</span>
                            <span>{event.related_lead}</span>
                          </div>
                        )}
                        {event.related_project && (
                          <div className="flex items-center gap-2 text-gray-700">
                            <span className="font-medium">Project:</span>
                            <span>{event.related_project}</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShowDayEventsDialog(false); // Close day events dialog before opening edit dialog
                        handleEventEdit(event, e);
                      }}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showEventDetail} onOpenChange={setShowEventDetail}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Event Details</DialogTitle>
          </DialogHeader>
          {selectedEvent && (
            <div className="space-y-4">
              <div>
                <Label>Event Title</Label>
                <Input
                  value={selectedEvent.title}
                  onChange={(e) => setSelectedEvent({...selectedEvent, title: e.target.value})}
                />
              </div>
              <div>
                <Label>Description</Label>
                <Textarea
                  value={selectedEvent.description || ""}
                  onChange={(e) => setSelectedEvent({...selectedEvent, description: e.target.value})}
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Start Time (Your Local Time)</Label>
                  <Input
                    type="datetime-local"
                    value={selectedEvent.start_time}
                    onChange={(e) => setSelectedEvent({...selectedEvent, start_time: e.target.value})}
                  />
                </div>
                <div>
                  <Label>End Time (Your Local Time)</Label>
                  <Input
                    type="datetime-local"
                    value={selectedEvent.end_time}
                    onChange={(e) => setSelectedEvent({...selectedEvent, end_time: e.target.value})}
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label>Event Type</Label>
                  <Select
                    value={selectedEvent.event_type}
                    onValueChange={(v) => setSelectedEvent({...selectedEvent, event_type: v, color: eventTypeColors[v] || '#64748b'})} // Updated default 'other' color
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="meeting">Meeting</SelectItem>
                      <SelectItem value="inspection">Inspection</SelectItem>
                      <SelectItem value="call">Call</SelectItem>
                      <SelectItem value="appointment">Appointment</SelectItem>
                      <SelectItem value="estimate">Estimate</SelectItem>
                      <SelectItem value="roofing_contractor">Roofing Contractor</SelectItem>
                      <SelectItem value="follow_up">Follow Up</SelectItem>
                      <SelectItem value="reminder">Reminder</SelectItem>
                      <SelectItem value="check_pickup">Check Pickup</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Assign To</Label>
                  <Input
                    value={selectedEvent.assigned_to || ""}
                    onChange={(e) => setSelectedEvent({...selectedEvent, assigned_to: e.target.value})}
                  />
                </div>
                <div>
                  <Label>Color</Label>
                  <Input
                    type="color"
                    value={selectedEvent.color || "#2563eb"} // Updated default color to match new meeting color
                    onChange={(e) => setSelectedEvent({...selectedEvent, color: e.target.value})}
                  />
                </div>
              </div>
              <div>
                <Label>Location</Label>
                <Input
                  value={selectedEvent.location || ""}
                  onChange={(e) => setSelectedEvent({...selectedEvent, location: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label>Related Customer</Label>
                  <Select
                    value={selectedEvent.related_customer || ""}
                    onValueChange={(v) => setSelectedEvent({...selectedEvent, related_customer: v})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select customer" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>None</SelectItem>
                      {customers.map((c) => (
                        <SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Related Lead</Label>
                  <Select
                    value={selectedEvent.related_lead || ""}
                    onValueChange={(v) => setSelectedEvent({...selectedEvent, related_lead: v})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select lead" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>None</SelectItem>
                      {leads.map((l) => (
                        <SelectItem key={l.id} value={l.name}>{l.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Related Project</Label>
                  <Select
                    value={selectedEvent.related_project || ""}
                    onValueChange={(v) => setSelectedEvent({...selectedEvent, related_project: v})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select project" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>None</SelectItem>
                      {projects.map((p) => (
                        <SelectItem key={p.id} value={p.name}>{p.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              {/* New SMS Notification Checkbox for editing */}
              <div className="flex items-center space-x-2 pt-2">
                <Checkbox
                  id="edit-send-sms-notification"
                  checked={selectedEvent.send_sms_notification}
                  onCheckedChange={(checked) => setSelectedEvent({ ...selectedEvent, send_sms_notification: checked })}
                />
                <Label htmlFor="edit-send-sms-notification" className="cursor-pointer">
                  Send SMS reminder 10 minutes before event
                </Label>
              </div>

              <div className="flex justify-between pt-4 border-t">
                <Button
                  variant="destructive"
                  onClick={handleDeleteEvent}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Event
                </Button>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setShowEventDetail(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleUpdateEvent} className="bg-blue-600 hover:bg-blue-700">
                    <Edit className="w-4 h-4 mr-2" />
                    Save Changes
                  </Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
