import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Wrench, Calculator, FileText, Download, Upload, Zap } from "lucide-react";

export default function Utilities() {
  const tools = [
    { icon: Calculator, title: "Calculator", description: "Quick calculations", color: "from-blue-500 to-blue-600" },
    { icon: FileText, title: "File Converter", description: "Convert documents", color: "from-green-500 to-green-600" },
    { icon: Download, title: "Bulk Export", description: "Export data", color: "from-purple-500 to-purple-600" },
    { icon: Upload, title: "Bulk Import", description: "Import data", color: "from-orange-500 to-orange-600" },
    { icon: Zap, title: "Automation", description: "Setup workflows", color: "from-pink-500 to-pink-600" },
    { icon: Wrench, title: "System Tools", description: "Admin utilities", color: "from-indigo-500 to-indigo-600" },
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Utilities</h1>
        <p className="text-gray-500 mt-1">Helpful tools and utilities</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.map((tool, idx) => {
          const Icon = tool.icon;
          return (
            <Card key={idx} className={`bg-gradient-to-br ${tool.color} text-white hover:shadow-xl transition-all cursor-pointer`}>
              <CardContent className="p-6 text-center">
                <Icon className="w-12 h-12 mx-auto mb-4" />
                <h3 className="font-bold text-lg mb-2">{tool.title}</h3>
                <p className="text-sm opacity-90">{tool.description}</p>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}