
import React, { useState, useEffect, useCallback, useMemo } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  FileText,
  Eye,
  Send,
  Download,
  Trash2,
  Filter,
  Search,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  Phone,
  Mail,
  MessageSquare,
} from "lucide-react";
import { format } from "date-fns";
import Dialer from "../components/communication/Dialer";
import EmailDialog from "../components/communication/EmailDialog";
import SMSDialog from "../components/communication/SMSDialog";

export default function Estimates() {
  const navigate = useNavigate();
  const location = useLocation();
  const queryClient = useQueryClient();
  
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);
  
  const urlParams = new URLSearchParams(location.search);
  const shouldPrefill = urlParams.get('prefill') === 'true';
  const shouldCreateNew = urlParams.get('create_new') === 'true';
  const prefillCustomerName = urlParams.get('customer_name');
  const prefillCustomerEmail = urlParams.get('customer_email');
  const prefillPropertyAddress = urlParams.get('property_address');
  const droneInspectionId = urlParams.get('drone_inspection_id');

  const [showDialog, setShowDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [formKey, setFormKey] = useState(0);
  
  const [formData, setFormData] = useState({
    customer_name: "",
    customer_email: "",
    customer_phone: "", // Added customer_phone to form data
    property_address: "",
    reference_number: "",
    insurance_company: "",
    adjuster_name: "",
    adjuster_phone: "",
    claim_number: "",
    notes: "",
    format_id: ""
  });

  const [user, setUser] = useState(null);

  const [showDialer, setShowDialer] = useState(false);
  const [showEmailDialog, setShowEmailDialog] = useState(false);
  const [showSMSDialog, setShowSMSDialog] = useState(false);
  const [selectedContact, setSelectedContact] = useState({ name: "", phone: "", email: "" });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  const { data: estimates = [] } = useQuery({
    queryKey: ['estimates'],
    queryFn: () => base44.entities.Estimate.list("-created_date", 500),
    initialData: [],
  });

  const { data: customFormats = [] } = useQuery({
    queryKey: ['custom-formats'],
    queryFn: () => base44.entities.EstimateFormat.filter({ is_active: true }),
    initialData: [],
  });

  // Fetch drone inspection if ID provided
  const { data: droneInspection } = useQuery({
    queryKey: ['drone-inspection', droneInspectionId],
    queryFn: () => droneInspectionId ? base44.entities.DroneInspection.filter({ id: droneInspectionId }).then(res => res[0]) : null,
    enabled: !!droneInspectionId,
  });

  useEffect(() => {
    if (shouldCreateNew && shouldPrefill) {
      const newFormData = {
        customer_name: prefillCustomerName || "",
        customer_email: prefillCustomerEmail || "",
        customer_phone: "", // Keep default empty or fetch if available from URL or drone
        property_address: prefillPropertyAddress || "",
        reference_number: "",
        insurance_company: "",
        adjuster_name: "",
        adjuster_phone: "",
        claim_number: "",
        notes: "",
        format_id: ""
      };

      // If drone inspection data exists, use it
      if (droneInspection) {
        newFormData.customer_name = droneInspection.customer_name || newFormData.customer_name;
        newFormData.property_address = droneInspection.property_address || newFormData.property_address;
        newFormData.customer_phone = droneInspection.customer_phone || newFormData.customer_phone;
        newFormData.customer_email = droneInspection.customer_email || newFormData.customer_email;
        newFormData.notes = `Drone Inspection: ${droneInspection.inspection_number}\n${droneInspection.notes || ""}`.trim();
      }

      setFormData(newFormData);
      setShowDialog(true);
      setFormKey(k => k + 1);
      
      // Clear URL params
      navigate(createPageUrl('Estimates'), { replace: true });
    }
  }, [shouldCreateNew, shouldPrefill, prefillCustomerName, prefillCustomerEmail, prefillPropertyAddress, droneInspection, navigate]);

  const createEstimateMutation = useMutation({
    mutationFn: async (data) => {
      // Auto-generate estimate number
      const allEstimates = await base44.entities.Estimate.list();
      const existingNumbers = allEstimates
        .map(e => {
          const match = e.estimate_number?.match(/(?:AI-)?EST-(\d+)/);
          return match ? parseInt(match[1]) : 0;
        })
        .filter(n => n > 0);
      
      const nextNumber = existingNumbers.length > 0 
        ? Math.max(...existingNumbers) + 1 
        : 1800;
      
      const estimateNumber = `EST-${nextNumber}`;
      
      // Auto-set valid until to 30 days from now
      const validUntil = new Date();
      validUntil.setDate(validUntil.getDate() + 30);
      
      // Calculate amount from drone inspection if available
      let estimateAmount = 0;
      if (droneInspection && droneInspection.estimated_repair_cost) {
        estimateAmount = droneInspection.estimated_repair_cost;
      }
      
      return base44.entities.Estimate.create({
        ...data,
        estimate_number: estimateNumber,
        valid_until: validUntil.toISOString().split('T')[0],
        amount: estimateAmount, // Will be updated in AI Estimator, or prefilled from drone inspection
      });
    },
    onSuccess: (newEstimate) => {
      queryClient.invalidateQueries({ queryKey: ['estimates'] });
      setShowDialog(false);
      setFormData({
        customer_name: "",
        customer_email: "",
        customer_phone: "", // Reset customer_phone
        property_address: "",
        reference_number: "",
        insurance_company: "",
        adjuster_name: "",
        adjuster_phone: "",
        claim_number: "",
        notes: "",
        format_id: ""
      });
      setFormKey(k => k + 1);

      // Navigate to AI Estimator with the new estimate
      if (newEstimate && newEstimate.id) {
        navigate(createPageUrl('AIEstimator') + '?estimate_id=' + newEstimate.id);
      }
    },
  });

  const deleteEstimateMutation = useMutation({
    mutationFn: (id) => base44.entities.Estimate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['estimates'] });
    },
  });

  const handleSubmit = useCallback((e) => {
    e.preventDefault();
    if (!myCompany) {
      alert("Please set up your company profile first!");
      return;
    }
    
    createEstimateMutation.mutate({
      customer_name: formData.customer_name,
      customer_email: formData.customer_email,
      customer_phone: formData.customer_phone, // Added customer_phone
      notes: formData.notes,
      format_id: formData.format_id,
      company_id: myCompany.id,
      status: 'draft',
      property_address: formData.property_address,
      reference_number: formData.reference_number,
      insurance_company: formData.insurance_company,
      adjuster_name: formData.adjuster_name,
      adjuster_phone: formData.adjuster_phone,
      claim_number: formData.claim_number,
    });
  }, [formData, myCompany, createEstimateMutation]);

  const handleDelete = (estimateId) => {
    if (window.confirm("Are you sure you want to delete this estimate?")) {
      deleteEstimateMutation.mutate(estimateId);
    }
  };

  const handleSendEstimate = async (estimate) => {
    try {
      await base44.functions.invoke('sendEstimateEmail', {
        estimateId: estimate.id,
        companyId: myCompany?.id
      });
      alert('Estimate email sent successfully!');
      queryClient.invalidateQueries({ queryKey: ['estimates'] });
    } catch (error) {
      alert('Failed to send estimate email: ' + error.message);
    }
  };

  const handleCall = (estimate) => {
    setSelectedContact({
      name: estimate.customer_name,
      phone: estimate.customer_phone || "",
      email: estimate.customer_email || ""
    });
    setShowDialer(true);
  };

  const handleEmail = (estimate) => {
    setSelectedContact({
      name: estimate.customer_name,
      phone: estimate.customer_phone || "",
      email: estimate.customer_email || ""
    });
    setShowEmailDialog(true);
  };

  const handleSMS = (estimate) => {
    setSelectedContact({
      name: estimate.customer_name,
      phone: estimate.customer_phone || "",
      email: estimate.customer_email || ""
    });
    setShowSMSDialog(true);
  };

  const filteredEstimates = estimates
    .filter(est => 
      statusFilter === 'all' || est.status === statusFilter
    )
    .filter(est =>
      est.customer_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      est.estimate_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      est.customer_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      est.customer_phone?.toLowerCase().includes(searchTerm.toLowerCase())
    );

  const getStatusBadge = (status) => {
    const statusConfig = {
      draft: { color: "bg-gray-100 text-gray-700", icon: Clock },
      sent: { color: "bg-blue-100 text-blue-700", icon: Send },
      viewed: { color: "bg-purple-100 text-purple-700", icon: Eye },
      accepted: { color: "bg-green-100 text-green-700", icon: CheckCircle },
      declined: { color: "bg-red-100 text-red-700", icon: XCircle },
      expired: { color: "bg-orange-100 text-orange-700", icon: AlertCircle }
    };

    const config = statusConfig[status] || statusConfig.draft;
    const Icon = config.icon;

    return (
      <Badge className={`${config.color} flex items-center justify-center gap-1`}>
        <Icon className="w-3 h-3" />
        <span className="capitalize">{status || 'draft'}</span>
      </Badge>
    );
  };

  const FormContent = useMemo(() => {
    return (
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 gap-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Customer Name *</Label>
              <Input
                value={formData.customer_name}
                onChange={(e) => setFormData(prev => ({...prev, customer_name: e.target.value}))}
                placeholder="Type or select customer"
                required
              />
            </div>

            <div>
              <Label>Customer Email</Label>
              <Input
                type="email"
                value={formData.customer_email}
                onChange={(e) => setFormData(prev => ({...prev, customer_email: e.target.value}))}
                placeholder="customer@example.com"
              />
            </div>
          </div>

          <div>
              <Label>Customer Phone</Label>
              <Input
                type="tel"
                value={formData.customer_phone}
                onChange={(e) => setFormData(prev => ({...prev, customer_phone: e.target.value}))}
                placeholder="(123) 456-7890"
              />
            </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Property Address</Label>
              <Input
                value={formData.property_address}
                onChange={(e) => setFormData(prev => ({...prev, property_address: e.target.value}))}
                placeholder="123 Main St, Anytown, USA"
              />
            </div>

            <div>
              <Label>Reference Number</Label>
              <Input
                value={formData.reference_number}
                onChange={(e) => setFormData(prev => ({...prev, reference_number: e.target.value}))}
                placeholder="Optional reference number"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Insurance Company</Label>
              <Input
                value={formData.insurance_company}
                onChange={(e) => setFormData(prev => ({...prev, insurance_company: e.target.value}))}
                placeholder="e.g., State Farm, Geico"
              />
            </div>

            <div>
              <Label>Claim Number</Label>
              <Input
                value={formData.claim_number}
                onChange={(e) => setFormData(prev => ({...prev, claim_number: e.target.value}))}
                placeholder="e.g., CLM-2023-001"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Adjuster Name</Label>
              <Input
                value={formData.adjuster_name}
                onChange={(e) => setFormData(prev => ({...prev, adjuster_name: e.target.value}))}
                placeholder="e.g., John Doe"
              />
            </div>

            <div>
              <Label>Adjuster Phone</Label>
              <Input
                value={formData.adjuster_phone}
                onChange={(e) => setFormData(prev => ({...prev, adjuster_phone: e.target.value}))}
                placeholder="e.g., (123) 456-7890"
              />
            </div>
          </div>

          <div>
            <Label>Custom Format</Label>
            <Select value={formData.format_id || 'none'} onValueChange={(value) => setFormData(prev => ({...prev, format_id: value === 'none' ? '' : value}))}>
              <SelectTrigger>
                <SelectValue placeholder="Select format (optional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Standard Format</SelectItem>
                {customFormats.map(format => (
                  <SelectItem key={format.id} value={format.id}>
                    {format.format_name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label>Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({...prev, notes: e.target.value}))}
              placeholder="Internal notes..."
              rows={3}
            />
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-800">
            <p className="font-semibold mb-1">ℹ️ Automatic Fields:</p>
            <ul className="list-disc list-inside space-y-1 text-xs">
              <li>Estimate number will be auto-generated (EST-####)</li>
              <li>Valid until will be set to 30 days from today</li>
              <li>Amount will be added in AI Estimator (or pre-filled from Drone Inspection)</li>
            </ul>
          </div>

          <div className="flex flex-col-reverse sm:flex-row justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={() => {
              setShowDialog(false);
              setFormKey(k => k + 1);
            }} className="w-full sm:w-auto">
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700 w-full sm:w-auto">
              Create Estimate
            </Button>
          </div>
        </div>
      </form>
    );
  }, [formData, customFormats, handleSubmit, setShowDialog, setFormKey]);

  return (
    <div className="p-4 lg:p-6 space-y-4 lg:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Estimates</h1>
          <p className="text-sm text-gray-500 mt-1">{filteredEstimates.length} total estimates</p>
        </div>
        
        {isMobile ? (
          <Sheet open={showDialog} onOpenChange={setShowDialog}>
            <SheetTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700 w-full sm:w-auto">
                <Plus className="w-4 h-4 mr-2" />
                New Estimate
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="h-[90vh] overflow-y-auto">
              <SheetHeader>
                <SheetTitle>Create New Estimate</SheetTitle>
              </SheetHeader>
              <div className="mt-6">
                {FormContent}
              </div>
            </SheetContent>
          </Sheet>
        ) : (
          <Dialog open={showDialog} onOpenChange={setShowDialog}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                New Estimate
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Estimate</DialogTitle>
              </DialogHeader>
              {FormContent}
            </DialogContent>
          </Dialog>
        )}
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search estimates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-48">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="sent">Sent</SelectItem>
            <SelectItem value="viewed">Viewed</SelectItem>
            <SelectItem value="accepted">Accepted</SelectItem>
            <SelectItem value="declined">Declined</SelectItem>
            <SelectItem value="expired">Expired</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card className="bg-white shadow-md">
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b bg-gray-50">
                <tr className="text-left text-xs text-gray-600 uppercase tracking-wider">
                  <th className="p-4 font-medium">Estimate #</th>
                  <th className="p-4 font-medium">Customer</th>
                  <th className="p-4 font-medium">Amount</th>
                  <th className="p-4 font-medium">Status</th>
                  <th className="p-4 font-medium">Valid Until</th>
                  <th className="p-4 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredEstimates.map((estimate) => (
                  <tr key={estimate.id} className="border-b hover:bg-gray-50 transition-colors">
                    <td className="p-4">
                      <div className="font-medium text-gray-900">{estimate.estimate_number}</div>
                      {estimate.project_name && (
                        <div className="text-xs text-gray-500">{estimate.project_name}</div>
                      )}
                    </td>
                    <td className="p-4">
                      <div className="font-medium text-gray-900">{estimate.customer_name}</div>
                      {estimate.customer_email && (
                        <div className="text-xs text-gray-500">{estimate.customer_email}</div>
                      )}
                      {estimate.customer_phone && (
                        <div className="text-xs text-gray-500">{estimate.customer_phone}</div>
                      )}
                    </td>
                    <td className="p-4">
                      <div className="font-semibold text-green-600">
                        ${estimate.amount?.toFixed(2) || '0.00'}
                      </div>
                    </td>
                    <td className="p-4">
                      {getStatusBadge(estimate.status)}
                    </td>
                    <td className="p-4 text-sm text-gray-600">
                      {estimate.valid_until ? format(new Date(estimate.valid_until), 'MMM d, yyyy') : '-'}
                    </td>
                    <td className="p-4">
                      <div className="flex items-center justify-end gap-1">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleCall(estimate)}
                          className="h-8 w-8 text-green-600 hover:text-green-700 hover:bg-green-50"
                          title="Call customer"
                          disabled={!estimate.customer_phone}
                        >
                          <Phone className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleEmail(estimate)}
                          className="h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                          title="Email customer"
                          disabled={!estimate.customer_email}
                        >
                          <Mail className="w-4 h-4" />
                        </Button>
                        
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleSMS(estimate)}
                          className="h-8 w-8 text-purple-600 hover:text-purple-700 hover:bg-purple-50"
                          title="Send SMS"
                          disabled={!estimate.customer_phone}
                        >
                          <MessageSquare className="w-4 h-4" />
                        </Button>

                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => navigate(createPageUrl('AIEstimator') + '?estimate_id=' + estimate.id)}
                          className="h-8 w-8 text-gray-600 hover:text-gray-700 hover:bg-gray-100"
                          title="View estimate"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>

                        {estimate.status === 'draft' && (
                          <Button
                            size="icon"
                            variant="ghost"
                            onClick={() => handleSendEstimate(estimate)}
                            className="h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                            title="Send estimate"
                          >
                            <Send className="w-4 h-4" />
                          </Button>
                        )}

                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleDelete(estimate.id)}
                          className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                          title="Delete estimate"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredEstimates.length === 0 && (
                  <tr>
                    <td colSpan={6} className="py-12 text-center">
                      <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-500 text-lg">No estimates found</p>
                      <p className="text-gray-400 text-sm mt-1">Create your first estimate to get started</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <Dialer
        open={showDialer}
        onOpenChange={setShowDialer}
        defaultNumber={selectedContact.phone}
        defaultName={selectedContact.name}
      />
      <EmailDialog
        open={showEmailDialog}
        onOpenChange={setShowEmailDialog}
        defaultTo={selectedContact.email}
        defaultName={selectedContact.name}
        companyId={myCompany?.id}
      />
      <SMSDialog
        open={showSMSDialog}
        onOpenChange={setShowSMSDialog}
        defaultTo={selectedContact.phone}
        defaultName={selectedContact.name}
      />
    </div>
  );
}
