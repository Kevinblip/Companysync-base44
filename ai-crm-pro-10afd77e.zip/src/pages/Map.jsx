
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MapContainer, TileLayer, Marker, Popup, Polygon } from 'react-leaflet';
import { MapPin, Users, TrendingUp, Filter, X, Phone, Mail, DollarSign, Home } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { createPageUrl } from "@/utils";
import { format } from "date-fns";
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix Leaflet default marker icon issue
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom home marker icons by type and status
const createHomeIcon = (type, status) => {
  let color = '#3b82f6'; // default blue
  
  if (type === 'lead') {
    if (status === 'won') color = '#10b981'; // green
    else if (status === 'lost') color = '#ef4444'; // red
    else if (status === 'qualified') color = '#f59e0b'; // orange
    else if (status === 'contacted') color = '#8b5cf6'; // purple
    else color = '#3b82f6'; // blue for new
  } else if (type === 'customer') {
    color = '#10b981'; // green for customers
  }
  
  return L.divIcon({
    className: 'custom-home-marker',
    html: `
      <div style="
        background: ${color};
        width: 32px;
        height: 32px;
        border-radius: 50%;
        border: 3px solid white;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
      ">
        🏠
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 16],
  });
};

export default function Map() {
  const [user, setUser] = useState(null);
  // Center on Cleveland, Ohio (Northeast Ohio)
  const [mapCenter, setMapCenter] = useState([41.4993, -81.6944]); // Cleveland coordinates
  const [mapZoom, setMapZoom] = useState(10); // Zoomed in to see neighborhoods
  const [filters, setFilters] = useState({
    type: 'all', // all, leads, customers
    status: 'all',
    assignedTo: 'all',
    search: ''
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  // CHANGED: Filter leads by company AND sales rep permissions
  const { data: allLeads = [] } = useQuery({
    queryKey: ['leads', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.Lead.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  // CHANGED: Filter customers by company AND sales rep permissions
  const { data: allCustomers = [] } = useQuery({
    queryKey: ['customers', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.Customer.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const { data: staff = [] } = useQuery({
    queryKey: ['staff', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.User.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  // ADDED: Check if user is admin
  const isAdmin = user?.role === 'admin';

  // ADDED: Filter data based on user role
  const leads = isAdmin 
    ? allLeads 
    : allLeads.filter(lead => lead.assigned_to === user?.email);

  const customers = isAdmin 
    ? allCustomers 
    : allCustomers.filter(customer => customer.assigned_to === user?.email);

  // Geocode an address to coordinates
  const geocodeAddress = async (address) => {
    if (!address) return null;
    
    try {
      // Add "Ohio" to search if not present to bias results to Ohio
      const searchAddress = address.toLowerCase().includes('ohio') || address.toLowerCase().includes('oh') 
        ? address 
        : `${address}, Ohio`;
      
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(searchAddress)}&limit=1&countrycodes=us`
      );
      const data = await response.json();
      
      if (data && data[0]) {
        return {
          lat: parseFloat(data[0].lat),
          lng: parseFloat(data[0].lon)
        };
      }
    } catch (error) {
      console.error('Geocoding error:', error);
    }
    return null;
  };

  // Combine leads and customers with their coordinates
  const [mapItems, setMapItems] = useState([]);
  const [isLoadingCoordinates, setIsLoadingCoordinates] = useState(false);

  useEffect(() => {
    const loadCoordinates = async () => {
      setIsLoadingCoordinates(true);
      
      const items = [];
      
      // Process leads
      for (const lead of leads) {
        if (lead.address) {
          const coords = await geocodeAddress(lead.address);
          if (coords) {
            items.push({
              type: 'lead',
              id: lead.id,
              name: lead.name,
              email: lead.email,
              phone: lead.phone,
              company: lead.company,
              address: lead.address,
              status: lead.status,
              value: lead.value,
              assigned_to: lead.assigned_to,
              coordinates: coords
            });
          }
        }
      }
      
      // Process customers
      for (const customer of customers) {
        if (customer.address) {
          const coords = await geocodeAddress(customer.address);
          if (coords) {
            items.push({
              type: 'customer',
              id: customer.id,
              name: customer.name,
              email: customer.email,
              phone: customer.phone,
              company: customer.company,
              address: customer.address,
              is_active: customer.is_active,
              assigned_to: customer.assigned_to,
              coordinates: coords
            });
          }
        }
      }
      
      setMapItems(items);
      setIsLoadingCoordinates(false);
    };
    
    // Only attempt to load coordinates if user is defined and there are leads/customers to process
    if (user && (leads.length > 0 || customers.length > 0)) {
      loadCoordinates();
    }
  }, [leads, customers, user]); // Added user to dependencies

  // Apply filters
  const filteredItems = mapItems.filter(item => {
    // Type filter
    if (filters.type === 'leads' && item.type !== 'lead') return false;
    if (filters.type === 'customers' && item.type !== 'customer') return false;
    
    // Status filter
    if (filters.status !== 'all') {
      if (item.type === 'lead' && item.status !== filters.status) return false;
      if (item.type === 'customer' && filters.status === 'active' && !item.is_active) return false;
      if (item.type === 'customer' && filters.status === 'inactive' && item.is_active) return false;
    }
    
    // Assigned to filter
    if (filters.assignedTo !== 'all' && item.assigned_to !== filters.assignedTo) return false;
    
    // Search filter
    if (filters.search) {
      const search = filters.search.toLowerCase();
      return item.name?.toLowerCase().includes(search) ||
             item.email?.toLowerCase().includes(search) ||
             item.company?.toLowerCase().includes(search) ||
             item.address?.toLowerCase().includes(search);
    }
    
    return true;
  });

  // Calculate stats
  const totalLeads = filteredItems.filter(i => i.type === 'lead').length;
  const totalCustomers = filteredItems.filter(i => i.type === 'customer').length;
  const wonLeads = filteredItems.filter(i => i.type === 'lead' && i.status === 'won').length;
  const newLeads = filteredItems.filter(i => i.type === 'lead' && i.status === 'new').length;

  // Get unique assigned staff for filter
  const assignedStaff = [...new Set(mapItems.map(i => i.assigned_to).filter(Boolean))];

  // Northeast Ohio boundary (approximate)
  const northeastOhioBoundary = [
    [41.8, -81.9],   // Northwest
    [41.8, -80.5],   // Northeast
    [41.1, -80.5],   // Southeast
    [41.1, -81.9],   // Southwest
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
          <Home className="w-8 h-8 text-blue-600" />
          Northeast Ohio Territory Map
        </h1>
        <div className="flex items-center gap-3 mt-2">
          <p className="text-gray-500">
            {isAdmin ? 'Viewing all company leads and customers' : 'Viewing your assigned leads and customers'}
          </p>
          {!isAdmin && (
            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
              👤 My Territory
            </Badge>
          )}
          {isAdmin && (
            <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
              👑 Admin View
            </Badge>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">
                  {isAdmin ? 'Total Leads' : 'My Leads'}
                </p>
                <p className="text-3xl font-bold text-blue-600">{totalLeads}</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">New Leads</p>
                <p className="text-3xl font-bold text-purple-600">{newLeads}</p>
              </div>
              <MapPin className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Won Deals</p>
                <p className="text-3xl font-bold text-green-600">{wonLeads}</p>
              </div>
              <Home className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">
                  {isAdmin ? 'Total Customers' : 'My Customers'}
                </p>
                <p className="text-3xl font-bold text-green-600">{totalCustomers}</p>
              </div>
              <Users className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader className="border-b bg-gray-50">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Filter className="w-5 h-5" />
              Map Filters
            </CardTitle>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFilters({ type: 'all', status: 'all', assignedTo: 'all', search: '' })}
            >
              <X className="w-4 h-4 mr-2" />
              Clear Filters
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label>Show</Label>
              <Select value={filters.type} onValueChange={(value) => setFilters({...filters, type: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All (Leads + Customers)</SelectItem>
                  <SelectItem value="leads">Leads Only</SelectItem>
                  <SelectItem value="customers">Customers Only</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Status</Label>
              <Select value={filters.status} onValueChange={(value) => setFilters({...filters, status: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="contacted">Contacted</SelectItem>
                  <SelectItem value="qualified">Qualified</SelectItem>
                  <SelectItem value="won">Won</SelectItem>
                  <SelectItem value="lost">Lost</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* CHANGED: Only show "Assigned To" filter for admins */}
            {isAdmin && (
              <div>
                <Label>Assigned To</Label>
                <Select value={filters.assignedTo} onValueChange={(value) => setFilters({...filters, assignedTo: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sales Reps</SelectItem>
                    {assignedStaff.map(email => {
                      const staffMember = staff.find(s => s.email === email);
                      return (
                        <SelectItem key={email} value={email}>
                          {staffMember?.full_name || email}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div>
              <Label>Search</Label>
              <Input
                placeholder="Name, address, company..."
                value={filters.search}
                onChange={(e) => setFilters({...filters, search: e.target.value})}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Map Legend */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4 items-center">
            <span className="font-semibold text-sm">Legend:</span>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-blue-500 border-2 border-white"></div>
              <span className="text-sm">New Lead</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-purple-500 border-2 border-white"></div>
              <span className="text-sm">Contacted Lead</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-orange-500 border-2 border-white"></div>
              <span className="text-sm">Qualified Lead</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-green-500 border-2 border-white"></div>
              <span className="text-sm">Won / Customer</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-red-500 border-2 border-white"></div>
              <span className="text-sm">Lost Lead</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Map */}
      <Card>
        <CardContent className="p-0">
          {isLoadingCoordinates ? (
            <div className="h-[700px] flex items-center justify-center bg-gray-50">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Loading map...</p>
                <p className="text-sm text-gray-500 mt-1">Geocoding {leads.length + customers.length} locations</p>
              </div>
            </div>
          ) : filteredItems.length === 0 ? (
            <div className="h-[700px] flex items-center justify-center bg-gray-50">
              <div className="text-center">
                <MapPin className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-600 text-lg font-semibold">No locations found</p>
                <p className="text-sm text-gray-500 mt-2">
                  {isAdmin 
                    ? 'Add addresses to your leads and customers to see them on the map'
                    : 'No leads or customers assigned to you yet, or they need addresses added'
                  }
                </p>
              </div>
            </div>
          ) : (
            <div className="h-[700px] rounded-lg overflow-hidden">
              <MapContainer
                center={mapCenter}
                zoom={mapZoom}
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; OpenStreetMap contributors'
                />
                
                {/* Northeast Ohio service area boundary */}
                <Polygon 
                  positions={northeastOhioBoundary} 
                  pathOptions={{ 
                    color: '#3b82f6', 
                    fillColor: '#3b82f6', 
                    fillOpacity: 0.1,
                    weight: 2,
                    dashArray: '5, 10'
                  }} 
                />
                
                {filteredItems.map((item) => {
                  const icon = createHomeIcon(item.type, item.status || (item.is_active ? 'active' : 'inactive'));
                  
                  return (
                    <Marker
                      key={`${item.type}-${item.id}`}
                      position={[item.coordinates.lat, item.coordinates.lng]}
                      icon={icon}
                    >
                      <Popup>
                        <div className="p-2 min-w-[250px]">
                          <div className="flex items-center justify-between mb-2">
                            <Badge className={
                              item.type === 'lead' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                            }>
                              {item.type === 'lead' ? '📋 Lead' : '✅ Customer'}
                            </Badge>
                            {item.status && (
                              <Badge variant="outline">
                                {item.status}
                              </Badge>
                            )}
                          </div>
                          
                          <h3 className="font-bold text-lg mb-2">{item.name}</h3>
                          
                          {item.company && (
                            <p className="text-sm text-gray-600 mb-1">🏢 {item.company}</p>
                          )}
                          
                          <p className="text-sm text-gray-600 mb-2">📍 {item.address}</p>
                          
                          {item.email && (
                            <p className="text-sm text-blue-600 flex items-center gap-1 mb-1">
                              <Mail className="w-3 h-3" />
                              {item.email}
                            </p>
                          )}
                          
                          {item.phone && (
                            <p className="text-sm text-green-600 flex items-center gap-1 mb-2">
                              <Phone className="w-3 h-3" />
                              {item.phone}
                            </p>
                          )}
                          
                          {item.value && (
                            <p className="text-sm font-semibold text-purple-600 flex items-center gap-1">
                              <DollarSign className="w-3 h-3" />
                              ${item.value.toLocaleString()}
                            </p>
                          )}
                          
                          {item.assigned_to && (
                            <p className="text-xs text-gray-500 mt-2">
                              Assigned: {staff.find(s => s.email === item.assigned_to)?.full_name || item.assigned_to}
                            </p>
                          )}
                          
                          <Button
                            size="sm"
                            className="w-full mt-3"
                            onClick={() => {
                              const page = item.type === 'lead' ? 'Leads' : 'Customers';
                              window.location.href = createPageUrl(page);
                            }}
                          >
                            View Details
                          </Button>
                        </div>
                      </Popup>
                    </Marker>
                  );
                })}
              </MapContainer>
            </div>
          )}
        </CardContent>
      </Card>

      {filteredItems.length > 0 && (
        <Alert className="bg-blue-50 border-blue-200">
          <MapPin className="w-4 h-4 text-blue-600" />
          <AlertDescription>
            <strong>Showing {filteredItems.length} locations</strong> - {totalLeads} leads and {totalCustomers} customers 
            {isAdmin ? ' across all sales reps' : ' assigned to you'} in Northeast Ohio.
            Click on any home pin to see details!
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
