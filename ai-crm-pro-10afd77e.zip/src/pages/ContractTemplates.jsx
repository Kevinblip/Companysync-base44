
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Upload,
  FileText,
  Sparkles,
  Loader2,
  Edit,
  Trash2,
  Eye,
  Send,
  FileSignature,
  X,
  Mail,
  MessageCircle
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useNavigate } from "react-router-dom";

export default function ContractTemplates() {
  const [user, setUser] = useState(null);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [showUseTemplateDialog, setShowUseTemplateDialog] = useState(false);
  const [showPdfPreview, setShowPdfPreview] = useState(false);
  const [showFieldConfig, setShowFieldConfig] = useState(false); // New state
  const [previewPdfUrl, setPreviewPdfUrl] = useState(null);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [uploadFile, setUploadFile] = useState(null);
  const [templateName, setTemplateName] = useState("");
  const [templateCategory, setTemplateCategory] = useState("service_agreement");
  const [isUploading, setIsUploading] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [fieldSettings, setFieldSettings] = useState([]); // New state
  
  const [contractForm, setContractForm] = useState({
    contract_name: "",
    customer_name: "",
    customer_email: "",
    customer_phone: "",
    create_as_lead: false,
    delivery_method: "email"
  });

  const navigate = useNavigate();
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  const { data: templates = [] } = useQuery({
    queryKey: ['contract-templates', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.ContractTemplate.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.Customer.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const deleteTemplateMutation = useMutation({
    mutationFn: (id) => base44.entities.ContractTemplate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contract-templates'] });
    },
  });

  const createLeadMutation = useMutation({
    mutationFn: async (leadData) => {
      return await base44.entities.Lead.create({
        company_id: myCompany?.id,
        name: leadData.name,
        email: leadData.email,
        phone: leadData.phone,
        status: "new",
        source: "manual",
        lead_source: "Contract Signing"
      });
    },
  });

  const createSessionMutation = useMutation({
    mutationFn: async (data) => {
      // Create lead if requested
      if (data.create_as_lead) {
        await createLeadMutation.mutateAsync({
          name: data.customer_name,
          email: data.customer_email,
          phone: data.customer_phone
        });
      }

      return await base44.entities.ContractSigningSession.create({
        company_id: myCompany?.id,
        template_id: selectedTemplate.id,
        template_name: selectedTemplate.template_name,
        contract_name: data.contract_name,
        customer_name: data.customer_name,
        customer_email: data.customer_email,
        customer_phone: data.customer_phone,
        delivery_method: data.delivery_method,
        rep_name: user?.full_name,
        rep_email: user?.email,
        status: 'draft',
        current_signer: 'rep'
      });
    },
    onSuccess: (session) => {
      queryClient.invalidateQueries({ queryKey: ['signing-sessions'] });
      // Invalidate leads query if a lead was created
      if (contractForm.create_as_lead) {
        queryClient.invalidateQueries({ queryKey: ['leads'] });
      }
      setShowUseTemplateDialog(false);
      // Navigate to rep signing page
      navigate(`/sign-contract-rep?sessionId=${session.id}`);
    },
  });

  // New mutation for updating field settings
  const updateFieldSettingsMutation = useMutation({
    mutationFn: ({ id, fields }) => base44.entities.ContractTemplate.update(id, { fillable_fields: fields }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contract-templates'] });
      setShowFieldConfig(false);
      alert('✅ Field settings saved!');
    },
    onError: (error) => {
      alert('❌ Error saving field settings: ' + error.message);
    }
  });

  const handleUploadSubmit = async (e) => {
    e.preventDefault();
    
    if (!uploadFile || !templateName) {
      alert('Please fill in all fields');
      return;
    }

    try {
      setIsUploading(true);

      // Upload file
      const { file_url } = await base44.integrations.Core.UploadFile({
        file: uploadFile
      });

      setIsAnalyzing(true);

      // Analyze with AI
      const analyzeResponse = await base44.functions.invoke('analyzeContractTemplate', {
        fileUrl: file_url,
        templateName,
        category: templateCategory
      });

      if (!analyzeResponse.data.success) {
        throw new Error(analyzeResponse.data.error);
      }

      // Create template
      await base44.entities.ContractTemplate.create({
        company_id: myCompany?.id,
        template_name: templateName,
        category: templateCategory,
        original_file_url: file_url,
        fillable_fields: analyzeResponse.data.fields,
        is_active: true
      });

      queryClient.invalidateQueries({ queryKey: ['contract-templates'] });
      setShowUploadDialog(false);
      setTemplateName("");
      setTemplateCategory("service_agreement");
      setUploadFile(null);

      alert(`✅ Template created with ${analyzeResponse.data.fields.length} fillable fields detected!`);

    } catch (error) {
      alert('❌ Error: ' + error.message);
    } finally {
      setIsUploading(false);
      setIsAnalyzing(false);
    }
  };

  const handleViewTemplate = (template) => {
    setPreviewPdfUrl(template.original_file_url);
    setShowPdfPreview(true);
  };

  const handleUseTemplate = (template) => {
    setSelectedTemplate(template);
    setContractForm({
      contract_name: "",
      customer_name: "",
      customer_email: "",
      customer_phone: "",
      create_as_lead: false,
      delivery_method: "email"
    });
    setShowUseTemplateDialog(true);
  };

  // New handler for configuring fields
  const handleConfigureFields = (template) => {
    setSelectedTemplate(template);
    setFieldSettings(template.fillable_fields || []);
    setShowFieldConfig(true);
  };

  // New handler for toggling field required status
  const toggleFieldRequired = (fieldIndex) => {
    setFieldSettings(prevSettings => {
      const updated = [...prevSettings];
      updated[fieldIndex] = {
        ...updated[fieldIndex],
        required: !updated[fieldIndex].required
      };
      return updated;
    });
  };

  // New handler for saving field settings
  const saveFieldSettings = () => {
    updateFieldSettingsMutation.mutate({
      id: selectedTemplate.id,
      fields: fieldSettings
    });
  };

  const handleStartSigning = (e) => {
    e.preventDefault();
    
    if (!contractForm.contract_name || !contractForm.customer_name) {
      alert('Please fill in contract name and customer name');
      return;
    }

    if (contractForm.delivery_method === 'email' && !contractForm.customer_email) {
      alert('Please provide customer email for email delivery');
      return;
    }

    if (contractForm.delivery_method === 'sms' && !contractForm.customer_phone) {
      alert('Please provide customer phone for SMS delivery');
      return;
    }

    createSessionMutation.mutate(contractForm);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Contract Templates</h1>
          <p className="text-gray-500 mt-1">Upload and manage contract templates</p>
        </div>

        <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Upload className="w-4 h-4 mr-2" />
              Upload Template
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Upload Contract Template</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleUploadSubmit} className="space-y-4">
              <Alert className="bg-blue-50 border-blue-200">
                <Sparkles className="w-4 h-4 text-blue-600" />
                <AlertDescription>
                  <strong>AI-Powered:</strong> We'll automatically detect fillable fields and who should fill them (rep vs customer).
                </AlertDescription>
              </Alert>

              <div>
                <Label>Template Name *</Label>
                <Input
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                  placeholder="e.g., Roofing Service Agreement"
                  required
                />
              </div>

              <div>
                <Label>Category</Label>
                <Select value={templateCategory} onValueChange={setTemplateCategory}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="service_agreement">Service Agreement</SelectItem>
                    <SelectItem value="maintenance_contract">Maintenance Contract</SelectItem>
                    <SelectItem value="work_order">Work Order</SelectItem>
                    <SelectItem value="proposal">Proposal</SelectItem>
                    <SelectItem value="nda">NDA</SelectItem>
                    <SelectItem value="warranty">Warranty</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Upload PDF/DOCX *</Label>
                <Input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={(e) => setUploadFile(e.target.files[0])}
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  PDF or Word document with your contract template
                </p>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowUploadDialog(false)}
                  disabled={isUploading || isAnalyzing}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={isUploading || isAnalyzing}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  {isUploading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Uploading...
                    </>
                  ) : isAnalyzing ? (
                    <>
                      <Sparkles className="w-4 h-4 mr-2 animate-pulse" />
                      Analyzing with AI...
                    </>
                  ) : (
                    'Upload & Analyze'
                  )}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {templates.map((template) => (
          <Card key={template.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg">{template.template_name}</CardTitle>
                  <Badge variant="outline" className="mt-2 capitalize">
                    {template.category.replace('_', ' ')}
                  </Badge>
                </div>
                <FileText className="w-8 h-8 text-blue-500" />
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-gray-600">
                <p>📝 {template.fillable_fields?.length || 0} fillable fields</p>
                <p>✅ Used {template.usage_count || 0} times</p>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleViewTemplate(template)}
                >
                  <Eye className="w-4 h-4 mr-1" />
                  View
                </Button>
                <Button
                  size="sm"
                  onClick={() => handleUseTemplate(template)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <FileSignature className="w-4 h-4 mr-1" />
                  Use
                </Button>
              </div>

              {/* New Button for Configure Fields */}
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleConfigureFields(template)}
                className="w-full"
              >
                <Edit className="w-4 h-4 mr-1" />
                Configure Fields
              </Button>

              <Button
                size="sm"
                variant="ghost"
                onClick={() => {
                  if (window.confirm('Delete this template?')) {
                    deleteTemplateMutation.mutate(template.id);
                  }
                }}
                className="w-full text-red-600 hover:text-red-700"
              >
                <Trash2 className="w-4 h-4 mr-1" />
                Delete
              </Button>
            </CardContent>
          </Card>
        ))}

        {templates.length === 0 && (
          <Card className="col-span-full">
            <CardContent className="p-12 text-center text-gray-500">
              <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="font-medium">No templates yet</p>
              <p className="text-sm mt-1">Upload your first contract template to get started</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* PDF Preview Modal - FIXED WITH GOOGLE VIEWER */}
      {showPdfPreview && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-6xl h-[90vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b bg-gray-50">
              <h2 className="text-xl font-bold">Template Preview</h2>
              <div className="flex items-center gap-2">
                <a
                  href={previewPdfUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-blue-600 hover:underline"
                >
                  Open in new tab
                </a>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    setShowPdfPreview(false);
                    setPreviewPdfUrl(null);
                  }}
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>
            </div>
            <div className="flex-1 overflow-hidden bg-gray-100">
              <iframe
                src={`https://docs.google.com/viewer?url=${encodeURIComponent(previewPdfUrl)}&embedded=true`}
                className="w-full h-full border-0"
                title="PDF Preview"
              />
            </div>
          </div>
        </div>
      )}

      {/* Field Configuration Dialog */}
      <Dialog open={showFieldConfig} onOpenChange={setShowFieldConfig}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Configure Fields: {selectedTemplate?.template_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <AlertDescription>
                <strong>Tip:</strong> Toggle which fields are required vs optional. These settings are saved for this template.
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              {fieldSettings.length > 0 ? (
                fieldSettings.map((field, index) => (
                  <Card key={index} className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="font-medium">{field.field_label}</p>
                          <Badge variant="outline" className="text-xs">
                            {field.field_type}
                          </Badge>
                          <Badge className={field.filled_by === 'rep' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'}>
                            {field.filled_by === 'rep' ? 'You fill' : 'Customer fills'}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-500 mt-1">
                          Field: <code>{field.field_name}</code>
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Label className="text-sm">{field.required ? 'Required' : 'Optional'}</Label>
                        <Button
                          size="sm"
                          variant={field.required ? "default" : "outline"}
                          onClick={() => toggleFieldRequired(index)}
                        >
                          {field.required ? 'Make Optional' : 'Make Required'}
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))
              ) : (
                <p className="text-center text-gray-500">No fillable fields detected for this template.</p>
              )}
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => setShowFieldConfig(false)}
                disabled={updateFieldSettingsMutation.isLoading}
              >
                Cancel
              </Button>
              <Button
                onClick={saveFieldSettings}
                disabled={updateFieldSettingsMutation.isLoading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {updateFieldSettingsMutation.isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save Settings'
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>


      {/* Use Template Dialog - ENHANCED */}
      <Dialog open={showUseTemplateDialog} onOpenChange={setShowUseTemplateDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Start Contract: {selectedTemplate?.template_name}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleStartSigning} className="space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <FileSignature className="w-4 h-4 text-blue-600" />
              <AlertDescription>
                <strong>Workflow:</strong> You'll fill your fields & sign first, then it will be sent to the customer.
              </AlertDescription>
            </Alert>

            <div>
              <Label>Contract Name *</Label>
              <Input
                value={contractForm.contract_name}
                onChange={(e) => setContractForm({...contractForm, contract_name: e.target.value})}
                placeholder="e.g., Smith Roofing Project - Jan 2025"
                required
              />
            </div>

            <div>
              <Label>Quick Select Customer (Optional)</Label>
              <Select onValueChange={(id) => {
                const customer = customers.find(c => c.id === id);
                if (customer) {
                  setContractForm({
                    ...contractForm, // Preserve existing contract_name, delivery_method, etc.
                    customer_name: customer.name,
                    customer_email: customer.email || '',
                    customer_phone: customer.phone || '',
                    create_as_lead: false // If selecting an existing customer, don't create as lead
                  });
                }
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select customer..." />
                </SelectTrigger>
                <SelectContent>
                  {customers.map(c => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name} {c.email ? `(${c.email})` : ''}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="border-t pt-4">
              <div className="flex items-center gap-2 mb-3">
                <input
                  type="checkbox"
                  id="create-lead"
                  checked={contractForm.create_as_lead}
                  onChange={(e) => setContractForm({...contractForm, create_as_lead: e.target.checked})}
                  className="w-4 h-4 text-blue-600 accent-blue-600"
                />
                <Label htmlFor="create-lead" className="cursor-pointer text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                  Create as new lead in CRM
                </Label>
              </div>

              <div>
                <Label>Customer Name *</Label>
                <Input
                  value={contractForm.customer_name}
                  onChange={(e) => setContractForm({...contractForm, customer_name: e.target.value})}
                  placeholder="John Smith"
                  required
                />
              </div>
            </div>

            <div>
              <Label>Delivery Method *</Label>
              <div className="flex gap-4 mt-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="delivery"
                    value="email"
                    checked={contractForm.delivery_method === 'email'}
                    onChange={(e) => setContractForm({...contractForm, delivery_method: e.target.value})}
                    className="w-4 h-4 text-blue-600 accent-blue-600"
                  />
                  <Mail className="w-4 h-4 text-gray-600" />
                  <span>Email</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="delivery"
                    value="sms"
                    checked={contractForm.delivery_method === 'sms'}
                    onChange={(e) => setContractForm({...contractForm, delivery_method: e.target.value})}
                    className="w-4 h-4 text-blue-600 accent-blue-600"
                  />
                  <MessageCircle className="w-4 h-4 text-gray-600" />
                  <span>SMS</span>
                </label>
              </div>
            </div>

            {contractForm.delivery_method === 'email' && (
              <div>
                <Label>Customer Email *</Label>
                <Input
                  type="email"
                  value={contractForm.customer_email}
                  onChange={(e) => setContractForm({...contractForm, customer_email: e.target.value})}
                  placeholder="john@example.com"
                  required
                />
              </div>
            )}

            {contractForm.delivery_method === 'sms' && (
              <div>
                <Label>Customer Phone *</Label>
                <Input
                  type="tel"
                  value={contractForm.customer_phone}
                  onChange={(e) => setContractForm({...contractForm, customer_phone: e.target.value})}
                  placeholder="(555) 123-4567"
                  required
                />
              </div>
            )}

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowUseTemplateDialog(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={createSessionMutation.isLoading || createLeadMutation.isLoading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {(createSessionMutation.isLoading || createLeadMutation.isLoading) ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Starting...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-2" />
                    Start Signing
                  </>
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
