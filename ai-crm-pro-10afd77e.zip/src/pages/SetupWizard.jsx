
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import {
  CheckCircle2,
  Circle,
  ArrowRight,
  ArrowLeft,
  Building2,
  Phone,
  Calendar,
  UserPlus,
  Sparkles,
  Loader2,
  Upload,
  Trophy
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function SetupWizard() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [currentStep, setCurrentStep] = useState(0);
  const [user, setUser] = useState(null);

  const [companyForm, setCompanyForm] = useState({
    company_name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    industry: "roofing"
  });

  const [twilioForm, setTwilioForm] = useState({
    account_sid: "",
    auth_token: "",
    main_phone_number: ""
  });

  const [firstLeadForm, setFirstLeadForm] = useState({
    name: "",
    email: "",
    phone: "",
    street: "",
    city: "",
    state: "",
    zip: "",
    notes: ""
  });

  const [logoFile, setLogoFile] = useState(null);
  const [uploadingLogo, setUploadingLogo] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  useEffect(() => {
    if (myCompany) {
      setCompanyForm({
        company_name: myCompany.company_name || "",
        email: myCompany.email || "",
        phone: myCompany.phone || "",
        address: myCompany.address || "",
        city: myCompany.city || "",
        state: myCompany.state || "",
        zip: myCompany.zip || "",
        industry: myCompany.industry || "roofing"
      });
      if (myCompany.logo_url) {
        setLogoFile(myCompany.logo_url);
      }
    }
  }, [myCompany]);

  const createCompanyMutation = useMutation({
    mutationFn: (data) => {
      if (myCompany) {
        return base44.entities.Company.update(myCompany.id, data);
      } else {
        return base44.entities.Company.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies'] });
    },
  });

  const createTwilioMutation = useMutation({
    mutationFn: async (data) => {
      const company = companies.find(c => c.created_by === user?.email);
      if (!company) throw new Error("Company not found");

      const existingSettings = await base44.entities.TwilioSettings.filter({ company_id: company.id });
      
      if (existingSettings.length > 0) {
        return base44.entities.TwilioSettings.update(existingSettings[0].id, {
          ...data,
          company_id: company.id
        });
      } else {
        return base44.entities.TwilioSettings.create({
          ...data,
          company_id: company.id
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['twilio-settings'] });
    },
  });

  const createLeadMutation = useMutation({
    mutationFn: (data) => base44.entities.Lead.create({
      ...data,
      status: 'new',
      source: 'manual',
      lead_source: 'Setup Wizard - First Lead',
      assigned_to: user?.email
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
    },
  });

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingLogo(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setLogoFile(file_url);
      
      const company = companies.find(c => c.created_by === user?.email);
      if (company) {
        await base44.entities.Company.update(company.id, { logo_url: file_url });
        queryClient.invalidateQueries({ queryKey: ['companies'] });
      }
    } catch (error) {
      alert("Failed to upload logo: " + error.message);
      console.error("Logo upload error:", error);
    }
    setUploadingLogo(false);
  };

  const handleCompanySubmit = async () => {
    if (!companyForm.company_name || !companyForm.email) {
      alert("Please enter company name and email");
      return;
    }

    try {
      await createCompanyMutation.mutateAsync(companyForm);
      // Refresh companies list to get updated data and then proceed to the next step
      await queryClient.invalidateQueries({ queryKey: ['companies'] });
      setCurrentStep(2); // Go to Twilio step
    } catch (error) {
      console.error("Company save error:", error);
      alert("Failed to save company info: " + error.message);
    }
  };

  const handleTwilioSubmit = async () => {
    // Allow skipping Twilio setup if both fields are empty
    if (!twilioForm.account_sid && !twilioForm.auth_token) {
      setCurrentStep(3); // Go to Google Calendar step
      return;
    }

    try {
      await createTwilioMutation.mutateAsync(twilioForm);
      setCurrentStep(3); // Go to Google Calendar step
    } catch (error) {
      console.error("Twilio save error:", error);
      alert("Failed to save Twilio settings: " + error.message);
    }
  };

  const handleGoogleCalendarConnect = async () => {
    try {
      const response = await base44.functions.invoke('connectGoogleCalendar', {});
      if (response.data.authUrl) {
        window.location.href = response.data.authUrl;
      }
    } catch (error) {
      console.error("Google Calendar error:", error);
      alert("Failed to connect Google Calendar: " + error.message);
    }
  };

  const handleLeadSubmit = async () => {
    // Allow skipping lead creation if name is empty
    if (!firstLeadForm.name) {
      setCurrentStep(5); // Go to All Done step
      return;
    }

    try {
      await createLeadMutation.mutateAsync(firstLeadForm);
      setCurrentStep(5); // Go to All Done step
    }
    catch (error) {
      console.error("Lead creation error:", error);
      alert("Failed to create lead: " + error.message);
    }
  };

  const handleFinish = async () => {
    try {
      const company = companies.find(c => c.created_by === user?.email);
      if (company) {
        await base44.entities.Company.update(company.id, { 
          setup_completed: true,
          setup_completed_at: new Date().toISOString()
        });
        await queryClient.invalidateQueries({ queryKey: ['companies'] }); // Invalidate to reflect setup_completed status
      }
      navigate(createPageUrl('Dashboard'));
    } catch (error) {
      console.error("Setup completion error:", error);
      alert("Failed to complete setup: " + error.message);
    }
  };

  const steps = [
    {
      id: 0,
      title: "Welcome",
      icon: Sparkles,
      description: "Let's get your CRM set up!"
    },
    {
      id: 1,
      title: "Company Info",
      icon: Building2,
      description: "Tell us about your business"
    },
    {
      id: 2,
      title: "Twilio (Optional)",
      icon: Phone,
      description: "Enable calling & SMS"
    },
    {
      id: 3,
      title: "Google Calendar",
      icon: Calendar,
      description: "Sync your events"
    },
    {
      id: 4,
      title: "First Lead",
      icon: UserPlus,
      description: "Add your first contact"
    },
    {
      id: 5,
      title: "All Done!",
      icon: Trophy,
      description: "You're ready to go"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = index === currentStep;
              const isCompleted = index < currentStep;

              return (
                <div key={step.id} className="flex items-center flex-1">
                  <div className="flex flex-col items-center">
                    <div
                      className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                        isActive
                          ? 'bg-blue-600 text-white scale-110 shadow-lg'
                          : isCompleted
                          ? 'bg-green-500 text-white'
                          : 'bg-gray-200 text-gray-400'
                      }`}
                    >
                      {isCompleted ? <CheckCircle2 className="w-6 h-6" /> : <Icon className="w-6 h-6" />}
                    </div>
                    <div className="text-center mt-2">
                      <p className={`text-xs font-medium ${isActive ? 'text-blue-600' : 'text-gray-500'}`}>
                        {step.title}
                      </p>
                    </div>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`flex-1 h-1 mx-2 transition-all duration-300 ${isCompleted ? 'bg-green-500' : 'bg-gray-200'}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <Card className="shadow-2xl">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
            <CardTitle className="text-2xl flex items-center gap-3">
              {React.createElement(steps[currentStep].icon, { className: "w-8 h-8" })}
              {steps[currentStep].title}
            </CardTitle>
            <CardDescription className="text-blue-100">
              {steps[currentStep].description}
            </CardDescription>
          </CardHeader>

          <CardContent className="p-8">
            {currentStep === 0 && (
              <div className="text-center space-y-6">
                <div className="w-24 h-24 mx-auto bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                  <Sparkles className="w-12 h-12 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Welcome to AI CRM Pro!</h2>
                <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                  We'll help you set up your CRM in just 5 minutes. Let's configure your company, integrations, and add your first lead.
                </p>
                <div className="flex justify-center gap-4 pt-6">
                  <Button onClick={() => setCurrentStep(1)} size="lg" className="bg-blue-600 hover:bg-blue-700">
                    Let's Get Started <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </div>
              </div>
            )}

            {currentStep === 1 && (
              <div className="space-y-6">
                <Alert className="bg-blue-50 border-blue-200">
                  <Building2 className="w-4 h-4 text-blue-600" />
                  <AlertDescription className="text-blue-900">
                    This information will appear on your estimates, invoices, and reports.
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label>Company Name *</Label>
                    <Input
                      value={companyForm.company_name}
                      onChange={(e) => setCompanyForm({...companyForm, company_name: e.target.value})}
                      placeholder="ABC Roofing Company"
                    />
                  </div>

                  <div>
                    <Label>Email *</Label>
                    <Input
                      type="email"
                      value={companyForm.email}
                      onChange={(e) => setCompanyForm({...companyForm, email: e.target.value})}
                      placeholder="info@yourcompany.com"
                    />
                  </div>

                  <div>
                    <Label>Phone</Label>
                    <Input
                      value={companyForm.phone}
                      onChange={(e) => setCompanyForm({...companyForm, phone: e.target.value})}
                      placeholder="(555) 123-4567"
                    />
                  </div>

                  <div className="col-span-2">
                    <Label>Company Logo</Label>
                    <div className="flex items-center gap-4">
                      {logoFile || myCompany?.logo_url ? (
                        <img src={logoFile || myCompany?.logo_url} alt="Logo" className="w-16 h-16 object-cover rounded-lg border" />
                      ) : (
                        <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                          <Building2 className="w-8 h-8 text-gray-400" />
                        </div>
                      )}
                      <Button
                        variant="outline"
                        onClick={() => document.getElementById('logo-upload').click()}
                        disabled={uploadingLogo}
                      >
                        {uploadingLogo ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                        Upload Logo
                      </Button>
                      <input
                        id="logo-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleLogoUpload}
                      />
                    </div>
                  </div>

                  <div className="col-span-2">
                    <Label>Address</Label>
                    <Input
                      value={companyForm.address}
                      onChange={(e) => setCompanyForm({...companyForm, address: e.target.value})}
                      placeholder="123 Main St"
                    />
                  </div>

                  <div>
                    <Label>City</Label>
                    <Input
                      value={companyForm.city}
                      onChange={(e) => setCompanyForm({...companyForm, city: e.target.value})}
                      placeholder="Cleveland"
                    />
                  </div>

                  <div>
                    <Label>State</Label>
                    <Input
                      value={companyForm.state}
                      onChange={(e) => setCompanyForm({...companyForm, state: e.target.value})}
                      placeholder="OH"
                    />
                  </div>

                  <div>
                    <Label>Zip Code</Label>
                    <Input
                      value={companyForm.zip}
                      onChange={(e) => setCompanyForm({...companyForm, zip: e.target.value})}
                      placeholder="44101"
                    />
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <Button variant="outline" onClick={() => setCurrentStep(0)}>
                    <ArrowLeft className="mr-2 w-4 h-4" /> Back
                  </Button>
                  <Button 
                    onClick={handleCompanySubmit}
                    disabled={createCompanyMutation.isLoading}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    {createCompanyMutation.isLoading ? <Loader2 className="mr-2 w-4 h-4 animate-spin" /> : null}
                    Continue <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-6">
                <Alert className="bg-purple-50 border-purple-200">
                  <Phone className="w-4 h-4 text-purple-600" />
                  <AlertDescription className="text-purple-900">
                    <strong>Optional:</strong> Connect Twilio to enable click-to-call and SMS features. You can skip this and set it up later in Settings.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  <div>
                    <Label>Twilio Account SID</Label>
                    <Input
                      value={twilioForm.account_sid}
                      onChange={(e) => setTwilioForm({...twilioForm, account_sid: e.target.value})}
                      placeholder="AC..."
                    />
                  </div>

                  <div>
                    <Label>Twilio Auth Token</Label>
                    <Input
                      type="password"
                      value={twilioForm.auth_token}
                      onChange={(e) => setTwilioForm({...twilioForm, auth_token: e.target.value})}
                      placeholder="Your auth token"
                    />
                  </div>

                  <div>
                    <Label>Main Phone Number</Label>
                    <Input
                      value={twilioForm.main_phone_number}
                      onChange={(e) => setTwilioForm({...twilioForm, main_phone_number: e.target.value})}
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>

                  <Alert>
                    <AlertDescription className="text-sm">
                      Don't have a Twilio account? <a href="https://www.twilio.com/try-twilio" target="_blank" className="text-blue-600 underline" rel="noopener noreferrer">Sign up here</a> (free trial available)
                    </AlertDescription>
                  </Alert>
                </div>

                <div className="flex justify-between pt-6">
                  <Button variant="outline" onClick={() => setCurrentStep(1)}>
                    <ArrowLeft className="mr-2 w-4 h-4" /> Back
                  </Button>
                  <div className="flex gap-3">
                    <Button variant="ghost" onClick={() => setCurrentStep(3)}>
                      Skip for Now
                    </Button>
                    <Button 
                      onClick={handleTwilioSubmit}
                      disabled={createTwilioMutation.isLoading}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      {createTwilioMutation.isLoading ? <Loader2 className="mr-2 w-4 h-4 animate-spin" /> : null}
                      Continue <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-6">
                <Alert className="bg-green-50 border-green-200">
                  <Calendar className="w-4 h-4 text-green-600" />
                  <AlertDescription className="text-green-900">
                    <strong>Optional:</strong> Connect Google Calendar to automatically sync your CRM events with your Google Calendar.
                  </AlertDescription>
                </Alert>

                <div className="text-center py-8">
                  <Calendar className="w-24 h-24 mx-auto mb-6 text-green-600" />
                  <h3 className="text-xl font-semibold mb-3">Sync Your Calendar</h3>
                  <p className="text-gray-600 mb-6">
                    Connect your Google Calendar to keep all your appointments, estimates, and follow-ups in sync.
                  </p>

                  <div className="flex justify-center gap-4">
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={handleGoogleCalendarConnect}
                    >
                      <Calendar className="mr-2 w-5 h-5" />
                      Connect Google Calendar
                    </Button>
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <Button variant="outline" onClick={() => setCurrentStep(2)}>
                    <ArrowLeft className="mr-2 w-4 h-4" /> Back
                  </Button>
                  <Button 
                    onClick={() => setCurrentStep(4)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Continue <ArrowRight className="ml-2 w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-6">
                <Alert className="bg-orange-50 border-orange-200">
                  <UserPlus className="w-4 h-4 text-orange-600" />
                  <AlertDescription className="text-orange-900">
                    <strong>Optional:</strong> Add your first lead to get started. You can always add more leads later.
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <Label>Name</Label>
                    <Input
                      value={firstLeadForm.name}
                      onChange={(e) => setFirstLeadForm({...firstLeadForm, name: e.target.value})}
                      placeholder="John Smith"
                    />
                  </div>

                  <div>
                    <Label>Email</Label>
                    <Input
                      type="email"
                      value={firstLeadForm.email}
                      onChange={(e) => setFirstLeadForm({...firstLeadForm, email: e.target.value})}
                      placeholder="john@example.com"
                    />
                  </div>

                  <div>
                    <Label>Phone</Label>
                    <Input
                      value={firstLeadForm.phone}
                      onChange={(e) => setFirstLeadForm({...firstLeadForm, phone: e.target.value})}
                      placeholder="(555) 123-4567"
                    />
                  </div>

                  <div className="col-span-2">
                    <Label>Address</Label>
                    <Input
                      value={firstLeadForm.street}
                      onChange={(e) => setFirstLeadForm({...firstLeadForm, street: e.target.value})}
                      placeholder="123 Main St"
                    />
                  </div>

                  <div>
                    <Label>City</Label>
                    <Input
                      value={firstLeadForm.city}
                      onChange={(e) => setFirstLeadForm({...firstLeadForm, city: e.target.value})}
                      placeholder="Cleveland"
                    />
                  </div>

                  <div>
                    <Label>State</Label>
                    <Input
                      value={firstLeadForm.state}
                      onChange={(e) => setFirstLeadForm({...firstLeadForm, state: e.target.value})}
                      placeholder="OH"
                    />
                  </div>

                  <div className="col-span-2">
                    <Label>Notes</Label>
                    <Textarea
                      value={firstLeadForm.notes}
                      onChange={(e) => setFirstLeadForm({...firstLeadForm, notes: e.target.value})}
                      placeholder="Any additional notes about this lead..."
                      rows={3}
                    />
                  </div>
                </div>

                <div className="flex justify-between pt-6">
                  <Button variant="outline" onClick={() => setCurrentStep(3)}>
                    <ArrowLeft className="mr-2 w-4 h-4" /> Back
                  </Button>
                  <div className="flex gap-3">
                    <Button variant="ghost" onClick={() => setCurrentStep(5)}>
                      Skip for Now
                    </Button>
                    <Button 
                      onClick={handleLeadSubmit}
                      disabled={createLeadMutation.isLoading}
                      className="bg-orange-600 hover:bg-orange-700"
                    >
                      {createLeadMutation.isLoading ? <Loader2 className="mr-2 w-4 h-4 animate-spin" /> : null}
                      Continue <ArrowRight className="ml-2 w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            )}

            {currentStep === 5 && (
              <div className="text-center space-y-6 py-8">
                <div className="w-32 h-32 mx-auto bg-gradient-to-br from-green-400 to-blue-500 rounded-full flex items-center justify-center animate-pulse">
                  <Trophy className="w-16 h-16 text-white" />
                </div>
                <h2 className="text-4xl font-bold text-gray-900">All Set! 🎉</h2>
                <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                  Your CRM is ready to go. Start managing your leads, creating estimates, and growing your business!
                </p>

                <div className="grid grid-cols-3 gap-4 max-w-2xl mx-auto pt-6">
                  <Card className="text-center p-4">
                    <Building2 className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                    <p className="text-sm font-medium">Company Set Up</p>
                  </Card>
                  <Card className="text-center p-4">
                    <Phone className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                    <p className="text-sm font-medium">Integrations Ready</p>
                  </Card>
                  <Card className="text-center p-4">
                    <UserPlus className="w-8 h-8 mx-auto mb-2 text-green-600" />
                    <p className="text-sm font-medium">First Lead Added</p>
                  </Card>
                </div>

                <div className="flex justify-center gap-4 pt-8">
                  <Button 
                    onClick={handleFinish}
                    size="lg"
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
                  >
                    Go to Dashboard <ArrowRight className="ml-2 w-5 h-5" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Skip Setup Button */}
        <div className="text-center mt-4">
          <Button
            variant="ghost"
            onClick={() => navigate(createPageUrl('Dashboard'))}
            className="text-gray-500"
          >
            Skip Setup (I'll do this later)
          </Button>
        </div>
      </div>
    </div>
  );
}
