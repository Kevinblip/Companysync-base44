
import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useLocation, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Camera, Loader2, Image as ImageIcon, Trash2, FileDown, Edit, CheckCircle, Save, Pen } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from '@/components/ui/input';
import LiveCameraCapture from '../components/inspections/LiveCameraCapture';
import SignaturePad from '../components/SignaturePad';

const sections = [
    'Front Elevation', 'Right Elevation', 'Rear Elevation', 'Left Elevation', 
    'Front Slope', 'Right Slope', 'Back Slope', 'Left Slope', 'Interior', 'Other'
];

export default function InspectionCapture() {
    const navigate = useNavigate();
    const location = useLocation();
    const queryClient = useQueryClient();

    const [jobId, setJobId] = useState(null);
    const [activeSection, setActiveSection] = useState(sections[0]);
    const [isSecureContext, setIsSecureContext] = useState(false);
    const [sectionNotes, setSectionNotes] = useState({});
    const [isExporting, setIsExporting] = useState(false);
    const [selectedPhotos, setSelectedPhotos] = useState([]);
    const [showBulkEditDialog, setShowBulkEditDialog] = useState(false);
    const [bulkCaption, setBulkCaption] = useState('');
    const [showSignatureDialog, setShowSignatureDialog] = useState(false);
    const [inspectorSignature, setInspectorSignature] = useState('');
    
    useEffect(() => {
        setIsSecureContext(window.isSecureContext);
        const params = new URLSearchParams(location.search);
        const id = params.get('id');
        if (id) {
            setJobId(id);
        }
    }, [location.search]);

    const { data: job, isLoading: isLoadingJob } = useQuery({
        queryKey: ['inspectionJob', jobId],
        queryFn: () => base44.entities.InspectionJob.get(jobId),
        enabled: !!jobId,
        onSuccess: (data) => {
            if (data?.notes) {
                try {
                    setSectionNotes(JSON.parse(data.notes));
                } catch (e) {
                    setSectionNotes({ [sections[0]]: data.notes });
                }
            }
            if (data?.inspector_signature) {
                setInspectorSignature(data.inspector_signature);
            }
        }
    });

    const { data: media = [], isLoading: isLoadingMedia } = useQuery({
        queryKey: ['inspectionMedia', jobId],
        queryFn: () => jobId ? base44.entities.JobMedia.filter({ related_entity_id: jobId, related_entity_type: 'InspectionJob' }) : [],
        enabled: !!jobId,
        initialData: []
    });

    const createJobMutation = useMutation({
        mutationFn: (newJobData) => base44.entities.InspectionJob.create(newJobData),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['inspectionJobs'] });
        }
    });
    
    const updateJobNotesMutation = useMutation({
        mutationFn: ({ id, notes }) => base44.entities.InspectionJob.update(id, { notes: JSON.stringify(notes) }),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['inspectionJob', jobId] });
          alert("✅ Notes saved!");
        }
    });

    const updateSignatureMutation = useMutation({
        mutationFn: ({ id, signature }) => base44.entities.InspectionJob.update(id, { inspector_signature: signature }),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['inspectionJob', jobId] });
          setShowSignatureDialog(false);
          alert("✅ Signature saved!");
        }
    });

    const uploadMutation = useMutation({
        mutationFn: async ({ file, section, caption, targetJobId }) => {
          const { file_url } = await base44.integrations.Core.UploadFile({ file });
          const file_type = file.type.startsWith('video') ? 'video' : 'photo';
    
          return base44.entities.JobMedia.create({
            related_entity_id: targetJobId,
            related_entity_type: 'InspectionJob',
            file_url,
            file_type,
            section,
            caption,
            uploaded_by_name: 'Admin'
          });
        },
        onSuccess: (data, variables) => {
          queryClient.invalidateQueries({ queryKey: ['inspectionMedia', variables.targetJobId] });
        }
    });

    const updateMediaMutation = useMutation({
        mutationFn: ({ id, caption }) => base44.entities.JobMedia.update(id, { caption }),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['inspectionMedia', jobId] });
        }
    });

    const deleteMutation = useMutation({
        mutationFn: (mediaId) => base44.entities.JobMedia.delete(mediaId),
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ['inspectionMedia', jobId] });
          setSelectedPhotos([]);
        }
    });

    const handleUploadWithJobCreation = async (uploadFn) => {
        let currentJobId = jobId;

        if (!currentJobId) {
            try {
                const newJob = await createJobMutation.mutateAsync({
                    property_address: `Unassigned Inspection - ${new Date().toLocaleString()}`,
                    status: 'pending'
                });
                currentJobId = newJob.id;
                setJobId(newJob.id);
                navigate(createPageUrl(`InspectionCapture?id=${newJob.id}`), { replace: true });
            } catch (error) {
                console.error("Failed to create temporary job", error);
                return;
            }
        }
        
        await uploadFn(currentJobId);
    };

    const handleLiveCaptureUpload = async ({ file, caption }) => {
        await handleUploadWithJobCreation(async (currentJobId) => {
            await uploadMutation.mutateAsync({ file, section: activeSection, caption, targetJobId: currentJobId });
        });
    };

    const handleSaveNotes = () => {
        if (!jobId) {
            alert("Please create the inspection job first before saving notes.");
            return;
        }
        updateJobNotesMutation.mutate({ id: jobId, notes: sectionNotes });
    };

    const handleSectionNotesChange = (section, text) => {
        setSectionNotes(prev => ({ ...prev, [section]: text }));
    };

    const handleSaveSignature = (signatureDataUrl) => {
        if (!jobId) {
            alert("Please create the inspection job first.");
            return;
        }
        setInspectorSignature(signatureDataUrl);
        updateSignatureMutation.mutate({ id: jobId, signature: signatureDataUrl });
    };

    const compressImage = (file) => {
        return new Promise((resolve, reject) => {
            const canvas = document.createElement("canvas");
            const ctx = canvas.getContext("2d");
            const img = new Image();

            img.onload = () => {
                // Calculate new dimensions (max 800px width)
                const maxWidth = 800;
                let width = img.width;
                let height = img.height;

                // Resize if too large, maintaining aspect ratio
                if (width > maxWidth || height > maxWidth) { // Use maxWidth for height too, to keep landscape/portrait flexibility
                    const ratio = Math.min(maxWidth / width, maxWidth / height);
                    width = width * ratio;
                    height = height * ratio;
                }
                
                canvas.width = width;
                canvas.height = height;

                // Draw and compress
                ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                canvas.toBlob(
                    (blob) => {
                        if (blob) {
                            const reader = new FileReader();
                            reader.onloadend = () => resolve(reader.result);
                            reader.readAsDataURL(blob);
                        } else {
                            reject(new Error("Canvas toBlob returned null"));
                        }
                    },
                    "image/jpeg",
                    0.6 // 60% quality for good compression
                );
            };

            img.onerror = (e) => reject(new Error("Failed to load image for compression: " + e.message));
            img.crossOrigin = 'anonymous'; // Important for handling images from other origins
            img.src = file;
        });
    };

    const handleExportPDF = async () => {
        if (!jobId) {
            alert("Please save the inspection first before exporting.");
            return;
        }

        setIsExporting(true);
        try {
            console.log("Starting PDF export with", media.length, "media items");
            
            const imagesData = [];
            for (const mediaItem of media) {
                if (mediaItem.file_type === 'photo') {
                    try {
                        console.log("Compressing image:", mediaItem.file_url);
                        
                        // Use your proven compression method
                        const compressedBase64 = await compressImage(mediaItem.file_url);
                        
                        console.log("✅ Compressed successfully");
                        
                        imagesData.push({
                            section: mediaItem.section,
                            caption: mediaItem.caption || '',
                            base64Data: compressedBase64
                        });
                    } catch (error) {
                        console.error('Error processing image:', mediaItem.file_url, error);
                    }
                }
            }
            
            console.log(`Successfully processed ${imagesData.length} images`);
            
            if (imagesData.length === 0 && media.some(item => item.file_type === 'photo')) {
                alert("No images could be processed for export. Ensure images are accessible.");
                setIsExporting(false);
                return;
            } else if (imagesData.length === 0 && !media.some(item => item.file_type === 'photo')) {
                // Allow export even if no photos, as notes and signature might be present
                console.log("No photos found for export, proceeding with other data.");
            }
            
            console.log("Sending to PDF generator...");
            const response = await base44.functions.invoke('generateInspectionPDF', { 
                jobId: jobId,
                imagesData: imagesData,
                sectionNotes: sectionNotes,
                inspectorSignature: inspectorSignature
            });
            
            console.log("PDF generated, downloading...");
            
            const blob = new Blob([response.data], { type: 'application/pdf' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `Inspection_Report_${job?.property_address?.replace(/[^a-zA-Z0-9]/g, '_') || 'Unknown'}_${new Date().toISOString().split('T')[0]}.pdf`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            a.remove();
            
            console.log("✅ PDF download initiated");
        } catch (error) {
            console.error("Error exporting PDF:", error);
            alert("Failed to export PDF: " + (error.message || "An unknown error occurred."));
        }
        setIsExporting(false);
    };

    const handlePhotoSelect = (photoId) => {
        setSelectedPhotos(prev => {
            if (prev.includes(photoId)) {
                return prev.filter(id => id !== photoId);
            } else {
                return [...prev, photoId];
            }
        });
    };

    const handleSelectAll = () => {
        if (selectedPhotos.length === activeSectionMedia.length) {
            setSelectedPhotos([]);
        } else {
            setSelectedPhotos(activeSectionMedia.map(m => m.id));
        }
    };

    const handleBulkEdit = () => {
        if (selectedPhotos.length === 0) return;
        setShowBulkEditDialog(true);
    };

    const handleBulkCaptionSave = async () => {
        for (const photoId of selectedPhotos) {
            const existingPhoto = media.find(m => m.id === photoId);
            const existingCaption = existingPhoto?.caption || '';
            const newCaption = existingCaption ? `${existingCaption}\n${bulkCaption}` : bulkCaption;
            await updateMediaMutation.mutateAsync({ id: photoId, caption: newCaption });
        }
        setShowBulkEditDialog(false);
        setSelectedPhotos([]);
        setBulkCaption('');
    };

    const handleBulkDelete = () => {
        if (selectedPhotos.length === 0) return;
        if (window.confirm(`Delete ${selectedPhotos.length} selected photos?`)) {
            selectedPhotos.forEach(photoId => {
                deleteMutation.mutate(photoId);
            });
        }
    };

    const activeSectionMedia = jobId ? media.filter(m => m.section === activeSection) : [];

    if (isLoadingJob && jobId) {
        return <div className="p-6 text-center"><Loader2 className="animate-spin" /></div>;
    }

    return (
        <div className="p-2 md:p-6 bg-gray-50 min-h-screen">
            <div className="max-w-7xl mx-auto space-y-4">
                <Button variant="ghost" onClick={() => navigate(createPageUrl('InspectionsDashboard'))} className="mb-2">
                    <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
                </Button>

                <div className="flex justify-between items-start">
                    <div>
                        <h1 className="text-xl md:text-2xl font-bold">Photo Capture</h1>
                        <p className="text-sm text-gray-500">{job?.property_address || 'New Unassigned Inspection'}</p>
                    </div>
                    {jobId && (
                        <Button 
                            onClick={handleExportPDF} 
                            disabled={isExporting}
                            className="bg-blue-600 hover:bg-blue-700"
                        >
                            {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <FileDown className="w-4 h-4 mr-2" />}
                            Export Report
                        </Button>
                    )}
                </div>
                
                {!isSecureContext && (
                    <Card className="bg-yellow-50 border-yellow-300">
                        <CardHeader>
                            <CardTitle className="text-yellow-800 flex items-center gap-2">
                                <Camera className="w-5 h-5"/> Action Required to Enable Camera
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            <p className="text-yellow-700 mb-4">Your browser requires a secure (HTTPS) connection to access the camera.</p>
                            <Button asChild>
                                <a href={window.location.href.replace('http://', 'https://://')}>
                                    Reload Page Securely to Activate Camera
                                </a>
                            </Button>
                        </CardContent>
                    </Card>
                )}

                {isSecureContext && <LiveCameraCapture onUpload={handleLiveCaptureUpload} onVoiceNote={text => handleSectionNotesChange(activeSection, (sectionNotes[activeSection] || '') + '\n' + text)} />}
                
                <Card>
                    <CardContent className="p-2 md:p-4">
                        <div className="mb-4 overflow-x-auto pb-2">
                           <div className="flex space-x-2 flex-wrap">
                            {sections.map(section => {
                                const count = jobId ? media.filter(m => m.section === section).length : 0;
                                return (
                                    <Button 
                                        key={section}
                                        variant={activeSection === section ? 'default' : 'outline'}
                                        onClick={() => {
                                            setActiveSection(section);
                                            setSelectedPhotos([]);
                                        }}
                                        className="flex-shrink-0 mb-2"
                                    >
                                        {section} {count > 0 && `(${count})`}
                                    </Button>
                                );
                            })}
                           </div>
                        </div>

                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-2">
                             <div>
                                <h3 className="font-semibold text-lg mb-1">{activeSection}</h3>
                                <p className="text-xs md:text-sm text-gray-600">Captured photos for this section.</p>
                            </div>
                            <div className="flex gap-2 flex-wrap">
                                {activeSectionMedia.length > 0 && (
                                    <>
                                        <Button 
                                            variant="outline" 
                                            size="sm" 
                                            onClick={handleSelectAll}
                                            className="text-blue-600"
                                        >
                                            <CheckCircle className="w-4 h-4 mr-1" />
                                            {selectedPhotos.length === activeSectionMedia.length ? 'Deselect All' : 'Select All'}
                                        </Button>
                                        {selectedPhotos.length > 0 && (
                                            <>
                                                <Button variant="outline" size="sm" onClick={handleBulkEdit}>
                                                    <Edit className="w-4 h-4 mr-1" /> Add Notes ({selectedPhotos.length})
                                                </Button>
                                                <Button variant="outline" size="sm" onClick={handleBulkDelete} className="text-red-600">
                                                    <Trash2 className="w-4 h-4 mr-1" /> Delete ({selectedPhotos.length})
                                                </Button>
                                            </>
                                        )}
                                    </>
                                )}
                            </div>
                        </div>

                        <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2 mb-4 min-h-[150px]">
                            {isLoadingMedia && jobId ? <div className="col-span-full flex justify-center items-center py-8"><Loader2 className="animate-spin h-8 w-8 text-gray-500"/></div> : (
                                activeSectionMedia.length > 0 ? (
                                    activeSectionMedia.map(item => {
                                        const isSelected = selectedPhotos.includes(item.id);
                                        return (
                                            <Card 
                                                key={item.id} 
                                                className={`relative group cursor-pointer ${isSelected ? 'ring-2 ring-blue-500' : ''}`}
                                                onClick={() => handlePhotoSelect(item.id)}
                                            >
                                                <div className="aspect-square bg-gray-200 rounded-t-md flex items-center justify-center">
                                                    <img src={item.file_url} alt={item.caption || ''} className="w-full h-full object-cover rounded-t-md" />
                                                    {isSelected && (
                                                        <div className="absolute top-1 right-1 bg-blue-500 text-white rounded-full p-1">
                                                            <CheckCircle className="w-4 h-4" />
                                                        </div>
                                                    )}
                                                </div>
                                                <CardContent className="p-1.5 hidden sm:block">
                                                    <p className="text-xs text-gray-600 truncate">{item.caption || 'No caption'}</p>
                                                </CardContent>
                                            </Card>
                                        );
                                    })
                                ) : (
                                    <div className="col-span-full flex flex-col items-center justify-center text-center text-gray-500 py-8">
                                        <ImageIcon className="w-10 h-10 mb-2"/>
                                        <p className="text-sm">No photos captured yet.</p>
                                        <p className="text-xs text-gray-400 mt-1">Use the camera above to take photos</p>
                                    </div>
                                )
                            )}
                        </div>

                        <div>
                            <div className="flex justify-between items-center mb-2">
                                <Label>Section Notes</Label>
                                <Button 
                                    size="sm" 
                                    variant="outline"
                                    onClick={handleSaveNotes}
                                    disabled={!jobId || updateJobNotesMutation.isLoading}
                                >
                                    {updateJobNotesMutation.isLoading ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Save className="w-4 h-4 mr-1" />}
                                    Save Notes
                                </Button>
                            </div>
                            <Textarea 
                                placeholder={`Add notes for ${activeSection}...`}
                                value={sectionNotes[activeSection] || ''}
                                onChange={(e) => handleSectionNotesChange(activeSection, e.target.value)}
                                rows={4}
                            />
                        </div>
                    </CardContent>
                </Card>

                {jobId && (
                    <Card>
                        <CardHeader>
                            <CardTitle className="flex items-center justify-between">
                                <span>Inspector Signature</span>
                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => setShowSignatureDialog(true)}
                                >
                                    <Pen className="w-4 h-4 mr-2" />
                                    {inspectorSignature ? 'Update Signature' : 'Add Signature'}
                                </Button>
                            </CardTitle>
                        </CardHeader>
                        <CardContent>
                            {inspectorSignature ? (
                                <div className="border rounded p-4 bg-white max-w-xs sm:max-w-sm">
                                    <img src={inspectorSignature} alt="Inspector Signature" className="max-h-32 w-full object-contain" />
                                </div>
                            ) : (
                                <p className="text-gray-500 text-sm">No signature added yet. Click "Add Signature" to certify this inspection.</p>
                            )}
                        </CardContent>
                    </Card>
                )}
            </div>

            <Dialog open={showBulkEditDialog} onOpenChange={setShowBulkEditDialog}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Add Notes to {selectedPhotos.length} Photos</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                        <div>
                            <Label>Additional notes (will be added to existing notes)</Label>
                            <Input
                                value={bulkCaption}
                                onChange={(e) => setBulkCaption(e.target.value)}
                                placeholder="e.g., Hail damage visible"
                            />
                        </div>
                    </div>
                    <div className="flex justify-end gap-2 mt-4">
                        <Button variant="outline" onClick={() => setShowBulkEditDialog(false)}>Cancel</Button>
                        <Button onClick={handleBulkCaptionSave}>Add Notes</Button>
                    </div>
                </DialogContent>
            </Dialog>

            <Dialog open={showSignatureDialog} onOpenChange={setShowSignatureDialog}>
                <DialogContent className="max-w-md">
                    <DialogHeader>
                        <DialogTitle>Inspector Signature</DialogTitle>
                    </DialogHeader>
                    <SignaturePad onSave={handleSaveSignature} onCancel={() => setShowSignatureDialog(false)} />
                </DialogContent>
            </Dialog>
        </div>
    );
}
