
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Edit, Trash2, Shield, Loader2, Save } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";

const PERMISSION_CONFIG = [
    {
        group: "Standard Permissions",
        features: [
            { name: "Estimates", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Invoices", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Proposals", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Payments", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Items", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Customers", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Leads", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Projects", capabilities: ["view", "create", "edit", "delete", "create_timesheets", "edit_milestones"] },
            { name: "Tasks", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Contracts", capabilities: ["view", "create", "edit", "delete"] },
        ],
    },
    {
        group: "Administrative",
        features: [
            { name: "Staff", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Settings", capabilities: ["view", "edit"] },
            { name: "Reports", capabilities: ["view"] },
            { name: "Workflows", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Email Templates", capabilities: ["view", "edit"] },
        ],
    },
    {
        group: "HR & Payroll",
        features: [
            { name: "HR Management", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Payroll Employees", capabilities: ["view_own", "view_global", "create", "edit", "delete"] },
            { name: "Payroll Attendances", capabilities: ["view_own", "view_global", "create", "edit"] },
            { name: "Payroll Commissions", capabilities: ["view_own", "view_global", "create", "edit", "delete"] },
        ],
    },
    {
        group: "Accounting",
        features: [
            { name: "Accounting Dashboard", capabilities: ["view"] },
            { name: "Transactions", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Journal Entry", capabilities: ["view", "create", "edit", "delete"] },
            { name: "Chart of Accounts", capabilities: ["view", "create", "edit", "delete"] },
        ],
    },
    {
        group: "Communication & Tools",
        features: [
            { name: "Zoom Meeting", capabilities: ["view"] },
            { name: "PrediX AI", capabilities: ["view", "create_images", "create_audio"] },
            { name: "Chat Module", capabilities: ["view", "audio_call", "video_call", "send_sms"] },
        ],
    }
];

const formatCapabilityName = (name) => {
    return name.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
};

function PermissionsGrid({ permissions, onPermissionChange }) {
  return (
    <div className="space-y-8 max-h-[60vh] overflow-y-auto p-1">
      {PERMISSION_CONFIG.map(({ group, features }) => (
        <div key={group}>
          <h3 className="text-xl font-bold mb-4 border-b pb-2">{group}</h3>
          <div className="space-y-4">
            {features.map(feature => (
              <div key={feature.name} className="grid grid-cols-1 md:grid-cols-5 items-start">
                <span className="font-semibold col-span-1">{feature.name}</span>
                <div className="col-span-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {feature.capabilities.map(capability => (
                    <div key={capability} className="flex items-center gap-2">
                      <Checkbox
                        id={`${feature.name}-${capability}`}
                        checked={permissions?.[feature.name.toLowerCase().replace(/ /g, '_')]?.[capability] || false}
                        onCheckedChange={() => onPermissionChange(feature.name, capability)}
                      />
                      <Label htmlFor={`${feature.name}-${capability}`} className="text-sm font-normal">
                        {formatCapabilityName(capability)}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export default function RolesManagement() {
  const [user, setUser] = useState(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingRole, setEditingRole] = useState(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  const { data: roles = [], isLoading: isLoadingRoles } = useQuery({
    queryKey: ['staff-roles', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.StaffRole.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
  });

  const upsertMutation = useMutation({
    mutationFn: (roleData) => {
      const payload = { ...roleData, company_id: myCompany.id };
      if (editingRole) {
        return base44.entities.StaffRole.update(editingRole.id, payload);
      } else {
        return base44.entities.StaffRole.create(payload);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-roles'] });
      setIsDialogOpen(false);
      setEditingRole(null);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (roleId) => base44.entities.StaffRole.delete(roleId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['staff-roles'] });
    }
  });

  const handleOpenDialog = (role = null) => {
    setEditingRole(role);
    setIsDialogOpen(true);
  };

  const handleDelete = (roleId) => {
    if (window.confirm("Are you sure you want to delete this role? This cannot be undone.")) {
      deleteMutation.mutate(roleId);
    }
  };
  
  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Roles Management</h1>
          <p className="text-gray-500 mt-1">Create and manage staff roles and permissions</p>
        </div>
        <Button onClick={() => handleOpenDialog()}>
          <Plus className="w-4 h-4 mr-2" />
          Create New Role
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Roles</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingRoles ? (
            <div className="flex justify-center items-center h-32">
              <Loader2 className="w-8 h-8 animate-spin text-gray-400" />
            </div>
          ) : roles.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Shield className="w-12 h-12 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold">No Roles Created Yet</h3>
              <p className="text-sm mb-4">Click "Create New Role" to set up your first role.</p>
              <Button onClick={() => handleOpenDialog()}>
                <Plus className="w-4 h-4 mr-2" />
                Create New Role
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {roles.map(role => (
                <div key={role.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                  <span className="font-semibold text-gray-800">{role.name}</span>
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => handleOpenDialog(role)}>
                      <Edit className="w-4 h-4 mr-2" /> Edit
                    </Button>
                    <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700" onClick={() => handleDelete(role.id)}>
                      <Trash2 className="w-4 h-4 mr-2" /> Delete
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      
      <RoleFormDialog 
        isOpen={isDialogOpen} 
        onOpenChange={setIsDialogOpen}
        role={editingRole}
        onSave={upsertMutation.mutate}
        isLoading={upsertMutation.isLoading}
      />
    </div>
  );
}

function RoleFormDialog({ isOpen, onOpenChange, role, onSave, isLoading }) {
    const [name, setName] = useState('');
    const [permissions, setPermissions] = useState({});

    useEffect(() => {
        if (isOpen && role) {
            setName(role.name);
            setPermissions(role.permissions || {});
        } else if (isOpen && !role) {
            setName('');
            setPermissions({});
        }
    }, [isOpen, role]);

    const handlePermissionChange = (featureKey, capability) => {
        setPermissions(p => {
          const newPermissions = JSON.parse(JSON.stringify(p)); // Deep copy
          const normalizedFeatureKey = featureKey.toLowerCase().replace(/ /g, '_');
          if (!newPermissions[normalizedFeatureKey]) newPermissions[normalizedFeatureKey] = {};
          newPermissions[normalizedFeatureKey][capability] = !newPermissions[normalizedFeatureKey][capability];
          return newPermissions;
        });
    };
    
    const handleSave = () => {
        if (!name.trim()) {
            alert("Role name is required.");
            return;
        }
        onSave({ name, permissions });
    };
    
    return (
        <Dialog open={isOpen} onOpenChange={onOpenChange}>
            <DialogContent className="max-w-4xl">
                <DialogHeader>
                    <DialogTitle>{role ? `Edit Role: ${role.name}` : 'Create New Role'}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                    <div>
                        <Label htmlFor="role-name" className="text-lg font-semibold">Role Name</Label>
                        <Input 
                            id="role-name"
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            placeholder="e.g., Sales Manager"
                            className="mt-2 text-base"
                        />
                    </div>
                    <PermissionsGrid permissions={permissions} onPermissionChange={handlePermissionChange} />
                </div>
                <DialogFooter>
                    <DialogClose asChild>
                        <Button type="button" variant="outline">Cancel</Button>
                    </DialogClose>
                    <Button onClick={handleSave} disabled={isLoading}>
                        {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                        <Save className="w-4 h-4 mr-2" />
                        Save Role
                    </Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    )
}
