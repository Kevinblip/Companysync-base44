import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  User,
  Phone,
  Mail,
  MapPin,
  ArrowLeft,
  DollarSign,
  FileText
} from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function CustomerProfile() {
  const navigate = useNavigate();
  const [customerName, setCustomerName] = useState(null);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const name = urlParams.get('name');
    if (name) {
      setCustomerName(decodeURIComponent(name));
    }
  }, []);

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
    initialData: [],
  });

  const customer = customers.find(c => c.name === customerName);

  const { data: estimates = [] } = useQuery({
    queryKey: ['customer-estimates', customerName],
    queryFn: () => customerName ? base44.entities.Estimate.filter({ customer_name: customerName }) : [],
    enabled: !!customerName,
    initialData: [],
  });

  const { data: invoices = [] } = useQuery({
    queryKey: ['customer-invoices', customerName],
    queryFn: () => customerName ? base44.entities.Invoice.filter({ customer_name: customerName }) : [],
    enabled: !!customerName,
    initialData: [],
  });

  const { data: payments = [] } = useQuery({
    queryKey: ['customer-payments', customerName],
    queryFn: () => customerName ? base44.entities.Payment.filter({ customer_name: customerName }) : [],
    enabled: !!customerName,
    initialData: [],
  });

  if (!customer) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-gray-500 mb-4">Customer not found</p>
            <Button onClick={() => navigate(createPageUrl('Customers'))}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Customers
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalRevenue = payments
    .filter(p => p.status === 'received')
    .reduce((sum, p) => sum + (p.amount || 0), 0);

  const totalEstimates = estimates.reduce((sum, e) => sum + (e.amount || 0), 0);
  const totalInvoices = invoices.reduce((sum, i) => sum + (i.amount || 0), 0);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            onClick={() => navigate(createPageUrl('Customers'))}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-3xl font-bold">{customer.name}</h1>
            {customer.company && <p className="text-gray-500">{customer.company}</p>}
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Total Revenue</p>
                <p className="text-2xl font-bold">${totalRevenue.toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Estimates</p>
                <p className="text-2xl font-bold">{estimates.length}</p>
                <p className="text-xs text-gray-400">${totalEstimates.toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Invoices</p>
                <p className="text-2xl font-bold">{invoices.length}</p>
                <p className="text-xs text-gray-400">${totalInvoices.toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Contact Info */}
      <Card>
        <CardHeader>
          <CardTitle>Contact Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-gray-400" />
              <div>
                <p className="text-sm text-gray-500">Name</p>
                <p className="font-medium">{customer.name}</p>
              </div>
            </div>

            {customer.email && (
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">Email</p>
                  <p className="font-medium">{customer.email}</p>
                </div>
              </div>
            )}

            {customer.phone && (
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">Phone</p>
                  <p className="font-medium">{customer.phone}</p>
                </div>
              </div>
            )}

            {customer.phone_2 && (
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">Phone 2</p>
                  <p className="font-medium">{customer.phone_2}</p>
                </div>
              </div>
            )}

            {customer.address && (
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-500">Address</p>
                  <p className="font-medium">{customer.address}</p>
                </div>
              </div>
            )}
          </div>

          {customer.notes && (
            <div className="pt-4 border-t">
              <p className="text-sm text-gray-500 mb-2">Notes</p>
              <p className="text-gray-700">{customer.notes}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Estimates */}
      {estimates.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Estimates ({estimates.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {estimates.slice(0, 5).map(estimate => (
                <div key={estimate.id} className="flex justify-between items-center p-3 border rounded hover:bg-gray-50">
                  <div>
                    <p className="font-medium">{estimate.estimate_number}</p>
                    <Badge variant="outline" className="mt-1">{estimate.status}</Badge>
                  </div>
                  <p className="font-bold text-green-600">${(estimate.amount || 0).toFixed(2)}</p>
                </div>
              ))}
            </div>
            {estimates.length > 5 && (
              <Button 
                variant="outline" 
                className="w-full mt-4"
                onClick={() => navigate(createPageUrl('Estimates'))}
              >
                View All Estimates
              </Button>
            )}
          </CardContent>
        </Card>
      )}

      {/* Recent Invoices */}
      {invoices.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Invoices ({invoices.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {invoices.slice(0, 5).map(invoice => (
                <div key={invoice.id} className="flex justify-between items-center p-3 border rounded hover:bg-gray-50">
                  <div>
                    <p className="font-medium">{invoice.invoice_number}</p>
                    <Badge variant="outline" className="mt-1">{invoice.status}</Badge>
                  </div>
                  <p className="font-bold text-green-600">${(invoice.amount || 0).toFixed(2)}</p>
                </div>
              ))}
            </div>
            {invoices.length > 5 && (
              <Button 
                variant="outline" 
                className="w-full mt-4"
                onClick={() => navigate(createPageUrl('Invoices'))}
              >
                View All Invoices
              </Button>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}