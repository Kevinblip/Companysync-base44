import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Upload,
  Globe,
  FileText,
  Brain,
  CheckCircle,
  Loader2,
  Trash2,
  Phone,
  MessageSquare,
  Mic
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function AITraining() {
  const [user, setUser] = useState(null);
  const [uploadType, setUploadType] = useState("website");
  const [websiteUrl, setWebsiteUrl] = useState("");
  const [textContent, setTextContent] = useState("");
  const [title, setTitle] = useState("");
  const [loading, setLoading] = useState(false);

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  const { data: profile = [] } = useQuery({
    queryKey: ['company-profile', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.CompanyProfile.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const { data: trainingData = [] } = useQuery({
    queryKey: ['training-data', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.AITrainingData.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const currentProfile = profile[0];

  const createProfileMutation = useMutation({
    mutationFn: (data) => base44.entities.CompanyProfile.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-profile'] });
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.CompanyProfile.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['company-profile'] });
    },
  });

  const createTrainingMutation = useMutation({
    mutationFn: (data) => base44.entities.AITrainingData.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-data'] });
      setWebsiteUrl("");
      setTextContent("");
      setTitle("");
      setLoading(false);
    },
  });

  const deleteTrainingMutation = useMutation({
    mutationFn: (id) => base44.entities.AITrainingData.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['training-data'] });
    },
  });

  const handleImportWebsite = async () => {
    if (!websiteUrl || !myCompany) return;
    
    setLoading(true);
    try {
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Visit this website: ${websiteUrl}
        
Extract and summarize:
1. What services/products they offer
2. Their target customers
3. Their sales process/approach
4. Key terminology they use
5. Any unique aspects of their business
6. Common questions customers ask
7. Pricing information (if available)

Format as structured text that can be used to train an AI assistant.`,
        add_context_from_internet: true
      });

      createTrainingMutation.mutate({
        company_id: myCompany.id,
        data_type: "website",
        title: `Website Import: ${websiteUrl}`,
        content: typeof response === 'string' ? response : JSON.stringify(response),
        source_url: websiteUrl,
        is_active: true,
        priority: 10
      });
    } catch (error) {
      alert("Failed to import website: " + error.message);
      setLoading(false);
    }
  };

  const handleUploadText = () => {
    if (!title || !textContent || !myCompany) return;

    createTrainingMutation.mutate({
      company_id: myCompany.id,
      data_type: "text",
      title: title,
      content: textContent,
      is_active: true,
      priority: 5
    });
  };

  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file || !myCompany) return;

    setLoading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });

      // Extract text from PDF
      const response = await base44.integrations.Core.InvokeLLM({
        prompt: `Read this PDF and extract all useful information that would help an AI assistant understand this business. Include services, processes, terminology, and any other relevant details.`,
        file_urls: [file_url]
      });

      createTrainingMutation.mutate({
        company_id: myCompany.id,
        data_type: "pdf",
        title: file.name,
        content: typeof response === 'string' ? response : JSON.stringify(response),
        file_url: file_url,
        is_active: true,
        priority: 8
      });
    } catch (error) {
      alert("Failed to upload file: " + error.message);
    }
    setLoading(false);
  };

  if (!myCompany) {
    return (
      <div className="p-6">
        <div className="text-center py-12 text-gray-500">
          Please set up your company first
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Train Your AI Assistant</h1>
        <p className="text-gray-500 mt-1">
          Help Lexi understand your business by uploading training materials
        </p>
      </div>

      {/* AI Capabilities Alert */}
      <Alert className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
        <Brain className="w-5 h-5 text-purple-600" />
        <AlertDescription>
          <div className="space-y-2">
            <p className="font-semibold text-purple-900">Lexi's AI Capabilities:</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-green-600" />
                <span>Answers incoming calls with natural voice</span>
              </div>
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-blue-600" />
                <span>Responds to incoming SMS intelligently</span>
              </div>
              <div className="flex items-center gap-2">
                <Mic className="w-4 h-4 text-purple-600" />
                <span>Uses ElevenLabs natural voice</span>
              </div>
            </div>
          </div>
        </AlertDescription>
      </Alert>

      {/* Training Status */}
      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Brain className="w-8 h-8 text-blue-600" />
              <div>
                <h3 className="font-semibold text-lg">AI Training Status</h3>
                <p className="text-sm text-gray-600">
                  {trainingData.length} training materials uploaded
                </p>
              </div>
            </div>
            <Badge className={
              trainingData.length > 0 ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"
            }>
              {trainingData.length > 0 ? "✅ Trained" : "⚠️ Not Trained Yet"}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Upload Options */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button
          variant={uploadType === "website" ? "default" : "outline"}
          className="h-auto py-6 flex-col gap-2"
          onClick={() => setUploadType("website")}
        >
          <Globe className="w-6 h-6" />
          <span>Import Website</span>
        </Button>
        <Button
          variant={uploadType === "pdf" ? "default" : "outline"}
          className="h-auto py-6 flex-col gap-2"
          onClick={() => setUploadType("pdf")}
        >
          <Upload className="w-6 h-6" />
          <span>Upload PDF</span>
        </Button>
        <Button
          variant={uploadType === "text" ? "default" : "outline"}
          className="h-auto py-6 flex-col gap-2"
          onClick={() => setUploadType("text")}
        >
          <FileText className="w-6 h-6" />
          <span>Add Text</span>
        </Button>
      </div>

      {/* Upload Forms */}
      <Card>
        <CardHeader>
          <CardTitle>
            {uploadType === "website" && "Import from Website"}
            {uploadType === "pdf" && "Upload PDF Document"}
            {uploadType === "text" && "Add Text Content"}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {uploadType === "website" && (
            <>
              <div>
                <Label>Website URL</Label>
                <Input
                  placeholder="https://yourcompany.com"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                />
                <p className="text-xs text-gray-500 mt-1">
                  AI will visit your website and extract key information
                </p>
              </div>
              <Button
                onClick={handleImportWebsite}
                disabled={!websiteUrl || loading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Importing...
                  </>
                ) : (
                  <>
                    <Globe className="w-4 h-4 mr-2" />
                    Import Website
                  </>
                )}
              </Button>
            </>
          )}

          {uploadType === "pdf" && (
            <>
              <div>
                <Label>Upload PDF File</Label>
                <Input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileUpload}
                  disabled={loading}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Upload service guides, manuals, or process documents
                </p>
              </div>
              {loading && (
                <div className="flex items-center gap-2 text-blue-600">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing PDF...</span>
                </div>
              )}
            </>
          )}

          {uploadType === "text" && (
            <>
              <div>
                <Label>Title</Label>
                <Input
                  placeholder="e.g., Our Service Process"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>
              <div>
                <Label>Content</Label>
                <Textarea
                  placeholder="Paste or type your content here... (FAQs, service descriptions, processes, pricing info, etc.)"
                  rows={8}
                  value={textContent}
                  onChange={(e) => setTextContent(e.target.value)}
                />
              </div>
              <Button
                onClick={handleUploadText}
                disabled={!title || !textContent || loading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <FileText className="w-4 h-4 mr-2" />
                Add Training Data
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      {/* Training Data List */}
      <Card>
        <CardHeader>
          <CardTitle>Training Materials ({trainingData.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {trainingData.map((data) => (
              <div
                key={data.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center gap-3 flex-1">
                  {data.data_type === "website" && <Globe className="w-5 h-5 text-blue-600" />}
                  {data.data_type === "pdf" && <FileText className="w-5 h-5 text-red-600" />}
                  {data.data_type === "text" && <FileText className="w-5 h-5 text-gray-600" />}
                  <div className="flex-1">
                    <p className="font-medium">{data.title}</p>
                    <p className="text-sm text-gray-500 line-clamp-2">
                      {data.content?.substring(0, 150)}...
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-green-50 text-green-700">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Active
                  </Badge>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      if (confirm('Delete this training material?')) {
                        deleteTrainingMutation.mutate(data.id);
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </Button>
                </div>
              </div>
            ))}
            {trainingData.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                <Brain className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p className="font-medium mb-1">No training materials yet</p>
                <p className="text-sm">Upload your website, PDFs, or add text to help Lexi understand your business!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Tips */}
      <Card>
        <CardHeader>
          <CardTitle>💡 Training Tips</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm text-gray-600">
            <p>✅ <strong>Website:</strong> Best for getting overall business info, services, and FAQs</p>
            <p>✅ <strong>PDFs:</strong> Great for detailed service guides, manuals, and processes</p>
            <p>✅ <strong>Text:</strong> Perfect for specific instructions, scripts, or custom info</p>
            <p>✅ <strong>More data = Better AI:</strong> The more you train, the smarter Lexi gets!</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}