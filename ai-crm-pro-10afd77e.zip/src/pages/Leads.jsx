
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Plus, Search, Mail, Phone, MessageCircle, Eye, Edit, Trash2, Download, RefreshCw, Calendar, Columns3, TrendingUp, TrendingDown, Minus, Flame, Snowflake, ThermometerSun, Trophy, UserPlus, Camera } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import Dialer from "../components/communication/Dialer";
import EmailDialog from "../components/communication/EmailDialog";
import SMSDialog from "../components/communication/SMSDialog";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuCheckboxItem,
} from "@/components/ui/dropdown-menu";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import LeadLeaderboard from "../components/leads/LeadLeaderboard";

export default function Leads() {
  const navigate = useNavigate();
  const [showDialog, setShowDialog] = useState(false);
  const [editingLead, setEditingLead] = useState(null);
  const [viewingLead, setViewingLead] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [showDialer, setShowDialer] = useState(false);
  const [showEmailDialog, setShowEmailDialog] = useState(false);
  const [showSMSDialog, setShowSMSDialog] = useState(false);
  const [selectedLead, setSelectedLead] = useState(null);
  const [selectedLeads, setSelectedLeads] = useState([]);
  const [quickFilter, setQuickFilter] = useState("all");
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    phone_2: "",
    company: "",
    street: "",
    city: "",
    state: "",
    zip: "",
    status: "new",
    source: "manual",
    lead_source: "",
    value: 0,
    is_active: true,
    notes: "",
    last_contact_date: "",
    next_follow_up_date: ""
  });
  const [pageSize, setPageSize] = useState(25);
  const [currentPage, setCurrentPage] = useState(1);
  const [scoreFilter, setScoreFilter] = useState("all");
  const [showLeaderboard, setShowLeaderboard] = useState(false);

  const [visibleColumns, setVisibleColumns] = useState({
    id: false,
    company: true,
    name: true,
    email: true,
    phone: true,
    phone_2: false,
    source: true,
    status: true,
    value: true,
    last_contact: false,
    next_follow_up: true,
    active: false,
    date_created: false,
  });

  const toggleColumn = (column) => {
    setVisibleColumns(prev => ({ ...prev, [column]: !prev[column] }));
  };

  const queryClient = useQueryClient();

  const safeFormatDate = (dateValue, formatString = 'MMM d, yyyy') => {
    if (!dateValue) return '-';
    try {
      const date = new Date(dateValue);
      if (isNaN(date.getTime())) return '-';
      return format(date, formatString);
    } catch (e) {
      console.error("Error formatting date:", e, "Value:", dateValue);
      return '-';
    }
  };

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list("-created_date"),
    initialData: [],
  });

  const { data: communications = [] } = useQuery({
    queryKey: ['communications'],
    queryFn: () => base44.entities.Communication.list("-created_date", 1000),
    initialData: [],
  });

  const { data: calendarEvents = [] } = useQuery({
    queryKey: ['calendar-events'],
    queryFn: () => base44.entities.CalendarEvent.list("-start_time", 1000),
    initialData: [],
  });

  const { data: leadScores = [] } = useQuery({
    queryKey: ['lead-scores'],
    queryFn: () => base44.entities.LeadScore.list("-total_score"),
    initialData: [],
  });

  const { data: inspections = [] } = useQuery({
    queryKey: ['lead-inspections'],
    queryFn: () => base44.entities.InspectionJob.filter({ related_lead_id: { $ne: null } }),
    initialData: [],
  });

  const createLeadMutation = useMutation({
    mutationFn: async (leadData) => {
      const newLead = await base44.entities.Lead.create(leadData);
      
      try {
        await base44.functions.invoke('executeWorkflow', {
          triggerType: 'lead_created',
          entityType: 'Lead',
          entityId: newLead.id,
          entityData: newLead
        });
        console.log('✅ Workflows triggered for new lead:', newLead.id);
      } catch (error) {
        console.error('⚠️ Workflow trigger failed (non-critical):', error);
      }
      
      return newLead;
    },
    onSuccess: (newLead) => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      updateLeadScore(newLead.id, 'lead_created', 50, 'New lead created');
      handleCloseDialog();
      alert('Lead created successfully! Workflows started.');
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Lead.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      handleCloseDialog();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Lead.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
    },
  });

  const bulkDeleteMutation = useMutation({
    mutationFn: async (ids) => {
      let successCount = 0;
      let errorCount = 0;
      const errors = [];

      for (const id of ids) {
        try {
          await base44.entities.Lead.delete(id);
          successCount++;
        } catch (error) {
          errorCount++;
          errors.push({ id, error: error.message });
          console.error(`Failed to delete lead ${id}:`, error);
        }
      }

      return { successCount, errorCount, errors };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      setSelectedLeads([]);
      
      if (result.errorCount > 0) {
        alert(`Deleted ${result.successCount} leads successfully.\n${result.errorCount} leads could not be deleted (they may have been already deleted or don't exist).`);
      } else {
        alert(`Successfully deleted ${result.successCount} leads!`);
      }
    },
    onError: (error) => {
      console.error("Bulk delete failed:", error);
      alert('Failed to delete leads. Please try again.');
    }
  });

  const convertToCustomerMutation = useMutation({
    mutationFn: async (lead) => {
      // Create customer with ALL lead data including address
      const customerData = {
        name: lead.name,
        company: lead.company || "",
        email: lead.email || "",
        phone: lead.phone || "",
        phone_2: lead.phone_2 || "",
        street: lead.street || "",
        city: lead.city || "",
        state: lead.state || "",
        zip: lead.zip || "",
        customer_type: "residential", // Default type
        source: lead.source,
        referral_source: lead.lead_source || "",
        is_active: lead.is_active !== false,
        notes: [
          lead.notes || "",
          `\n\n--- Converted from Lead ---`,
          `Original Lead ID: ${lead.id}`,
          `Lead Status: ${lead.status}`,
          `Lead Value: $${lead.value || 0}`,
          `Created: ${safeFormatDate(lead.created_date)}`,
          `Last Contact: ${safeFormatDate(lead.last_contact_date)}`,
          lead.next_follow_up_date ? `Follow-up Date: ${safeFormatDate(lead.next_follow_up_date)}` : ""
        ].filter(Boolean).join("\n")
      };

      const newCustomer = await base44.entities.Customer.create(customerData);
      
      // Delete the lead
      await base44.entities.Lead.delete(lead.id);
      
      return newCustomer;
    },
    onSuccess: (customer) => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
      queryClient.invalidateQueries({ queryKey: ['customers'] }); // Invalidate customers to show new customer
      alert(`✅ Lead converted to customer successfully!\n\nCustomer: ${customer.name}`);
      setViewingLead(null); // Close the details dialog
    },
    onError: (error) => {
      alert(`❌ Failed to convert lead: ${error.message}`);
    }
  });

  const getLeadScore = (leadId) => {
    return leadScores.find(s => s.lead_id === leadId);
  };

  const updateLeadScore = async (leadId, action, points, description) => {
    try {
      await base44.functions.invoke('updateLeadScore', {
        leadId,
        action,
        points,
        actionDescription: description
      });
      queryClient.invalidateQueries({ queryKey: ['lead-scores'] });
    } catch (error) {
      console.error('Failed to update lead score:', error);
    }
  };

  const getLeadWithContactInfo = (lead) => {
    const leadComms = communications.filter(c => {
      const matchByName = c.contact_name && lead.name && c.contact_name.toLowerCase() === lead.name.toLowerCase();
      const matchByPhone1 = c.contact_phone && lead.phone && c.contact_phone === lead.phone;
      const matchByPhone2 = c.contact_phone && lead.phone_2 && c.contact_phone === lead.phone_2;
      const matchByEmail = c.contact_email && lead.email && c.contact_email.toLowerCase() === lead.email.toLowerCase();
      
      return matchByName || matchByPhone1 || matchByPhone2 || matchByEmail;
    }).sort((a, b) => new Date(b.created_date).getTime() - new Date(a.created_date).getTime());

    const lastContact = leadComms.length > 0 
      ? leadComms[0].created_date 
      : lead.created_date;

    const upcomingEvents = calendarEvents.filter(e => 
      e.related_lead && lead.name && e.related_lead.toLowerCase() === lead.name.toLowerCase() &&
      new Date(e.start_time).getTime() > new Date().getTime() &&
      e.status !== 'cancelled'
    ).sort((a, b) => new Date(a.start_time).getTime() - new Date(b.start_time).getTime());
    
    let nextFollowUp = lead.next_follow_up_date;
    if (!nextFollowUp && upcomingEvents.length > 0) {
        nextFollowUp = upcomingEvents[0].start_time;
    }
    
    return {
      ...lead,
      last_contact_date: lastContact,
      next_follow_up_date: nextFollowUp,
      communication_count: leadComms.length
    };
  };

  const handleEdit = (lead) => {
    setEditingLead(lead);
    setFormData({
      name: lead.name || "",
      email: lead.email || "",
      phone: lead.phone || "",
      phone_2: lead.phone_2 || "",
      company: lead.company || "",
      street: lead.street || "",
      city: lead.city || "",
      state: lead.state || "",
      zip: lead.zip || "",
      status: lead.status || "new",
      source: lead.source || "manual",
      lead_source: lead.lead_source || "",
      value: lead.value || 0,
      is_active: lead.is_active !== false,
      notes: lead.notes || "",
      last_contact_date: lead.last_contact_date || "",
      next_follow_up_date: lead.next_follow_up_date || ""
    });
    setShowDialog(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this lead?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleCloseDialog = () => {
    setShowDialog(false);
    setEditingLead(null);
    setFormData({
      name: "",
      email: "",
      phone: "",
      phone_2: "",
      company: "",
      street: "",
      city: "",
      state: "",
      zip: "",
      status: "new",
      source: "manual",
      lead_source: "",
      value: 0,
      is_active: true,
      notes: "",
      last_contact_date: "",
      next_follow_up_date: ""
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingLead) {
      updateMutation.mutate({ id: editingLead.id, data: formData });
    } else {
      createLeadMutation.mutate(formData);
    }
  };

  const handleConvertToCustomer = (lead) => {
    if (window.confirm(`Convert "${lead.name}" to a customer?\n\nAll lead data (notes, contact info, etc.) will be transferred to the customer record.`)) {
      convertToCustomerMutation.mutate(lead);
    }
  };

  const handleToggleActive = (lead) => {
    updateMutation.mutate({
      id: lead.id,
      data: { ...lead, is_active: !lead.is_active }
    });
  };

  const handleStatusChange = (lead, newStatus) => {
    updateMutation.mutate({
      id: lead.id,
      data: { ...lead, status: newStatus }
    });
    let points = 0;
    let description = `Lead status changed to ${newStatus}`;
    if (newStatus === 'qualified') points = 25;
    else if (newStatus === 'proposal') points = 30;
    else if (newStatus === 'negotiation') points = 40;
    else if (newStatus === 'won') points = 100;
    else if (newStatus === 'lost') points = -50;
    
    if (points !== 0) updateLeadScore(lead.id, 'status_change', points, description);
  };

  const handleCommunication = (lead, type) => {
    setSelectedLead(lead);
    
    if (type === 'phone') {
      updateLeadScore(lead.id, 'call_initiated', 30, 'Called lead');
      setShowDialer(true);
    }
    if (type === 'email') {
      updateLeadScore(lead.id, 'email_sent', 20, 'Sent email');
      setShowEmailDialog(true);
    }
    if (type === 'sms') {
      updateLeadScore(lead.id, 'sms_sent', 15, 'Sent SMS');
      setShowSMSDialog(true);
    }
  };

  const handleCreateEstimate = (lead) => {
    updateLeadScore(lead.id, 'estimate_created', 40, 'Created estimate for lead');
    navigate(createPageUrl('Estimates') + `?from_lead=${lead.id}&customer_name=${encodeURIComponent(lead.name)}&customer_email=${encodeURIComponent(lead.email || '')}`);
  };

  const handleSelectAll = () => {
    const currentPageLeadIds = paginatedLeads.map(lead => lead.id);
    const areAllCurrentPageSelected = currentPageLeadIds.every(id => selectedLeads.includes(id));

    if (areAllCurrentPageSelected) {
      setSelectedLeads(prev => prev.filter(id => !currentPageLeadIds.includes(id)));
    } else {
      setSelectedLeads(prev => [...new Set([...prev, ...currentPageLeadIds])]);
    }
  };

  const handleSelectLead = (id) => {
    if (selectedLeads.includes(id)) {
      setSelectedLeads(selectedLeads.filter(leadId => leadId !== id));
    } else {
      setSelectedLeads([...selectedLeads, id]);
    }
  };

  const handleBulkDelete = () => {
    if (selectedLeads.length === 0) {
      alert('Please select at least one lead to delete.');
      return;
    }

    const existingSelectedLeads = selectedLeads.filter(id => 
      leads.some(lead => lead.id === id)
    );

    if (existingSelectedLeads.length === 0) {
      alert('No valid leads selected. They may have been already deleted.');
      setSelectedLeads([]);
      return;
    }

    if (existingSelectedLeads.length < selectedLeads.length) {
      const difference = selectedLeads.length - existingSelectedLeads.length;
      if (!window.confirm(`${difference} of your selected leads no longer exist.\n\nDelete the remaining ${existingSelectedLeads.length} leads? This cannot be undone!`)) {
        setSelectedLeads(existingSelectedLeads);
        return;
      }
    } else {
      if (!window.confirm(`Are you sure you want to delete ${existingSelectedLeads.length} selected leads? This cannot be undone!`)) {
        return;
      }
    }

    bulkDeleteMutation.mutate(existingSelectedLeads);
  };

  const handleExportCSV = (exportMode = 'dynamic') => {
    let leadsToExport = [];

    if (exportMode === 'selectedOnly') {
      leadsToExport = filteredLeads.filter(lead => selectedLeads.includes(lead.id));
    } else {
      leadsToExport = selectedLeads.length > 0
        ? filteredLeads.filter(lead => selectedLeads.includes(lead.id))
        : filteredLeads;
    }

    if (leadsToExport.length === 0) {
      alert('No leads to export');
      return;
    }

    const headers = ['ID', 'Company', 'Primary Contact', 'Email', 'Phone 1', 'Phone 2', 'Street', 'City', 'State', 'Zip', 'Source', 'Status', 'Value', 'Active', 'Date Created', 'Last Contact Date', 'Next Follow Up Date', 'Notes'];
    const rows = leadsToExport.map(lead => {
      const enrichedLead = getLeadWithContactInfo(lead);
      return [
        lead.id,
        lead.company || '',
        lead.name || '',
        lead.email || '',
        lead.phone || '',
        lead.phone_2 || '',
        lead.street || '',
        lead.city || '',
        lead.state || '',
        lead.zip || '',
        lead.source || '',
        lead.status || '',
        lead.value || 0,
        lead.is_active ? 'Yes' : 'No',
        safeFormatDate(lead.created_date, 'yyyy-MM-dd'),
        safeFormatDate(enrichedLead.last_contact_date, 'yyyy-MM-dd HH:mm'),
        safeFormatDate(enrichedLead.next_follow_up_date, 'yyyy-MM-dd'),
        lead.notes || ''
      ];
    });

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `leads_export_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();

    alert(`Exported ${leadsToExport.length} leads to CSV!`);
  };

  const handleBulkStatusChange = (newStatus) => {
    if (selectedLeads.length === 0) {
      alert('Please select leads first');
      return;
    }

    if (window.confirm(`Change status to "${newStatus}" for ${selectedLeads.length} selected leads?`)) {
      selectedLeads.forEach(id => {
        const lead = leads.find(l => l.id === id);
        if (lead) {
          updateMutation.mutate({
            id: lead.id,
            data: { ...lead, status: newStatus }
          });
          let points = 0;
          let description = `Bulk status change to ${newStatus}`;
          if (newStatus === 'qualified') points = 25;
          else if (newStatus === 'proposal') points = 30;
          else if (newStatus === 'negotiation') points = 40;
          else if (newStatus === 'won') points = 100;
          else if (newStatus === 'lost') points = -50;
          
          if (points !== 0) updateLeadScore(lead.id, 'status_change', points, description);
        }
      });
      setSelectedLeads([]);
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      'new': 'bg-blue-100 text-blue-700 border-blue-200',
      'contacted': 'bg-yellow-100 text-yellow-700 border-yellow-200',
      'qualified': 'bg-green-100 text-green-700 border-green-200',
      'proposal': 'bg-purple-100 text-purple-700 border-purple-200',
      'negotiation': 'bg-orange-100 text-orange-700 border-orange-200',
      'won': 'bg-emerald-100 text-emerald-700 border-emerald-200',
      'lost': 'bg-red-100 text-red-700 border-red-200',
    };
    return colors[status] || 'bg-gray-100 text-gray-700 border-gray-200';
  };

  const getSourceBadge = (lead) => {
    const sourceColors = {
      'storm_tracker': 'bg-orange-100 text-orange-700 border-orange-200',
      'property_importer': 'bg-purple-100 text-purple-700 border-purple-200',
      'website': 'bg-blue-100 text-blue-700 border-blue-200',
      'referral': 'bg-green-100 text-green-700 border-green-200',
      'manual': 'bg-gray-100 text-gray-700 border-gray-200',
      'cold_call': 'bg-cyan-100 text-cyan-700 border-cyan-200',
      'social_media': 'bg-indigo-100 text-indigo-700 border-indigo-200',
      'advertisement': 'bg-pink-100 text-pink-700 border-pink-200',
      'other': 'bg-gray-100 text-gray-700 border-gray-200'
    };

    const sourceLabels = {
      'storm_tracker': '⛈️ Storm',
      'property_importer': '🏘️ Import',
      'website': '🌐 Website',
      'referral': '👥 Referral',
      'manual': '✍️ Manual',
      'cold_call': '📞 Cold Call',
      'social_media': '📱 Social',
      'advertisement': '📢 Ad',
      'other': 'Other'
    };

    return (
      <Badge variant="outline" className={sourceColors[lead.source] || sourceColors.other}>
        {sourceLabels[lead.source] || lead.source}
      </Badge>
    );
  };

  const handleScheduleMeeting = (lead) => {
    updateLeadScore(lead.id, 'meeting_scheduled', 20, 'Meeting scheduled with lead');
    navigate(createPageUrl('Calendar') + `?lead=${encodeURIComponent(lead.name)}&action=new`);
  };

  const handleSetFollowUp = async (lead, days) => {
    const followUpDate = new Date();
    followUpDate.setDate(followUpDate.getDate() + days);
    
    updateMutation.mutate({
      id: lead.id,
      data: { ...lead, next_follow_up_date: followUpDate.toISOString() }
    });
    updateLeadScore(lead.id, 'followup_set', 10, `Follow-up set for ${safeFormatDate(followUpDate, 'MMM d')}`);
  };

  const renderTemperatureBadge = (leadId) => {
    const score = getLeadScore(leadId);
    if (!score) return null;

    const tempConfig = {
      hot: { icon: Flame, color: 'bg-red-100 text-red-700 border-red-300', label: 'HOT' },
      warm: { icon: ThermometerSun, color: 'bg-orange-100 text-orange-700 border-orange-300', label: 'WARM' },
      cold: { icon: Snowflake, color: 'bg-blue-100 text-blue-700 border-blue-300', label: 'COLD' }
    };

    const config = tempConfig[score.temperature] || tempConfig.cold;
    const Icon = config.icon;

    const recentHistory = (score.score_history || []).slice(-3);
    let trendPoints = 0;
    if (recentHistory.length > 1) {
        trendPoints = recentHistory.reduce((sum, entry) => sum + entry.points, 0);
    }
    
    let TrendIcon = Minus;
    let trendColor = 'text-gray-400';
    if (trendPoints > 10) {
        TrendIcon = TrendingUp;
        trendColor = 'text-green-500';
    } else if (trendPoints < -10) {
        TrendIcon = TrendingDown;
        trendColor = 'text-red-500';
    }

    return (
      <div className="flex items-center gap-1">
        <Badge variant="outline" className={`${config.color} flex items-center gap-1 font-semibold`}>
          <Icon className="w-3 h-3" />
          {score.total_score}
        </Badge>
        {score.score_history && score.score_history.length > 1 && (
            <TrendIcon className={`w-4 h-4 ${trendColor}`} />
        )}
      </div>
    );
  };

  const getFilteredLeadsByQuickFilter = () => {
    const now = new Date();
    const allLeadsWithInfo = leads.map(getLeadWithContactInfo);
    
    let filtered = allLeadsWithInfo;
    
    switch(quickFilter) {
      case "needs_follow_up":
        filtered = allLeadsWithInfo.filter(lead => {
          if (!lead.next_follow_up_date) return false;
          return new Date(lead.next_follow_up_date).setHours(0,0,0,0) <= now.setHours(0,0,0,0);
        });
        break;
      case "no_contact_7_days":
        const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        filtered = allLeadsWithInfo.filter(lead => {
          if (!lead.last_contact_date) return true;
          return new Date(lead.last_contact_date) < sevenDaysAgo;
        });
        break;
      case "contacted_today":
        filtered = allLeadsWithInfo.filter(lead => {
          if (!lead.last_contact_date) return false;
          const lastContact = new Date(lead.last_contact_date);
          return lastContact.toDateString() === now.toDateString();
        });
        break;
      case "upcoming_follow_ups":
        filtered = allLeadsWithInfo.filter(lead => {
          if (!lead.next_follow_up_date) return false;
          const followUp = new Date(lead.next_follow_up_date);
          return followUp.setHours(0,0,0,0) > now.setHours(0,0,0,0);
        });
        break;
      case "all":
      default:
        break;
    }
    
    return filtered;
  };

  const leadsAfterQuickFilter = getFilteredLeadsByQuickFilter();
  
  const filteredLeadsWithScore = leadsAfterQuickFilter.filter(lead => {
    const matchesSearch = lead.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.company?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.lead_source?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.street?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.city?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.state?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.zip?.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (!matchesSearch) return false;

    if (scoreFilter === "all") return true;
    
    const score = getLeadScore(lead.id);
    if (!score) return scoreFilter === "cold";
    
    return score.temperature === scoreFilter;
  });

  const sortedLeads = [...filteredLeadsWithScore].sort((a, b) => {
    const scoreA = getLeadScore(a.id);
    const scoreB = getLeadScore(b.id);
    const scoreValA = scoreA?.total_score ?? -Infinity;
    const scoreValB = scoreB?.total_score ?? -Infinity;
    return scoreValB - scoreValA;
  });

  const filteredLeads = sortedLeads;

  const effectivePageSize = pageSize === 'all' ? filteredLeads.length : pageSize;
  const totalPages = effectivePageSize === 0 ? 0 : Math.ceil(filteredLeads.length / effectivePageSize);
  const paginatedLeads = pageSize === 'all'
    ? filteredLeads
    : filteredLeads.slice((currentPage - 1) * effectivePageSize, currentPage * effectivePageSize);

  // Calculate metrics
  const totalLeads = leads.length;
  const activeLeads = leads.filter(l => l.is_active !== false).length;
  const newLeads = leads.filter(l => l.status === 'new').length;
  const qualifiedLeads = leads.filter(l => l.status === 'qualified').length;
  const wonLeads = leads.filter(l => l.status === 'won').length;
  const totalLeadValue = leads.reduce((sum, l) => sum + (l.value || 0), 0);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Lead Manager</h1>
        <button 
          onClick={() => navigate(createPageUrl('Customers'))}
          className="text-blue-600 hover:underline text-sm flex items-center gap-1 mt-1"
        >
          Customers →
        </button>
      </div>

      {/* Metric Cards - Smaller and horizontal */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <Card className="bg-white">
          <CardContent className="p-3">
            <div className="text-xl font-bold text-gray-900">{totalLeads}</div>
            <div className="text-xs text-gray-500">Total Leads</div>
          </CardContent>
        </Card>
        <Card className="bg-white">
          <CardContent className="p-3">
            <div className="text-xl font-bold text-green-600">{activeLeads}</div>
            <div className="text-xs text-gray-500">Active Leads</div>
          </CardContent>
        </Card>
        <Card className="bg-white">
          <CardContent className="p-3">
            <div className="text-xl font-bold text-blue-600">{newLeads}</div>
            <div className="text-xs text-gray-500">New Leads</div>
          </CardContent>
        </Card>
        <Card className="bg-white">
          <CardContent className="p-3">
            <div className="text-xl font-bold text-purple-600">{qualifiedLeads}</div>
            <div className="text-xs text-gray-500">Qualified</div>
          </CardContent>
        </Card>
        <Card className="bg-white">
          <CardContent className="p-3">
            <div className="text-xl font-bold text-green-600">{wonLeads}</div>
            <div className="text-xs text-gray-500">Won Deals</div>
          </CardContent>
        </Card>
        <Card className="bg-white">
          <CardContent className="p-3">
            <div className="text-xl font-bold text-gray-900">${totalLeadValue.toLocaleString()}</div>
            <div className="text-xs text-gray-500">Pipeline Value</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="leads" className="w-full">
        <TabsList>
          <TabsTrigger value="leads">All Leads</TabsTrigger>
          <TabsTrigger value="inspections" className="flex items-center gap-2">
            <Camera className="w-4 h-4" />
            Inspections ({inspections.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="leads" className="space-y-4">
          {/* Action Buttons Row */}
          <div className="flex items-center justify-between">
            <div className="flex gap-2">
              <Dialog open={showDialog} onOpenChange={setShowDialog}>
                <DialogTrigger asChild>
                  <Button 
                    className="bg-blue-600 hover:bg-blue-700 text-sm h-9"
                    onClick={() => {
                      setEditingLead(null);
                      setFormData({
                        name: "",
                        email: "",
                        phone: "",
                        phone_2: "",
                        company: "",
                        street: "",
                        city: "",
                        state: "",
                        zip: "",
                        status: "new",
                        source: "manual",
                        lead_source: "",
                        value: 0,
                        is_active: true,
                        notes: "",
                        last_contact_date: "",
                        next_follow_up_date: ""
                      });
                    }}
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    New Lead
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>{editingLead ? 'Edit Lead' : 'Add New Lead'}</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label>Primary Contact *</Label>
                        <Input
                          value={formData.name}
                          onChange={(e) => setFormData({...formData, name: e.target.value})}
                          required
                          placeholder="John Doe"
                        />
                      </div>
                      <div>
                        <Label>Company</Label>
                        <Input
                          value={formData.company}
                          onChange={(e) => setFormData({...formData, company: e.target.value})}
                          placeholder="ABC Corporation"
                        />
                      </div>
                      <div>
                        <Label>Email</Label>
                        <Input
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData({...formData, email: e.target.value})}
                          placeholder="john@example.com"
                        />
                      </div>
                      <div>
                        <Label>Phone 1</Label>
                        <Input
                          value={formData.phone}
                          onChange={(e) => setFormData({...formData, phone: e.target.value})}
                          placeholder="(555) 123-4567"
                        />
                      </div>
                      <div>
                        <Label>Phone 2</Label>
                        <Input
                          value={formData.phone_2}
                          onChange={(e) => setFormData({...formData, phone_2: e.target.value})}
                          placeholder="(555) 987-6543"
                        />
                      </div>
                      <div>
                        <Label>Status</Label>
                        <Select value={formData.status} onValueChange={(v) => setFormData({...formData, status: v})}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="new">New</SelectItem>
                            <SelectItem value="contacted">Contacted</SelectItem>
                            <SelectItem value="qualified">Qualified</SelectItem>
                            <SelectItem value="proposal">Proposal</SelectItem>
                            <SelectItem value="negotiation">Negotiation</SelectItem>
                            <SelectItem value="won">Won</SelectItem>
                            <SelectItem value="lost">Lost</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h3 className="font-semibold mb-3">Address</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="col-span-2">
                          <Label>Street</Label>
                          <Input
                            value={formData.street}
                            onChange={(e) => setFormData({...formData, street: e.target.value})}
                            placeholder="123 Main Street"
                          />
                        </div>
                        <div>
                          <Label>City</Label>
                          <Input
                            value={formData.city}
                            onChange={(e) => setFormData({...formData, city: e.target.value})}
                            placeholder="Mansfield"
                          />
                        </div>
                        <div>
                          <Label>State</Label>
                          <Input
                            value={formData.state}
                            onChange={(e) => setFormData({...formData, state: e.target.value})}
                            placeholder="OH"
                            maxLength={2}
                          />
                        </div>
                        <div>
                          <Label>Zip Code</Label>
                          <Input
                            value={formData.zip}
                            onChange={(e) => setFormData({...formData, zip: e.target.value})}
                            placeholder="44903"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h3 className="font-semibold mb-3">Lead Source</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label>Source</Label>
                          <Select value={formData.source} onValueChange={(v) => setFormData({...formData, source: v})}>
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="manual">Manual Entry</SelectItem>
                              <SelectItem value="website">Website</SelectItem>
                              <SelectItem value="referral">Referral</SelectItem>
                              <SelectItem value="social_media">Social Media</SelectItem>
                              <SelectItem value="advertisement">Advertisement</SelectItem>
                              <SelectItem value="cold_call">Cold Call</SelectItem>
                              <SelectItem value="storm_tracker">Storm Tracker</SelectItem>
                              <SelectItem value="property_importer">Property Importer</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label>Estimated Value</Label>
                          <Input
                            type="number"
                            value={formData.value}
                            onChange={(e) => setFormData({...formData, value: parseFloat(e.target.value)})}
                            placeholder="0"
                          />
                        </div>
                        <div className="col-span-2">
                          <Label>Source Details (Optional)</Label>
                          <Input
                            placeholder="e.g., Mansfield Hail Storm - Jan 15, 2024"
                            value={formData.lead_source}
                            onChange={(e) => setFormData({...formData, lead_source: e.target.value})}
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <Label>Notes</Label>
                      <Textarea
                        value={formData.notes}
                        onChange={(e) => setFormData({...formData, notes: e.target.value})}
                        rows={3}
                        placeholder="Add any additional notes about this lead..."
                      />
                    </div>
                    <div className="flex items-center gap-3">
                      <Switch
                        checked={formData.is_active}
                        onCheckedChange={(checked) => setFormData({...formData, is_active: checked})}
                      />
                      <Label>Active</Label>
                    </div>
                    <div className="flex justify-end gap-3">
                      <Button type="button" variant="outline" onClick={handleCloseDialog}>
                        Cancel
                      </Button>
                      <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                        {editingLead ? 'Update Lead' : 'Create Lead'}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>

              <Button variant="outline" onClick={() => navigate(createPageUrl('LeadFinder'))} className="text-sm h-9">
                <Search className="w-4 h-4 mr-2" />
                Lead Finder
              </Button>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => setShowLeaderboard(!showLeaderboard)}
                className="text-sm h-9 border-yellow-300 text-yellow-700 hover:bg-yellow-50"
              >
                <Trophy className="w-4 h-4 mr-2" />
                {showLeaderboard ? 'Hide' : 'Show'} Leaderboard
              </Button>
              {selectedLeads.length > 0 && (
                <Button
                  variant="destructive"
                  onClick={handleBulkDelete}
                  disabled={bulkDeleteMutation.isLoading}
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete {selectedLeads.length} Selected
                </Button>
              )}
            </div>
          </div>

          {showLeaderboard && (
            <LeadLeaderboard 
              leadScores={leadScores}
              leads={leads}
              onLeadClick={(lead) => setViewingLead(getLeadWithContactInfo(lead))}
            />
          )}

          <Card className="bg-white shadow-sm">
            <CardContent className="p-4">
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={quickFilter === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {setQuickFilter("all"); setCurrentPage(1);}}
                >
                  All Leads ({leads.length})
                </Button>
                <Button
                  variant={quickFilter === "needs_follow_up" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {setQuickFilter("needs_follow_up"); setCurrentPage(1);}}
                  className={quickFilter === "needs_follow_up" ? "bg-red-600 hover:bg-red-700 text-white" : ""}
                >
                  🔔 Needs Follow-up ({leadsAfterQuickFilter.filter(lead => {
                    if (!lead.next_follow_up_date) return false;
                    const now = new Date();
                    return new Date(lead.next_follow_up_date).setHours(0,0,0,0) <= now.setHours(0,0,0,0);
                  }).length})
                </Button>
                <Button
                  variant={quickFilter === "no_contact_7_days" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {setQuickFilter("no_contact_7_days"); setCurrentPage(1);}}
                  className={quickFilter === "no_contact_7_days" ? "bg-orange-600 hover:bg-orange-700 text-white" : ""}
                >
                  ⚠️ No Contact 7+ Days ({leadsAfterQuickFilter.filter(lead => {
                    const now = new Date();
                    const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                    if (!lead.last_contact_date) return true;
                    return new Date(lead.last_contact_date) < sevenDaysAgo;
                  }).length})
                </Button>
                <Button
                  variant={quickFilter === "contacted_today" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {setQuickFilter("contacted_today"); setCurrentPage(1);}}
                  className={quickFilter === "contacted_today" ? "bg-green-600 hover:bg-green-700 text-white" : ""}
                >
                  ✅ Contacted Today ({leadsAfterQuickFilter.filter(lead => {
                    if (!lead.last_contact_date) return false;
                    const now = new Date();
                    const lastContact = new Date(lead.last_contact_date);
                    return lastContact.toDateString() === now.toDateString();
                  }).length})
                </Button>
                <Button
                  variant={quickFilter === "upcoming_follow_ups" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {setQuickFilter("upcoming_follow_ups"); setCurrentPage(1);}}
                  className={quickFilter === "upcoming_follow_ups" ? "bg-blue-600 hover:bg-blue-700 text-white" : ""}
                >
                  📅 Upcoming Follow-ups ({leadsAfterQuickFilter.filter(lead => {
                    if (!lead.next_follow_up_date) return false;
                    const now = new Date();
                    const followUp = new Date(lead.next_follow_up_date);
                    return followUp.setHours(0,0,0,0) > now.setHours(0,0,0,0);
                  }).length})
                </Button>
                
                <div className="w-px h-8 bg-gray-300"></div>
                
                <Button
                  variant={scoreFilter === "all" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {setScoreFilter("all"); setCurrentPage(1);}}
                >
                  All Temperatures
                </Button>
                <Button
                  variant={scoreFilter === "hot" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {setScoreFilter("hot"); setCurrentPage(1);}}
                  className={scoreFilter === "hot" ? "bg-red-600 hover:bg-red-700 text-white" : ""}
                >
                  <Flame className="w-4 h-4 mr-1" />
                  Hot ({leadScores.filter(s => s.temperature === 'hot').length})
                </Button>
                <Button
                  variant={scoreFilter === "warm" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {setScoreFilter("warm"); setCurrentPage(1);}}
                  className={scoreFilter === "warm" ? "bg-orange-600 hover:bg-orange-700 text-white" : ""}
                >
                  <ThermometerSun className="w-4 h-4 mr-1" />
                  Warm ({leadScores.filter(s => s.temperature === 'warm').length})
                </Button>
                <Button
                  variant={scoreFilter === "cold" ? "default" : "outline"}
                  size="sm"
                  onClick={() => {setScoreFilter("cold"); setCurrentPage(1);}}
                  className={scoreFilter === "cold" ? "bg-blue-600 hover:bg-blue-700 text-white" : ""}
                >
                  <Snowflake className="w-4 h-4 mr-1" />
                  Cold ({leadScores.filter(s => s.temperature === 'cold').length})
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md">
            <div className="px-6 py-3 border-b bg-gray-50 flex flex-wrap items-center gap-3">
              <Select value={pageSize.toString()} onValueChange={(value) => {
                setPageSize(value === 'all' ? 'all' : parseInt(value));
                setCurrentPage(1);
              }}>
                <SelectTrigger className="w-20">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="25">25</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                  <SelectItem value="100">100</SelectItem>
                  <SelectItem value="all">All</SelectItem>
                </SelectContent>
              </Select>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Columns3 className="w-4 h-4 mr-2" />
                    Columns
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56">
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.id}
                    onCheckedChange={() => toggleColumn('id')}
                  >
                    ID
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.company}
                    onCheckedChange={() => toggleColumn('company')}
                  >
                    Company
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.name}
                    onCheckedChange={() => toggleColumn('name')}
                    disabled
                  >
                    Primary Contact (Required)
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.email}
                    onCheckedChange={() => toggleColumn('email')}
                  >
                    Email
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.phone}
                    onCheckedChange={() => toggleColumn('phone')}
                  >
                    Phone 1
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.phone_2}
                    onCheckedChange={() => toggleColumn('phone_2')}
                  >
                    Phone 2
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.source}
                    onCheckedChange={() => toggleColumn('source')}
                  >
                    Source
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.status}
                    onCheckedChange={() => toggleColumn('status')}
                  >
                    Status
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.value}
                    onCheckedChange={() => toggleColumn('value')}
                  >
                    Value
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.last_contact}
                    onCheckedChange={() => toggleColumn('last_contact')}
                  >
                    Last Contact
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.next_follow_up}
                    onCheckedChange={() => toggleColumn('next_follow_up')}
                  >
                    Next Follow-up
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.active}
                    onCheckedChange={() => toggleColumn('active')}
                  >
                    Active
                  </DropdownMenuCheckboxItem>
                  <DropdownMenuCheckboxItem
                    checked={visibleColumns.date_created}
                    onCheckedChange={() => toggleColumn('date_created')}
                  >
                    Date Created
                  </DropdownMenuCheckboxItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button variant="outline" size="sm" onClick={() => handleExportCSV('dynamic')}>
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" disabled={selectedLeads.length === 0}>
                    Bulk Actions
                    {selectedLeads.length > 0 && (
                      <Badge variant="secondary" className="ml-2">
                        {selectedLeads.length}
                      </Badge>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start">
                  <DropdownMenuItem onClick={() => handleBulkStatusChange('new')}>
                    Change Status → New
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleBulkStatusChange('contacted')}>
                    Change Status → Contacted
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleBulkStatusChange('qualified')}>
                    Change Status → Qualified
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleBulkStatusChange('proposal')}>
                    Change Status → Proposal
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleBulkStatusChange('negotiation')}>
                    Change Status → Negotiation
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleBulkStatusChange('won')}>
                    Change Status → Won
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleBulkStatusChange('lost')}>
                    Change Status → Lost
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleExportCSV('selectedOnly')}>
                    <Download className="w-4 h-4 mr-2" />
                    Export Selected
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={handleBulkDelete}
                    className="text-red-600"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Delete Selected
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button
                variant="outline"
                size="sm"
                onClick={() => queryClient.invalidateQueries({ queryKey: ['leads'] })}
              >
                <RefreshCw className="w-4 h-4" />
              </Button>

              <div className="flex-1 flex justify-end min-w-[200px]">
                <div className="relative w-full max-w-xs">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search by name, email, etc..."
                    value={searchTerm}
                    onChange={(e) => {
                      setSearchTerm(e.target.value);
                      setCurrentPage(1);
                    }}
                    className="pl-10"
                    size="sm"
                  />
                </div>
              </div>
            </div>

            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-3 text-left">
                        <Checkbox
                          checked={paginatedLeads.length > 0 && paginatedLeads.every(lead => selectedLeads.includes(lead.id))}
                          indeterminate={paginatedLeads.length > 0 && paginatedLeads.some(lead => selectedLeads.includes(lead.id)) && !paginatedLeads.every(lead => selectedLeads.includes(lead.id))}
                          onCheckedChange={handleSelectAll}
                          disabled={paginatedLeads.length === 0}
                        />
                      </th>
                      {visibleColumns.id && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                      )}
                      {visibleColumns.name && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                      )}
                      {visibleColumns.company && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Company</th>
                      )}
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Score</th>
                      {visibleColumns.email && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                      )}
                      {visibleColumns.phone && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone</th>
                      )}
                      {visibleColumns.phone_2 && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone 2</th>
                      )}
                      {visibleColumns.source && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Source</th>
                      )}
                      {visibleColumns.status && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                      )}
                      {visibleColumns.value && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                      )}
                      {visibleColumns.last_contact && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Last Contact</th>
                      )}
                      {visibleColumns.next_follow_up && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Next Follow-up</th>
                      )}
                      {visibleColumns.active && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Active</th>
                      )}
                      {visibleColumns.date_created && (
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Created</th>
                      )}
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {paginatedLeads.map((lead, index) => {
                      const leadWithInfo = getLeadWithContactInfo(lead);
                      const isOverdue = leadWithInfo.next_follow_up_date && new Date(leadWithInfo.next_follow_up_date).setHours(0,0,0,0) <= new Date().setHours(0,0,0,0);
                      const leadScore = getLeadScore(lead.id);
                      
                      return (
                        <tr key={lead.id} className={`hover:bg-gray-50 ${isOverdue ? 'bg-red-50' : leadScore?.temperature === 'hot' ? 'bg-red-50/30' : ''}`}>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <Checkbox
                              checked={selectedLeads.includes(lead.id)}
                              onCheckedChange={() => handleSelectLead(lead.id)}
                            />
                          </td>
                          {visibleColumns.id && (
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{index + 1 + (currentPage - 1) * effectivePageSize}</td>
                          )}
                          {visibleColumns.name && (
                            <td className="px-4 py-3 whitespace-nowrap">
                              <button
                                onClick={() => setViewingLead(getLeadWithContactInfo(lead))}
                                className="text-sm font-medium text-blue-600 hover:text-blue-800 hover:underline"
                              >
                                {lead.name}
                              </button>
                            </td>
                          )}
                          {visibleColumns.company && (
                            <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{lead.company || '-'}</td>
                          )}
                          <td className="px-4 py-3 whitespace-nowrap">
                            {renderTemperatureBadge(lead.id)}
                            {leadScore && leadScore.score_history && leadScore.score_history.length > 0 && (
                              <button
                                onClick={() => setViewingLead(leadWithInfo)}
                                className="text-xs text-blue-600 hover:underline mt-1 block"
                              >
                                View history
                              </button>
                            )}
                          </td>
                          {visibleColumns.email && (
                            <td className="px-4 py-3 whitespace-nowrap">
                              <div className="flex items-center gap-2">
                                <span className="text-sm text-blue-600">{lead.email || '-'}</span>
                                {lead.email && (
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    className="h-7 w-7 p-0 hover:bg-blue-50"
                                    onClick={() => handleCommunication(lead, 'email')}
                                    title="Send email"
                                  >
                                    <Mail className="w-4 h-4 text-blue-600" />
                                  </Button>
                                )}
                              </div>
                            </td>
                          )}
                          {visibleColumns.phone && (
                            <td className="px-4 py-3 whitespace-nowrap">
                              <div className="flex items-center gap-2">
                                <span className="text-sm text-gray-900">{lead.phone || '-'}</span>
                                {lead.phone && (
                                  <div className="flex gap-1">
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      className="h-7 w-7 p-0 hover:bg-green-50"
                                      onClick={() => handleCommunication(lead, 'phone')}
                                      title="Call"
                                    >
                                      <Phone className="w-4 h-4 text-green-600" />
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      className="h-7 w-7 p-0 hover:bg-purple-50"
                                      onClick={() => handleCommunication(lead, 'sms')}
                                      title="Send SMS"
                                    >
                                      <MessageCircle className="w-4 h-4 text-purple-600" />
                                    </Button>
                                  </div>
                                )}
                              </div>
                            </td>
                          )}
                          {visibleColumns.phone_2 && (
                            <td className="px-4 py-3 whitespace-nowrap">
                              <div className="flex items-center gap-2">
                                <span className="text-sm text-gray-900">{lead.phone_2 || '-'}</span>
                                {lead.phone_2 && (
                                  <div className="flex gap-1">
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      className="h-7 w-7 p-0 hover:bg-green-50"
                                      onClick={() => {
                                        setSelectedLead({ ...lead, phone: lead.phone_2 });
                                        setShowDialer(true);
                                      }}
                                      title="Call"
                                    >
                                      <Phone className="w-4 h-4 text-green-600" />
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="ghost"
                                      className="h-7 w-7 p-0 hover:bg-purple-50"
                                      onClick={() => {
                                        setSelectedLead({ ...lead, phone: lead.phone_2 });
                                        setShowSMSDialog(true);
                                      }}
                                      title="Send SMS"
                                    >
                                      <MessageCircle className="w-4 h-4 text-purple-600" />
                                    </Button>
                                  </div>
                                )}
                              </div>
                            </td>
                          )}
                          {visibleColumns.source && (
                            <td className="px-4 py-3 whitespace-nowrap">
                              <div className="flex flex-col gap-1">
                                {getSourceBadge(lead)}
                                {lead.lead_source && (
                                  <span className="text-xs text-gray-500 truncate max-w-[150px]" title={lead.lead_source}>
                                    {lead.lead_source}
                                  </span>
                                )}
                              </div>
                            </td>
                          )}
                          {visibleColumns.status && (
                            <td className="px-4 py-3 whitespace-nowrap">
                              <Select value={lead.status} onValueChange={(v) => handleStatusChange(lead, v)}>
                                <SelectTrigger className="w-32 h-8">
                                  <Badge variant="outline" className={getStatusColor(lead.status)}>
                                    {lead.status}
                                  </Badge>
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="new">New</SelectItem>
                                  <SelectItem value="contacted">Contacted</SelectItem>
                                  <SelectItem value="qualified">Qualified</SelectItem>
                                  <SelectItem value="proposal">Proposal</SelectItem>
                                  <SelectItem value="negotiation">Negotiation</SelectItem>
                                  <SelectItem value="won">Won</SelectItem>
                                  <SelectItem value="lost">Lost</SelectItem>
                                </SelectContent>
                              </Select>
                            </td>
                          )}
                          {visibleColumns.value && (
                            <td className="px-4 py-3 whitespace-nowrap text-sm font-semibold text-green-600">
                              ${(lead.value || 0).toLocaleString()}
                            </td>
                          )}
                          {visibleColumns.last_contact && (
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                              {safeFormatDate(leadWithInfo.last_contact_date, 'MMM d, yyyy')}
                              {leadWithInfo.communication_count > 0 && (
                                <Badge variant="outline" className="mt-1 text-xs">
                                  {leadWithInfo.communication_count} contacts
                                </Badge>
                              )}
                            </td>
                          )}
                          {visibleColumns.next_follow_up && (
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                              {leadWithInfo.next_follow_up_date ? (
                                <span className={isOverdue ? 'text-red-600 font-semibold' : 'text-gray-900'}>
                                  {safeFormatDate(leadWithInfo.next_follow_up_date, 'MMM d, yyyy')}
                                  {isOverdue && (
                                    <Badge variant="destructive" className="ml-1 text-xs">
                                      Overdue
                                    </Badge>
                                  )}
                                </span>
                              ) : (
                                <DropdownMenu>
                                  <DropdownMenuTrigger asChild>
                                    <Button variant="outline" size="sm" className="h-7 px-2 text-xs">
                                      Set Follow-up
                                    </Button>
                                  </DropdownMenuTrigger>
                                  <DropdownMenuContent>
                                    <DropdownMenuItem onClick={() => handleSetFollowUp(lead, 1)}>
                                      Tomorrow
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => handleSetFollowUp(lead, 3)}>
                                      In 3 Days
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => handleSetFollowUp(lead, 7)}>
                                      In 1 Week
                                    </DropdownMenuItem>
                                    <DropdownMenuItem onClick={() => handleSetFollowUp(lead, 14)}>
                                      In 2 Weeks
                                    </DropdownMenuItem>
                                  </DropdownMenuContent>
                                </DropdownMenu>
                              )}
                            </td>
                          )}
                          {visibleColumns.active && (
                            <td className="px-4 py-3 whitespace-nowrap">
                              <Switch
                                checked={lead.is_active}
                                onCheckedChange={() => handleToggleActive(lead)}
                              />
                            </td>
                          )}
                          {visibleColumns.date_created && (
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                              {safeFormatDate(lead.created_date, 'yyyy-MM-dd')}
                            </td>
                          )}
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="flex items-center gap-1">
                              <Button
                                size="sm"
                                onClick={() => handleCreateEstimate(lead)}
                                className="bg-green-600 hover:bg-green-700 text-xs h-7"
                                title="Create estimate"
                              >
                                Create Estimate
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleScheduleMeeting(lead)}
                                className="text-xs h-7 w-7 p-0"
                                title="Schedule meeting"
                              >
                                📅
                              </Button>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="outline" size="sm" className="h-7 w-7 p-0">
                                    ⋮
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => setViewingLead(getLeadWithContactInfo(lead))}>
                                    <Eye className="w-4 h-4 mr-2" />
                                    View Details
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleEdit(lead)}>
                                    <Edit className="w-4 h-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem 
                                    onClick={() => handleConvertToCustomer(lead)} 
                                    className="text-blue-600"
                                    disabled={convertToCustomerMutation.isLoading}
                                  >
                                    <UserPlus className="w-4 h-4 mr-2" />
                                    Convert to Customer
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleCommunication(lead, 'email')}>
                                    <Mail className="w-4 h-4 mr-2" />
                                    Send Email
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleCommunication(lead, 'phone')}>
                                    <Phone className="w-4 h-4 mr-2" />
                                    Call
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleCommunication(lead, 'sms')}>
                                    <MessageCircle className="w-4 h-4 mr-2" />
                                    Send SMS
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => handleDelete(lead.id)} className="text-red-600">
                                    <Trash2 className="w-4 h-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                    {paginatedLeads.length === 0 && (
                      <tr>
                        <td colSpan={16} className="px-6 py-12 text-center text-gray-500">
                          No leads found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {filteredLeads.length > 0 && pageSize !== 'all' && totalPages > 1 && (
                <div className="px-6 py-3 border-t flex items-center justify-between">
                  <div className="text-sm text-gray-500">
                    Showing {((currentPage - 1) * effectivePageSize) + 1} to {Math.min(currentPage * effectivePageSize, filteredLeads.length)} of {filteredLeads.length} leads
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inspections" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Inspection Leads</CardTitle>
              <p className="text-sm text-gray-500">Leads generated from property inspections</p>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {inspections.map(inspection => {
                  const relatedLead = leads.find(l => l.id === inspection.related_lead_id);
                  return (
                    <div key={inspection.id} className="p-4 border rounded-lg hover:bg-gray-50">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold">{inspection.client_name}</h3>
                          <p className="text-sm text-gray-600">{inspection.property_address}</p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="outline">{inspection.status}</Badge>
                            <Badge>{inspection.lead_source}</Badge>
                            {relatedLead && (
                              <Badge className="bg-green-100 text-green-800">
                                Lead: {relatedLead.status}
                              </Badge>
                            )}
                          </div>
                        </div>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => navigate(createPageUrl(`InspectionCapture?id=${inspection.id}`))}
                        >
                          View Inspection
                        </Button>
                      </div>
                    </div>
                  );
                })}
                {inspections.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <Camera className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p>No inspection leads yet</p>
                    <p className="text-sm">Inspections will automatically create leads here</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={!!viewingLead} onOpenChange={() => setViewingLead(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center gap-3">
              Lead Details - {viewingLead?.name}
              {viewingLead && renderTemperatureBadge(viewingLead.id)}
              <Button
                size="sm"
                onClick={() => handleConvertToCustomer(viewingLead)}
                className="ml-auto bg-blue-600 hover:bg-blue-700"
                disabled={convertToCustomerMutation.isLoading}
              >
                <UserPlus className="w-4 h-4 mr-2" />
                {convertToCustomerMutation.isLoading ? 'Converting...' : 'Convert to Customer'}
              </Button>
            </DialogTitle>
          </DialogHeader>
          {viewingLead && (
            <ScrollArea className="flex-grow pr-4">
              <Tabs defaultValue="details" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="score">
                    Score History ({getLeadScore(viewingLead.id)?.score_history?.length || 0})
                  </TabsTrigger>
                  <TabsTrigger value="communications">
                    Communications ({communications.filter(c => 
                      c.contact_name === viewingLead.name || 
                      (c.contact_phone && (c.contact_phone === viewingLead.phone || c.contact_phone === viewingLead.phone_2)) ||
                      c.contact_email === viewingLead.email
                    ).length})
                  </TabsTrigger>
                  <TabsTrigger value="meetings">
                    Meetings ({calendarEvents.filter(e => 
                      e.related_lead && viewingLead.name && e.related_lead.toLowerCase() === viewingLead.name.toLowerCase()
                    ).length})
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="details" className="space-y-4 mt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-gray-500">Name</Label>
                      <p className="font-semibold">{viewingLead.name}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Company</Label>
                      <p className="font-semibold">{viewingLead.company || '-'}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Email</Label>
                      <p className="font-semibold text-blue-600">{viewingLead.email || '-'}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Phone 1</Label>
                      <p className="font-semibold">{viewingLead.phone || '-'}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Phone 2</Label>
                      <p className="font-semibold">{viewingLead.phone_2 || '-'}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Status</Label>
                      <Badge variant="outline" className={getStatusColor(viewingLead.status)}>
                        {viewingLead.status}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                    <div className="col-span-2">
                      <Label className="text-gray-500">Address</Label>
                      <p className="font-semibold">
                        {viewingLead.street && <span>{viewingLead.street}<br /></span>}
                        {viewingLead.city && <span>{viewingLead.city}, </span>}
                        {viewingLead.state && <span>{viewingLead.state} </span>}
                        {viewingLead.zip && <span>{viewingLead.zip}</span>}
                        {!viewingLead.street && !viewingLead.city && !viewingLead.state && !viewingLead.zip && '-'}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                    <div>
                      <Label className="text-gray-500">Source</Label>
                      <div className="flex items-center gap-2">
                        {getSourceBadge(viewingLead)}
                      </div>
                    </div>
                    {viewingLead.lead_source && (
                      <div>
                        <Label className="text-gray-500">Source Details</Label>
                        <p className="font-semibold">{viewingLead.lead_source}</p>
                      </div>
                    )}
                    <div>
                      <Label className="text-gray-500">Estimated Value</Label>
                      <p className="font-semibold text-green-600">${(viewingLead.value || 0).toLocaleString()}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Created Date</Label>
                      <p className="font-semibold">{safeFormatDate(viewingLead.created_date, 'MMM d, yyyy')}</p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Active</Label>
                      <p className="font-semibold">{viewingLead.is_active ? '✅ Yes' : '❌ No'}</p>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                    <div>
                      <Label className="text-gray-500">Last Contact</Label>
                      <p className="font-semibold">
                        {safeFormatDate(viewingLead.last_contact_date, 'MMM d, yyyy h:mm a')}
                      </p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Next Follow-up</Label>
                      <p className="font-semibold">
                        {safeFormatDate(viewingLead.next_follow_up_date, 'MMM d, yyyy')}
                      </p>
                    </div>
                    <div>
                      <Label className="text-gray-500">Total Communications</Label>
                      <p className="font-semibold text-blue-600">{viewingLead.communication_count || 0}</p>
                    </div>
                  </div>

                  {viewingLead.notes && (
                    <div>
                      <Label className="text-gray-500">Notes</Label>
                      <p className="mt-1 p-3 bg-gray-50 rounded border">{viewingLead.notes}</p>
                    </div>
                  )}

                  <div className="flex gap-3 pt-4 border-t">
                    <Button onClick={() => {
                      setViewingLead(null);
                      handleCommunication(viewingLead, 'phone');
                    }} className="bg-green-600 hover:bg-green-700">
                      <Phone className="w-4 h-4 mr-2" />
                      Call Now
                    </Button>
                    <Button onClick={() => {
                      setViewingLead(null);
                      handleCommunication(viewingLead, 'email');
                    }} className="bg-blue-600 hover:bg-blue-700">
                      <Mail className="w-4 h-4 mr-2" />
                      Send Email
                    </Button>
                    <Button onClick={() => {
                      setViewingLead(null);
                      handleCommunication(viewingLead, 'sms');
                    }} className="bg-purple-600 hover:bg-purple-700">
                      <MessageCircle className="w-4 h-4 mr-2" />
                      Send SMS
                    </Button>
                    <Button onClick={() => {
                      setViewingLead(null);
                      handleScheduleMeeting(viewingLead);
                    }} variant="outline">
                      📅 Schedule Meeting
                    </Button>
                  </div>
                </TabsContent>

                <TabsContent value="score" className="space-y-3 mt-4">
                  {(() => {
                    const score = getLeadScore(viewingLead.id);
                    if (!score || !score.score_history || score.score_history.length === 0) {
                      return (
                        <div className="text-center py-8 text-gray-500">
                          <TrendingUp className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                          <p>No scoring history yet</p>
                          <p className="text-sm text-gray-400">Score will update as you interact with this lead</p>
                        </div>
                      );
                    }

                    return (
                      <>
                        <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200">
                          <CardContent className="p-6">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="text-sm text-gray-600">Current Score</p>
                                <p className="text-4xl font-bold text-gray-900">{score.total_score}</p>
                              </div>
                              <div className="text-right">
                                {score.temperature === 'hot' && <Flame className="w-16 h-16 text-red-500" />}
                                {score.temperature === 'warm' && <ThermometerSun className="w-16 h-16 text-orange-500" />}
                                {score.temperature === 'cold' && <Snowflake className="w-16 h-16 text-blue-500" />}
                                <p className="text-lg font-semibold uppercase">{score.temperature}</p>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        <div className="space-y-2">
                          {[...score.score_history].reverse().map((entry, idx) => (
                            <Card key={idx} className="bg-white">
                              <CardContent className="p-4">
                                <div className="flex items-start justify-between">
                                  <div className="flex-1">
                                    <p className="font-medium text-sm">{entry.actionDescription || entry.action}</p>
                                    <p className="text-xs text-gray-500">
                                      {safeFormatDate(entry.timestamp, 'MMM d, yyyy h:mm a')}
                                    </p>
                                  </div>
                                  <Badge 
                                    variant="outline" 
                                    className={`${entry.points > 0 ? 'bg-green-100 text-green-700 border-green-300' : 'bg-red-100 text-red-700 border-red-300'} font-semibold`}
                                  >
                                    {entry.points > 0 ? '+' : ''}{entry.points}
                                  </Badge>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </>
                    );
                  })()}
                </TabsContent>

                <TabsContent value="communications" className="space-y-3 mt-4">
                  {communications.filter(c => 
                    c.contact_name === viewingLead.name || 
                    (c.contact_phone && (c.contact_phone === viewingLead.phone || c.contact_phone === viewingLead.phone_2)) ||
                    c.contact_email === viewingLead.email
                  ).sort((a,b) => new Date(b.created_date).getTime() - new Date(a.created_date).getTime())
                  .map(comm => (
                    <Card key={comm.id} className="bg-gray-50">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                            comm.communication_type === 'call' ? 'bg-green-100' :
                            comm.communication_type === 'email' ? 'bg-blue-100' :
                            comm.communication_type === 'sms' ? 'bg-purple-100' : 'bg-gray-100'
                          }`}>
                            {comm.communication_type === 'call' && <Phone className="w-5 h-5 text-green-600" />}
                            {comm.communication_type === 'email' && <Mail className="w-5 h-5 text-blue-600" />}
                            {comm.communication_type === 'sms' && <MessageCircle className="w-5 h-5 text-purple-600" />}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <Badge variant="secondary">{comm.communication_type}</Badge>
                              <span className="text-xs text-gray-500">
                                {safeFormatDate(comm.created_date, 'MMM d, yyyy h:mm a')}
                              </span>
                            </div>
                            {comm.subject && (
                              <p className="font-medium text-sm mb-1">{comm.subject}</p>
                            )}
                            <p className="text-sm text-gray-600">{comm.message}</p>
                            {comm.duration_minutes > 0 && (
                              <p className="text-xs text-gray-500 mt-1">Duration: {comm.duration_minutes} min</p>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {communications.filter(c => 
                    c.contact_name === viewingLead.name || 
                    (c.contact_phone && (c.contact_phone === viewingLead.phone || c.contact_phone === viewingLead.phone_2)) ||
                    c.contact_email === viewingLead.email
                  ).length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <MessageCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p>No communications yet</p>
                      <p className="text-sm text-gray-400">Start by calling, texting, or emailing this lead</p>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="meetings" className="space-y-3 mt-4">
                  {calendarEvents.filter(e => 
                    e.related_lead && viewingLead.name && e.related_lead.toLowerCase() === viewingLead.name.toLowerCase()
                  ).sort((a,b) => new Date(b.start_time).getTime() - new Date(a.start_time).getTime())
                  .map(event => (
                    <Card key={event.id} className="bg-gray-50">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h4 className="font-semibold">{event.title}</h4>
                            <p className="text-sm text-gray-600 mt-1">{event.description}</p>
                            <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                              <span>📅 {safeFormatDate(event.start_time, 'MMM d, yyyy h:mm a')}</span>
                              {event.location && <span>📍 {event.location}</span>}
                            </div>
                          </div>
                          <Badge>{event.event_type}</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {calendarEvents.filter(e => 
                    e.related_lead && viewingLead.name && e.related_lead.toLowerCase() === viewingLead.name.toLowerCase()
                  ).length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      <Calendar className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p>No meetings scheduled</p>
                      <Button onClick={() => {
                        setViewingLead(null);
                        handleScheduleMeeting(viewingLead);
                      }} className="mt-3">
                        📅 Schedule Meeting
                      </Button>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </ScrollArea>
          )}
        </DialogContent>
      </Dialog>

      <Dialer
        open={showDialer}
        onOpenChange={setShowDialer}
        defaultNumber={selectedLead?.phone || selectedLead?.phone_2}
      />
      <EmailDialog
        open={showEmailDialog}
        onOpenChange={setShowEmailDialog}
        defaultTo={selectedLead?.email}
      />
      <SMSDialog
        open={showSMSDialog}
        onOpenChange={setShowSMSDialog}
        defaultTo={selectedLead?.phone || selectedLead?.phone_2}
      />
    </div>
  );
}
