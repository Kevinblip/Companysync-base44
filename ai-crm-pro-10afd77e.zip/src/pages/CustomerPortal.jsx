import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  FileText,
  Download,
  DollarSign,
  Calendar,
  CheckCircle2,
  Clock,
  MessageCircle,
  Send,
  Paperclip,
  CreditCard,
  Eye,
  ThumbsUp,
  ThumbsDown
} from "lucide-react";
import { format } from "date-fns";

export default function CustomerPortal() {
  const [user, setUser] = useState(null);
  const [viewingDocument, setViewingDocument] = useState(null);
  const [newMessage, setNewMessage] = useState("");
  const [selectedConversation, setSelectedConversation] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  // Fetch customer data
  const { data: customers = [] } = useQuery({
    queryKey: ['customers', user?.email],
    queryFn: () => base44.entities.Customer.filter({ email: user?.email }),
    enabled: !!user,
    initialData: [],
  });

  const customer = customers[0];

  // Fetch estimates
  const { data: estimates = [] } = useQuery({
    queryKey: ['estimates', customer?.name],
    queryFn: () => base44.entities.Estimate.filter({ customer_name: customer?.name }),
    enabled: !!customer,
    initialData: [],
  });

  // Fetch invoices
  const { data: invoices = [] } = useQuery({
    queryKey: ['invoices', customer?.name],
    queryFn: () => base44.entities.Invoice.filter({ customer_name: customer?.name }),
    enabled: !!customer,
    initialData: [],
  });

  // Fetch projects
  const { data: projects = [] } = useQuery({
    queryKey: ['projects', customer?.name],
    queryFn: () => base44.entities.Project.filter({ customer_name: customer?.name }),
    enabled: !!customer,
    initialData: [],
  });

  // Fetch appointments
  const { data: appointments = [] } = useQuery({
    queryKey: ['appointments', customer?.name],
    queryFn: () => base44.entities.CalendarEvent.filter({ related_customer: customer?.name }),
    enabled: !!customer,
    initialData: [],
  });

  // Fetch payments
  const { data: payments = [] } = useQuery({
    queryKey: ['payments', customer?.name],
    queryFn: () => base44.entities.Payment.filter({ customer_name: customer?.name }),
    enabled: !!customer,
    initialData: [],
  });

  // Fetch documents
  const { data: documents = [] } = useQuery({
    queryKey: ['documents', customer?.name],
    queryFn: () => base44.entities.Document.filter({
      related_customer: customer?.name,
      is_customer_visible: true
    }),
    enabled: !!customer,
    initialData: [],
  });

  // Fetch messages
  const { data: messages = [] } = useQuery({
    queryKey: ['messages', user?.email],
    queryFn: () => base44.entities.Message.filter({
      to_user_email: user?.email
    }),
    enabled: !!user,
    initialData: [],
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
        <Card className="w-96">
          <CardContent className="p-8 text-center">
            <p className="text-gray-500">Loading...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
        <Card className="w-96">
          <CardContent className="p-8 text-center">
            <p className="text-gray-500">No customer account found for {user.email}</p>
            <p className="text-sm text-gray-400 mt-2">Please contact support</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const totalOutstanding = invoices
    .filter(i => i.status !== 'paid' && i.status !== 'cancelled')
    .reduce((sum, inv) => sum + (inv.amount || 0), 0);

  const openEstimates = estimates.filter(e => e.status !== 'accepted' && e.status !== 'declined' && e.status !== 'expired');
  const completedProjects = projects.filter(p => p.status === 'completed');
  const upcomingAppointments = appointments.filter(a => {
    return new Date(a.start_time) > new Date() && a.status === 'scheduled';
  }).sort((a, b) => new Date(a.start_time) - new Date(b.start_time));

  const handleAcceptEstimate = async (estimate) => {
    if (window.confirm('Accept this estimate?')) {
      await base44.entities.Estimate.update(estimate.id, {
        ...estimate,
        status: 'accepted'
      });
      alert('Estimate accepted! We will contact you shortly.');
    }
  };

  const handleDeclineEstimate = async (estimate) => {
    if (window.confirm('Decline this estimate?')) {
      await base44.entities.Estimate.update(estimate.id, {
        ...estimate,
        status: 'declined'
      });
      alert('Estimate declined.');
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim()) return;

    await base44.entities.Message.create({
      from_user_email: user.email,
      from_user_name: user.full_name,
      to_user_email: 'support@company.com', // Or get from company settings
      to_user_name: 'Support Team',
      subject: 'Customer inquiry',
      message_body: newMessage,
      message_type: 'customer_to_staff',
      conversation_id: selectedConversation || `conv_${Date.now()}`
    });

    setNewMessage("");
    alert('Message sent! We will respond shortly.');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold">Welcome back, {customer.name}! 👋</h1>
          <p className="text-blue-100 mt-2">Your customer portal dashboard</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Outstanding Balance</p>
                  <p className="text-2xl font-bold text-red-600">${totalOutstanding.toLocaleString()}</p>
                </div>
                <DollarSign className="w-8 h-8 text-red-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Open Estimates</p>
                  <p className="text-2xl font-bold text-blue-600">{openEstimates.length}</p>
                </div>
                <FileText className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Active Projects</p>
                  <p className="text-2xl font-bold text-green-600">{projects.filter(p => p.status === 'in_progress').length}</p>
                </div>
                <Clock className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Completed Projects</p>
                  <p className="text-2xl font-bold text-purple-600">{completedProjects.length}</p>
                </div>
                <CheckCircle2 className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Card className="bg-white shadow-lg">
          <Tabs defaultValue="estimates" className="w-full">
            <TabsList className="w-full justify-start border-b rounded-none bg-gray-50 p-0">
              <TabsTrigger value="estimates" className="px-6 py-3">
                Estimates ({estimates.length})
              </TabsTrigger>
              <TabsTrigger value="invoices" className="px-6 py-3">
                Invoices ({invoices.length})
              </TabsTrigger>
              <TabsTrigger value="payments" className="px-6 py-3">
                Payment History ({payments.length})
              </TabsTrigger>
              <TabsTrigger value="projects" className="px-6 py-3">
                Projects ({projects.length})
              </TabsTrigger>
              <TabsTrigger value="appointments" className="px-6 py-3">
                Appointments ({appointments.length})
              </TabsTrigger>
              <TabsTrigger value="documents" className="px-6 py-3">
                Documents ({documents.length})
              </TabsTrigger>
              <TabsTrigger value="messages" className="px-6 py-3">
                Messages ({messages.filter(m => !m.is_read).length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="estimates" className="p-6">
              <div className="space-y-4">
                {estimates.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <p>No estimates yet</p>
                  </div>
                ) : (
                  estimates.map((estimate) => (
                    <Card key={estimate.id} className="bg-gray-50">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-lg font-semibold">
                                Estimate #{estimate.estimate_number}
                              </h3>
                              <Badge variant="outline" className={
                                estimate.status === 'accepted' ? 'bg-green-100 text-green-700 border-green-200' :
                                estimate.status === 'declined' ? 'bg-red-100 text-red-700 border-red-200' :
                                estimate.status === 'expired' ? 'bg-gray-100 text-gray-700 border-gray-200' :
                                'bg-blue-100 text-blue-700 border-blue-200'
                              }>
                                {estimate.status}
                              </Badge>
                            </div>
                            <p className="text-2xl font-bold text-gray-900 mb-2">
                              ${(estimate.amount || 0).toLocaleString()}
                            </p>
                            {estimate.valid_until && (
                              <p className="text-sm text-gray-500">
                                Valid until: {format(new Date(estimate.valid_until), 'MMM d, yyyy')}
                              </p>
                            )}
                          </div>

                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setViewingDocument({ type: 'estimate', data: estimate })}
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              View
                            </Button>
                            {estimate.status === 'sent' || estimate.status === 'viewed' ? (
                              <>
                                <Button
                                  size="sm"
                                  className="bg-green-600 hover:bg-green-700"
                                  onClick={() => handleAcceptEstimate(estimate)}
                                >
                                  <ThumbsUp className="w-4 h-4 mr-2" />
                                  Accept
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-red-600 border-red-300 hover:bg-red-50"
                                  onClick={() => handleDeclineEstimate(estimate)}
                                >
                                  <ThumbsDown className="w-4 h-4 mr-2" />
                                  Decline
                                </Button>
                              </>
                            ) : null}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="invoices" className="p-6">
              <div className="space-y-4">
                {invoices.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <p>No invoices yet</p>
                  </div>
                ) : (
                  invoices.map((invoice) => (
                    <Card key={invoice.id} className="bg-gray-50">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                              <h3 className="text-lg font-semibold">
                                Invoice #{invoice.invoice_number}
                              </h3>
                              <Badge variant="outline" className={
                                invoice.status === 'paid' ? 'bg-green-100 text-green-700 border-green-200' :
                                invoice.status === 'overdue' ? 'bg-red-100 text-red-700 border-red-200' :
                                'bg-yellow-100 text-yellow-700 border-yellow-200'
                              }>
                                {invoice.status}
                              </Badge>
                            </div>
                            <p className="text-2xl font-bold text-gray-900 mb-2">
                              ${(invoice.amount || 0).toLocaleString()}
                            </p>
                            {invoice.due_date && (
                              <p className="text-sm text-gray-500">
                                Due: {format(new Date(invoice.due_date), 'MMM d, yyyy')}
                              </p>
                            )}
                          </div>

                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setViewingDocument({ type: 'invoice', data: invoice })}
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              View
                            </Button>
                            {invoice.status !== 'paid' && invoice.status !== 'cancelled' && (
                              <Button
                                size="sm"
                                className="bg-green-600 hover:bg-green-700"
                              >
                                <CreditCard className="w-4 h-4 mr-2" />
                                Pay Now
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="payments" className="p-6">
              <div className="space-y-4">
                {payments.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <DollarSign className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <p>No payment history yet</p>
                  </div>
                ) : (
                  payments.map((payment) => (
                    <Card key={payment.id} className="bg-gray-50">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold">Payment #{payment.payment_number}</p>
                            <p className="text-sm text-gray-500">
                              {format(new Date(payment.payment_date), 'MMM d, yyyy')} • {payment.payment_method}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-green-600">
                              ${(payment.amount || 0).toLocaleString()}
                            </p>
                            <Badge variant="outline" className="bg-green-100 text-green-700 border-green-200">
                              {payment.status}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="projects" className="p-6">
              <div className="space-y-4">
                {projects.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <Clock className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <p>No projects yet</p>
                  </div>
                ) : (
                  projects.map((project) => (
                    <Card key={project.id} className="bg-gray-50">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h3 className="text-lg font-semibold">{project.name}</h3>
                            <p className="text-sm text-gray-500 mt-1">{project.description}</p>
                          </div>
                          <Badge variant="outline" className={
                            project.status === 'completed' ? 'bg-green-100 text-green-700 border-green-200' :
                            project.status === 'in_progress' ? 'bg-blue-100 text-blue-700 border-blue-200' :
                            'bg-gray-100 text-gray-700 border-gray-200'
                          }>
                            {project.status}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          {project.start_date && (
                            <div>
                              <p className="text-gray-500">Start Date</p>
                              <p className="font-semibold">{format(new Date(project.start_date), 'MMM d, yyyy')}</p>
                            </div>
                          )}
                          {project.deadline && (
                            <div>
                              <p className="text-gray-500">Deadline</p>
                              <p className="font-semibold">{format(new Date(project.deadline), 'MMM d, yyyy')}</p>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="appointments" className="p-6">
              <div className="space-y-4">
                {appointments.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <Calendar className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <p>No appointments scheduled</p>
                  </div>
                ) : (
                  appointments.map((appointment) => (
                    <Card key={appointment.id} className="bg-gray-50">
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-4">
                            <div className="w-16 h-16 bg-blue-100 rounded-lg flex flex-col items-center justify-center">
                              <p className="text-2xl font-bold text-blue-600">
                                {format(new Date(appointment.start_time), 'd')}
                              </p>
                              <p className="text-xs text-blue-600">
                                {format(new Date(appointment.start_time), 'MMM')}
                              </p>
                            </div>
                            <div>
                              <h3 className="font-semibold text-lg">{appointment.title}</h3>
                              <p className="text-sm text-gray-500 mt-1">{appointment.description}</p>
                              <p className="text-sm text-gray-600 mt-2">
                                📅 {format(new Date(appointment.start_time), 'MMM d, yyyy h:mm a')}
                              </p>
                              {appointment.location && (
                                <p className="text-sm text-gray-600">📍 {appointment.location}</p>
                              )}
                            </div>
                          </div>
                          <Badge variant="outline" className={
                            appointment.status === 'completed' ? 'bg-green-100 text-green-700 border-green-200' :
                            appointment.status === 'cancelled' ? 'bg-red-100 text-red-700 border-red-200' :
                            'bg-blue-100 text-blue-700 border-blue-200'
                          }>
                            {appointment.status}
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="documents" className="p-6">
              <div className="space-y-4">
                {documents.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <p>No documents available</p>
                  </div>
                ) : (
                  documents.map((doc) => (
                    <Card key={doc.id} className="bg-gray-50">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <FileText className="w-8 h-8 text-blue-500" />
                            <div>
                              <p className="font-semibold">{doc.document_name}</p>
                              <p className="text-sm text-gray-500">
                                {format(new Date(doc.created_date), 'MMM d, yyyy')}
                              </p>
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => window.open(doc.file_url, '_blank')}
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </TabsContent>

            <TabsContent value="messages" className="p-6">
              <div className="grid grid-cols-3 gap-6">
                <div className="col-span-1 space-y-2">
                  <h3 className="font-semibold mb-2">Conversations</h3>
                  {messages.length === 0 ? (
                    <p className="text-sm text-gray-500">No messages yet</p>
                  ) : (
                    messages.map((msg) => (
                      <Card
                        key={msg.id}
                        className={`cursor-pointer hover:bg-gray-50 ${!msg.is_read ? 'border-blue-500' : ''}`}
                        onClick={() => setSelectedConversation(msg.conversation_id)}
                      >
                        <CardContent className="p-3">
                          <p className="font-semibold text-sm">{msg.subject || 'No subject'}</p>
                          <p className="text-xs text-gray-500 truncate">{msg.message_body}</p>
                          <p className="text-xs text-gray-400 mt-1">
                            {format(new Date(msg.created_date), 'MMM d')}
                          </p>
                        </CardContent>
                      </Card>
                    ))
                  )}
                </div>

                <div className="col-span-2">
                  <Card className="h-[600px] flex flex-col">
                    <CardHeader className="border-b">
                      <CardTitle>Send a Message</CardTitle>
                    </CardHeader>
                    <CardContent className="flex-1 p-4 flex flex-col">
                      <div className="flex-1 overflow-y-auto mb-4">
                        {messages.filter(m => m.conversation_id === selectedConversation).map(msg => (
                          <div key={msg.id} className="mb-4 p-3 bg-gray-50 rounded-lg">
                            <div className="flex justify-between items-start mb-2">
                              <p className="font-semibold text-sm">{msg.from_user_name}</p>
                              <p className="text-xs text-gray-500">
                                {format(new Date(msg.created_date), 'MMM d, h:mm a')}
                              </p>
                            </div>
                            <p className="text-sm">{msg.message_body}</p>
                          </div>
                        ))}
                      </div>
                      <div className="space-y-3">
                        <Textarea
                          placeholder="Type your message..."
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          rows={4}
                        />
                        <div className="flex justify-between">
                          <Button variant="outline" size="sm">
                            <Paperclip className="w-4 h-4 mr-2" />
                            Attach File
                          </Button>
                          <Button
                            onClick={handleSendMessage}
                            disabled={!newMessage.trim()}
                            className="bg-blue-600 hover:bg-blue-700"
                          >
                            <Send className="w-4 h-4 mr-2" />
                            Send Message
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </Card>
      </div>
    </div>
  );
}