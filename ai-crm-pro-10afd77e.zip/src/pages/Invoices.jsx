import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Mail, Send, Eye, Download, CheckCircle } from "lucide-react";

export default function Invoices() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [sendingInvoice, setSendingInvoice] = useState(null);

  const { data: invoices = [] } = useQuery({
    queryKey: ['invoices'],
    queryFn: () => base44.entities.Invoice.list("-created_date"),
    initialData: [],
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const [user, setUser] = useState(null);
  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const myCompany = companies.find(c => c.created_by === user?.email);

  const getStatusColor = (status) => {
    const colors = {
      'paid': 'bg-green-100 text-green-700 border-green-200',
      'sent': 'bg-blue-100 text-blue-700 border-blue-200',
      'draft': 'bg-gray-100 text-gray-700 border-gray-200',
      'overdue': 'bg-red-100 text-red-700 border-red-200',
    };
    return colors[status] || 'bg-gray-100 text-gray-700 border-gray-200';
  };

  const sendInvoiceMutation = useMutation({
    mutationFn: async (invoice) => {
      setSendingInvoice(invoice.id);
      
      const response = await base44.functions.invoke('sendInvoiceEmail', {
        invoiceId: invoice.id,
        companyId: myCompany?.id
      });
      
      await base44.entities.Invoice.update(invoice.id, {
        status: 'sent',
        sent_date: new Date().toISOString()
      });

      try {
        await base44.functions.invoke('executeWorkflow', {
          triggerType: 'invoice_created',
          entityType: 'Invoice',
          entityId: invoice.id,
          entityData: invoice
        });
      } catch (error) {
        console.error('⚠️ Workflow trigger failed:', error);
      }

      return response;
    },
    onSuccess: (data, invoice) => {
      queryClient.invalidateQueries({ queryKey: ['invoices'] });
      setSendingInvoice(null);
      alert(`✅ Invoice sent to ${invoice.customer_email}!\n\n📧 Email delivered\n⏰ Payment reminders scheduled`);
    },
    onError: (error) => {
      setSendingInvoice(null);
      alert(`❌ Failed to send invoice: ${error.message}`);
    }
  });

  const handleSendInvoice = (invoice) => {
    if (!invoice.customer_email) {
      alert('❌ Cannot send invoice: Customer email is missing.\n\nPlease add an email address first.');
      return;
    }

    if (window.confirm(`Send invoice ${invoice.invoice_number} to ${invoice.customer_email}?`)) {
      sendInvoiceMutation.mutate(invoice);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Invoices</h1>
        <p className="text-gray-500 mt-1">Manage your invoices and payments</p>
      </div>

      <Card className="bg-white shadow-md">
        <CardHeader>
          <CardTitle>All Invoices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm text-gray-500">
                  <th className="pb-3 font-medium">Invoice #</th>
                  <th className="pb-3 font-medium">Customer</th>
                  <th className="pb-3 font-medium">Amount</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium">Issue Date</th>
                  <th className="pb-3 font-medium">Due Date</th>
                  <th className="pb-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((invoice) => (
                  <tr key={invoice.id} className="border-b hover:bg-gray-50">
                    <td className="py-4 font-medium">{invoice.invoice_number}</td>
                    <td className="py-4">
                      <button
                        onClick={() => navigate(createPageUrl('customer-profile') + `?name=${encodeURIComponent(invoice.customer_name)}`)}
                        className="text-blue-600 hover:underline"
                      >
                        {invoice.customer_name}
                      </button>
                    </td>
                    <td className="py-4 font-semibold text-green-600">
                      ${invoice.amount?.toFixed(2)}
                    </td>
                    <td className="py-4">
                      <Badge variant="outline" className={getStatusColor(invoice.status)}>
                        {invoice.status}
                      </Badge>
                    </td>
                    <td className="py-4 text-sm text-gray-600">
                      {invoice.issue_date ? format(new Date(invoice.issue_date), 'MMM d, yyyy') : '-'}
                    </td>
                    <td className="py-4 text-sm text-gray-600">
                      {invoice.due_date ? format(new Date(invoice.due_date), 'MMM d, yyyy') : '-'}
                    </td>
                    <td className="py-4 text-right">
                      <div className="flex items-center justify-end gap-2">
                        {invoice.status !== 'paid' && invoice.status !== 'cancelled' && (
                          <Button
                            size="sm"
                            onClick={() => handleSendInvoice(invoice)}
                            disabled={sendInvoiceMutation.isLoading && sendingInvoice === invoice.id || !invoice.customer_email}
                            className="bg-blue-600 hover:bg-blue-700"
                            title={!invoice.customer_email ? 'Add customer email first' : 'Send invoice via email'}
                          >
                            {sendInvoiceMutation.isLoading && sendingInvoice === invoice.id ? (
                              <>
                                <svg className="animate-spin h-4 w-4 mr-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Sending...
                              </>
                            ) : (
                              <>
                                <Send className="w-4 h-4 mr-1" />
                                Send
                              </>
                            )}
                          </Button>
                        )}
                        {invoice.status === 'sent' && (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Sent
                          </Badge>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
                {invoices.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-gray-500">
                      No invoices yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}