import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Plus,
  FileSignature,
  CheckCircle,
  Clock,
  XCircle,
  Edit,
  Trash2,
  Search,
  AlertTriangle
} from "lucide-react";
import { format } from "date-fns";

export default function Contracts() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingContract, setEditingContract] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [formData, setFormData] = useState({
    contract_name: "",
    customer_name: "",
    contract_type: "service",
    start_date: "",
    end_date: "",
    value: 0,
    status: "draft",
    terms: "",
    notes: ""
  });

  const [user, setUser] = useState(null);
  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  const queryClient = useQueryClient();

  const { data: contracts = [] } = useQuery({
    queryKey: ['contracts', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.Contract.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.Customer.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Contract.create({
      ...data,
      company_id: myCompany?.id
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contracts'] });
      handleCloseDialog();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Contract.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contracts'] });
      handleCloseDialog();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Contract.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['contracts'] });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingContract) {
      updateMutation.mutate({ id: editingContract.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleCloseDialog = () => {
    setShowDialog(false);
    setEditingContract(null);
    setFormData({
      contract_name: "",
      customer_name: "",
      contract_type: "service",
      start_date: "",
      end_date: "",
      value: 0,
      status: "draft",
      terms: "",
      notes: ""
    });
  };

  const handleEdit = (contract) => {
    setEditingContract(contract);
    setFormData({
      contract_name: contract.contract_name || "",
      customer_name: contract.customer_name || "",
      contract_type: contract.contract_type || "service",
      start_date: contract.start_date?.split('T')[0] || "",
      end_date: contract.end_date?.split('T')[0] || "",
      value: contract.value || 0,
      status: contract.status || "draft",
      terms: contract.terms || "",
      notes: contract.notes || ""
    });
    setShowDialog(true);
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this contract?')) {
      deleteMutation.mutate(id);
    }
  };

  const pendingContracts = contracts.filter(c => c.status === 'draft').length;
  const activeContracts = contracts.filter(c => c.status === 'active').length;
  const expiringSoon = contracts.filter(c => {
    if (!c.end_date || c.status !== 'active') return false;
    const endDate = new Date(c.end_date);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry > 0 && daysUntilExpiry <= 30;
  }).length;
  const expiredContracts = contracts.filter(c => c.status === 'expired').length;

  const filteredContracts = contracts.filter(contract =>
    contract.contract_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contract.customer_name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status) => {
    const colors = {
      'draft': 'bg-gray-100 text-gray-700 border-gray-200',
      'active': 'bg-green-100 text-green-700 border-green-200',
      'expired': 'bg-red-100 text-red-700 border-red-200',
      'terminated': 'bg-orange-100 text-orange-700 border-orange-200'
    };
    return colors[status] || 'bg-gray-100 text-gray-700 border-gray-200';
  };

  const getStatusIcon = (status) => {
    const icons = {
      'draft': Clock,
      'active': CheckCircle,
      'expired': XCircle,
      'terminated': AlertTriangle
    };
    return icons[status] || Clock;
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Contracts</h1>
          <p className="text-gray-500 mt-1">Manage customer contracts and agreements</p>
        </div>
        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Contract
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingContract ? 'Edit Contract' : 'Create New Contract'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="contract-name">Contract Name *</Label>
                <Input
                  id="contract-name"
                  value={formData.contract_name}
                  onChange={(e) => setFormData({...formData, contract_name: e.target.value})}
                  placeholder="e.g., Annual Maintenance Agreement"
                  required
                />
              </div>

              <div>
                <Label htmlFor="customer-select">Customer *</Label>
                <Select
                  value={formData.customer_name}
                  onValueChange={(value) => setFormData({...formData, customer_name: value})}
                >
                  <SelectTrigger id="customer-select">
                    <SelectValue placeholder="Select customer" />
                  </SelectTrigger>
                  <SelectContent>
                    {customers.map((customer) => (
                      <SelectItem key={customer.id} value={customer.name}>
                        {customer.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="contract-type">Contract Type</Label>
                  <Select
                    value={formData.contract_type}
                    onValueChange={(value) => setFormData({...formData, contract_type: value})}
                  >
                    <SelectTrigger id="contract-type">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="service">Service</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="subscription">Subscription</SelectItem>
                      <SelectItem value="project">Project</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="value">Contract Value ($)</Label>
                  <Input
                    id="value"
                    type="number"
                    step="0.01"
                    value={formData.value}
                    onChange={(e) => setFormData({...formData, value: parseFloat(e.target.value)})}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="start-date">Start Date *</Label>
                  <Input
                    id="start-date"
                    type="date"
                    value={formData.start_date}
                    onChange={(e) => setFormData({...formData, start_date: e.target.value})}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="end-date">End Date *</Label>
                  <Input
                    id="end-date"
                    type="date"
                    value={formData.end_date}
                    onChange={(e) => setFormData({...formData, end_date: e.target.value})}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData({...formData, status: value})}
                >
                  <SelectTrigger id="status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="expired">Expired</SelectItem>
                    <SelectItem value="terminated">Terminated</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="terms">Terms & Conditions</Label>
                <Textarea
                  id="terms"
                  value={formData.terms}
                  onChange={(e) => setFormData({...formData, terms: e.target.value})}
                  rows={4}
                  placeholder="Enter contract terms and conditions..."
                />
              </div>

              <div>
                <Label htmlFor="notes">Internal Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  rows={3}
                  placeholder="Internal notes (not visible to customer)..."
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button type="button" variant="outline" onClick={handleCloseDialog}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingContract ? 'Update Contract' : 'Create Contract'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
          <CardContent className="p-6">
            <Clock className="w-8 h-8 text-blue-600 mb-2" />
            <h3 className="text-2xl font-bold">{pendingContracts}</h3>
            <p className="text-sm text-gray-600">Pending</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-6">
            <CheckCircle className="w-8 h-8 text-green-600 mb-2" />
            <h3 className="text-2xl font-bold">{activeContracts}</h3>
            <p className="text-sm text-gray-600">Active</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 border-orange-200">
          <CardContent className="p-6">
            <AlertTriangle className="w-8 h-8 text-orange-600 mb-2" />
            <h3 className="text-2xl font-bold">{expiringSoon}</h3>
            <p className="text-sm text-gray-600">Expiring Soon</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-pink-50 border-red-200">
          <CardContent className="p-6">
            <XCircle className="w-8 h-8 text-red-600 mb-2" />
            <h3 className="text-2xl font-bold">{expiredContracts}</h3>
            <p className="text-sm text-gray-600">Expired</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>All Contracts</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search contracts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredContracts.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <FileSignature className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p>No contracts yet</p>
              <p className="text-sm mt-1">Create your first contract to get started!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-xs text-gray-500">
                    <th className="pb-3 font-medium">Contract Name</th>
                    <th className="pb-3 font-medium">Customer</th>
                    <th className="pb-3 font-medium">Type</th>
                    <th className="pb-3 font-medium">Value</th>
                    <th className="pb-3 font-medium">Start Date</th>
                    <th className="pb-3 font-medium">End Date</th>
                    <th className="pb-3 font-medium">Status</th>
                    <th className="pb-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredContracts.map((contract) => {
                    const StatusIcon = getStatusIcon(contract.status);
                    return (
                      <tr key={contract.id} className="border-b hover:bg-gray-50">
                        <td className="py-4 font-medium">{contract.contract_name}</td>
                        <td className="py-4 text-gray-600">{contract.customer_name}</td>
                        <td className="py-4 text-sm text-gray-600 capitalize">
                          {contract.contract_type?.replace('_', ' ')}
                        </td>
                        <td className="py-4 font-semibold text-green-600">
                          ${contract.value?.toFixed(2) || '0.00'}
                        </td>
                        <td className="py-4 text-sm text-gray-600">
                          {contract.start_date ? format(new Date(contract.start_date), 'MMM d, yyyy') : '-'}
                        </td>
                        <td className="py-4 text-sm text-gray-600">
                          {contract.end_date ? format(new Date(contract.end_date), 'MMM d, yyyy') : '-'}
                        </td>
                        <td className="py-4">
                          <Badge variant="outline" className={`${getStatusColor(contract.status)} flex items-center gap-1 w-fit`}>
                            <StatusIcon className="w-3 h-3" />
                            {contract.status}
                          </Badge>
                        </td>
                        <td className="py-4">
                          <div className="flex gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEdit(contract)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDelete(contract.id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}