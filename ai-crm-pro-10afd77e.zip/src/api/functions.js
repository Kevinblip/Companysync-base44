import { base44 } from './base44Client';


export const sendSMS = base44.functions.sendSMS;

export const makeCall = base44.functions.makeCall;

export const incomingSMSWebhook = base44.functions.incomingSMSWebhook;

export const callStatusWebhook = base44.functions.callStatusWebhook;

export const recordingWebhook = base44.functions.recordingWebhook;

export const incomingCall = base44.functions.incomingCall;

export const incomingSMS = base44.functions.incomingSMS;

export const fetchStormData = base44.functions.fetchStormData;

export const generateStormLeads = base44.functions.generateStormLeads;

export const sendStormAlerts = base44.functions.sendStormAlerts;

export const importPropertyData = base44.functions.importPropertyData;

export const extractEstimateWithClaude = base44.functions.extractEstimateWithClaude;

export const extractEstimateGPT4o = base44.functions.extractEstimateGPT4o;

export const chatGPT4o = base44.functions.chatGPT4o;

export const checkReminders = base44.functions.checkReminders;

export const testWorkflow = base44.functions.testWorkflow;

export const lexiWorkflowAgent = base44.functions.lexiWorkflowAgent;

export const executeWorkflow = base44.functions.executeWorkflow;

export const processWorkflowQueue = base44.functions.processWorkflowQueue;

export const sendInvoiceEmail = base44.functions.sendInvoiceEmail;

export const sendEstimateEmail = base44.functions.sendEstimateEmail;

export const updateLeadScore = base44.functions.updateLeadScore;

export const decayLeadScores = base44.functions.decayLeadScores;

export const generateReportPDF = base44.functions.generateReportPDF;

export const sendScheduledReports = base44.functions.sendScheduledReports;

export const assignCustomerNumbers = base44.functions.assignCustomerNumbers;

export const calendarFeed = base44.functions.calendarFeed;

export const createThoughtlyAgent = base44.functions.createThoughtlyAgent;

export const listThoughtlyAgents = base44.functions.listThoughtlyAgents;

export const processContractTemplate = base44.functions.processContractTemplate;

export const fillContractTemplate = base44.functions.fillContractTemplate;

export const analyzeContractTemplate = base44.functions.analyzeContractTemplate;

export const sendContractSigningLink = base44.functions.sendContractSigningLink;

export const generateSignedPDF = base44.functions.generateSignedPDF;

export const thoughtlyWebhook = base44.functions.thoughtlyWebhook;

export const connectGoogleCalendar = base44.functions.connectGoogleCalendar;

export const calculateLeadScore = base44.functions.calculateLeadScore;

export const elevenLabsSpeak = base44.functions.elevenLabsSpeak;

export const lexiChat = base44.functions.lexiChat;

export const lexiVoiceWebhook = base44.functions.lexiVoiceWebhook;

export const googleCalendarCallback = base44.functions.googleCalendarCallback;

export const checkGoogleCalendarConnection = base44.functions.checkGoogleCalendarConnection;

export const disconnectGoogleCalendar = base44.functions.disconnectGoogleCalendar;

export const syncGoogleCalendar = base44.functions.syncGoogleCalendar;

export const importStaff = base44.functions.importStaff;

export const getCrewCamJobs = base44.functions.getCrewCamJobs;

export const sendInspectionAssignment = base44.functions.sendInspectionAssignment;

export const getGoogleMapsApiKey = base44.functions.getGoogleMapsApiKey;

export const syncCrewCamJob = base44.functions.syncCrewCamJob;

export const testLexiBackend = base44.functions.testLexiBackend;

export const generateDroneReport = base44.functions.generateDroneReport;

export const generateInspectionPDF = base44.functions.generateInspectionPDF;

