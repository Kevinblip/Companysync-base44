import { base44 } from './base44Client';


export const Lead = base44.entities.Lead;

export const Customer = base44.entities.Customer;

export const Task = base44.entities.Task;

export const Invoice = base44.entities.Invoice;

export const Estimate = base44.entities.Estimate;

export const Project = base44.entities.Project;

export const CompanySetting = base44.entities.CompanySetting;

export const CalendarEvent = base44.entities.CalendarEvent;

export const PriceListItem = base44.entities.PriceListItem;

export const Communication = base44.entities.Communication;

export const Item = base44.entities.Item;

export const SubscriptionPlan = base44.entities.SubscriptionPlan;

export const CompanySubscription = base44.entities.CompanySubscription;

export const Payment = base44.entities.Payment;

export const Proposal = base44.entities.Proposal;

export const DroneInspection = base44.entities.DroneInspection;

export const IntegrationSetting = base44.entities.IntegrationSetting;

export const EstimateFormat = base44.entities.EstimateFormat;

export const CalendarSettings = base44.entities.CalendarSettings;

export const TaskBoard = base44.entities.TaskBoard;

export const Company = base44.entities.Company;

export const TwilioSettings = base44.entities.TwilioSettings;

export const Contract = base44.entities.Contract;

export const StormEvent = base44.entities.StormEvent;

export const StormAlertSettings = base44.entities.StormAlertSettings;

export const MenuSettings = base44.entities.MenuSettings;

export const CustomField = base44.entities.CustomField;

export const ImportLog = base44.entities.ImportLog;

export const EmailTemplate = base44.entities.EmailTemplate;

export const SMSTemplate = base44.entities.SMSTemplate;

export const Workflow = base44.entities.Workflow;

export const LeadScore = base44.entities.LeadScore;

export const WorkflowExecution = base44.entities.WorkflowExecution;

export const KnowledgeBaseArticle = base44.entities.KnowledgeBaseArticle;

export const Document = base44.entities.Document;

export const Signature = base44.entities.Signature;

export const Message = base44.entities.Message;

export const SavedReport = base44.entities.SavedReport;

export const DashboardWidget = base44.entities.DashboardWidget;

export const RevenueGoal = base44.entities.RevenueGoal;

export const AITrainingData = base44.entities.AITrainingData;

export const CompanyProfile = base44.entities.CompanyProfile;

export const Property = base44.entities.Property;

export const ContractTemplate = base44.entities.ContractTemplate;

export const GeneratedContract = base44.entities.GeneratedContract;

export const ContractSigningSession = base44.entities.ContractSigningSession;

export const AIMemory = base44.entities.AIMemory;

export const ConversationHistory = base44.entities.ConversationHistory;

export const StaffProfile = base44.entities.StaffProfile;

export const Transaction = base44.entities.Transaction;

export const ChartOfAccount = base44.entities.ChartOfAccount;

export const StaffRole = base44.entities.StaffRole;

export const JobMedia = base44.entities.JobMedia;

export const InspectionJob = base44.entities.InspectionJob;



// auth sdk:
export const User = base44.auth;