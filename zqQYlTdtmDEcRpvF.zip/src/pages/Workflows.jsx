import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Play,
  Pause,
  Plus,
  Trash2,
  Edit,
  Copy,
  Activity,
  Mail,
  MessageSquare,
  CheckSquare,
  Clock,
  Zap,
  Settings,
  TrendingUp,
  Eye
} from "lucide-react";
import { format } from "date-fns";

export default function Workflows() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingWorkflow, setEditingWorkflow] = useState(null);
  const [formData, setFormData] = useState({
    workflow_name: "",
    description: "",
    trigger_type: "estimate_created",
    is_active: true,
    actions: []
  });

  const queryClient = useQueryClient();

  const { data: workflows = [] } = useQuery({
    queryKey: ['workflows'],
    queryFn: () => base44.entities.Workflow.list("-created_date"),
    initialData: [],
  });

  const { data: executions = [] } = useQuery({
    queryKey: ['workflow-executions'],
    queryFn: () => base44.entities.WorkflowExecution.filter({ status: 'active' }),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Workflow.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
      setShowDialog(false);
      resetForm();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Workflow.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Workflow.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['workflows'] });
    },
  });

  const testMutation = useMutation({
    mutationFn: async (workflowId) => {
      const response = await base44.functions.invoke('testWorkflow', { workflowId });
      return response.data;
    },
  });

  const resetForm = () => {
    setFormData({
      workflow_name: "",
      description: "",
      trigger_type: "estimate_created",
      is_active: true,
      actions: []
    });
    setEditingWorkflow(null);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (editingWorkflow) {
      updateMutation.mutate({ id: editingWorkflow.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (workflow) => {
    setEditingWorkflow(workflow);
    setFormData(workflow);
    setShowDialog(true);
  };

  const handleToggle = (workflow) => {
    updateMutation.mutate({
      id: workflow.id,
      data: { ...workflow, is_active: !workflow.is_active }
    });
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this workflow?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleTest = (id) => {
    testMutation.mutate(id);
  };

  const getTriggerIcon = (trigger) => {
    if (trigger.includes('estimate')) return <Mail className="w-4 h-4" />;
    if (trigger.includes('lead')) return <TrendingUp className="w-4 h-4" />;
    if (trigger.includes('invoice')) return <CheckSquare className="w-4 h-4" />;
    return <Zap className="w-4 h-4" />;
  };

  const activeWorkflows = workflows.filter(w => w.is_active).length;
  const totalExecutions = workflows.reduce((sum, w) => sum + (w.execution_count || 0), 0);
  const runningNow = executions.length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Workflow Automation</h1>
          <p className="text-gray-500 mt-1">Automate your sales process and follow-ups</p>
        </div>

        <Dialog open={showDialog} onOpenChange={(open) => {
          setShowDialog(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Create Workflow
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingWorkflow ? 'Edit Workflow' : 'Create New Workflow'}
              </DialogTitle>
            </DialogHeader>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Workflow Name *</Label>
                <Input
                  value={formData.workflow_name}
                  onChange={(e) => setFormData({...formData, workflow_name: e.target.value})}
                  placeholder="e.g., New Estimate Follow-up"
                  required
                />
              </div>

              <div>
                <Label>Description</Label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="What does this workflow do?"
                  rows={3}
                />
              </div>

              <div>
                <Label>Trigger *</Label>
                <Select
                  value={formData.trigger_type}
                  onValueChange={(value) => setFormData({...formData, trigger_type: value})}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="estimate_created">Estimate Created</SelectItem>
                    <SelectItem value="estimate_accepted">Estimate Accepted</SelectItem>
                    <SelectItem value="estimate_declined">Estimate Declined</SelectItem>
                    <SelectItem value="invoice_created">Invoice Created</SelectItem>
                    <SelectItem value="invoice_paid">Invoice Paid</SelectItem>
                    <SelectItem value="invoice_overdue">Invoice Overdue</SelectItem>
                    <SelectItem value="lead_created">Lead Created</SelectItem>
                    <SelectItem value="customer_created">Customer Created</SelectItem>
                    <SelectItem value="appointment_created">Appointment Created</SelectItem>
                    <SelectItem value="project_started">Project Started</SelectItem>
                    <SelectItem value="payment_received">Payment Received</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-3">
                <Switch
                  checked={formData.is_active}
                  onCheckedChange={(checked) => setFormData({...formData, is_active: checked})}
                />
                <Label>Active</Label>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-sm text-blue-800">
                  <strong>Note:</strong> After creating the workflow, you can add automation steps like sending emails, creating tasks, and more in the workflow editor.
                </p>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    setShowDialog(false);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingWorkflow ? 'Update' : 'Create'} Workflow
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Workflows</p>
                <p className="text-3xl font-bold text-gray-900">{workflows.length}</p>
              </div>
              <Settings className="w-8 h-8 text-gray-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Active Workflows</p>
                <p className="text-3xl font-bold text-green-600">{activeWorkflows}</p>
              </div>
              <Activity className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Total Executions</p>
                <p className="text-3xl font-bold text-blue-600">{totalExecutions}</p>
              </div>
              <Zap className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Running Now</p>
                <p className="text-3xl font-bold text-purple-600">{runningNow}</p>
              </div>
              <Clock className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Workflows List */}
      <Card>
        <CardHeader>
          <CardTitle>Your Workflows</CardTitle>
        </CardHeader>
        <CardContent>
          {workflows.length === 0 ? (
            <div className="text-center py-12">
              <Activity className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <p className="text-gray-500 font-medium mb-2">No workflows yet</p>
              <p className="text-sm text-gray-400 mb-4">Create your first workflow to automate your business</p>
              <Button onClick={() => setShowDialog(true)} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Create First Workflow
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {workflows.map((workflow) => (
                <Card key={workflow.id} className="border-2">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4 flex-1">
                        <div className="p-3 bg-blue-100 rounded-lg">
                          {getTriggerIcon(workflow.trigger_type)}
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-semibold text-gray-900">
                              {workflow.workflow_name}
                            </h3>
                            {workflow.is_active ? (
                              <Badge className="bg-green-100 text-green-700">Active</Badge>
                            ) : (
                              <Badge variant="outline">Inactive</Badge>
                            )}
                            {workflow.is_default && (
                              <Badge variant="outline" className="bg-purple-50 text-purple-700">
                                Template
                              </Badge>
                            )}
                          </div>

                          {workflow.description && (
                            <p className="text-sm text-gray-600 mb-3">{workflow.description}</p>
                          )}

                          <div className="flex items-center gap-6 text-sm text-gray-500">
                            <div className="flex items-center gap-2">
                              <Zap className="w-4 h-4" />
                              <span>Trigger: {workflow.trigger_type.replace(/_/g, ' ')}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Activity className="w-4 h-4" />
                              <span>{workflow.execution_count || 0} executions</span>
                            </div>
                            {workflow.last_executed && (
                              <div className="flex items-center gap-2">
                                <Clock className="w-4 h-4" />
                                <span>Last run: {format(new Date(workflow.last_executed), 'MMM d, h:mm a')}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleToggle(workflow)}
                        >
                          {workflow.is_active ? (
                            <><Pause className="w-4 h-4 mr-2" /> Pause</>
                          ) : (
                            <><Play className="w-4 h-4 mr-2" /> Activate</>
                          )}
                        </Button>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(workflow)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>

                        {!workflow.is_default && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(workflow.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Running Workflows */}
      {runningNow > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 animate-pulse text-green-600" />
              Currently Running ({runningNow})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {executions.slice(0, 5).map((execution) => (
                <div key={execution.id} className="flex items-center justify-between p-4 border rounded-lg bg-green-50">
                  <div>
                    <p className="font-medium text-gray-900">{execution.entity_name}</p>
                    <p className="text-sm text-gray-600">{execution.workflow_name}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      Step {execution.current_step + 1} • Next action: {execution.next_action_time ? format(new Date(execution.next_action_time), 'MMM d, h:mm a') : 'Now'}
                    </p>
                  </div>
                  <Badge className="bg-green-100 text-green-700">
                    <Activity className="w-3 h-3 mr-1 animate-pulse" />
                    Running
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}