import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Search, BookOpen, FileText, Video, HelpCircle } from "lucide-react";

export default function KnowledgeBase() {
  const categories = [
    { icon: FileText, title: "Getting Started", count: 0, color: "text-blue-600" },
    { icon: Video, title: "Video Tutorials", count: 0, color: "text-purple-600" },
    { icon: HelpCircle, title: "FAQs", count: 0, color: "text-green-600" },
    { icon: BookOpen, title: "Best Practices", count: 0, color: "text-orange-600" },
  ];

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Knowledge Base</h1>
        <p className="text-gray-500 mt-1">Learn how to use the CRM effectively</p>
      </div>

      <Card className="bg-gradient-to-r from-blue-50 to-purple-50">
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search articles, guides, and tutorials..."
              className="pl-12 h-12 text-lg"
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((category, idx) => {
          const Icon = category.icon;
          return (
            <Card key={idx} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6 text-center">
                <Icon className={`w-12 h-12 mx-auto mb-4 ${category.color}`} />
                <h3 className="font-bold text-lg mb-2">{category.title}</h3>
                <p className="text-gray-500 text-sm">{category.count} articles</p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardContent className="p-12 text-center text-gray-500">
          <BookOpen className="w-16 h-16 mx-auto mb-4 text-gray-300" />
          <h3 className="text-lg font-semibold mb-2">Knowledge Base Coming Soon</h3>
          <p>Guides and tutorials will be added here</p>
        </CardContent>
      </Card>
    </div>
  );
}