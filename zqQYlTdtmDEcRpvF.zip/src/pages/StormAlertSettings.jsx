
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Bell, Plus, X, Save, MapPin, Mail, MessageSquare, Target, Info } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export default function StormAlertSettings() {
  const [user, setUser] = useState(null);
  const [settings, setSettings] = useState({
    service_center_location: '',
    service_radius_miles: 60,
    service_areas: [],
    alert_severity_threshold: 'moderate',
    enable_email_alerts: true,
    enable_sms_alerts: true,
    alert_recipients: [],
    auto_generate_leads: false,
    storm_types_to_monitor: ['hail', 'tornado', 'high_wind', 'thunderstorm', 'general_advisory']
  });
  const [newArea, setNewArea] = useState('');
  const [newRecipient, setNewRecipient] = useState({
    name: '',
    email: '',
    phone: '',
    notify_email: true,
    notify_sms: false
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  const { data: alertSettings = [] } = useQuery({
    queryKey: ['storm-alert-settings', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.StormAlertSettings.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const currentSettings = alertSettings[0];

  useEffect(() => {
    if (currentSettings) {
      setSettings({
        service_center_location: currentSettings.service_center_location || '',
        service_radius_miles: currentSettings.service_radius_miles || 60,
        service_areas: currentSettings.service_areas || [],
        alert_severity_threshold: currentSettings.alert_severity_threshold || 'moderate',
        enable_email_alerts: currentSettings.enable_email_alerts ?? true,
        enable_sms_alerts: currentSettings.enable_sms_alerts ?? true,
        alert_recipients: currentSettings.alert_recipients || [],
        auto_generate_leads: currentSettings.auto_generate_leads ?? false,
        storm_types_to_monitor: currentSettings.storm_types_to_monitor || ['hail', 'tornado', 'high_wind', 'thunderstorm', 'general_advisory']
      });
    }
  }, [currentSettings]);

  const saveSettingsMutation = useMutation({
    mutationFn: (data) => {
      if (currentSettings) {
        return base44.entities.StormAlertSettings.update(currentSettings.id, data);
      } else {
        return base44.entities.StormAlertSettings.create({ ...data, company_id: myCompany.id });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['storm-alert-settings'] });
      alert("Storm alert settings saved successfully!");
    },
  });

  const handleAddArea = () => {
    if (newArea.trim()) {
      setSettings({
        ...settings,
        service_areas: [...settings.service_areas, newArea.trim()]
      });
      setNewArea('');
    }
  };

  const handleRemoveArea = (index) => {
    setSettings({
      ...settings,
      service_areas: settings.service_areas.filter((_, i) => i !== index)
    });
  };

  const handleAddRecipient = () => {
    if (newRecipient.name && (newRecipient.email || newRecipient.phone)) {
      setSettings({
        ...settings,
        alert_recipients: [...settings.alert_recipients, newRecipient]
      });
      setNewRecipient({
        name: '',
        email: '',
        phone: '',
        notify_email: true,
        notify_sms: false
      });
    }
  };

  const handleRemoveRecipient = (index) => {
    setSettings({
      ...settings,
      alert_recipients: settings.alert_recipients.filter((_, i) => i !== index)
    });
  };

  const toggleStormType = (type) => {
    const types = settings.storm_types_to_monitor;
    if (types.includes(type)) {
      setSettings({
        ...settings,
        storm_types_to_monitor: types.filter(t => t !== type)
      });
    } else {
      setSettings({
        ...settings,
        storm_types_to_monitor: [...types, type]
      });
    }
  };

  const handleSave = () => {
    if (!myCompany) {
      alert("Please set up your company profile first!");
      return;
    }
    saveSettingsMutation.mutate(settings);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center">
          <Bell className="w-7 h-7 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Storm Alert Settings</h1>
          <p className="text-gray-500 mt-1">Configure automatic notifications for storms in your service areas</p>
        </div>
      </div>

      <Alert className="bg-blue-50 border-blue-200">
        <AlertDescription>
          <strong>How it works:</strong> Set your service area center and radius. When storms hit within your radius, you'll automatically receive email/SMS alerts with storm details and the option to generate leads instantly.
        </AlertDescription>
      </Alert>

      {/* Service Radius */}
      <Card className="bg-white shadow-md">
        <CardHeader className="border-b bg-gray-50">
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5" />
            Service Area Radius
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Service Center Location</Label>
              <Input
                placeholder="e.g., Cleveland, OH or Northeast Ohio"
                value={settings.service_center_location}
                onChange={(e) => setSettings({...settings, service_center_location: e.target.value})}
              />
              <p className="text-xs text-gray-500 mt-1">Your primary service area center</p>
            </div>
            
            <div>
              <Label>Service Radius (miles)</Label>
              <Input
                type="number"
                placeholder="60"
                value={settings.service_radius_miles}
                onChange={(e) => setSettings({...settings, service_radius_miles: parseInt(e.target.value) || 0})}
              />
              <p className="text-xs text-gray-500 mt-1">How far from center you serve</p>
            </div>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <strong>📍 Your Coverage:</strong> {settings.service_radius_miles || 60} mile radius from {settings.service_center_location || 'your location'}
              {settings.service_center_location === '' && ' (Please set your service center location above)'}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Additional Specific Areas */}
      <Card className="bg-white shadow-md">
        <CardHeader className="border-b bg-gray-50">
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Additional Specific Areas (Optional)
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <p className="text-sm text-gray-600">
            Add specific counties or cities outside your radius that you also want to monitor. Examples: "Cuyahoga County, OH", "Summit County, OH"
          </p>
          
          <div className="flex gap-2">
            <Input
              placeholder="e.g., Cuyahoga County, OH"
              value={newArea}
              onChange={(e) => setNewArea(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleAddArea()}
            />
            <Button onClick={handleAddArea}>
              <Plus className="w-4 h-4 mr-2" />
              Add
            </Button>
          </div>

          <div className="flex flex-wrap gap-2">
            {settings.service_areas.map((area, index) => (
              <Badge key={index} variant="secondary" className="px-3 py-1.5 text-sm">
                {area}
                <button
                  onClick={() => handleRemoveArea(index)}
                  className="ml-2 hover:text-red-600"
                >
                  <X className="w-3 h-3" />
                </button>
              </Badge>
            ))}
          </div>

          {settings.service_areas.length === 0 && (
            <p className="text-sm text-gray-400 italic">No additional areas configured</p>
          )}
        </CardContent>
      </Card>

      {/* Storm Types */}
      <Card className="bg-white shadow-md">
        <CardHeader className="border-b bg-gray-50">
          <CardTitle>Storm Types to Monitor</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {['hail', 'tornado', 'high_wind', 'thunderstorm', 'flood', 'winter_storm', 'tropical', 'general_advisory'].map(type => (
              <div key={type} className="flex items-center gap-3 p-3 border rounded-lg">
                <Switch
                  checked={settings.storm_types_to_monitor.includes(type)}
                  onCheckedChange={() => toggleStormType(type)}
                  id={`storm-type-${type}`}
                />
                <Label className="capitalize cursor-pointer" htmlFor={`storm-type-${type}`}>
                  {type.replace(/_/g, ' ')}
                </Label>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Alert Settings */}
      <Card className="bg-white shadow-md">
        <CardHeader className="border-b bg-gray-50">
          <CardTitle>Alert Settings</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div>
            <Label>Minimum Severity Level</Label>
            <Select
              value={settings.alert_severity_threshold}
              onValueChange={(value) => setSettings({...settings, alert_severity_threshold: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Storms (includes Advisories)</SelectItem>
                <SelectItem value="minor">Minor or Higher</SelectItem>
                <SelectItem value="moderate">Moderate or Higher</SelectItem>
                <SelectItem value="severe">Severe or Higher</SelectItem>
                <SelectItem value="extreme">Extreme Only</SelectItem>
              </SelectContent>
            </Select>
            <Alert variant="default" className="mt-2 text-sm bg-yellow-50 border-yellow-200 text-yellow-800">
              <Info className="h-4 w-4" />
              <AlertTitle>Tip</AlertTitle>
              <AlertDescription>
                To see "Advisories" and "Watches", set severity to "All Storms" or "Minor".
              </AlertDescription>
            </Alert>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Enable Email Alerts</Label>
              <p className="text-sm text-gray-500">Send storm notifications via email</p>
            </div>
            <Switch
              checked={settings.enable_email_alerts}
              onCheckedChange={(checked) => setSettings({...settings, enable_email_alerts: checked})}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Enable SMS Alerts</Label>
              <p className="text-sm text-gray-500">Send storm notifications via text message</p>
            </div>
            <Switch
              checked={settings.enable_sms_alerts}
              onCheckedChange={(checked) => setSettings({...settings, enable_sms_alerts: checked})}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <Label>Auto-Generate Leads</Label>
              <p className="text-sm text-gray-500">Automatically create leads when storms hit your areas</p>
            </div>
            <Switch
              checked={settings.auto_generate_leads}
              onCheckedChange={(checked) => setSettings({...settings, auto_generate_leads: checked})}
            />
          </div>
        </CardContent>
      </Card>

      {/* Alert Recipients */}
      <Card className="bg-white shadow-md">
        <CardHeader className="border-b bg-gray-50">
          <CardTitle>Alert Recipients</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Name</Label>
              <Input
                placeholder="John Doe"
                value={newRecipient.name}
                onChange={(e) => setNewRecipient({...newRecipient, name: e.target.value})}
              />
            </div>

            <div>
              <Label>Email</Label>
              <Input
                type="email"
                placeholder="john@example.com"
                value={newRecipient.email}
                onChange={(e) => setNewRecipient({...newRecipient, email: e.target.value})}
              />
            </div>

            <div>
              <Label>Phone (for SMS)</Label>
              <Input
                placeholder="+1 (555) 123-4567"
                value={newRecipient.phone}
                onChange={(e) => setNewRecipient({...newRecipient, phone: e.target.value})}
              />
            </div>

            <div className="flex items-end gap-2">
              <div className="flex items-center gap-2">
                <Switch
                  checked={newRecipient.notify_email}
                  onCheckedChange={(checked) => setNewRecipient({...newRecipient, notify_email: checked})}
                />
                <Label>Email</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  checked={newRecipient.notify_sms}
                  onCheckedChange={(checked) => setNewRecipient({...newRecipient, notify_sms: checked})}
                />
                <Label>SMS</Label>
              </div>
            </div>
          </div>

          <Button onClick={handleAddRecipient} className="w-full">
            <Plus className="w-4 h-4 mr-2" />
            Add Recipient
          </Button>

          <div className="space-y-2">
            {settings.alert_recipients.map((recipient, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg bg-gray-50">
                <div>
                  <p className="font-medium">{recipient.name}</p>
                  <div className="flex gap-3 text-sm text-gray-600">
                    {recipient.email && (
                      <span className="flex items-center gap-1">
                        <Mail className="w-3 h-3" />
                        {recipient.email}
                      </span>
                    )}
                    {recipient.phone && (
                      <span className="flex items-center gap-1">
                        <MessageSquare className="w-3 h-3" />
                        {recipient.phone}
                      </span>
                    )}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleRemoveRecipient(index)}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>

          {settings.alert_recipients.length === 0 && (
            <p className="text-sm text-gray-400 italic">No recipients configured yet</p>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          className="bg-blue-600 hover:bg-blue-700"
          disabled={saveSettingsMutation.isLoading}
        >
          <Save className="w-4 h-4 mr-2" />
          {saveSettingsMutation.isLoading ? "Saving..." : "Save Alert Settings"}
        </Button>
      </div>
    </div>
  );
}
