
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Send, Eye, X } from "lucide-react";
import { useNavigate } from "react-router-dom";
import SignaturePad from "../components/SignaturePad";

export default function SignContractRep() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [sessionId, setSessionId] = useState(null);
  const [formValues, setFormValues] = useState({});
  const [signatureData, setSignatureData] = useState(null);
  const [showPdfPreview, setShowPdfPreview] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    
    const params = new URLSearchParams(window.location.search);
    setSessionId(params.get('sessionId'));
  }, []);

  const { data: session } = useQuery({
    queryKey: ['signing-session', sessionId],
    queryFn: () => base44.entities.ContractSigningSession.get(sessionId),
    enabled: !!sessionId,
  });

  const { data: template } = useQuery({
    queryKey: ['contract-template', session?.template_id],
    queryFn: () => base44.entities.ContractTemplate.get(session.template_id),
    enabled: !!session?.template_id,
  });

  const saveRepFieldsMutation = useMutation({
    mutationFn: async ({ fields, signature }) => {
      return await base44.entities.ContractSigningSession.update(sessionId, {
        rep_fields: fields,
        rep_signature_url: signature,
        rep_signed_at: new Date().toISOString(),
        status: 'rep_signed',
        current_signer: 'customer'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['signing-session'] });
    },
  });

  const sendToCustomerMutation = useMutation({
    mutationFn: async () => {
      return await base44.functions.invoke('sendContractSigningLink', {
        sessionId: sessionId
      });
    },
    onSuccess: () => {
      alert('✅ Contract sent to customer!\n' + 
        (session?.delivery_method === 'sms' ? '📱 ' + session?.customer_phone : '📧 ' + session?.customer_email));
      navigate('/ContractTemplates'); // FIXED: correct page name
    },
  });

  useEffect(() => {
    if (template?.fillable_fields && user) {
      const repFields = template.fillable_fields.filter(f => f.filled_by === 'rep');
      const initialValues = {};
      repFields.forEach(field => {
        if (field.field_type === 'text' && field.field_name.toLowerCase().includes('rep_name')) {
          initialValues[field.field_name] = user?.full_name || '';
        } else if (field.field_type === 'email' && field.field_name.toLowerCase().includes('rep_email')) {
          initialValues[field.field_name] = user?.email || '';
        } else if (field.field_type === 'date') {
          initialValues[field.field_name] = new Date().toISOString().split('T')[0];
        }
      });
      setFormValues(initialValues);
    }
  }, [template, user]);

  const handleSignAndSend = async () => {
    console.log('🔍 Signature data:', signatureData ? 'EXISTS' : 'MISSING');
    
    if (!signatureData) {
      alert('❌ Please sign the document first');
      return;
    }

    // Validate required fields
    const repFields = template.fillable_fields.filter(f => f.filled_by === 'rep' && f.field_type !== 'signature');
    const missingRequired = repFields.filter(f => f.required && !formValues[f.field_name]);
    
    if (missingRequired.length > 0) {
      alert(`❌ Please fill in required fields: ${missingRequired.map(f => f.field_label).join(', ')}`);
      return;
    }

    console.log('💾 Saving rep fields and signature...');

    try {
      await saveRepFieldsMutation.mutateAsync({
        fields: formValues,
        signature: signatureData
      });

      console.log('✅ Rep fields saved, sending to customer...');

      await sendToCustomerMutation.mutateAsync();
    } catch (error) {
      console.error('❌ Error:', error);
      alert('❌ Error: ' + error.message);
    }
  };

  if (!session || !template) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  const repFields = template.fillable_fields?.filter(f => f.filled_by === 'rep') || [];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Sign Contract</h1>
        <p className="text-gray-500 mt-1">{template.template_name}</p>
        <Badge className="mt-2 bg-blue-100 text-blue-700">
          Step 1: Your Signature
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form Side */}
        <Card>
          <CardHeader>
            <CardTitle>Fill Your Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="bg-blue-50 border-blue-200">
              <AlertDescription>
                <strong>Customer:</strong> {session.customer_name}
                <br />
                {session.delivery_method === 'email' && <>📧 {session.customer_email}</>}
                {session.delivery_method === 'sms' && <>📱 {session.customer_phone}</>}
              </AlertDescription>
            </Alert>

            {repFields.map((field) => {
              if (field.field_type === 'signature') return null;

              return (
                <div key={field.field_name}>
                  <Label htmlFor={field.field_name}>
                    {field.field_label}
                    {field.required && <span className="text-red-500"> *</span>}
                  </Label>
                  {field.field_type === 'date' ? (
                    <Input
                      id={field.field_name}
                      type="date"
                      value={formValues[field.field_name] || ''}
                      onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                      required={field.required}
                    />
                  ) : field.field_type === 'email' ? (
                    <Input
                      id={field.field_name}
                      type="email"
                      value={formValues[field.field_name] || ''}
                      onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                      placeholder={field.placeholder}
                      required={field.required}
                    />
                  ) : field.field_type === 'phone' ? (
                    <Input
                      id={field.field_name}
                      type="tel"
                      value={formValues[field.field_name] || ''}
                      onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                      placeholder={field.placeholder || "(XXX) XXX-XXXX"}
                      required={field.required}
                    />
                  ) : (
                    <Input
                      id={field.field_name}
                      type="text"
                      value={formValues[field.field_name] || ''}
                      onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                      placeholder={field.placeholder}
                      required={field.required}
                    />
                  )}
                </div>
              );
            })}

            {/* SIGNATURE PAD */}
            <div className="border-t pt-4 mt-4">
              <Label className="text-lg font-bold text-gray-900 block mb-2">
                Your Signature *
              </Label>
              <p className="text-sm text-gray-600 mb-3">
                Draw your signature using your mouse or finger
              </p>
              <SignaturePad onSignatureChange={(data) => {
                console.log('📝 Signature changed:', data ? 'CAPTURED' : 'CLEARED');
                setSignatureData(data);
              }} />
              
              {/* Debug info */}
              {signatureData && (
                <div className="mt-2 p-2 bg-green-50 border border-green-200 rounded text-sm text-green-700">
                  ✅ Signature ready to send
                </div>
              )}
            </div>

            <Button
              onClick={handleSignAndSend}
              disabled={saveRepFieldsMutation.isLoading || sendToCustomerMutation.isLoading || !signatureData}
              className="w-full bg-blue-600 hover:bg-blue-700 text-lg py-6"
            >
              {(saveRepFieldsMutation.isLoading || sendToCustomerMutation.isLoading) ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-5 h-5 mr-2" />
                  Sign & Send to Customer
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* PDF Preview Side */}
        <div className="sticky top-6">
          <Card className="h-[800px]">
            <CardHeader className="border-b bg-gray-50">
              <div className="flex items-center justify-between">
                <CardTitle>Contract Preview</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowPdfPreview(true)}
                  className="text-blue-600 hover:text-blue-700"
                >
                  <Eye className="w-4 h-4 mr-1" />
                  Full Screen
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0 h-[720px]">
              <iframe
                src={`https://docs.google.com/viewer?url=${encodeURIComponent(template.original_file_url)}&embedded=true`}
                className="w-full h-full border-0"
                title="Contract Preview"
                aria-label="Contract Preview"
              />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Full Screen PDF Preview */}
      {showPdfPreview && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg w-full max-w-6xl h-[95vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b bg-gray-50">
              <h2 className="text-xl font-bold">Contract Preview</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowPdfPreview(false)}
              >
                <X className="w-5 h-5" />
                <span className="sr-only">Close full screen preview</span>
              </Button>
            </div>
            <div className="flex-1 overflow-hidden">
              <iframe
                src={`https://docs.google.com/viewer?url=${encodeURIComponent(template.original_file_url)}&embedded=true`}
                className="w-full h-full border-0"
                title="Contract Full Preview"
                aria-label="Contract Full Screen Preview"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
