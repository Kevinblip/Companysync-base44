
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { Download, ChevronDown, ChevronRight, AlertCircle, Search, FileSpreadsheet, FileText, Share2, TrendingUp } from "lucide-react";
import { format, eachMonthOfInterval, startOfYear, endOfYear, subYears } from "date-fns";

export default function Reports() {
  const [selectedCategory, setSelectedCategory] = useState('sales');
  const [selectedReport, setSelectedReport] = useState('invoices');
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());
  const [compareYear, setCompareYear] = useState((new Date().getFullYear() - 1).toString());
  const [showComparison, setShowComparison] = useState(false);
  const [statusFilter, setStatusFilter] = useState('all');
  const [saleAgentFilter, setSaleAgentFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [itemsPerPage, setItemsPerPage] = useState('25');
  const [currentPage, setCurrentPage] = useState(1); // Fixed syntax error here
  const [excludeBillable, setExcludeBillable] = useState(false);

  // Fetch data
  const { data: invoices = [] } = useQuery({
    queryKey: ['invoices'],
    queryFn: () => base44.entities.Invoice.list("-created_date", 10000),
    initialData: [],
  });

  const { data: estimates = [] } = useQuery({
    queryKey: ['estimates'],
    queryFn: () => base44.entities.Estimate.list("-created_date", 10000),
    initialData: [],
  });

  const { data: proposals = [] } = useQuery({
    queryKey: ['proposals'],
    queryFn: () => base44.entities.Proposal.list("-created_date", 10000),
    initialData: [],
  });

  const { data: payments = [] } = useQuery({
    queryKey: ['payments'],
    queryFn: () => base44.entities.Payment.list("-payment_date", 10000),
    initialData: [],
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list("-created_date", 10000),
    initialData: [],
  });

  const { data: items = [] } = useQuery({
    queryKey: ['items'],
    queryFn: () => base44.entities.Item.list("-created_date", 10000),
    initialData: [],
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list("-created_date", 10000),
    initialData: [],
  });

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    initialData: [],
  });

  // Filter active invoices (exclude cancelled)
  const activeInvoices = invoices.filter(inv => inv.status !== 'cancelled');
  const activeEstimates = estimates.filter(est => est.status !== 'declined');

  // Report categories
  const reportCategories = {
    sales: {
      label: 'Sales',
      reports: [
        { id: 'invoices', label: 'Invoices Report' },
        { id: 'items', label: 'Items Report' },
        { id: 'payments', label: 'Payments Received' },
        { id: 'credit_notes', label: 'Credit Notes Report' },
        { id: 'proposals', label: 'Proposals Report' },
        { id: 'estimates', label: 'Estimates Report' },
        { id: 'customers', label: 'Customers Report' },
      ]
    },
    charts: {
      label: 'Charts Based Report',
      reports: [
        { id: 'total_income', label: 'Total Income' },
        { id: 'payment_modes', label: 'Payment Modes (Transactions)' },
        { id: 'customer_groups', label: 'Total Value By Customer Groups' },
        { id: 'yoy_comparison', label: 'Year-over-Year Comparison' },
        { id: 'mom_comparison', label: 'Month-over-Month Comparison' },
      ]
    },
    expenses: {
      label: 'Expenses',
      reports: [
        { id: 'expenses_overview', label: 'Expenses Overview' },
      ]
    },
    expenses_vs_income: {
      label: 'Expenses vs Income',
      reports: [
        { id: 'income_expense_comparison', label: 'Income vs Expenses' },
      ]
    },
    leads: {
      label: 'Leads',
      reports: [
        { id: 'leads_overview', label: 'Leads Overview' },
        { id: 'leads_conversions', label: 'Leads Conversions' },
        { id: 'sources_conversion', label: 'Sources Conversion' },
      ]
    },
  };

  // Year-over-Year Comparison Data
  const getYoYComparisonData = () => {
    const currentYear = parseInt(selectedYear);
    const previousYear = parseInt(compareYear);

    const months = eachMonthOfInterval({
      start: startOfYear(new Date(currentYear, 0, 1)),
      end: endOfYear(new Date(currentYear, 11, 31))
    });

    return months.map(month => {
      const currentYearPayments = payments.filter(p => {
        if (!p.payment_date) return false;
        const paymentDate = new Date(p.payment_date);
        return paymentDate.getFullYear() === currentYear && 
               paymentDate.getMonth() === month.getMonth() &&
               p.status === 'received';
      });

      const previousYearPayments = payments.filter(p => {
        if (!p.payment_date) return false;
        const paymentDate = new Date(p.payment_date);
        return paymentDate.getFullYear() === previousYear && 
               paymentDate.getMonth() === month.getMonth() &&
               p.status === 'received';
      });

      const currentRevenue = currentYearPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
      const previousRevenue = previousYearPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
      const growth = previousRevenue > 0 ? ((currentRevenue - previousRevenue) / previousRevenue * 100).toFixed(1) : 0;

      return {
        month: format(month, 'MMM'),
        [currentYear]: currentRevenue,
        [previousYear]: previousRevenue,
        growth: parseFloat(growth)
      };
    });
  };

  // Month-over-Month Comparison Data
  const getMoMComparisonData = () => {
    const year = parseInt(selectedYear);
    const months = eachMonthOfInterval({
      start: startOfYear(new Date(year, 0, 1)),
      end: endOfYear(new Date(year, 11, 31))
    });

    return months.map((month, index) => {
      const currentMonthPayments = payments.filter(p => {
        if (!p.payment_date) return false;
        const paymentDate = new Date(p.payment_date);
        return paymentDate.getFullYear() === year && 
               paymentDate.getMonth() === month.getMonth() &&
               p.status === 'received';
      });

      const previousMonth = index > 0 ? months[index - 1] : null;
      const previousMonthPayments = previousMonth ? payments.filter(p => {
        if (!p.payment_date) return false;
        const paymentDate = new Date(p.payment_date);
        return paymentDate.getFullYear() === year && 
               paymentDate.getMonth() === previousMonth.getMonth() &&
               p.status === 'received';
      }) : [];

      const currentRevenue = currentMonthPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
      const previousRevenue = previousMonthPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
      const growth = previousRevenue > 0 ? ((currentRevenue - previousRevenue) / previousRevenue * 100).toFixed(1) : 0;

      return {
        month: format(month, 'MMM yyyy'),
        revenue: currentRevenue,
        previousMonth: previousRevenue,
        growth: parseFloat(growth)
      };
    });
  };

  // Chart data functions
  const getMonthlyIncomeData = () => {
    const year = parseInt(selectedYear);
    const months = eachMonthOfInterval({
      start: startOfYear(new Date(year, 0, 1)),
      end: endOfYear(new Date(year, 11, 31))
    });

    return months.map(month => {
      const monthPayments = payments.filter(p => {
        if (!p.payment_date) return false;
        const paymentDate = new Date(p.payment_date);
        return paymentDate.getFullYear() === year && 
               paymentDate.getMonth() === month.getMonth() &&
               p.status === 'received';
      });

      return {
        month: format(month, 'MMMM - yyyy'),
        income: monthPayments.reduce((sum, p) => sum + (p.amount || 0), 0)
      };
    });
  };

  const getPaymentModesData = () => {
    const year = parseInt(selectedYear);
    const months = eachMonthOfInterval({
      start: startOfYear(new Date(year, 0, 1)),
      end: endOfYear(new Date(year, 11, 31))
    });

    return months.map(month => {
      const monthPayments = payments.filter(p => {
        if (!p.payment_date) return false;
        const paymentDate = new Date(p.payment_date);
        return paymentDate.getFullYear() === year && 
               paymentDate.getMonth() === month.getMonth() &&
               p.status === 'received';
      });

      const result = { month: format(month, 'MMM yyyy') };
      monthPayments.forEach(p => {
        const mode = p.payment_method || 'other';
        result[mode] = (result[mode] || 0) + (p.amount || 0);
      });
      
      return result;
    });
  };

  const getCustomerGroupsData = () => {
    const customerRevenue = {};
    
    customers.forEach(customer => {
      const customerPayments = payments.filter(p => 
        p.customer_name === customer.name && p.status === 'received'
      );
      const total = customerPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
      
      if (total > 0) {
        customerRevenue[customer.name] = total;
      }
    });

    return Object.keys(customerRevenue).map(name => ({
      customer: name,
      value: customerRevenue[name]
    }));
  };

  const getLeadsConversionData = () => {
    const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    return daysOfWeek.map(day => ({
      day,
      conversions: Math.floor(Math.random() * 10) // Replace with real data
    }));
  };

  const getSourcesConversionData = () => {
    const sources = ['Advertising', 'Anvyl List', 'CRM', 'Google', 'External Lead Provider', 'Website', 'Referral', 'Incoming Voicemail', 'Incoming SMS', 'other'];
    return sources.map(source => ({
      source,
      count: leads.filter(l => l.source === source).length
    }));
  };

  const getExpensesData = () => {
    // Mock expenses by category for now
    const categories = [
      'Accounting', 'Advertising', 'Automobile', 'Bank Charges', 'Banner',
      'Bookkeeper', 'Building Repairs', 'car repair', 'Commission',
      'Commission : Your Insurance Claim Network', 'Commissions & fees',
      'Computer Repairs', 'Cost of Labor'
    ];
    
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 
                    'July', 'August', 'September', 'October', 'November', 'December'];
    
    return categories.map(category => {
      const row = { category };
      months.forEach(month => {
        row[month] = 0; // Replace with real expense data
      });
      row['Year (2025)'] = 0;
      return row;
    });
  };

  const getIncomeExpenseComparisonData = () => {
    const year = parseInt(selectedYear);
    const months = eachMonthOfInterval({
      start: startOfYear(new Date(year, 0, 1)),
      end: endOfYear(new Date(year, 11, 31))
    });

    return months.map(month => {
      const monthPayments = payments.filter(p => {
        if (!p.payment_date) return false;
        const paymentDate = new Date(p.payment_date);
        return paymentDate.getFullYear() === year && 
               paymentDate.getMonth() === month.getMonth() &&
               p.status === 'received';
      });

      const income = monthPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
      
      return {
        month: format(month, 'MMM yyyy'),
        income: income,
        expenses: income * 0.3 // Mock: 30% of income as expenses
      };
    });
  };

  // Export to Excel with formulas
  const exportToExcel = () => {
    const data = getReportData();
    const columns = getReportColumns();

    let csv = columns.map(col => col.label).join(',') + '\n';
    
    data.forEach((row, index) => {
      csv += columns.map(col => {
        let value = row[col.key];
        if (col.format) {
          value = col.format(value);
        }
        return `"${value || ''}"`;
      }).join(',') + '\n';
    });

    // Add totals row with Excel formulas
    if (selectedReport === 'invoices' || selectedReport === 'payments') {
      const totalRowIndex = data.length + 2;
      const amountColLetter = 'E'; // Adjust based on actual column
      csv += `"TOTAL",,,,"=SUM(${amountColLetter}2:${amountColLetter}${totalRowIndex - 1})"\n`;
    }

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedReport}_${selectedYear}.csv`;
    a.click();
  };

  // Export to PDF with charts
  const exportToPDF = async () => {
    alert('📄 Generating PDF with charts...');
    
    try {
      const response = await base44.functions.invoke('generateReportPDF', {
        reportType: selectedReport,
        reportData: getReportData(),
        reportName: reportCategories[selectedCategory].reports.find(r => r.id === selectedReport)?.label || 'Report',
        year: selectedYear
      });

      if (response.data) {
        const blob = new Blob([response.data], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${selectedReport}_${selectedYear}.pdf`;
        a.click();
      }
    } catch (error) {
      console.error('PDF generation error:', error);
      alert('❌ Error generating PDF: ' + error.message);
    }
  };

  // Sync to Google Sheets
  const syncToGoogleSheets = async () => {
    alert('📊 Syncing to Google Sheets...\n\nThis will:\n1. Create a new Google Sheet\n2. Export your data\n3. Auto-update daily\n\n(Feature coming soon!)');
    
    // TODO: Implement Google Sheets API integration
    // const data = getReportData();
    // const response = await base44.functions.invoke('syncToGoogleSheets', {
    //   reportType: selectedReport,
    //   data: data,
    //   sheetName: `${selectedReport}_${selectedYear}`
    // });
  };

  const getReportData = () => {
    switch(selectedReport) {
      case 'invoices':
        return getInvoicesReportData();
      case 'payments':
        return getPaymentsReportData();
      case 'items':
        return getItemsReportData();
      case 'estimates':
        return getEstimatesReportData();
      case 'proposals':
        return getProposalsReportData();
      case 'customers':
        return getCustomersReportData();
      default:
        return [];
    }
  };

  const getReportColumns = () => {
    switch(selectedReport) {
      case 'invoices':
        return [
          { key: 'invoice_number', label: 'Invoice #' },
          { key: 'customer_name', label: 'Customer' },
          { key: 'created_date', label: 'Date', format: (val) => val ? format(new Date(val), 'yyyy-MM-dd') : '-' },
          { key: 'due_date', label: 'Due Date', format: (val) => val ? format(new Date(val), 'yyyy-MM-dd') : '-' },
          { key: 'amount', label: 'Amount', format: (val) => `$${(val || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}` },
          { key: 'status', label: 'Status' }
        ];
      case 'payments':
        return [
          { key: 'payment_number', label: 'Payment #' },
          { key: 'payment_date', label: 'Date', format: (val) => val ? format(new Date(val), 'yyyy-MM-dd') : '-' },
          { key: 'invoice_number', label: 'Invoice #' },
          { key: 'customer_name', label: 'Customer' },
          { key: 'amount', label: 'Amount', format: (val) => `$${(val || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}` },
          { key: 'payment_method', label: 'Payment Mode' },
          { key: 'reference_number', label: 'Transaction ID' },
          { key: 'notes', label: 'Note' }
        ];
      default:
        return [];
    }
  };

  // Table data functions
  const getInvoicesReportData = () => {
    let filtered = activeInvoices;
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(inv => inv.status === statusFilter);
    }
    
    if (searchTerm) {
      filtered = filtered.filter(inv => 
        inv.invoice_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        inv.customer_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return filtered;
  };

  const getPaymentsReportData = () => {
    let filtered = payments.filter(p => p.status === 'received');
    
    if (searchTerm) {
      filtered = filtered.filter(p => 
        p.payment_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.customer_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return filtered;
  };

  const getItemsReportData = () => {
    const itemsSold = {};
    
    activeInvoices.filter(inv => inv.status === 'paid').forEach(invoice => {
      invoice.items?.forEach(item => {
        if (!itemsSold[item.description]) {
          itemsSold[item.description] = {
            name: item.description,
            quantity: 0,
            totalAmount: 0,
            count: 0
          };
        }
        
        itemsSold[item.description].quantity += item.quantity || 0;
        itemsSold[item.description].totalAmount += item.amount || 0;
        itemsSold[item.description].count += 1;
      });
    });

    return Object.values(itemsSold).map(item => ({
      ...item,
      averagePrice: item.count > 0 ? item.totalAmount / item.quantity : 0
    }));
  };

  const getEstimatesReportData = () => {
    let filtered = activeEstimates;
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(est => est.status === statusFilter);
    }
    
    if (searchTerm) {
      filtered = filtered.filter(est => 
        est.estimate_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        est.customer_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return filtered;
  };

  const getProposalsReportData = () => {
    let filtered = proposals;
    
    if (statusFilter !== 'all') {
      filtered = filtered.filter(prop => prop.status === statusFilter);
    }
    
    if (searchTerm) {
      filtered = filtered.filter(prop => 
        prop.proposal_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        prop.customer_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return filtered;
  };

  const getCustomersReportData = () => {
    return customers.map(customer => {
      const customerPayments = payments.filter(p => 
        p.customer_name === customer.name && p.status === 'received'
      );
      const totalRevenue = customerPayments.reduce((sum, p) => sum + (p.amount || 0), 0);
      const customerInvoices = activeInvoices.filter(inv => inv.customer_name === customer.name);
      
      return {
        ...customer,
        totalRevenue,
        invoiceCount: customerInvoices.length
      };
    });
  };

  const handleExport = () => {
    exportToExcel();
  };

  const renderReportContent = () => {
    // Year-over-Year Comparison
    if (selectedReport === 'yoy_comparison') {
      const data = getYoYComparisonData();
      const currentYearTotal = data.reduce((sum, d) => sum + (d[selectedYear] || 0), 0);
      const previousYearTotal = data.reduce((sum, d) => sum + (d[compareYear] || 0), 0);
      const overallGrowth = previousYearTotal > 0 ? ((currentYearTotal - previousYearTotal) / previousYearTotal * 100).toFixed(1) : 0;

      return (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="text-sm text-gray-600 mb-1">{selectedYear} Total</div>
                <div className="text-2xl font-bold text-blue-600">${currentYearTotal.toLocaleString()}</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-sm text-gray-600 mb-1">{compareYear} Total</div>
                <div className="text-2xl font-bold text-gray-600">${previousYearTotal.toLocaleString()}</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-sm text-gray-600 mb-1">Growth</div>
                <div className={`text-2xl font-bold flex items-center gap-2 ${overallGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  <TrendingUp className="w-5 h-5" />
                  {overallGrowth}%
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Year-over-Year Revenue Comparison</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={exportToPDF}>
                    <FileText className="w-4 h-4 mr-2" />
                    PDF
                  </Button>
                  <Button variant="outline" size="sm" onClick={exportToExcel}>
                    <FileSpreadsheet className="w-4 h-4 mr-2" />
                    Excel
                  </Button>
                  <Button variant="outline" size="sm" onClick={syncToGoogleSheets}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Google Sheets
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                  <Legend />
                  <Bar dataKey={selectedYear} fill="#3b82f6" name={`${selectedYear} Revenue`} />
                  <Bar dataKey={compareYear} fill="#94a3b8" name={`${compareYear} Revenue`} />
                </BarChart>
              </ResponsiveContainer>

              <div className="mt-6">
                <h4 className="font-semibold mb-3">Monthly Growth Rates</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {data.map((month) => (
                    <div key={month.month} className="bg-gray-50 p-3 rounded">
                      <div className="text-sm text-gray-600">{month.month}</div>
                      <div className={`text-lg font-bold ${month.growth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {month.growth}%
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    // Month-over-Month Comparison
    if (selectedReport === 'mom_comparison') {
      const data = getMoMComparisonData();
      const avgGrowth = (data.reduce((sum, d) => sum + d.growth, 0) / data.length).toFixed(1);
      const bestMonth = data.reduce((max, d) => d.revenue > max.revenue ? d : max, data[0]);
      const worstMonth = data.reduce((min, d) => d.revenue < min.revenue ? d : min, data[0]);

      return (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-6">
                <div className="text-sm text-gray-600 mb-1">Avg Growth</div>
                <div className={`text-2xl font-bold ${avgGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {avgGrowth}%
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-sm text-gray-600 mb-1">Best Month</div>
                <div className="text-2xl font-bold text-blue-600">{bestMonth.month}</div>
                <div className="text-sm text-gray-500">${bestMonth.revenue.toLocaleString()}</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="text-sm text-gray-600 mb-1">Lowest Month</div>
                <div className="text-2xl font-bold text-gray-600">{worstMonth.month}</div>
                <div className="text-sm text-gray-500">${worstMonth.revenue.toLocaleString()}</div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Month-over-Month Revenue Trend</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={exportToPDF}>
                    <FileText className="w-4 h-4 mr-2" />
                    PDF
                  </Button>
                  <Button variant="outline" size="sm" onClick={exportToExcel}>
                    <FileSpreadsheet className="w-4 h-4 mr-2" />
                    Excel
                  </Button>
                  <Button variant="outline" size="sm" onClick={syncToGoogleSheets}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Google Sheets
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                  <Legend />
                  <Line type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={2} name="Revenue" />
                  <Line type="monotone" dataKey="previousMonth" stroke="#94a3b8" strokeDasharray="5 5" name="Previous Month" />
                </LineChart>
              </ResponsiveContainer>

              <div className="mt-6">
                <h4 className="font-semibold mb-3">Monthly Growth Analysis</h4>
                <div className="space-y-2">
                  {data.map((month, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <span className="font-medium">{month.month}</span>
                      <div className="flex items-center gap-4">
                        <span className="text-gray-600">${month.revenue.toLocaleString()}</span>
                        <Badge variant="outline" className={month.growth >= 0 ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}>
                          {month.growth >= 0 ? '+' : ''}{month.growth}%
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    // Chart reports
    if (selectedReport === 'total_income') {
      return (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
            <AlertCircle className="w-5 h-5" />
            <span className="text-sm">Cancelled invoices are excluded from the report</span>
          </div>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Total Income - {selectedYear}</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={exportToPDF}>
                    <FileText className="w-4 h-4 mr-2" />
                    PDF
                  </Button>
                  <Button variant="outline" size="sm" onClick={exportToExcel}>
                    <FileSpreadsheet className="w-4 h-4 mr-2" />
                    Excel
                  </Button>
                  <Button variant="outline" size="sm" onClick={syncToGoogleSheets}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Google Sheets
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={getMonthlyIncomeData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" angle={-45} textAnchor="end" height={100} />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                  <Bar dataKey="income" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (selectedReport === 'payment_modes') {
      const paymentModes = ['bank', 'check', 'credit_card', 'cash', 'paypal', 'stripe'];
      const colors = ['#06b6d4', '#0ea5e9', '#ec4899', '#6b7280', '#8b5cf6', '#ef4444', '#06b6d4', '#84cc16'];
      
      return (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
            <AlertCircle className="w-5 h-5" />
            <span className="text-sm">Cancelled invoices are excluded from the report</span>
          </div>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Payment Modes Distribution - {selectedYear}</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={exportToPDF}>
                    <FileText className="w-4 h-4 mr-2" />
                    PDF
                  </Button>
                  <Button variant="outline" size="sm" onClick={syncToGoogleSheets}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Google Sheets
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={getPaymentModesData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                  <Legend />
                  {paymentModes.map((mode, index) => (
                    <Bar key={mode} dataKey={mode} fill={colors[index]} />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (selectedReport === 'customer_groups') {
      return (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
            <AlertCircle className="w-5 h-5" />
            <span className="text-sm">Cancelled invoices are excluded from the report</span>
          </div>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Revenue by Customer</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={exportToPDF}>
                    <FileText className="w-4 h-4 mr-2" />
                    PDF
                  </Button>
                  <Button variant="outline" size="sm" onClick={syncToGoogleSheets}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Google Sheets
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={getCustomerGroupsData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="customer" angle={-45} textAnchor="end" height={120} />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                  <Line type="monotone" dataKey="value" stroke="#a855f7" fill="#a855f7" fillOpacity={0.3} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (selectedReport === 'expenses_overview') {
      const expensesData = getExpensesData();
      const months = ['January', 'February', 'March', 'April', 'May', 'June', 
                      'July', 'August', 'September', 'October', 'November', 'December'];
      
      return (
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <Checkbox 
              id="exclude-billable" 
              checked={excludeBillable}
              onCheckedChange={setExcludeBillable}
            />
            <Label htmlFor="exclude-billable" className="text-sm cursor-pointer">
              Exclude Billable Expenses
            </Label>
          </div>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Expenses Overview - {selectedYear}</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={exportToExcel}>
                    <FileSpreadsheet className="w-4 h-4 mr-2" />
                    Excel
                  </Button>
                  <Button variant="outline" size="sm" onClick={syncToGoogleSheets}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Google Sheets
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full border">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="border px-4 py-2 text-left text-sm font-semibold">Category</th>
                      {months.map(month => (
                        <th key={month} className="border px-4 py-2 text-left text-sm font-semibold">{month}</th>
                      ))}
                      <th className="border px-4 py-2 text-left text-sm font-semibold">Year ({selectedYear})</th>
                    </tr>
                  </thead>
                  <tbody>
                    {expensesData.map((row, idx) => (
                      <tr key={idx} className="hover:bg-gray-50">
                        <td className="border px-4 py-2 text-sm">{row.category}</td>
                        {months.map(month => (
                          <td key={month} className="border px-4 py-2 text-sm">${row[month].toFixed(2)}</td>
                        ))}
                        <td className="border px-4 py-2 text-sm font-semibold">${row[`Year (${selectedYear})`].toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (selectedReport === 'income_expense_comparison') {
      return (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
            <AlertCircle className="w-5 h-5" />
            <span className="text-sm">Amount is displayed in your base currency - Only use this report if you are using 1 currency for payments and expenses.</span>
          </div>
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Income vs Expenses - {selectedYear}</CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={exportToPDF}>
                    <FileText className="w-4 h-4 mr-2" />
                    PDF
                  </Button>
                  <Button variant="outline" size="sm" onClick={syncToGoogleSheets}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Google Sheets
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={getIncomeExpenseComparisonData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                  <Legend />
                  <Bar dataKey="income" fill="#10b981" name="Total Income" />
                  <Bar dataKey="expenses" fill="#ef4444" name="Expenses" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (selectedReport === 'leads_conversions') {
      return (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>This Week Leads Conversions</CardTitle>
                <Button variant="outline" size="sm" onClick={syncToGoogleSheets}>
                  <Share2 className="w-4 h-4 mr-2" />
                  Google Sheets
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={getLeadsConversionData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="conversions" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (selectedReport === 'sources_conversion') {
      return (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Sources Conversion</CardTitle>
                <Button variant="outline" size="sm" onClick={syncToGoogleSheets}>
                  <Share2 className="w-4 h-4 mr-2" />
                  Google Sheets
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={getSourcesConversionData()}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="source" angle={-45} textAnchor="end" height={120} />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      );
    }

    if (selectedReport === 'leads_overview') {
      return (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">This Week Leads Conversions</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={getLeadsConversionData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="conversions" fill="#3b82f6" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold mb-4">Sources Conversion</h3>
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart data={getSourcesConversionData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="source" angle={-45} textAnchor="end" height={100} />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="count" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </div>
      );
    }

    // Table reports
    const renderTable = () => {
      let data = [];
      let columns = [];
      let totals = {};

      switch(selectedReport) {
        case 'invoices':
          data = getInvoicesReportData();
          columns = [
            { key: 'invoice_number', label: 'Invoice #' },
            { key: 'customer_name', label: 'Customer' },
            { key: 'created_date', label: 'Date', format: (val) => val ? format(new Date(val), 'yyyy-MM-dd') : '-' },
            { key: 'due_date', label: 'Due Date', format: (val) => val ? format(new Date(val), 'yyyy-MM-dd') : '-' },
            { key: 'amount', label: 'Amount', format: (val) => `$${(val || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}` },
            { key: 'status', label: 'Status' }
          ];
          totals = { amount: data.reduce((sum, item) => sum + (item.amount || 0), 0) };
          break;

        case 'payments':
          data = getPaymentsReportData();
          columns = [
            { key: 'payment_number', label: 'Payment #' },
            { key: 'payment_date', label: 'Date', format: (val) => val ? format(new Date(val), 'yyyy-MM-dd') : '-' },
            { key: 'invoice_number', label: 'Invoice #' },
            { key: 'customer_name', label: 'Customer' },
            { key: 'amount', label: 'Amount', format: (val) => `$${(val || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}` },
            { key: 'payment_method', label: 'Payment Mode' },
            { key: 'reference_number', label: 'Transaction ID' },
            { key: 'notes', label: 'Note' }
          ];
          totals = { amount: data.reduce((sum, item) => sum + (item.amount || 0), 0) };
          break;

        case 'items':
          data = getItemsReportData();
          columns = [
            { key: 'name', label: 'Item' },
            { key: 'quantity', label: 'Quantity Sold' },
            { key: 'totalAmount', label: 'Total Amount', format: (val) => `$${(val || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}` },
            { key: 'averagePrice', label: 'Average Price', format: (val) => `$${(val || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}` }
          ];
          totals = { 
            quantity: data.reduce((sum, item) => sum + (item.quantity || 0), 0),
            totalAmount: data.reduce((sum, item) => sum + (item.totalAmount || 0), 0)
          };
          break;

        case 'estimates':
          data = getEstimatesReportData();
          columns = [
            { key: 'estimate_number', label: 'Estimate #' },
            { key: 'customer_name', label: 'Customer' },
            { key: 'created_date', label: 'Date', format: (val) => val ? format(new Date(val), 'yyyy-MM-dd') : '-' },
            { key: 'valid_until', label: 'Expiry Date', format: (val) => val ? format(new Date(val), 'yyyy-MM-dd') : '-' },
            { key: 'amount', label: 'Amount', format: (val) => `$${(val || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}` },
            { key: 'status', label: 'Status' }
          ];
          totals = { amount: data.reduce((sum, item) => sum + (item.amount || 0), 0) };
          break;

        case 'proposals':
          data = getProposalsReportData();
          columns = [
            { key: 'proposal_number', label: 'Proposal #' },
            { key: 'customer_name', label: 'Customer' },
            { key: 'title', label: 'Title' },
            { key: 'created_date', label: 'Date', format: (val) => val ? format(new Date(val), 'yyyy-MM-dd') : '-' },
            { key: 'amount', label: 'Amount', format: (val) => `$${(val || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}` },
            { key: 'status', label: 'Status' }
          ];
          totals = { amount: data.reduce((sum, item) => sum + (item.amount || 0), 0) };
          break;

        case 'customers':
          data = getCustomersReportData();
          columns = [
            { key: 'name', label: 'Customer' },
            { key: 'email', label: 'Email' },
            { key: 'phone', label: 'Phone' },
            { key: 'company', label: 'Company' },
            { key: 'invoiceCount', label: 'Invoices' },
            { key: 'totalRevenue', label: 'Total Revenue', format: (val) => `$${(val || 0).toLocaleString('en-US', {minimumFractionDigits: 2})}` }
          ];
          totals = { totalRevenue: data.reduce((sum, item) => sum + (item.totalRevenue || 0), 0) };
          break;

        default:
          return null;
      }

      const perPage = parseInt(itemsPerPage);
      const startIndex = (currentPage - 1) * perPage;
      const endIndex = startIndex + perPage;
      const paginatedData = data.slice(startIndex, endIndex);
      const totalPages = Math.ceil(data.length / perPage);

      return (
        <div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-white border-b">
                <tr>
                  {columns.map((col) => (
                    <th key={col.key} className="text-left p-3 text-sm font-semibold text-gray-700">
                      {col.label}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {paginatedData.map((row, index) => (
                  <tr key={index} className="border-b hover:bg-gray-50">
                    {columns.map((col) => (
                      <td key={col.key} className="p-3 text-sm text-gray-900">
                        {col.format ? col.format(row[col.key]) : (row[col.key] || '-')}
                      </td>
                    ))}
                  </tr>
                ))}
                <tr className="bg-gray-50 font-semibold">
                  <td className="p-3 text-sm" colSpan={columns.findIndex(c => Object.keys(totals).includes(c.key))}>
                    Total (Per Page)
                  </td>
                  {columns.slice(columns.findIndex(c => Object.keys(totals).includes(c.key))).map((col) => (
                    <td key={col.key} className="p-3 text-sm">
                      {totals[col.key] !== undefined 
                        ? (col.format ? col.format(totals[col.key]) : totals[col.key])
                        : ''}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-between mt-4 px-3 text-sm text-gray-600">
            <span>Showing {startIndex + 1} to {Math.min(endIndex, data.length)} of {data.length} entries</span>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                Previous
              </Button>
              <Button variant="outline" size="sm" disabled>
                {currentPage}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                Next
              </Button>
            </div>
          </div>
        </div>
      );
    };

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 text-red-600 bg-red-50 p-3 rounded-lg">
          <AlertCircle className="w-5 h-5" />
          <span className="text-sm">Cancelled invoices are excluded from the report</span>
        </div>

        <Card>
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold mb-4">Generated Report</h3>
            
            {selectedReport === 'items' && (
              <div className="mb-4 text-sm text-blue-600 bg-blue-50 p-3 rounded">
                Items report is generated only from paid invoices before discounts and taxes.
              </div>
            )}

            <div className="flex gap-4 mb-4 flex-wrap">
              {!['items', 'customers', 'expenses_overview', 'income_expense_comparison', 'leads_overview', 'leads_conversions', 'sources_conversion'].includes(selectedReport) && (
                <div>
                  <Label className="text-sm text-gray-600">Status</Label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="sent">Sent</SelectItem>
                      <SelectItem value="paid">Paid</SelectItem>
                      <SelectItem value="overdue">Overdue</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              {(selectedReport === 'invoices' || selectedReport === 'estimates') && (
                <div>
                  <Label className="text-sm text-gray-600">Sale Agent</Label>
                  <Select value={saleAgentFilter} onValueChange={setSaleAgentFilter}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      {users.map(user => (
                        <SelectItem key={user.id} value={user.email}>{user.full_name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div className="flex items-end gap-2">
                <Select value={itemsPerPage} onValueChange={setItemsPerPage}>
                  <SelectTrigger className="w-20">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="25">25</SelectItem>
                    <SelectItem value="50">50</SelectItem>
                    <SelectItem value="100">100</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={exportToExcel}>
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  Excel
                </Button>
                <Button variant="outline" size="sm" onClick={exportToPDF}>
                  <FileText className="w-4 h-4 mr-2" />
                  PDF
                </Button>
                <Button variant="outline" size="sm" onClick={syncToGoogleSheets}>
                  <Share2 className="w-4 h-4 mr-2" />
                  Sheets
                </Button>
                <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                </Button>
              </div>

              <div className="relative ml-auto">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
            </div>

            {renderTable()}
          </CardContent>
        </Card>
      </div>
    );
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-80 bg-white border-r overflow-y-auto">
        <div className="p-4 space-y-2">
          {Object.entries(reportCategories).map(([categoryId, category]) => (
            <Collapsible key={categoryId}>
              <CollapsibleTrigger className="flex items-center justify-between w-full p-3 hover:bg-gray-50 rounded-lg transition-colors text-left">
                <span className="font-semibold text-gray-700">{category.label}</span>
                <ChevronDown className="w-4 h-4 text-gray-500" />
              </CollapsibleTrigger>
              <CollapsibleContent className="mt-1 ml-3 space-y-1">
                {category.reports.map((report) => (
                  <button
                    key={report.id}
                    onClick={() => {
                      setSelectedCategory(categoryId);
                      setSelectedReport(report.id);
                      setCurrentPage(1);
                      setSearchTerm('');
                      setStatusFilter('all');
                    }}
                    className={`w-full text-left px-3 py-2 rounded-lg transition-colors text-sm ${
                      selectedReport === report.id
                        ? 'bg-blue-50 text-blue-700 font-medium'
                        : 'text-gray-600 hover:bg-gray-50'
                    }`}
                  >
                    <ChevronRight className="w-3 h-3 inline mr-2" />
                    {report.label}
                  </button>
                ))}
              </CollapsibleContent>
            </Collapsible>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                {reportCategories[selectedCategory]?.label || 'Reports'}
              </h1>
              <p className="text-gray-500 mt-1">View detailed business reports and analytics</p>
            </div>

            <div className="flex gap-4">
              {(['total_income', 'payment_modes', 'customer_groups', 'income_expense_comparison', 'expenses_overview', 'yoy_comparison', 'mom_comparison'].includes(selectedReport)) && (
                <>
                  <div>
                    <Label className="text-sm text-gray-600">Year</Label>
                    <Select value={selectedYear} onValueChange={setSelectedYear}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[2025, 2024, 2023, 2022].map(year => (
                          <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {selectedReport === 'yoy_comparison' && (
                    <div>
                      <Label className="text-sm text-gray-600">Compare to</Label>
                      <Select value={compareYear} onValueChange={setCompareYear}>
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {[2024, 2023, 2022, 2021].map(year => (
                            <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>

          {renderReportContent()}
        </div>
      </div>
    </div>
  );
}
