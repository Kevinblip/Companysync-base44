import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { Mail, Phone, DollarSign } from "lucide-react";

export default function SalesTracking() {
  const queryClient = useQueryClient();

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list("-created_date"),
    initialData: [],
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Lead.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leads'] });
    },
  });

  const columns = [
    { id: 'new', title: 'New Leads', color: 'bg-blue-100' },
    { id: 'contacted', title: 'Contacted', color: 'bg-yellow-100' },
    { id: 'qualified', title: 'Qualified', color: 'bg-purple-100' },
    { id: 'proposal', title: 'Proposal', color: 'bg-orange-100' },
    { id: 'negotiation', title: 'Negotiation', color: 'bg-pink-100' },
    { id: 'won', title: 'Won', color: 'bg-green-100' },
  ];

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const leadId = result.draggableId;
    const newStatus = result.destination.droppableId;
    const lead = leads.find(l => l.id === leadId);

    if (lead && lead.status !== newStatus) {
      updateMutation.mutate({
        id: leadId,
        data: { ...lead, status: newStatus }
      });
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Sales Pipeline</h1>
        <p className="text-gray-500 mt-1">Drag and drop leads to update their status</p>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {columns.map((column) => {
            const columnLeads = leads.filter(l => l.status === column.id);
            const totalValue = columnLeads.reduce((sum, l) => sum + (l.value || 0), 0);

            return (
              <Droppable key={column.id} droppableId={column.id}>
                {(provided, snapshot) => (
                  <Card className={`${snapshot.isDraggingOver ? 'ring-2 ring-blue-400' : ''}`}>
                    <CardHeader className={`${column.color} border-b`}>
                      <CardTitle className="text-sm font-semibold">
                        {column.title}
                        <Badge variant="outline" className="ml-2">{columnLeads.length}</Badge>
                      </CardTitle>
                      <div className="text-xs text-gray-600 font-semibold mt-1">
                        ${totalValue.toFixed(2)}
                      </div>
                    </CardHeader>
                    <CardContent
                      ref={provided.innerRef}
                      {...provided.droppableProps}
                      className="p-2 min-h-[400px] space-y-2"
                    >
                      {columnLeads.map((lead, index) => (
                        <Draggable key={lead.id} draggableId={lead.id} index={index}>
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              {...provided.dragHandleProps}
                              className={`bg-white p-3 rounded-lg shadow border ${
                                snapshot.isDragging ? 'ring-2 ring-blue-400' : ''
                              }`}
                            >
                              <div className="font-semibold text-sm mb-1">{lead.name}</div>
                              {lead.company && (
                                <div className="text-xs text-gray-500 mb-2">{lead.company}</div>
                              )}
                              <div className="flex items-center gap-2 text-xs text-gray-600">
                                {lead.email && <Mail className="w-3 h-3" />}
                                {lead.phone && <Phone className="w-3 h-3" />}
                              </div>
                              {lead.value > 0 && (
                                <div className="mt-2 flex items-center gap-1 text-sm font-semibold text-green-600">
                                  <DollarSign className="w-4 h-4" />
                                  {lead.value.toFixed(2)}
                                </div>
                              )}
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                    </CardContent>
                  </Card>
                )}
              </Droppable>
            );
          })}
        </div>
      </DragDropContext>
    </div>
  );
}