
import React from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DollarSign, CreditCard, TrendingUp } from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Payments() {
  const navigate = useNavigate();
  const queryClient = useQueryClient(); // Initialize useQueryClient
  const [showCreateDialog, setShowCreateDialog] = React.useState(false); // State for dialog visibility, implied by onSuccess

  const { data: payments = [] } = useQuery({
    queryKey: ['payments'],
    queryFn: () => base44.entities.Payment.list("-payment_date"),
    initialData: [],
  });

  const totalReceived = payments.filter(p => p.status === 'received').reduce((sum, p) => sum + (p.amount || 0), 0);
  const pendingAmount = payments.filter(p => p.status === 'pending').reduce((sum, p) => sum + (p.amount || 0), 0);

  const getStatusColor = (status) => {
    const colors = {
      'received': 'bg-green-100 text-green-700 border-green-200',
      'pending': 'bg-yellow-100 text-yellow-700 border-yellow-200',
      'failed': 'bg-red-100 text-red-700 border-red-200',
      'refunded': 'bg-gray-100 text-gray-700 border-gray-200'
    };
    return colors[status] || colors.pending;
  };

  const getMethodIcon = (method) => {
    if (method?.includes('card')) return CreditCard;
    return DollarSign;
  };

  const createPaymentMutation = useMutation({
    mutationFn: async (paymentData) => {
      const newPayment = await base44.entities.Payment.create(paymentData);
      
      // 🔥 TRIGGER WORKFLOW: payment_received
      try {
        await base44.functions.invoke('executeWorkflow', {
          triggerType: 'payment_received',
          entityType: 'Payment',
          entityId: newPayment.id,
          entityData: newPayment
        });
        console.log('✅ Payment received workflows triggered:', newPayment.id);
      } catch (error) {
        console.error('⚠️ Workflow trigger failed (non-critical):', error);
      }
      
      return newPayment;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payments'] });
      setShowCreateDialog(false);
      alert('Payment recorded! Thank you workflows started.');
    },
  });


  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Payments</h1>
        <p className="text-gray-500 mt-1">Track all customer payments</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <DollarSign className="w-8 h-8" />
              <span className="text-sm opacity-80">Total Received</span>
            </div>
            <h3 className="text-3xl font-bold">${totalReceived.toFixed(2)}</h3>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-8 h-8" />
              <span className="text-sm opacity-80">Pending</span>
            </div>
            <h3 className="text-3xl font-bold">${pendingAmount.toFixed(2)}</h3>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-2">
              <CreditCard className="w-8 h-8" />
              <span className="text-sm opacity-80">Transactions</span>
            </div>
            <h3 className="text-3xl font-bold">{payments.length}</h3>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-white shadow-md">
        <CardHeader>
          <CardTitle>Payment History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm text-gray-500">
                  <th className="pb-3 font-medium">Payment #</th>
                  <th className="pb-3 font-medium">Customer</th>
                  <th className="pb-3 font-medium">Invoice</th>
                  <th className="pb-3 font-medium">Amount</th>
                  <th className="pb-3 font-medium">Method</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium">Date</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((payment) => {
                  const MethodIcon = getMethodIcon(payment.payment_method);
                  return (
                    <tr key={payment.id} className="border-b hover:bg-gray-50">
                      <td className="py-4 font-medium">{payment.payment_number}</td>
                      <td className="py-4">
                        <button
                          onClick={() => navigate(createPageUrl('customer-profile') + `?name=${encodeURIComponent(payment.customer_name)}`)}
                          className="text-blue-600 hover:underline"
                        >
                          {payment.customer_name}
                        </button>
                      </td>
                      <td className="py-4 text-sm text-gray-600">{payment.invoice_number || '-'}</td>
                      <td className="py-4 font-semibold text-green-600">
                        ${payment.amount?.toFixed(2)}
                      </td>
                      <td className="py-4">
                        <div className="flex items-center gap-2">
                          <MethodIcon className="w-4 h-4 text-gray-400" />
                          <span className="text-sm capitalize">{payment.payment_method?.replace(/_/g, ' ')}</span>
                        </div>
                      </td>
                      <td className="py-4">
                        <Badge variant="outline" className={getStatusColor(payment.status)}>
                          {payment.status}
                        </Badge>
                      </td>
                      <td className="py-4 text-sm text-gray-600">
                        {format(new Date(payment.payment_date), 'MMM d, yyyy')}
                      </td>
                    </tr>
                  );
                })}
                {payments.length === 0 && (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-gray-500">
                      No payments yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
