
import React, { useState, useEffect, useCallback } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Plus, Search, Mail, Phone, MessageCircle, Eye, Edit, Trash2, Download, RefreshCw, Upload, Filter, MapPin, Building2, ChevronLeft, Users, Loader2 } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import Dialer from "../components/communication/Dialer";
import EmailDialog from "../components/communication/EmailDialog";
import SMSDialog from "../components/communication/SMSDialog";
import SwipeableCard from "../components/SwipeableCard";
import PullToRefresh from "../components/PullToRefresh";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function Customers() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile(); // Check on mount
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const [showForm, setShowForm] = useState(false); // Changed from showDialog to showForm
  const [searchTerm, setSearchTerm] = useState("");
  const [showDialer, setShowDialer] = useState(false);
  const [showEmailDialog, setShowEmailDialog] = useState(false);
  const [showSMSDialog, setShowSMSDialog] = useState(false);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [editingCustomer, setEditingCustomer] = useState(null); // New state for editing
  const [selectedCustomers, setSelectedCustomers] = useState([]);
  const [pageSize, setPageSize] = useState(25);
  const [currentPage, setCurrentPage] = useState(1);
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    status: 'all', // all, active, inactive
    group: 'all',
    source: 'all',
    customer_type: 'all'
  });
  // Full formData structure for consistency and mutation
  const [formData, setFormData] = useState({
    name: "",
    company: "",
    customer_type: "residential",
    email: "",
    phone: "",
    phone_2: "",
    street: "",
    city: "",
    state: "",
    zip: "",
    website: "",
    source: "other",
    referral_source: "",
    is_active: true,
    notes: "",
    group: "",
    tags: [],
    insurance_company: "",
    adjuster_name: "",
    adjuster_phone: ""
  });

  const [visibleColumns, setVisibleColumns] = useState({
    id: true, // Represents customer_number
    company: true,
    name: true, // Represents primary contact name
    customer_type: true, // New
    email: true,
    phone: true, // Represents phone_1
    phone_2: false, // Hidden by default, can be toggled
    address: true, // Combined address
    source: true, // New
    group: false, // Hidden by default, can be toggled
    insurance_company: false, // Hidden by default, can be toggled
    adjuster_name: false, // Hidden by default, can be toggled
    adjuster_phone: false, // Hidden by default, can be toggled
    active: true,
    communication: true,
    date_created: true,
    actions: true
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list("-customer_number"), // Order by customer_number for finding max
    initialData: [],
  });

  // Calculate metrics
  const totalCustomers = customers.length;
  const activeCustomers = customers.filter(c => c.is_active).length;
  const inactiveCustomers = customers.filter(c => !c.is_active).length;
  
  // For contacts logged in today, we'd need to check User entity
  // For now, let's just show 0 or calculate from last_login if available
  const contactsLoggedInToday = 0; // TODO: Query User entity with last_login = today

  // NEW: Memoize form change handler
  const handleFormChange = useCallback((field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  }, []);

  const createMutation = useMutation({ // Renamed from createCustomerMutation for clarity with editing
    mutationFn: async (customerData) => {
      // Don't pass 'id' - let base44 auto-generate it
      const { id, street, city, state, zip, ...dataWithoutId } = customerData;
      
      // Calculate next customer number
      const maxNumber = customers.reduce((max, c) => 
        Math.max(max, c.customer_number || 0), 0
      );
      const nextNumber = maxNumber + 1;

      // Build full address from parts if available
      const addressParts = [street, city, state, zip].filter(Boolean);
      const fullAddress = addressParts.join(', ');
      
      const newCustomer = await base44.entities.Customer.create({
        ...dataWithoutId,
        customer_number: nextNumber, // Add the calculated customer number
        street, // Store individual address components
        city,
        state,
        zip,
        address: fullAddress || undefined // Store combined address, or undefined if no parts
      });
      
      // 🔥 TRIGGER WORKFLOW: customer_created
      try {
        await base44.functions.invoke('executeWorkflow', {
          triggerType: 'customer_created',
          entityType: 'Customer',
          entityId: newCustomer.id,
          entityData: newCustomer
        });
        console.log('✅ Workflows triggered for new customer:', newCustomer.id);
      } catch (error) {
        console.error('⚠️ Workflow trigger failed (non-critical):', error);
      }
      
      return newCustomer;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      setShowForm(false); // Use showForm
      setEditingCustomer(null); // Clear editing state
      setFormData({ // Reset form data
        name: "",
        company: "",
        customer_type: "residential",
        email: "",
        phone: "",
        phone_2: "",
        street: "",
        city: "",
        state: "",
        zip: "",
        website: "",
        source: "other",
        referral_source: "",
        is_active: true,
        notes: "",
        group: "",
        tags: [],
        insurance_company: "",
        adjuster_name: "",
        adjuster_phone: ""
      });
      alert('Customer created successfully!');
    },
    onError: (error) => {
      console.error("Error creating customer:", error);
      alert(`Failed to create customer: ${error.message}`);
    }
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }) => {
      const { street, city, state, zip, ...dataWithoutAddressParts } = data;
      const addressParts = [street, city, state, zip].filter(Boolean);
      const fullAddress = addressParts.join(', ');

      const updatedCustomer = await base44.entities.Customer.update(id, {
        ...dataWithoutAddressParts,
        street,
        city,
        state,
        zip,
        address: fullAddress || undefined
      });

      // 🔥 TRIGGER WORKFLOW: customer_updated
      try {
        await base44.functions.invoke('executeWorkflow', {
          triggerType: 'customer_updated',
          entityType: 'Customer',
          entityId: updatedCustomer.id,
          entityData: updatedCustomer
        });
        console.log('✅ Workflows triggered for updated customer:', updatedCustomer.id);
      } catch (error) {
        console.error('⚠️ Workflow trigger failed (non-critical):', error);
      }

      return updatedCustomer;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      setShowForm(false); // Use showForm
      setEditingCustomer(null); // Clear editing state
      setFormData({ // Reset form data
        name: "",
        company: "",
        customer_type: "residential",
        email: "",
        phone: "",
        phone_2: "",
        street: "",
        city: "",
        state: "",
        zip: "",
        website: "",
        source: "other",
        referral_source: "",
        is_active: true,
        notes: "",
        group: "",
        tags: [],
        insurance_company: "",
        adjuster_name: "",
        adjuster_phone: ""
      });
      alert('Customer updated successfully!');
    },
    onError: (error) => {
      console.error("Error updating customer:", error);
      alert(`Failed to update customer: ${error.message}`);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Customer.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    },
  });

  const bulkDeleteMutation = useMutation({
    mutationFn: async (ids) => {
      let successCount = 0;
      let errorCount = 0;
      const errors = [];

      for (const id of ids) {
        try {
          await base44.entities.Customer.delete(id);
          successCount++;
        } catch (error) {
          errorCount++;
          errors.push({ id, error: error.message });
          console.error(`Failed to delete customer ${id}:`, error);
        }
      }

      return { successCount, errorCount, errors };
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      setSelectedCustomers([]);
      
      if (result.errorCount > 0) {
        alert(`Deleted ${result.successCount} customers successfully.\n${result.errorCount} customers could not be deleted.`);
      } else {
        alert(`Successfully deleted ${result.successCount} customers!`);
      }
    },
    onError: (error) => {
      console.error("Bulk delete failed:", error);
      alert('Failed to delete customers. Please try again.');
    }
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (editingCustomer) {
      updateMutation.mutate({ id: editingCustomer.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleCancel = () => {
    setShowForm(false);
    setEditingCustomer(null);
    setFormData({
      name: "",
      company: "",
      customer_type: "residential",
      email: "",
      phone: "",
      phone_2: "",
      street: "",
      city: "",
      state: "",
      zip: "",
      website: "",
      source: "other",
      referral_source: "",
      is_active: true,
      notes: "",
      group: "",
      tags: [],
      insurance_company: "",
      adjuster_name: "",
      adjuster_phone: ""
    });
  };

  const handleToggleActive = (customer) => {
    updateMutation.mutate({
      id: customer.id,
      data: { ...customer, is_active: !customer.is_active }
    });
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this customer?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleCommunication = (customer, type) => {
    setSelectedCustomer(customer);
    if (type === 'phone') setShowDialer(true);
    if (type === 'email') setShowEmailDialog(true);
    if (type === 'sms') setShowSMSDialog(true);
  };

  const handleSelectAll = () => {
    const currentPageCustomerIds = paginatedCustomers.map(customer => customer.id);
    const areAllCurrentPageSelected = currentPageCustomerIds.every(id => selectedCustomers.includes(id));

    if (areAllCurrentPageSelected) {
      setSelectedCustomers(prev => prev.filter(id => !currentPageCustomerIds.includes(id)));
    } else {
      setSelectedCustomers(prev => [...new Set([...prev, ...currentPageCustomerIds])]);
    }
  };

  const handleSelectCustomer = (id) => {
    if (selectedCustomers.includes(id)) {
      setSelectedCustomers(selectedCustomers.filter(customerId => customerId !== id));
    } else {
      setSelectedCustomers([...selectedCustomers, id]);
    }
  };

  const handleBulkDelete = () => {
    if (selectedCustomers.length === 0) {
      alert('Please select at least one customer to delete.');
      return;
    }

    const existingSelectedCustomers = selectedCustomers.filter(id => 
      customers.some(customer => customer.id === id)
    );

    if (existingSelectedCustomers.length === 0) {
      alert('No valid customers selected. They may have been already deleted.');
      setSelectedCustomers([]);
      return;
    }

    if (existingSelectedCustomers.length < selectedCustomers.length) {
      const difference = selectedCustomers.length - existingSelectedCustomers.length;
      if (!window.confirm(`${difference} of your selected customers no longer exist.\n\nDelete the remaining ${existingSelectedCustomers.length} customers? This cannot be undone!`)) {
        setSelectedCustomers(existingSelectedCustomers);
        return;
      }
    } else {
      if (!window.confirm(`Are you sure you want to delete ${existingSelectedCustomers.length} selected customers? This cannot be undone!`)) {
        return;
      }
    }

    bulkDeleteMutation.mutate(existingSelectedCustomers);
  };

  const handleExportCSV = () => {
    const customersToExport = selectedCustomers.length > 0
      ? filteredCustomers.filter(customer => selectedCustomers.includes(customer.id))
      : filteredCustomers;

    if (customersToExport.length === 0) {
      alert('No customers to export');
      return;
    }

    const headers = ['ID', 'Customer Number', 'Name', 'Company', 'Type', 'Email', 'Phone 1', 'Phone 2', 'Website', 'Street', 'City', 'State', 'Zip', 'Source', 'Referral Source', 'Group', 'Insurance Company', 'Adjuster Name', 'Adjuster Phone', 'Active', 'Date Created', 'Notes'];
    const rows = customersToExport.map(customer => [
      customer.id,
      customer.customer_number || '',
      customer.name || '',
      customer.company || '',
      customer.customer_type || '',
      customer.email || '',
      customer.phone || '',
      customer.phone_2 || '',
      customer.website || '',
      customer.street || '',
      customer.city || '',
      customer.state || '',
      customer.zip || '',
      customer.source || '',
      customer.referral_source || '',
      customer.group || '',
      customer.insurance_company || '',
      customer.adjuster_name || '',
      customer.adjuster_phone || '',
      customer.is_active ? 'Yes' : 'No',
      new Date(customer.created_date).toLocaleDateString(),
      customer.notes || ''
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `customers_export_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();

    alert(`Exported ${customersToExport.length} customers to CSV!`);
  };

  const handleImport = () => {
    navigate(createPageUrl('DataImport') + '?entity=Customer');
  };

  const handleEdit = (customer) => {
    setEditingCustomer(customer);
    setFormData({
      name: customer.name || "",
      company: customer.company || "",
      customer_type: customer.customer_type || "residential",
      email: customer.email || "",
      phone: customer.phone || "",
      phone_2: customer.phone_2 || "",
      street: customer.street || "",
      city: customer.city || "",
      state: customer.state || "",
      zip: customer.zip || "",
      website: customer.website || "",
      source: customer.source || "other",
      referral_source: customer.referral_source || "",
      is_active: customer.is_active,
      notes: customer.notes || "",
      group: customer.group || "",
      tags: customer.tags || [],
      insurance_company: customer.insurance_company || "",
      adjuster_name: customer.adjuster_name || "",
      adjuster_phone: customer.adjuster_phone || ""
    });
    setShowForm(true);
  };

  const toggleColumn = (column) => {
    setVisibleColumns(prev => ({
      ...prev,
      [column]: !prev[column]
    }));
  };

  const columnDisplayNames = {
    id: "Customer #",
    company: "Company",
    name: "Primary Contact",
    customer_type: "Type",
    email: "Email",
    phone: "Phone 1",
    phone_2: "Phone 2",
    address: "Address",
    source: "Source",
    group: "Group",
    insurance_company: "Insurance",
    adjuster_name: "Adjuster Name",
    adjuster_phone: "Adjuster Phone",
    active: "Active",
    communication: "Communication",
    date_created: "Date Created",
    actions: "Actions",
  };

  // Apply filters
  let filteredCustomers = customers.filter(customer =>
    customer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.company?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.address?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.street?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.city?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.state?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.zip?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    customer.phone?.includes(searchTerm) ||
    customer.phone_2?.includes(searchTerm)
  );

  // Apply status filter
  if (filters.status === 'active') {
    filteredCustomers = filteredCustomers.filter(c => c.is_active);
  } else if (filters.status === 'inactive') {
    filteredCustomers = filteredCustomers.filter(c => !c.is_active);
  }

  // Apply group filter
  if (filters.group !== 'all') {
    filteredCustomers = filteredCustomers.filter(c => c.group === filters.group);
  }

  // Apply source filter
  if (filters.source !== 'all') {
    filteredCustomers = filteredCustomers.filter(c => c.source === filters.source);
  }

  // Apply customer type filter
  if (filters.customer_type !== 'all') {
    filteredCustomers = filteredCustomers.filter(c => c.customer_type === filters.customer_type);
  }

  // Get unique groups for filter dropdown
  const uniqueGroups = [...new Set(customers.map(c => c.group).filter(Boolean))];
  // Get unique sources for filter dropdown
  const uniqueSources = [...new Set(customers.map(c => c.source).filter(Boolean))];


  // Pagination
  const effectivePageSize = pageSize === 'all' ? filteredCustomers.length : pageSize;
  const totalPages = effectivePageSize === 0 ? 0 : Math.ceil(filteredCustomers.length / effectivePageSize);
  const paginatedCustomers = pageSize === 'all' 
    ? filteredCustomers 
    : filteredCustomers.slice((currentPage - 1) * effectivePageSize, currentPage * effectivePageSize);

  const handleRefresh = async () => {
    await queryClient.invalidateQueries({ queryKey: ['customers'] });
  };

  return (
    <div className="flex flex-col h-screen">
      <div className="p-4 md:p-6 space-y-4 flex-shrink-0">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Customers</h1>
          <button 
            onClick={() => navigate(createPageUrl('Customers'))}
            className="text-blue-600 hover:underline text-sm flex items-center gap-1 mt-1"
          >
            Contacts →
          </button>
        </div>

        {/* Metric Cards - Horizontal Scroll on Mobile */}
        <div className="overflow-x-auto no-scrollbar">
          <div className="flex md:grid md:grid-cols-4 lg:grid-cols-6 gap-3 pb-2" style={{ minWidth: isMobile ? '800px' : 'auto' }}>
            <Card className="bg-white flex-shrink-0" style={{ minWidth: isMobile ? '180px' : 'auto' }}>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-gray-900">{totalCustomers}</div>
                <div className="text-sm text-gray-500">Total Customers</div>
              </CardContent>
            </Card>
            <Card className="bg-white flex-shrink-0" style={{ minWidth: isMobile ? '180px' : 'auto' }}>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-green-600">{activeCustomers}</div>
                <div className="text-sm text-gray-500">Active Customers</div>
              </CardContent>
            </Card>
            <Card className="bg-white flex-shrink-0" style={{ minWidth: isMobile ? '180px' : 'auto' }}>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-red-600">{inactiveCustomers}</div>
                <div className="text-sm text-gray-500">Inactive Customers</div>
              </CardContent>
            </Card>
            <Card className="bg-white flex-shrink-0" style={{ minWidth: isMobile ? '180px' : 'auto' }}>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-blue-600">{activeCustomers}</div>
                <div className="text-sm text-gray-500">Active Contacts</div>
              </CardContent>
            </Card>
            <Card className="bg-white flex-shrink-0" style={{ minWidth: isMobile ? '180px' : 'auto' }}>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-orange-600">{inactiveCustomers}</div>
                <div className="text-sm text-gray-500">Inactive Contacts</div>
              </CardContent>
            </Card>
            <Card className="bg-white flex-shrink-0" style={{ minWidth: isMobile ? '180px' : 'auto' }}>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-gray-900">{contactsLoggedInToday}</div>
                <div className="text-sm text-gray-500">Contacts Logged In Today</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Search Bar - Sticky on Mobile */}
        <div className={`${isMobile ? 'sticky top-0 z-20 bg-background -mx-4 px-4 pt-3 pb-1 shadow-sm' : ''}`}>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              placeholder="Search customers..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1); // Reset pagination on search
              }}
              className="pl-10 h-12 text-base"
              autoComplete="off" // Helps with mobile input jumping
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2 items-center justify-between">
          <div className="flex gap-2">
            {isMobile ? (
              <Sheet open={showForm} onOpenChange={setShowForm}> {/* Use showForm */}
                <SheetTrigger asChild>
                  <Button className="flex-1 bg-blue-600 hover:bg-blue-700 h-12">
                    <Plus className="w-5 h-5 mr-2" />
                    New Customer
                  </Button>
                </SheetTrigger>
                <SheetContent side="bottom" className="h-[90vh] overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>{editingCustomer ? "Edit Customer" : "Add New Customer"}</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6">
                    {/* Form Content */}
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="name">Primary Contact *</Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => handleFormChange("name", e.target.value)}
                            placeholder="John Doe"
                            required
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div>
                          <Label htmlFor="company">Company</Label>
                          <Input
                            id="company"
                            value={formData.company}
                            onChange={(e) => handleFormChange("company", e.target.value)}
                            placeholder="ABC Roofing Inc."
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div>
                          <Label htmlFor="customer_type">Customer Type</Label>
                          <Select value={formData.customer_type} onValueChange={(v) => handleFormChange("customer_type", v)}>
                            <SelectTrigger id="customer_type" className="h-12 text-base">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="residential">Residential</SelectItem>
                              <SelectItem value="commercial">Commercial</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleFormChange("email", e.target.value)}
                            placeholder="john@example.com"
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div>
                          <Label htmlFor="phone">Phone 1</Label>
                          <Input
                            id="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={(e) => handleFormChange("phone", e.target.value)}
                            placeholder="(555) 123-4567"
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>
                        <div>
                          <Label htmlFor="phone_2">Phone 2</Label>
                          <Input
                            id="phone_2"
                            type="tel"
                            value={formData.phone_2}
                            onChange={(e) => handleFormChange("phone_2", e.target.value)}
                            placeholder="(555) 987-6543"
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div className="border-t pt-4">
                          <h3 className="font-semibold mb-3">Address</h3>
                          <div className="grid grid-cols-1 gap-4">
                            <div>
                              <Label htmlFor="street">Street Address</Label>
                              <Input
                                id="street"
                                value={formData.street}
                                onChange={(e) => handleFormChange("street", e.target.value)}
                                placeholder="123 Main Street"
                                className="h-12 text-base"
                                autoComplete="off"
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label htmlFor="city">City</Label>
                                <Input
                                  id="city"
                                  value={formData.city}
                                  onChange={(e) => handleFormChange("city", e.target.value)}
                                  placeholder="Cleveland"
                                  className="h-12 text-base"
                                  autoComplete="off"
                                />
                              </div>
                              <div>
                                <Label htmlFor="state">State</Label>
                                <Input
                                  id="state"
                                  value={formData.state}
                                  onChange={(e) => handleFormChange("state", e.target.value)}
                                  placeholder="OH"
                                  maxLength={2}
                                  className="h-12 text-base"
                                  autoComplete="off"
                                />
                              </div>
                              <div>
                                <Label htmlFor="zip">Zip Code</Label>
                                <Input
                                  id="zip"
                                  value={formData.zip}
                                  onChange={(e) => handleFormChange("zip", e.target.value)}
                                  placeholder="44101"
                                  className="h-12 text-base"
                                  autoComplete="off"
                                />
                              </div>
                            </div>
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="website">Website</Label>
                          <Input
                            id="website"
                            value={formData.website}
                            onChange={(e) => handleFormChange("website", e.target.value)}
                            placeholder="https://example.com"
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div>
                          <Label htmlFor="source">Source *</Label>
                          <Select value={formData.source} onValueChange={(v) => handleFormChange("source", v)}>
                            <SelectTrigger id="source" className="h-12 text-base">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="website">Website</SelectItem>
                              <SelectItem value="referral">Referral</SelectItem>
                              <SelectItem value="storm_tracker">Storm Tracker</SelectItem>
                              <SelectItem value="property_importer">Property Importer</SelectItem>
                              <SelectItem value="social_media">Social Media</SelectItem>
                              <SelectItem value="advertisement">Advertisement</SelectItem>
                              <SelectItem value="cold_call">Cold Call</SelectItem>
                              <SelectItem value="walk_in">Walk In</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        {formData.source === 'referral' && (
                          <div>
                            <Label htmlFor="referral_source">Referred By</Label>
                            <Input
                              id="referral_source"
                              value={formData.referral_source}
                              onChange={(e) => handleFormChange("referral_source", e.target.value)}
                              placeholder="Who referred this customer?"
                              className="h-12 text-base"
                              autoComplete="off"
                            />
                          </div>
                        )}

                        <div className="border-t pt-4">
                          <h3 className="font-semibold mb-3">Additional Info</h3>
                          <div className="grid grid-cols-1 gap-4">
                            <div>
                              <Label htmlFor="group">Group</Label>
                              <Input
                                id="group"
                                value={formData.group}
                                onChange={(e) => handleFormChange("group", e.target.value)}
                                placeholder="e.g., Retail Sales, VIP"
                                className="h-12 text-base"
                                autoComplete="off"
                              />
                            </div>
                            <div>
                              <Label htmlFor="insurance_company">Insurance Company</Label>
                              <Input
                                id="insurance_company"
                                value={formData.insurance_company}
                                onChange={(e) => handleFormChange("insurance_company", e.target.value)}
                                placeholder="e.g., State Farm"
                                className="h-12 text-base"
                                autoComplete="off"
                              />
                            </div>
                            <div>
                              <Label htmlFor="adjuster_name">Adjuster Name</Label>
                              <Input
                                id="adjuster_name"
                                value={formData.adjuster_name}
                                onChange={(e) => handleFormChange("adjuster_name", e.target.value)}
                                className="h-12 text-base"
                                autoComplete="off"
                              />
                            </div>
                            <div>
                              <Label htmlFor="adjuster_phone">Adjuster Phone</Label>
                              <Input
                                id="adjuster_phone"
                                value={formData.adjuster_phone}
                                onChange={(e) => handleFormChange("adjuster_phone", e.target.value)}
                                className="h-12 text-base"
                                autoComplete="off"
                              />
                            </div>
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="notes">Notes</Label>
                          <Textarea
                            id="notes"
                            value={formData.notes}
                            onChange={(e) => handleFormChange("notes", e.target.value)}
                            rows={3}
                            placeholder="Additional notes about this customer..."
                            className="text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div className="flex items-center gap-3">
                          <Switch
                            id="is_active"
                            checked={formData.is_active}
                            onCheckedChange={(checked) => handleFormChange("is_active", checked)}
                          />
                          <Label htmlFor="is_active">Active</Label>
                        </div>
                      </div>

                      <div className="flex gap-3 pt-4">
                        <Button type="button" variant="outline" onClick={handleCancel} className="flex-1 h-12">
                          Cancel
                        </Button>
                        <Button
                          type="submit"
                          className="flex-1 h-12 bg-blue-600 hover:bg-blue-700"
                          disabled={createMutation.isPending || updateMutation.isPending}
                        >
                          {createMutation.isPending || updateMutation.isPending ? (
                            <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
                          ) : (
                            <>{editingCustomer ? "Update Customer" : "Create Customer"}</>
                          )}
                        </Button>
                      </div>
                    </form>
                  </div>
                </SheetContent>
              </Sheet>
            ) : (
              <Sheet open={showForm} onOpenChange={setShowForm}> {/* Use showForm */}
                <SheetTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700 text-sm h-9">
                    <Plus className="w-4 h-4 mr-2" />
                    New Customer
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>{editingCustomer ? "Edit Customer" : "Add New Customer"}</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6">
                    {/* Form Content */}
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="name">Primary Contact *</Label>
                          <Input
                            id="name"
                            value={formData.name}
                            onChange={(e) => handleFormChange("name", e.target.value)}
                            placeholder="John Doe"
                            required
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div>
                          <Label htmlFor="company">Company</Label>
                          <Input
                            id="company"
                            value={formData.company}
                            onChange={(e) => handleFormChange("company", e.target.value)}
                            placeholder="ABC Roofing Inc."
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div>
                          <Label htmlFor="customer_type">Customer Type</Label>
                          <Select value={formData.customer_type} onValueChange={(v) => handleFormChange("customer_type", v)}>
                            <SelectTrigger id="customer_type" className="h-12 text-base">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="residential">Residential</SelectItem>
                              <SelectItem value="commercial">Commercial</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <Label htmlFor="email">Email</Label>
                          <Input
                            id="email"
                            type="email"
                            value={formData.email}
                            onChange={(e) => handleFormChange("email", e.target.value)}
                            placeholder="john@example.com"
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div>
                          <Label htmlFor="phone">Phone 1</Label>
                          <Input
                            id="phone"
                            type="tel"
                            value={formData.phone}
                            onChange={(e) => handleFormChange("phone", e.target.value)}
                            placeholder="(555) 123-4567"
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>
                        <div>
                          <Label htmlFor="phone_2">Phone 2</Label>
                          <Input
                            id="phone_2"
                            type="tel"
                            value={formData.phone_2}
                            onChange={(e) => handleFormChange("phone_2", e.target.value)}
                            placeholder="(555) 987-6543"
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div className="border-t pt-4">
                          <h3 className="font-semibold mb-3">Address</h3>
                          <div className="grid grid-cols-1 gap-4">
                            <div>
                              <Label htmlFor="street">Street Address</Label>
                              <Input
                                id="street"
                                value={formData.street}
                                onChange={(e) => handleFormChange("street", e.target.value)}
                                placeholder="123 Main Street"
                                className="h-12 text-base"
                                autoComplete="off"
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div>
                                <Label htmlFor="city">City</Label>
                                <Input
                                  id="city"
                                  value={formData.city}
                                  onChange={(e) => handleFormChange("city", e.target.value)}
                                  placeholder="Cleveland"
                                  className="h-12 text-base"
                                  autoComplete="off"
                                />
                              </div>
                              <div>
                                <Label htmlFor="state">State</Label>
                                <Input
                                  id="state"
                                  value={formData.state}
                                  onChange={(e) => handleFormChange("state", e.target.value)}
                                  placeholder="OH"
                                  maxLength={2}
                                  className="h-12 text-base"
                                  autoComplete="off"
                                />
                              </div>
                              <div>
                                <Label htmlFor="zip">Zip Code</Label>
                                <Input
                                  id="zip"
                                  value={formData.zip}
                                  onChange={(e) => handleFormChange("zip", e.target.value)}
                                  placeholder="44101"
                                  className="h-12 text-base"
                                  autoComplete="off"
                                />
                              </div>
                            </div>
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="website">Website</Label>
                          <Input
                            id="website"
                            value={formData.website}
                            onChange={(e) => handleFormChange("website", e.target.value)}
                            placeholder="https://example.com"
                            className="h-12 text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div>
                          <Label htmlFor="source">Source *</Label>
                          <Select value={formData.source} onValueChange={(v) => handleFormChange("source", v)}>
                            <SelectTrigger id="source" className="h-12 text-base">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="website">Website</SelectItem>
                              <SelectItem value="referral">Referral</SelectItem>
                              <SelectItem value="storm_tracker">Storm Tracker</SelectItem>
                              <SelectItem value="property_importer">Property Importer</SelectItem>
                              <SelectItem value="social_media">Social Media</SelectItem>
                              <SelectItem value="advertisement">Advertisement</SelectItem>
                              <SelectItem value="cold_call">Cold Call</SelectItem>
                              <SelectItem value="walk_in">Walk In</SelectItem>
                              <SelectItem value="other">Other</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        {formData.source === 'referral' && (
                          <div>
                            <Label htmlFor="referral_source">Referred By</Label>
                            <Input
                              id="referral_source"
                              value={formData.referral_source}
                              onChange={(e) => handleFormChange("referral_source", e.target.value)}
                              placeholder="Who referred this customer?"
                              className="h-12 text-base"
                              autoComplete="off"
                            />
                          </div>
                        )}

                        <div className="border-t pt-4">
                          <h3 className="font-semibold mb-3">Additional Info</h3>
                          <div className="grid grid-cols-1 gap-4">
                            <div>
                              <Label htmlFor="group">Group</Label>
                              <Input
                                id="group"
                                value={formData.group}
                                onChange={(e) => handleFormChange("group", e.target.value)}
                                placeholder="e.g., Retail Sales, VIP"
                                className="h-12 text-base"
                                autoComplete="off"
                              />
                            </div>
                            <div>
                              <Label htmlFor="insurance_company">Insurance Company</Label>
                              <Input
                                id="insurance_company"
                                value={formData.insurance_company}
                                onChange={(e) => handleFormChange("insurance_company", e.target.value)}
                                placeholder="e.g., State Farm"
                                className="h-12 text-base"
                                autoComplete="off"
                              />
                            </div>
                            <div>
                              <Label htmlFor="adjuster_name">Adjuster Name</Label>
                              <Input
                                id="adjuster_name"
                                value={formData.adjuster_name}
                                onChange={(e) => handleFormChange("adjuster_name", e.target.value)}
                                className="h-12 text-base"
                                autoComplete="off"
                              />
                            </div>
                            <div>
                              <Label htmlFor="adjuster_phone">Adjuster Phone</Label>
                              <Input
                                id="adjuster_phone"
                                value={formData.adjuster_phone}
                                onChange={(e) => handleFormChange("adjuster_phone", e.target.value)}
                                className="h-12 text-base"
                                autoComplete="off"
                              />
                            </div>
                          </div>
                        </div>

                        <div>
                          <Label htmlFor="notes">Notes</Label>
                          <Textarea
                            id="notes"
                            value={formData.notes}
                            onChange={(e) => handleFormChange("notes", e.target.value)}
                            rows={3}
                            placeholder="Additional notes about this customer..."
                            className="text-base"
                            autoComplete="off"
                          />
                        </div>

                        <div className="flex items-center gap-3">
                          <Switch
                            id="is_active"
                            checked={formData.is_active}
                            onCheckedChange={(checked) => handleFormChange("is_active", checked)}
                          />
                          <Label htmlFor="is_active">Active</Label>
                        </div>
                      </div>

                      <div className="flex gap-3 pt-4">
                        <Button type="button" variant="outline" onClick={handleCancel} className="flex-1 h-12">
                          Cancel
                        </Button>
                        <Button
                          type="submit"
                          className="flex-1 h-12 bg-blue-600 hover:bg-blue-700"
                          disabled={createMutation.isPending || updateMutation.isPending}
                        >
                          {createMutation.isPending || updateMutation.isPending ? (
                            <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</>
                          ) : (
                            <>{editingCustomer ? "Update Customer" : "Create Customer"}</>
                          )}
                        </Button>
                      </div>
                    </form>
                  </div>
                </SheetContent>
              </Sheet>
            )}

            <Button variant="outline" onClick={handleImport} className="text-sm h-9">
              <Upload className="w-4 h-4 mr-2" />
              Import
            </Button>
          </div>

          <div className="flex gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="h-9">
                  <Eye className="w-4 h-4 mr-2" />
                  Columns
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                {Object.keys(visibleColumns).map(col => (
                  <DropdownMenuItem
                    key={col}
                    onSelect={(e) => {
                      e.preventDefault(); // Prevent dropdown from closing
                      toggleColumn(col);
                    }}
                    className="flex items-center justify-between"
                  >
                    <span>{columnDisplayNames[col]}</span>
                    <Checkbox checked={visibleColumns[col]} className="ml-2 pointer-events-none" />
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button 
              variant="outline" 
              onClick={() => setShowFilters(!showFilters)} 
              className={`text-sm h-9 ${showFilters ? 'bg-blue-50 border-blue-300' : ''}`}
            >
              <Filter className="w-4 h-4 mr-2" />
              Filters
            </Button>
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="px-4 py-3 border-b bg-gray-50 rounded-lg">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <Label className="text-xs">Status</Label>
                <Select value={filters.status} onValueChange={(value) => {
                  setFilters({...filters, status: value});
                  setCurrentPage(1); // Reset pagination on filter change
                }}>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active Only</SelectItem>
                    <SelectItem value="inactive">Inactive Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Type</Label>
                <Select value={filters.customer_type} onValueChange={(value) => {
                  setFilters({...filters, customer_type: value});
                  setCurrentPage(1);
                }}>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="residential">Residential</SelectItem>
                    <SelectItem value="commercial">Commercial</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Source</Label>
                <Select value={filters.source} onValueChange={(value) => {
                  setFilters({...filters, source: value});
                  setCurrentPage(1);
                }}>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Sources</SelectItem>
                    {uniqueSources.map(source => (
                      <SelectItem key={source} value={source}>{source.replace(/_/g, ' ')}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Group</Label>
                <Select value={filters.group} onValueChange={(value) => {
                  setFilters({...filters, group: value});
                  setCurrentPage(1);
                }}>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Groups</SelectItem>
                    {uniqueGroups.map(group => (
                      <SelectItem key={group} value={group}>{group}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Customer List with Pull to Refresh on Mobile or Desktop Table */}
      {isMobile ? (
        <div className="flex-1 overflow-hidden">
          <PullToRefresh onRefresh={handleRefresh}>
            <div className="px-4 pb-4 space-y-3">
              {/* Swipe Hint at top */}
              {paginatedCustomers.length > 0 && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-2 flex items-center gap-2 text-sm text-blue-800">
                  <ChevronLeft className="w-5 h-5" />
                  <span>💡 Swipe left on any card for quick actions</span>
                </div>
              )}
              
              {paginatedCustomers.length === 0 && (
                <div className="text-center py-12 text-gray-500">
                  <Users className="w-16 h-16 mx-auto mb-3 text-gray-300" />
                  <p className="font-medium">No customers found</p>
                  <p className="text-sm mt-1">Try adjusting your search or filters</p>
                </div>
              )}

              {paginatedCustomers.map((customer) => (
                <SwipeableCard
                  key={customer.id}
                  onCall={customer.phone ? () => handleCommunication(customer, 'phone') : null}
                  onEmail={customer.email ? () => handleCommunication(customer, 'email') : null}
                  onSMS={customer.phone ? () => handleCommunication(customer, 'sms') : null}
                  onDelete={() => handleDelete(customer.id)}
                  className="p-4 rounded-lg shadow-sm border border-gray-200"
                >
                  <div 
                    onClick={() => navigate(createPageUrl('CustomerProfile') + `?id=${customer.id}`)}
                    className="space-y-3"
                  >
                    {/* Header */}
                    <div className="flex items-start justify-between">
                      <div className="flex-1 pr-6">
                        <h3 className="font-semibold text-lg text-gray-900">{customer.name}</h3>
                        {customer.company && (
                          <div className="flex items-center gap-1 text-sm text-gray-600 mt-1">
                            <Building2 className="w-4 h-4" />
                            {customer.company}
                          </div>
                        )}
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <Badge variant="outline" className={customer.is_active ? "bg-green-50 text-green-700 border-green-200" : "bg-gray-50 text-gray-700"}>
                          {customer.is_active ? "Active" : "Inactive"}
                        </Badge>
                        {customer.customer_type && (
                          <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200 text-xs">
                            {customer.customer_type}
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Contact Info */}
                    <div className="space-y-2">
                      {customer.phone && (
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="w-4 h-4 text-gray-400 flex-shrink-0" />
                          <a href={`tel:${customer.phone}`} className="text-blue-600 font-medium" onClick={(e) => e.stopPropagation()}>
                            {customer.phone}
                          </a>
                        </div>
                      )}
                      {customer.email && (
                        <div className="flex items-center gap-2 text-sm">
                          <Mail className="w-4 h-4 text-gray-400 flex-shrink-0" />
                          <a href={`mailto:${customer.email}`} className="text-blue-600 truncate" onClick={(e) => e.stopPropagation()}>
                            {customer.email}
                          </a>
                        </div>
                      )}
                      {(customer.street || customer.address) && (
                        <div className="flex items-start gap-2 text-sm text-gray-600">
                          <MapPin className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                          <div>
                            {customer.street && <div>{customer.street}</div>}
                            {(customer.city || customer.state || customer.zip) && (
                              <div className="text-gray-500">
                                {[customer.city, customer.state, customer.zip].filter(Boolean).join(', ')}
                              </div>
                            )}
                            {!customer.street && customer.address && <div>{customer.address}</div>}
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Footer */}
                    <div className="flex items-center justify-between text-xs text-gray-500 pt-2 border-t">
                      <span className="font-medium">#{customer.customer_number || '-'}</span>
                      <span>{format(new Date(customer.created_date), 'MMM d, yyyy')}</span>
                    </div>
                  </div>
                </SwipeableCard>
              ))}
            </div>
          </PullToRefresh>
          {/* Mobile Pagination */}
          {filteredCustomers.length > 0 && pageSize !== 'all' && totalPages > 1 && (
            <div className="px-4 py-2 border-t flex items-center justify-between bg-white sticky bottom-0 z-10">
              <div className="text-xs text-gray-500">
                Showing {((currentPage - 1) * effectivePageSize) + 1} to {Math.min(currentPage * effectivePageSize, filteredCustomers.length)} of {filteredCustomers.length} customers
              </div>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                  disabled={currentPage === 1}
                  className="h-8 text-xs"
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                  disabled={currentPage === totalPages}
                  className="h-8 text-xs"
                >
                  Next
                </Button>
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="flex-1 overflow-auto px-6 pb-6">
          <Card className="bg-white shadow-md">
            {/* Control Bar */}
            <div className="px-4 py-2 border-b bg-gray-50 flex items-center gap-2">
              {/* Page Size Selector */}
              <Select value={pageSize.toString()} onValueChange={(value) => {
                setPageSize(value === 'all' ? 'all' : parseInt(value));
                setCurrentPage(1);
              }}>
                <SelectTrigger className="w-16 h-8 text-sm">
                  <SelectValue placeholder="Page Size" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="25">25</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                  <SelectItem value="100">100</SelectItem>
                  <SelectItem value="all">All</SelectItem>
                </SelectContent>
              </Select>

              {/* Export Button */}
              <Button variant="outline" size="sm" onClick={handleExportCSV} className="h-8 text-xs">
                <Download className="w-3 h-3 mr-1" />
                Export
              </Button>

              {/* Bulk Actions */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" disabled={selectedCustomers.length === 0} className="h-8 text-xs">
                    Bulk Actions
                    {selectedCustomers.length > 0 && (
                      <Badge variant="secondary" className="ml-2 text-xs">
                        {selectedCustomers.length}
                      </Badge>
                    )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start">
                  <DropdownMenuItem onSelect={handleExportCSV}>
                    <Download className="w-3 h-3 mr-2" />
                    Export Selected
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onSelect={handleBulkDelete}
                    className="text-red-600"
                  >
                    <Trash2 className="w-3 h-3 mr-2" />
                    Delete Selected
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Refresh Button */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => queryClient.invalidateQueries({ queryKey: ['customers'] })}
                className="h-8"
              >
                <RefreshCw className="w-3 h-3" />
              </Button>

              {/* Results count */}
              <div className="ml-auto text-xs text-gray-500">
                {filteredCustomers.length} customer{filteredCustomers.length !== 1 ? 's' : ''}
              </div>
            </div>

            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-4 py-2 text-left">
                        <Checkbox
                          checked={paginatedCustomers.length > 0 && paginatedCustomers.every(customer => selectedCustomers.includes(customer.id))}
                          indeterminate={paginatedCustomers.length > 0 && paginatedCustomers.some(customer => selectedCustomers.includes(customer.id)) && !paginatedCustomers.every(customer => selectedCustomers.includes(customer.id))}
                          onCheckedChange={handleSelectAll}
                          disabled={paginatedCustomers.length === 0}
                        />
                      </th>
                      {visibleColumns.id && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>}
                      {visibleColumns.name && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Primary Contact</th>}
                      {visibleColumns.company && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Company</th>}
                      {visibleColumns.customer_type && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>}
                      {visibleColumns.email && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>}
                      {visibleColumns.phone && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone 1</th>}
                      {visibleColumns.phone_2 && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Phone 2</th>}
                      {visibleColumns.address && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Address</th>}
                      {visibleColumns.source && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Source</th>}
                      {visibleColumns.group && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Group</th>}
                      {visibleColumns.insurance_company && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Insurance</th>}
                      {visibleColumns.adjuster_name && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Adjuster Name</th>}
                      {visibleColumns.adjuster_phone && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Adjuster Phone</th>}
                      {visibleColumns.active && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Active</th>}
                      {visibleColumns.communication && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Communication</th>}
                      {visibleColumns.date_created && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date Created</th>}
                      {visibleColumns.actions && <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>}
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {paginatedCustomers.map((customer) => (
                      <tr key={customer.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3 whitespace-nowrap">
                          <Checkbox
                            checked={selectedCustomers.includes(customer.id)}
                            onCheckedChange={() => handleSelectCustomer(customer.id)}
                          />
                        </td>
                        {visibleColumns.id && <td className="px-4 py-3 whitespace-nowrap text-sm font-medium text-gray-900">{customer.customer_number || '-'}</td>}
                        {visibleColumns.name && (
                          <td className="px-4 py-3 whitespace-nowrap">
                            <button
                              onClick={() => navigate(createPageUrl('CustomerProfile') + `?id=${customer.id}`)}
                              className="text-sm font-medium text-blue-600 hover:text-blue-800 hover:underline"
                            >
                              {customer.name}
                            </button>
                          </td>
                        )}
                        {visibleColumns.company && <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{customer.company || '-'}</td>}
                        {visibleColumns.customer_type && (
                          <td className="px-4 py-3 whitespace-nowrap">
                            <Badge variant="outline" className="text-xs">{customer.customer_type || 'Residential'}</Badge>
                          </td>
                        )}
                        {visibleColumns.email && <td className="px-4 py-3 whitespace-nowrap text-sm text-blue-600">{customer.email || '-'}</td>}
                        {visibleColumns.phone && <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{customer.phone || '-'}</td>}
                        {visibleColumns.phone_2 && <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{customer.phone_2 || '-'}</td>}
                        {visibleColumns.address && (
                          <td className="px-4 py-3 text-sm text-gray-900">
                            {customer.street || customer.address ? (
                              <div>
                                {customer.street && <div>{customer.street}</div>}
                                {(customer.city || customer.state || customer.zip) && (
                                  <div className="text-xs text-gray-500">
                                    {[customer.city, customer.state, customer.zip].filter(Boolean).join(', ')}
                                  </div>
                                )}
                                {/* Fallback for old records that only have 'address' field */}
                                {!customer.street && customer.address && <div>{customer.address}</div>}
                              </div>
                            ) : '-'}
                          </td>
                        )}
                        {visibleColumns.source && (
                          <td className="px-4 py-3 whitespace-nowrap">
                            <Badge variant="outline" className="text-xs">
                              {customer.source ? customer.source.replace(/_/g, ' ') : '-'}
                            </Badge>
                          </td>
                        )}
                        {visibleColumns.group && <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">
                          {customer.group || '-'}
                        </td>}
                        {visibleColumns.insurance_company && <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{customer.insurance_company || '-'}</td>}
                        {visibleColumns.adjuster_name && <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{customer.adjuster_name || '-'}</td>}
                        {visibleColumns.adjuster_phone && <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900">{customer.adjuster_phone || '-'}</td>}
                        {visibleColumns.active && (
                          <td className="px-4 py-3 whitespace-nowrap">
                            <Switch
                              checked={customer.is_active}
                              onCheckedChange={() => handleToggleActive(customer)}
                            />
                          </td>
                        )}
                        {visibleColumns.communication && (
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="flex items-center gap-1">
                              <button
                                onClick={() => handleCommunication(customer, 'email')}
                                className="p-1.5 hover:bg-blue-50 rounded-full transition-colors"
                                title="Send email"
                              >
                                <Mail className="w-3.5 h-3.5 text-blue-600" />
                              </button>
                              <button
                                onClick={() => handleCommunication(customer, 'phone')}
                                className="p-1.5 hover:bg-green-50 rounded-full transition-colors"
                                title="Make call"
                              >
                                <Phone className="w-3.5 h-3.5 text-green-600" />
                              </button>
                              <button
                                onClick={() => handleCommunication(customer, 'sms')}
                                className="p-1.5 hover:bg-purple-50 rounded-full transition-colors"
                                title="Send SMS"
                              >
                                <MessageCircle className="w-3.5 h-3.5 text-purple-600" />
                              </button>
                            </div>
                          </td>
                        )}
                        {visibleColumns.date_created && (
                          <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500">
                            {format(new Date(customer.created_date), 'yyyy-MM-dd')}
                          </td>
                        )}
                        {visibleColumns.actions && (
                          <td className="px-4 py-3 whitespace-nowrap">
                            <div className="flex items-center gap-1">
                              <button
                                className="p-1.5 hover:bg-blue-100 rounded-full transition-colors"
                                title="View profile"
                                onClick={() => navigate(createPageUrl('CustomerProfile') + `?id=${customer.id}`)}
                              >
                                <Eye className="w-3.5 h-3.5 text-blue-600" />
                              </button>
                              <button
                                className="p-1.5 hover:bg-gray-100 rounded-full transition-colors"
                                title="Edit customer"
                                onClick={() => handleEdit(customer)}
                              >
                                <Edit className="w-3.5 h-3.5 text-gray-600" />
                              </button>
                              <button
                                className="p-1.5 hover:bg-red-100 rounded-full transition-colors"
                                title="Delete customer"
                                onClick={() => handleDelete(customer.id)}
                              >
                                <Trash2 className="w-3.5 h-3.5 text-red-600" />
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    ))}
                    {paginatedCustomers.length === 0 && (
                      <tr>
                        <td colSpan={Object.values(visibleColumns).filter(Boolean).length + 1} className="px-4 py-8 text-center text-gray-500 text-sm">
                          No customers found
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Pagination */}
              {filteredCustomers.length > 0 && pageSize !== 'all' && totalPages > 1 && (
                <div className="px-4 py-2 border-t flex items-center justify-between">
                  <div className="text-xs text-gray-500">
                    Showing {((currentPage - 1) * effectivePageSize) + 1} to {Math.min(currentPage * effectivePageSize, filteredCustomers.length)} of {filteredCustomers.length} customers
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                      className="h-8 text-xs"
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                      className="h-8 text-xs"
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {/* Communication Dialogs */}
      <Dialer
        open={showDialer}
        onOpenChange={setShowDialer}
        defaultNumber={selectedCustomer?.phone || selectedCustomer?.phone_2}
      />
      <EmailDialog
        open={showEmailDialog}
        onOpenChange={setShowEmailDialog}
        defaultTo={selectedCustomer?.email}
      />
      <SMSDialog
        open={showSMSDialog}
        onOpenChange={setShowSMSDialog}
        defaultTo={selectedCustomer?.phone || selectedCustomer?.phone_2}
      />
    </div>
  );
}
