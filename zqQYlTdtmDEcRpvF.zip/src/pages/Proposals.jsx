import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Plus, 
  Search, 
  FileText,
  Send,
  CheckCircle2,
  XCircle,
  Eye,
  Edit,
  Trash2,
  DollarSign
} from "lucide-react";
import { format } from "date-fns";

export default function Proposals() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [showDialog, setShowDialog] = useState(false);
  const [editingProposal, setEditingProposal] = useState(null);
  const [formData, setFormData] = useState({
    proposal_number: "",
    customer_name: "",
    customer_email: "",
    title: "",
    amount: 0,
    status: "draft",
    valid_until: "",
    sections: [{ title: "Project Overview", content: "" }],
    terms: "",
    notes: ""
  });

  const queryClient = useQueryClient();

  const { data: proposals = [] } = useQuery({
    queryKey: ['proposals'],
    queryFn: () => base44.entities.Proposal.list("-created_date"),
    initialData: [],
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
    initialData: [],
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Proposal.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['proposals'] });
      handleCloseDialog();
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Proposal.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['proposals'] });
      handleCloseDialog();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Proposal.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['proposals'] });
    },
  });

  const handleCloseDialog = () => {
    setShowDialog(false);
    setEditingProposal(null);
    setFormData({
      proposal_number: "",
      customer_name: "",
      customer_email: "",
      title: "",
      amount: 0,
      status: "draft",
      valid_until: "",
      sections: [{ title: "Project Overview", content: "" }],
      terms: "",
      notes: ""
    });
  };

  const handleEdit = (proposal) => {
    setEditingProposal(proposal);
    setFormData({
      proposal_number: proposal.proposal_number || "",
      customer_name: proposal.customer_name || "",
      customer_email: proposal.customer_email || "",
      title: proposal.title || "",
      amount: proposal.amount || 0,
      status: proposal.status || "draft",
      valid_until: proposal.valid_until?.split('T')[0] || "",
      sections: proposal.sections || [{ title: "Project Overview", content: "" }],
      terms: proposal.terms || "",
      notes: proposal.notes || ""
    });
    setShowDialog(true);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.proposal_number && !editingProposal) {
      const proposalNum = `PROP-${Date.now().toString().slice(-8)}`;
      formData.proposal_number = proposalNum;
    }

    if (editingProposal) {
      updateMutation.mutate({ id: editingProposal.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleDelete = (id) => {
    if (window.confirm('Are you sure you want to delete this proposal?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleStatusChange = (proposal, newStatus) => {
    updateMutation.mutate({
      id: proposal.id,
      data: { ...proposal, status: newStatus }
    });
  };

  const addSection = () => {
    setFormData({
      ...formData,
      sections: [...formData.sections, { title: "", content: "" }]
    });
  };

  const updateSection = (index, field, value) => {
    const newSections = [...formData.sections];
    newSections[index][field] = value;
    setFormData({ ...formData, sections: newSections });
  };

  const removeSection = (index) => {
    setFormData({
      ...formData,
      sections: formData.sections.filter((_, i) => i !== index)
    });
  };

  const getStatusIcon = (status) => {
    const icons = {
      'draft': FileText,
      'sent': Send,
      'viewed': Eye,
      'accepted': CheckCircle2,
      'declined': XCircle
    };
    return icons[status] || FileText;
  };

  const getStatusColor = (status) => {
    const colors = {
      'draft': 'bg-gray-100 text-gray-700 border-gray-200',
      'sent': 'bg-blue-100 text-blue-700 border-blue-200',
      'viewed': 'bg-purple-100 text-purple-700 border-purple-200',
      'accepted': 'bg-green-100 text-green-700 border-green-200',
      'declined': 'bg-red-100 text-red-700 border-red-200'
    };
    return colors[status] || 'bg-gray-100 text-gray-700 border-gray-200';
  };

  const filteredProposals = proposals.filter(proposal => {
    const matchesSearch = 
      proposal.proposal_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      proposal.customer_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      proposal.title?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = filterStatus === "all" || proposal.status === filterStatus;
    
    return matchesSearch && matchesStatus;
  });

  const totalProposalValue = proposals
    .filter(p => ['sent', 'viewed', 'accepted'].includes(p.status))
    .reduce((sum, prop) => sum + (prop.amount || 0), 0);

  const acceptedValue = proposals
    .filter(p => p.status === 'accepted')
    .reduce((sum, prop) => sum + (prop.amount || 0), 0);

  const conversionRate = proposals.length > 0 
    ? ((proposals.filter(p => p.status === 'accepted').length / proposals.length) * 100).toFixed(1)
    : 0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Proposals</h1>
          <p className="text-gray-500 mt-1">Create and manage professional proposals</p>
        </div>

        <Dialog open={showDialog} onOpenChange={setShowDialog}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              New Proposal
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingProposal ? 'Edit Proposal' : 'Create New Proposal'}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Proposal Number</Label>
                  <Input
                    value={formData.proposal_number}
                    onChange={(e) => setFormData({...formData, proposal_number: e.target.value})}
                    placeholder="Auto-generated if empty"
                  />
                </div>
                <div>
                  <Label>Status</Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({...formData, status: value})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="sent">Sent</SelectItem>
                      <SelectItem value="viewed">Viewed</SelectItem>
                      <SelectItem value="accepted">Accepted</SelectItem>
                      <SelectItem value="declined">Declined</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Customer Name *</Label>
                  <Input
                    value={formData.customer_name}
                    onChange={(e) => setFormData({...formData, customer_name: e.target.value})}
                    required
                    placeholder="Select or enter customer"
                    list="customers-list"
                  />
                  <datalist id="customers-list">
                    {customers.map((customer) => (
                      <option key={customer.id} value={customer.name} />
                    ))}
                  </datalist>
                </div>
                <div>
                  <Label>Customer Email</Label>
                  <Input
                    type="email"
                    value={formData.customer_email}
                    onChange={(e) => setFormData({...formData, customer_email: e.target.value})}
                    placeholder="customer@example.com"
                  />
                </div>
              </div>

              <div>
                <Label>Proposal Title *</Label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  required
                  placeholder="Complete Roof Replacement Project"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Total Amount *</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                    <Input
                      type="number"
                      step="0.01"
                      value={formData.amount}
                      onChange={(e) => setFormData({...formData, amount: parseFloat(e.target.value)})}
                      required
                      className="pl-10"
                      placeholder="0.00"
                    />
                  </div>
                </div>
                <div>
                  <Label>Valid Until</Label>
                  <Input
                    type="date"
                    value={formData.valid_until}
                    onChange={(e) => setFormData({...formData, valid_until: e.target.value})}
                  />
                </div>
              </div>

              <div className="border-t pt-4">
                <div className="flex justify-between items-center mb-3">
                  <Label className="text-base font-semibold">Proposal Sections</Label>
                  <Button type="button" size="sm" variant="outline" onClick={addSection}>
                    <Plus className="w-3 h-3 mr-1" />
                    Add Section
                  </Button>
                </div>
                
                <div className="space-y-4">
                  {formData.sections.map((section, index) => (
                    <Card key={index} className="bg-gray-50">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex justify-between items-start gap-3">
                          <Input
                            value={section.title}
                            onChange={(e) => updateSection(index, 'title', e.target.value)}
                            placeholder="Section Title"
                            className="font-medium"
                          />
                          {formData.sections.length > 1 && (
                            <Button
                              type="button"
                              size="icon"
                              variant="ghost"
                              onClick={() => removeSection(index)}
                            >
                              <Trash2 className="w-4 h-4 text-red-600" />
                            </Button>
                          )}
                        </div>
                        <Textarea
                          value={section.content}
                          onChange={(e) => updateSection(index, 'content', e.target.value)}
                          rows={4}
                          placeholder="Section content..."
                          className="bg-white"
                        />
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              <div>
                <Label>Terms & Conditions</Label>
                <Textarea
                  value={formData.terms}
                  onChange={(e) => setFormData({...formData, terms: e.target.value})}
                  rows={3}
                  placeholder="Payment terms, warranties, etc..."
                />
              </div>

              <div>
                <Label>Internal Notes</Label>
                <Textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({...formData, notes: e.target.value})}
                  rows={2}
                  placeholder="Notes for internal use only..."
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button type="button" variant="outline" onClick={handleCloseDialog}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingProposal ? 'Update Proposal' : 'Create Proposal'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-blue-700">Total Proposal Value</p>
                <p className="text-3xl font-bold text-blue-900">${totalProposalValue.toFixed(2)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-700">Accepted Value</p>
                <p className="text-3xl font-bold text-green-900">${acceptedValue.toFixed(2)}</p>
              </div>
              <CheckCircle2 className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-purple-700">Win Rate</p>
                <p className="text-3xl font-bold text-purple-900">{conversionRate}%</p>
              </div>
              <FileText className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-white shadow-md">
        <CardHeader>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search proposals..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="sent">Sent</SelectItem>
                <SelectItem value="viewed">Viewed</SelectItem>
                <SelectItem value="accepted">Accepted</SelectItem>
                <SelectItem value="declined">Declined</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b text-left text-sm text-gray-500">
                  <th className="pb-3 font-medium">Proposal #</th>
                  <th className="pb-3 font-medium">Title</th>
                  <th className="pb-3 font-medium">Customer</th>
                  <th className="pb-3 font-medium">Amount</th>
                  <th className="pb-3 font-medium">Status</th>
                  <th className="pb-3 font-medium">Valid Until</th>
                  <th className="pb-3 font-medium">Created</th>
                  <th className="pb-3 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredProposals.map((proposal) => {
                  const StatusIcon = getStatusIcon(proposal.status);
                  return (
                    <tr key={proposal.id} className="border-b hover:bg-gray-50">
                      <td className="py-4 font-medium">{proposal.proposal_number}</td>
                      <td className="py-4 max-w-xs truncate">{proposal.title}</td>
                      <td className="py-4">{proposal.customer_name}</td>
                      <td className="py-4 font-semibold text-green-600">
                        ${proposal.amount?.toFixed(2)}
                      </td>
                      <td className="py-4">
                        <Select
                          value={proposal.status}
                          onValueChange={(value) => handleStatusChange(proposal, value)}
                        >
                          <SelectTrigger className="w-32">
                            <Badge variant="outline" className={`${getStatusColor(proposal.status)} flex items-center gap-1`}>
                              <StatusIcon className="w-3 h-3" />
                              {proposal.status}
                            </Badge>
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="draft">Draft</SelectItem>
                            <SelectItem value="sent">Sent</SelectItem>
                            <SelectItem value="viewed">Viewed</SelectItem>
                            <SelectItem value="accepted">Accepted</SelectItem>
                            <SelectItem value="declined">Declined</SelectItem>
                          </SelectContent>
                        </Select>
                      </td>
                      <td className="py-4 text-sm text-gray-600">
                        {proposal.valid_until ? format(new Date(proposal.valid_until), 'MMM d, yyyy') : '-'}
                      </td>
                      <td className="py-4 text-sm text-gray-600">
                        {format(new Date(proposal.created_date), 'MMM d, yyyy')}
                      </td>
                      <td className="py-4">
                        <div className="flex gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(proposal)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(proposal.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {filteredProposals.length === 0 && (
                  <tr>
                    <td colSpan={8} className="py-12 text-center text-gray-500">
                      <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p>No proposals found</p>
                      <p className="text-sm mt-1">Create your first proposal to get started!</p>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}