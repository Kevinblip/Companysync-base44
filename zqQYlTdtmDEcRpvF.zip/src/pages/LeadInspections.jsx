import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { format } from 'date-fns';
import { Camera, Calendar, MapPin, User, FileText, Eye } from 'lucide-react';

export default function LeadInspections() {
    const navigate = useNavigate();

    const { data: inspections = [], isLoading } = useQuery({
        queryKey: ['allInspections'],
        queryFn: () => base44.entities.InspectionJob.list('-created_date'),
        initialData: [],
    });

    const { data: leads = [] } = useQuery({
        queryKey: ['leads'],
        queryFn: () => base44.entities.Lead.list(),
        initialData: [],
    });

    // Enrich inspections with lead data
    const enrichedInspections = inspections.map(inspection => {
        const lead = leads.find(l => l.id === inspection.related_lead_id);
        return {
            ...inspection,
            leadName: lead?.name || inspection.client_name,
            leadStatus: lead?.status || 'unknown'
        };
    });

    const getStatusColor = (status) => {
        const colors = {
            'pending': 'bg-yellow-100 text-yellow-800 border-yellow-200',
            'assigned': 'bg-blue-100 text-blue-800 border-blue-200',
            'in_progress': 'bg-purple-100 text-purple-800 border-purple-200',
            'completed': 'bg-green-100 text-green-800 border-green-200',
            'cancelled': 'bg-gray-100 text-gray-800 border-gray-200',
        };
        return colors[status] || 'bg-gray-100 text-gray-800 border-gray-200';
    };

    const getPriorityColor = (priority) => {
        const colors = {
            'Low': 'bg-gray-100 text-gray-600',
            'Normal': 'bg-blue-100 text-blue-700',
            'High': 'bg-orange-100 text-orange-700',
            'Urgent': 'bg-red-100 text-red-700',
        };
        return colors[priority] || 'bg-gray-100 text-gray-600';
    };

    if (isLoading) {
        return <div className="p-6 text-center">Loading inspections...</div>;
    }

    return (
        <div className="p-6 space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">Lead Inspections</h1>
                <p className="text-gray-500 mt-1">View all inspections linked to your leads</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {enrichedInspections.map((inspection) => (
                    <Card key={inspection.id} className="hover:shadow-lg transition-shadow">
                        <CardHeader className="pb-3">
                            <div className="flex items-start justify-between">
                                <div className="flex-1">
                                    <CardTitle className="text-lg">{inspection.leadName}</CardTitle>
                                    <div className="flex items-center gap-2 mt-1">
                                        <Badge variant="outline" className={getStatusColor(inspection.status)}>
                                            {inspection.status}
                                        </Badge>
                                        <Badge variant="outline" className={getPriorityColor(inspection.priority)}>
                                            {inspection.priority}
                                        </Badge>
                                    </div>
                                </div>
                                <Camera className="w-5 h-5 text-gray-400" />
                            </div>
                        </CardHeader>
                        <CardContent className="space-y-3">
                            <div className="flex items-start gap-2 text-sm">
                                <MapPin className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                                <span className="text-gray-600">{inspection.property_address}</span>
                            </div>

                            {inspection.scheduled_date && (
                                <div className="flex items-center gap-2 text-sm">
                                    <Calendar className="w-4 h-4 text-gray-400" />
                                    <span className="text-gray-600">
                                        {format(new Date(inspection.scheduled_date), 'MMM d, yyyy')}
                                        {inspection.inspection_time && ` at ${inspection.inspection_time}`}
                                    </span>
                                </div>
                            )}

                            {inspection.assigned_to_email && (
                                <div className="flex items-center gap-2 text-sm">
                                    <User className="w-4 h-4 text-gray-400" />
                                    <span className="text-gray-600">{inspection.assigned_to_email}</span>
                                </div>
                            )}

                            {inspection.damage_type && (
                                <div className="flex items-center gap-2 text-sm">
                                    <FileText className="w-4 h-4 text-gray-400" />
                                    <span className="text-gray-600">{inspection.damage_type}</span>
                                </div>
                            )}

                            <Button 
                                className="w-full mt-3"
                                variant="outline"
                                onClick={() => navigate(createPageUrl('InspectionCapture') + `?id=${inspection.id}`)}
                            >
                                <Eye className="w-4 h-4 mr-2" />
                                View Inspection
                            </Button>
                        </CardContent>
                    </Card>
                ))}
            </div>

            {enrichedInspections.length === 0 && (
                <Card className="p-12 text-center">
                    <Camera className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <h3 className="text-lg font-semibold mb-2">No Inspections Yet</h3>
                    <p className="text-gray-500">Inspections created from leads will appear here</p>
                </Card>
            )}
        </div>
    );
}