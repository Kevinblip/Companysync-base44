import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Plus, Calendar as CalendarIcon, List, Columns, Settings, Trash2, X } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format } from "date-fns";

export default function Tasks() {
  const [showTaskDialog, setShowTaskDialog] = useState(false);
  const [showBoardDialog, setShowBoardDialog] = useState(false);
  const [currentBoard, setCurrentBoard] = useState(null);
  const [viewMode, setViewMode] = useState("kanban");
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    status: "not_started",
    column: "todo",
    priority: "medium",
    start_date: "",
    due_date: "",
    tags: [],
    board_id: ""
  });
  const [boardFormData, setBoardFormData] = useState({
    name: "",
    description: "",
    columns: [
      {id: "todo", name: "To Do", color: "#94a3b8"},
      {id: "in_progress", name: "In Progress", color: "#3b82f6"},
      {id: "done", name: "Done", color: "#10b981"}
    ]
  });

  const queryClient = useQueryClient();

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks'],
    queryFn: () => base44.entities.Task.list("-created_date"),
    initialData: [],
  });

  const { data: boards = [] } = useQuery({
    queryKey: ['task-boards'],
    queryFn: () => base44.entities.TaskBoard.list("-created_date"),
    initialData: [],
  });

  const createTaskMutation = useMutation({
    mutationFn: (data) => base44.entities.Task.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      setShowTaskDialog(false);
      setFormData({
        name: "",
        description: "",
        status: "not_started",
        column: "todo",
        priority: "medium",
        start_date: "",
        due_date: "",
        tags: [],
        board_id: currentBoard?.id || ""
      });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Task.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: (id) => base44.entities.Task.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
    },
  });

  const createBoardMutation = useMutation({
    mutationFn: (data) => base44.entities.TaskBoard.create(data),
    onSuccess: (newBoard) => {
      queryClient.invalidateQueries({ queryKey: ['task-boards'] });
      setShowBoardDialog(false);
      setCurrentBoard(newBoard);
      setBoardFormData({
        name: "",
        description: "",
        columns: [
          {id: "todo", name: "To Do", color: "#94a3b8"},
          {id: "in_progress", name: "In Progress", color: "#3b82f6"},
          {id: "done", name: "Done", color: "#10b981"}
        ]
      });
    },
  });

  const deleteBoardMutation = useMutation({
    mutationFn: (id) => base44.entities.TaskBoard.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['task-boards'] });
      if (currentBoard && boards.length > 0) {
        setCurrentBoard(boards[0]);
      }
    },
  });

  React.useEffect(() => {
    if (!currentBoard && boards.length > 0) {
      const defaultBoard = boards.find(b => b.is_default) || boards[0];
      setCurrentBoard(defaultBoard);
    }
  }, [boards, currentBoard]);

  const handleTaskSubmit = (e) => {
    e.preventDefault();
    createTaskMutation.mutate({
      ...formData,
      board_id: currentBoard?.id || ""
    });
  };

  const handleBoardSubmit = (e) => {
    e.preventDefault();
    createBoardMutation.mutate(boardFormData);
  };

  const handleDragEnd = (result) => {
    if (!result.destination || !currentBoard) return;

    const taskId = result.draggableId;
    const destinationColumn = result.destination.droppableId;
    const task = tasks.find(t => t.id === taskId);

    if (task && task.column !== destinationColumn) {
      updateTaskMutation.mutate({
        id: taskId,
        data: { ...task, column: destinationColumn, order: result.destination.index }
      });
    }
  };

  const addColumnToBoard = () => {
    setBoardFormData({
      ...boardFormData,
      columns: [
        ...boardFormData.columns,
        {
          id: `col_${Date.now()}`,
          name: "New Column",
          color: "#6366f1"
        }
      ]
    });
  };

  const removeColumn = (index) => {
    setBoardFormData({
      ...boardFormData,
      columns: boardFormData.columns.filter((_, i) => i !== index)
    });
  };

  const updateColumn = (index, field, value) => {
    const newColumns = [...boardFormData.columns];
    newColumns[index] = { ...newColumns[index], [field]: value };
    setBoardFormData({ ...boardFormData, columns: newColumns });
  };

  const getStatusColor = (status) => {
    const colors = {
      'job_completed': 'bg-green-100 text-green-700 border-green-200',
      'not_started': 'bg-yellow-100 text-yellow-700 border-yellow-200',
      'in_progress': 'bg-blue-100 text-blue-700 border-blue-200',
    };
    return colors[status] || 'bg-gray-100 text-gray-700 border-gray-200';
  };

  const getPriorityColor = (priority) => {
    const colors = {
      'high': 'bg-red-100 text-red-700',
      'medium': 'bg-orange-100 text-orange-700',
      'low': 'bg-blue-100 text-blue-700',
    };
    return colors[priority] || 'bg-gray-100 text-gray-700';
  };

  const boardTasks = tasks.filter(t => t.board_id === currentBoard?.id);
  const columns = currentBoard?.columns || [];

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Tasks</h1>
          <p className="text-gray-500 mt-1">Manage your tasks with Kanban boards</p>
        </div>

        <div className="flex gap-2">
          <div className="flex gap-1 bg-gray-100 p-1 rounded-lg">
            <Button
              variant={viewMode === "kanban" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("kanban")}
            >
              <Columns className="w-4 h-4 mr-2" />
              Kanban
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
            >
              <List className="w-4 h-4 mr-2" />
              List
            </Button>
          </div>

          <Dialog open={showBoardDialog} onOpenChange={setShowBoardDialog}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Settings className="w-4 h-4 mr-2" />
                Manage Boards
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create New Board</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleBoardSubmit} className="space-y-4">
                <div>
                  <Label>Board Name *</Label>
                  <Input
                    value={boardFormData.name}
                    onChange={(e) => setBoardFormData({...boardFormData, name: e.target.value})}
                    placeholder="Sales Pipeline, Projects, etc."
                    required
                  />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={boardFormData.description}
                    onChange={(e) => setBoardFormData({...boardFormData, description: e.target.value})}
                    rows={2}
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Columns</Label>
                    <Button type="button" variant="outline" size="sm" onClick={addColumnToBoard}>
                      <Plus className="w-4 h-4 mr-1" />
                      Add Column
                    </Button>
                  </div>
                  <div className="space-y-2">
                    {boardFormData.columns.map((col, index) => (
                      <div key={index} className="flex gap-2 items-center">
                        <Input
                          placeholder="Column Name"
                          value={col.name}
                          onChange={(e) => updateColumn(index, 'name', e.target.value)}
                          className="flex-1"
                        />
                        <Input
                          type="color"
                          value={col.color}
                          onChange={(e) => updateColumn(index, 'color', e.target.value)}
                          className="w-20"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => removeColumn(index)}
                          disabled={boardFormData.columns.length <= 2}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="flex justify-end gap-3 pt-4">
                  <Button type="button" variant="outline" onClick={() => setShowBoardDialog(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    Create Board
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>

          <Dialog open={showTaskDialog} onOpenChange={setShowTaskDialog}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Add Task
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Create New Task</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleTaskSubmit} className="space-y-4">
                <div>
                  <Label>Task Name *</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                  />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    rows={3}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Column</Label>
                    <Select value={formData.column} onValueChange={(v) => setFormData({...formData, column: v})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {columns.map(col => (
                          <SelectItem key={col.id} value={col.id}>{col.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Priority</Label>
                    <Select value={formData.priority} onValueChange={(v) => setFormData({...formData, priority: v})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Start Date</Label>
                    <Input
                      type="date"
                      value={formData.start_date}
                      onChange={(e) => setFormData({...formData, start_date: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label>Due Date</Label>
                    <Input
                      type="date"
                      value={formData.due_date}
                      onChange={(e) => setFormData({...formData, due_date: e.target.value})}
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-3">
                  <Button type="button" variant="outline" onClick={() => setShowTaskDialog(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                    Create Task
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {boards.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <Tabs value={currentBoard?.id} onValueChange={(val) => setCurrentBoard(boards.find(b => b.id === val))}>
              <div className="flex items-center justify-between">
                <TabsList className="bg-gray-100">
                  {boards.map(board => (
                    <TabsTrigger key={board.id} value={board.id}>
                      {board.name}
                    </TabsTrigger>
                  ))}
                </TabsList>
                {currentBoard && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      if (window.confirm(`Delete board "${currentBoard.name}"? This won't delete the tasks.`)) {
                        deleteBoardMutation.mutate(currentBoard.id);
                      }
                    }}
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </Button>
                )}
              </div>
            </Tabs>
          </CardContent>
        </Card>
      )}

      {viewMode === "kanban" && currentBoard && (
        <DragDropContext onDragEnd={handleDragEnd}>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {columns.map(column => {
              const columnTasks = boardTasks.filter(t => t.column === column.id);
              return (
                <Droppable key={column.id} droppableId={column.id}>
                  {(provided, snapshot) => (
                    <Card className={snapshot.isDraggingOver ? 'ring-2 ring-blue-400' : ''}>
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-3 h-3 rounded-full"
                              style={{ backgroundColor: column.color }}
                            />
                            <h3 className="font-semibold">{column.name}</h3>
                          </div>
                          <Badge variant="outline">{columnTasks.length}</Badge>
                        </div>
                        <div
                          ref={provided.innerRef}
                          {...provided.droppableProps}
                          className="space-y-2 min-h-[400px]"
                        >
                          {columnTasks.map((task, index) => (
                            <Draggable key={task.id} draggableId={task.id} index={index}>
                              {(provided, snapshot) => (
                                <div
                                  ref={provided.innerRef}
                                  {...provided.draggableProps}
                                  {...provided.dragHandleProps}
                                  className={`bg-white p-3 rounded-lg border shadow-sm hover:shadow-md transition-shadow ${
                                    snapshot.isDragging ? 'ring-2 ring-blue-400 shadow-lg' : ''
                                  }`}
                                >
                                  <div className="flex items-start justify-between mb-2">
                                    <h4 className="font-medium text-sm flex-1">{task.name}</h4>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-6 w-6 -mt-1 -mr-1"
                                      onClick={() => {
                                        if (window.confirm('Delete this task?')) {
                                          deleteTaskMutation.mutate(task.id);
                                        }
                                      }}
                                    >
                                      <Trash2 className="w-3 h-3 text-gray-400 hover:text-red-600" />
                                    </Button>
                                  </div>
                                  {task.description && (
                                    <p className="text-xs text-gray-600 mb-2 line-clamp-2">{task.description}</p>
                                  )}
                                  <div className="flex items-center gap-2 flex-wrap">
                                    <Badge className={getPriorityColor(task.priority)} variant="outline">
                                      {task.priority}
                                    </Badge>
                                    {task.due_date && (
                                      <div className="flex items-center gap-1 text-xs text-gray-500">
                                        <CalendarIcon className="w-3 h-3" />
                                        {format(new Date(task.due_date), 'MMM d')}
                                      </div>
                                    )}
                                  </div>
                                  {task.tags && task.tags.length > 0 && (
                                    <div className="flex gap-1 mt-2 flex-wrap">
                                      {task.tags.map((tag, i) => (
                                        <Badge key={i} variant="outline" className="text-xs">
                                          {tag}
                                        </Badge>
                                      ))}
                                    </div>
                                  )}
                                </div>
                              )}
                            </Draggable>
                          ))}
                          {provided.placeholder}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </Droppable>
              );
            })}
          </div>
        </DragDropContext>
      )}

      {viewMode === "list" && (
        <Card className="bg-white shadow-md">
          <CardContent className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b text-left text-sm text-gray-500">
                    <th className="pb-3 font-medium">Task Name</th>
                    <th className="pb-3 font-medium">Status</th>
                    <th className="pb-3 font-medium">Priority</th>
                    <th className="pb-3 font-medium">Due Date</th>
                    <th className="pb-3 font-medium">Tags</th>
                    <th className="pb-3 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {boardTasks.map((task) => (
                    <tr key={task.id} className="border-b hover:bg-gray-50">
                      <td className="py-4">
                        <div>
                          <div className="font-medium">{task.name}</div>
                          {task.description && (
                            <div className="text-sm text-gray-500 mt-1">{task.description}</div>
                          )}
                        </div>
                      </td>
                      <td className="py-4">
                        <Badge variant="outline" className={getStatusColor(task.status)}>
                          {task.status?.replace(/_/g, ' ')}
                        </Badge>
                      </td>
                      <td className="py-4">
                        <Badge className={getPriorityColor(task.priority)}>
                          {task.priority}
                        </Badge>
                      </td>
                      <td className="py-4 text-sm text-gray-600">
                        {task.due_date ? (
                          <div className="flex items-center gap-2">
                            <CalendarIcon className="w-4 h-4 text-gray-400" />
                            {format(new Date(task.due_date), 'MMM d, yyyy')}
                          </div>
                        ) : '-'}
                      </td>
                      <td className="py-4">
                        {task.tags?.map((tag, i) => (
                          <Badge key={i} variant="outline" className="bg-blue-50 text-blue-700 border-blue-200 mr-1">
                            {tag}
                          </Badge>
                        ))}
                      </td>
                      <td className="py-4">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            if (window.confirm('Delete this task?')) {
                              deleteTaskMutation.mutate(task.id);
                            }
                          }}
                        >
                          <Trash2 className="w-4 h-4 text-gray-400 hover:text-red-600" />
                        </Button>
                      </td>
                    </tr>
                  ))}
                  {boardTasks.length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-gray-500">
                        No tasks in this board yet
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {boards.length === 0 && (
        <Card className="bg-white shadow-md">
          <CardContent className="p-12 text-center text-gray-500">
            <Columns className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-semibold mb-2">No Boards Yet</h3>
            <p className="mb-4">Create your first board to start organizing tasks</p>
            <Button onClick={() => setShowBoardDialog(true)} className="bg-blue-600 hover:bg-blue-700">
              <Plus className="w-4 h-4 mr-2" />
              Create First Board
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}