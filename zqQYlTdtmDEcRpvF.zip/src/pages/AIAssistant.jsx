
/**
 * LEXI AI ASSISTANT - OPTIMIZED VERSION
 * 
 * Cost Optimization Strategy:
 * - Uses GPT-4o-mini for 90% of queries ($0.0005/1K tokens vs $0.01/1K tokens)
 * - Falls back to GPT-4o only for complex tasks
 * - Implements smart caching for price lists and templates
 * - Expected cost reduction: 80-90%
 * 
 * BACKUP VERSION: See pages/AIAssistant-GPT4o-Full.js for original full GPT-4o version
 */

import React, { useState, useRef, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Send, Bot, User, Loader2, Sparkles, Mic, Paperclip, Phone, StopCircle, X, CheckCircle, Calendar, UserPlus, Briefcase, FileText, ScrollText, TrendingUp, Target, ShieldCheck, UploadCloud } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import ProposedEventCard from '../components/scheduling/ProposedEventCard';

export default function AIAssistant() {
  const DEFAULT_LEXI_PHOTO_URL = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/68eba3445754d69c10afd77e/052fc8435_download51lexi.jpeg";

  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isListeningForWakeWord, setIsListeningForWakeWord] = useState(false);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [attachedFiles, setAttachedFiles] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(true);
  const [isUploadingAvatar, setIsUploadingAvatar] = useState(false);
  const [sessionId, setSessionId] = useState(null); // NEW: State for current conversation session ID
  const mediaRecorderRef = useRef(null);
  const currentTranscriptRef = useRef('');
  const fileInputRef = useRef(null);
  const avatarFileInputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const wakeWordRecognitionRef = useRef(null);
  const isProcessingWakeWordRef = useRef(false); // NEW: prevent double-triggering

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(false);
  const audioRef = useRef(null); // Ref for the audio element from ElevenLabs

  // Cached data (refreshes every 5 minutes)
  const [cachedPriceList, setCachedPriceList] = useState([]);
  const [cachedTemplates, setCachedTemplates] = useState({ email: [], sms: [] });
  const [lastCacheTime, setLastCacheTime] = useState(null);

  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
  });

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
    enabled: !!user,
  });

  const myCompany = React.useMemo(() => companies.find(c => c.created_by === user?.email), [companies, user?.email]);
  
  // FIX: Use useMemo to ensure stable avatar URL
  const lexiPhotoUrl = React.useMemo(() => {
    return myCompany?.lexi_avatar_url || DEFAULT_LEXI_PHOTO_URL;
  }, [myCompany?.lexi_avatar_url]);

  const { data: invoices = [] } = useQuery({
    queryKey: ['invoices'],
    queryFn: () => base44.entities.Invoice.list("-created_date", 1000),
    enabled: !!user,
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list("-created_date", 1000),
    enabled: !!user,
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks'],
    queryFn: () => base44.entities.Task.list("-created_date", 1000),
    enabled: !!user,
  });

  const { data: calendarEvents = [] } = useQuery({
    queryKey: ['calendar-events-initial'],
    queryFn: () => base44.entities.CalendarEvent.list("-start_time", 1000),
    enabled: !!user,
  });

  // NEW: Generate a unique session ID when the component mounts
  useEffect(() => {
    setSessionId(`lexi-session-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`);
  }, []);

  const eventCreateMutation = useMutation({
      mutationFn: (eventData) => base44.entities.CalendarEvent.create({
          title: eventData.title,
          description: eventData.description || '',
          start_time: eventData.start_time,
          end_time: eventData.end_time || eventData.start_time, // If end_time not provided, use start_time
          event_type: eventData.event_type || 'reminder',
          location: eventData.location || eventData.related_to || '', // Use 'location' or fallback to 'related_to'
          assigned_to: eventData.assigned_to || user?.email, // Added assigned_to from outline
          status: 'scheduled',
          send_email_notification: eventData.send_email_notification !== undefined ? eventData.send_email_notification : true,
          send_sms_notification: eventData.send_sms_notification === true, // Added send_sms_notification from outline
          send_browser_notification: eventData.send_browser_notification !== undefined ? eventData.send_browser_notification : true,
          related_customer: eventData.related_customer || '', // Added related_customer from outline
          related_lead: eventData.related_lead || '', // Added related_lead from outline
          related_project: eventData.related_project || '' // Added related_project from outline
      }),
      onSuccess: (createdEvent, variables) => { // variables contains the original eventData passed to mutate, including _messageIndex and tempId
          queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
          queryClient.invalidateQueries({ queryKey: ['calendar-events-initial'] });
          queryClient.invalidateQueries({ queryKey: ['reminders'] });

          setMessages(prev => {
              const newMessages = [...prev];
              const messageIdxToUpdate = variables._messageIndex; 

              if (messageIdxToUpdate !== undefined && newMessages[messageIdxToUpdate]) {
                  const messageToUpdate = { ...newMessages[messageIdxToUpdate] };
                  messageToUpdate.pendingActions = messageToUpdate.pendingActions.filter(action => 
                    !(action.type === 'create_calendar_event' && action.data.tempId === variables.tempId)
                  );
                  
                  if (messageToUpdate.pendingActions.length === 0) {
                      messageToUpdate.confirmationHandled = true;
                      messageToUpdate.pendingActions = null;
                  }
                  newMessages[messageIdxToUpdate] = messageToUpdate;
              }
              
              const successMessage = `✅ Event "${createdEvent.title}" successfully scheduled for ${new Date(createdEvent.start_time).toLocaleString()}.`;
              
              if (autoSpeak) {
                speakText(successMessage);
              } else if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
                setTimeout(() => startWakeWordListening(), 1000);
              }

              return [...newMessages, { 
                role: "assistant", 
                content: successMessage, 
                timestamp: new Date().toISOString()
              }];
          });
      },
      onError: (error, variables) => { // variables here will also contain _messageIndex and tempId
          setMessages(prev => {
            const newMessages = [...prev];
            const errorMessage = `❌ Failed to schedule event "${variables.title || 'Unknown Event'}": ${error.message}`;

            const messageIdxToUpdate = variables._messageIndex;
            if (messageIdxToUpdate !== undefined && newMessages[messageIdxToUpdate]) {
                const messageToUpdate = { ...newMessages[messageIdxToUpdate] };
                // Remove the failed event from pendingActions to allow user to retry or propose new events
                messageToUpdate.pendingActions = messageToUpdate.pendingActions.filter(action => 
                  !(action.type === 'create_calendar_event' && action.data.tempId === variables.tempId)
                );
                if (messageToUpdate.pendingActions.length === 0) {
                  messageToUpdate.confirmationHandled = true;
                  messageToUpdate.pendingActions = null;
                }
                newMessages[messageIdxToUpdate] = messageToUpdate;
            }
            
            if (autoSpeak) {
              speakText(errorMessage);
            } else if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
              setTimeout(() => startWakeWordListening(), 1000);
            }

            return [...newMessages, { 
              role: "assistant", 
              content: errorMessage, 
              timestamp: new Date().toISOString() 
            }];
          });
      }
  });
  
  const scrollToBottom = () => {
    try {
      if (messagesEndRef.current) {
        messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
      }
    } catch (error) {
      console.warn('Scroll error (non-critical):', error);
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Generate personalized greeting when user loads
  useEffect(() => {
    if (user && messages.length === 0) {
      const greeting = `👋 Hi ${user.full_name?.split(' ')[0] || 'there'}! I'm Lexi, your AI assistant. I have full access to your CRM and can help with anything. What can I do for you today?`;
      setMessages([{ role: "assistant", content: greeting }]);
    }
  }, [user, messages.length]); // Add messages.length to dependencies to re-evaluate when messages change

  // Cache price lists and templates
  useEffect(() => {
    const loadCachedData = async () => {
      try {
        const now = Date.now();
        // Refresh cache every 5 minutes
        if (!lastCacheTime || (now - lastCacheTime) > 300000) {
          console.log('🔄 Refreshing cache...');
          
          const [priceList, emailTemplates, smsTemplates] = await Promise.all([
            base44.entities.PriceListItem.list("-created_date", 100).catch(() => []),
            base44.entities.EmailTemplate.list("-created_date", 50).catch(() => []),
            base44.entities.SMSTemplate.list("-created_date", 50).catch(() => [])
          ]);

          setCachedPriceList(priceList);
          setCachedTemplates({ email: emailTemplates, sms: smsTemplates });
          setLastCacheTime(now);
          console.log('✅ Cache refreshed');
        }
      } catch (error) {
        console.warn('Cache refresh error:', error);
      }
    };

    if (user) {
      loadCachedData();
    }
  }, [user, lastCacheTime]);

  // Check reminders
  useEffect(() => {
    const checkForReminders = async () => {
      try {
        const response = await base44.functions.invoke('checkReminders');
        if (response.data.notifications_sent > 0) {
          console.log(`🔔 ${response.data.notifications_sent} reminder(s) sent`);
          queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
          queryClient.invalidateQueries({ queryKey: ['reminders'] });
        }
      } catch (error) {
        console.warn('Failed to check reminders (non-critical):', error);
      }
    };

    checkForReminders();
    const interval = setInterval(checkForReminders, 60000); // Check every minute
    return () => clearInterval(interval);
  }, [queryClient]);

  // Notification permission
  useEffect(() => {
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().then(permission => {
        console.log('📬 Notification permission:', permission);
      });
    }
  }, []);

  const speakText = async (text) => {
    try {
      // Stop any current speech (browser or ElevenLabs)
      stopSpeaking(); 
      
      setIsSpeaking(true);
      
      console.log('🎙️ Generating speech with ElevenLabs (Bella)...');
      
      // Call ElevenLabs backend function with Bella voice
      const response = await base44.functions.invoke('elevenLabsSpeak', {
        text: text,
        voiceId: 'EXAVITQu4vr4xnSDxMaL' // Bella - warm, conversational female voice
      });

      // Check if we should fallback to browser speech
      if (response.data?.fallback || !response.data) {
        console.warn('⚠️ Falling back to browser speech...');
        throw new Error('Using browser fallback');
      }

      // Create audio from response
      const audioBlob = new Blob([response.data], { type: 'audio/mpeg' });
      const audioUrl = URL.createObjectURL(audioBlob);
      
      // Play audio
      const audio = new Audio(audioUrl);
      audioRef.current = audio;
      
      audio.onended = () => {
        setIsSpeaking(false);
        URL.revokeObjectURL(audioUrl);
        
        // Restart wake word listening after speaking finishes
        if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
          setTimeout(() => startWakeWordListening(), 1000);
        }
      };
      
      audio.onerror = (error) => {
        console.error('Audio playback error:', error);
        setIsSpeaking(false);
        URL.revokeObjectURL(audioUrl);
        
        // Restart wake word listening even on error
        if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
          setTimeout(() => startWakeWordListening(), 1000);
        }
      };
      
      await audio.play();
      
      console.log('✅ Playing ElevenLabs audio (Bella)');
      
    } catch (error) {
      console.error('❌ ElevenLabs speech error:', error.message);
      setIsSpeaking(false);
      
      // Fallback to browser speech synthesis
      console.log('⚠️ Falling back to browser speech...');
      if ('speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
          
          const utterance = new SpeechSynthesisUtterance(text);
          utterance.rate = 0.95;
          utterance.pitch = 1.1;
          utterance.volume = 1.0;
          
          const voices = window.speechSynthesis.getVoices();
          const femaleVoice = voices.find(voice => 
            voice.name.includes('Google US English Female') ||
            voice.name.includes('Samantha') ||
            (voice.name.toLowerCase().includes('female') && voice.lang.startsWith('en'))
          );
          
          if (femaleVoice) {
            utterance.voice = femaleVoice;
          }
          
          utterance.onstart = () => setIsSpeaking(true);
          utterance.onend = () => {
            setIsSpeaking(false);
            if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
              setTimeout(() => startWakeWordListening(), 1000);
            }
          };
          utterance.onerror = () => {
            setIsSpeaking(false);
            if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
              setTimeout(() => startWakeWordListening(), 1000);
            }
          };
          
          window.speechSynthesis.speak(utterance);
        } catch (fallbackError) {
          console.error('Browser speech also failed:', fallbackError);
          setIsSpeaking(false);
        }
      }
    }
  };

  const stopSpeaking = () => {
    try {
      // Stop ElevenLabs audio if playing
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current.currentTime = 0; // Reset playback position
        audioRef.current = null;
      }
      // Stop browser speech synthesis if speaking
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setIsSpeaking(false); // Ensure speaking state is false
    } catch (error) {
      console.warn("Error stopping speech (non-critical):", error);
    }
  };

  // Wake word detection - FIXED VERSION
  const startWakeWordListening = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      alert('Wake word detection is not supported in your browser. Please use Chrome, Edge, or Safari.');
      return;
    }

    // Stop any existing recognition first
    if (wakeWordRecognitionRef.current) {
      try {
        wakeWordRecognitionRef.current.stop();
      } catch (e) {
        // Ignore errors when stopping
      }
      wakeWordRecognitionRef.current = null;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event) => {
      // Skip if already processing a wake word
      if (isProcessingWakeWordRef.current) {
        return;
      }

      const transcript = Array.from(event.results)
        .map(result => result[0].transcript)
        .join('')
        .toLowerCase();

      // Check for wake words
      if (transcript.includes('hey lexi') || 
          transcript.includes('hey lexy') || 
          transcript.includes('ok lexi') ||
          transcript.includes('okay lexi')) {
        console.log('🎤 Wake word detected!');
        
        // Set processing flag
        isProcessingWakeWordRef.current = true;
        
        // Stop wake word listening
        try {
          recognition.stop();
        } catch (e) {
          // Ignore
        }
        
        stopSpeaking();
        
        // Visual feedback
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: '🎤 **Listening...**',
          timestamp: new Date().toISOString()
        }]);
        
        // Start recording the actual command after a short delay
        setTimeout(() => {
          startRecording(true); // Pass true to indicate wake word activation
        }, 800);
      }
    };

    recognition.onerror = (event) => {
      // Only log non-aborted errors
      if (event.error !== 'aborted' && event.error !== 'no-speech') {
        console.error('Wake word recognition error:', event.error);
      }
      
      // Only restart if still supposed to be listening AND not processing a wake word
      if (isListeningForWakeWord && !isProcessingWakeWordRef.current && event.error !== 'aborted') {
        setTimeout(() => {
          try {
            recognition.start();
          } catch (e) {
            // Ignore
          }
        }, 1000);
      }
    };

    recognition.onend = () => {
      console.log('👂 Wake word recognition ended');
      
      // Only restart if still supposed to be listening AND not processing a wake word
      if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
        setTimeout(() => {
          try {
            recognition.start();
            console.log('👂 Wake word recognition restarted');
          } catch (e) {
            // Ignore
          }
        }, 1000);
      }
    };

    wakeWordRecognitionRef.current = recognition;
    
    try {
      recognition.start();
      setIsListeningForWakeWord(true);
      console.log('👂 Wake word listening started...');
    } catch (e) {
      console.error('Failed to start wake word recognition:', e);
    }
  };

  const stopWakeWordListening = () => {
    isProcessingWakeWordRef.current = false; // Reset processing flag
    
    if (wakeWordRecognitionRef.current) {
      try {
        wakeWordRecognitionRef.current.stop();
      } catch (e) {
        console.warn('Error stopping wake word recognition:', e);
      }
      wakeWordRecognitionRef.current = null;
    }
    setIsListeningForWakeWord(false);
    console.log('👂 Wake word listening stopped');
  };

  const executeActions = async (actions) => {
    const results = [];
    
    console.log('🎬 Starting to execute', actions.length, 'actions');
    
    for (const action of actions) {
      try {
        if (action.type === 'create_calendar_event') {
          // This type of action is handled by eventCreateMutation through handleConfirmEvent
          // This block should ideally not be reached if handled via ProposedEventCard
          results.push(`⚠️ Calendar event creation for "${action.data.title}" should be handled by confirmation card.`);
        }
        else if (action.type === 'update_calendar_event') {
          if (!action.id) {
            results.push(`❌ Failed to update calendar event: 'id' is required`);
            continue;
          }
          const event = await base44.entities.CalendarEvent.update(action.id, action.data);
          results.push(`✅ Updated calendar event: "${event.title}"`);
          queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
          queryClient.invalidateQueries({ queryKey: ['calendar-events-initial'] });
        }
        else if (action.type === 'delete_calendar_event') {
          const eventId = action.id || action.data?.id; // Allow id to be directly on action or nested under data
          if (!eventId) {
            results.push(`❌ Failed to delete calendar event: 'id' is required`);
            continue;
          }
          await base44.entities.CalendarEvent.delete(eventId);
          results.push(`✅ Deleted calendar event with ID: ${eventId}.`); // More specific message for confirmation
          queryClient.invalidateQueries({ queryKey: ['calendar-events'] });
          queryClient.invalidateQueries({ queryKey: ['calendar-events-initial'] });
        }
        else if (action.type === 'create_lead') {
          const lead = await base44.entities.Lead.create({
            name: action.data.name,
            email: action.data.email || '',
            phone: action.data.phone || '',
            company: action.data.company || '',
            street: action.data.street || '',
            city: action.data.city || '',
            state: action.data.state || '',
            zip: action.data.zip || '',
            status: action.data.status || 'new',
            source: action.data.source || 'lexi_ai', 
            lead_source: action.data.lead_source || 'Created by Lexi AI Assistant',
            notes: action.data.notes || '',
            assigned_to: action.data.assigned_to || user?.email
          });
          results.push(`✅ Created lead: ${lead.name} (${lead.status})`);
          queryClient.invalidateQueries({ queryKey: ['leads'] });
        }
        else if (action.type === 'update_lead') {
          if (!action.id) {
              results.push(`❌ Failed to update lead: 'id' is required`);
              continue;
          }
          const lead = await base44.entities.Lead.update(action.id, action.data);
          results.push(`✅ Updated lead: ${lead.name}`);
          queryClient.invalidateQueries({ queryKey: ['leads'] });
        }
        else if (action.type === 'create_customer') {
          const customer = await base44.entities.Customer.create({
            name: action.data.name,
            email: action.data.email || '',
            phone: action.data.phone || '',
            company: action.data.company || '',
            street: action.data.street || '',
            city: action.data.city || '',
            state: action.data.state || '',
            zip: action.data.zip || '',
            source: action.data.source || 'lexi_ai',
            notes: action.data.notes || ''
          });
          results.push(`✅ Created customer: ${customer.name}`);
          queryClient.invalidateQueries({ queryKey: ['customers'] });
        }
        else if (action.type === 'update_customer') {
          if (!action.id) {
              results.push(`❌ Failed to update customer: 'id' is required`);
              continue;
          }
          const customer = await base44.entities.Customer.update(action.id, action.data);
          results.push(`✅ Updated customer: ${customer.name}`);
          queryClient.invalidateQueries({ queryKey: ['customers'] });
        }
        else if (action.type === 'create_task') {
          const task = await base44.entities.Task.create({
            name: action.data.name || action.data.title,
            description: action.data.description || '',
            priority: action.data.priority || 'medium',
            status: action.data.status || 'not_started',
            due_date: action.data.due_date || null,
            assigned_to: action.data.assigned_to || user?.email,
            related_to: action.data.related_to || ''
          });
          results.push(`✅ Created task: ${task.name}`);
          queryClient.invalidateQueries({ queryKey: ['tasks'] });
        }
        else if (action.type === 'send_email') {
          await base44.integrations.Core.SendEmail({
            to: action.data.to,
            subject: action.data.subject,
            body: action.data.body,
            from_name: action.data.from_name || myCompany?.company_name || 'AI CRM Pro'
          });
          results.push(`✅ Sent email to ${action.data.to}`);
        }
        else if (action.type === 'send_sms') {
          await base44.functions.invoke('sendSMS', {
            to: action.data.to,
            message: action.data.body,
            contactName: action.data.contact_name
          });
          results.push(`✅ Sent SMS to ${action.data.to}`);
        }
        else if (action.type === 'log_communication') {
          const comm = await base44.entities.Communication.create(action.data);
          results.push(`✅ Logged communication with ${comm.contact_name}`);
          queryClient.invalidateQueries({ queryKey: ['communications'] });
        }
        else if (action.type === 'create_estimate') {
          const estimate = await base44.entities.Estimate.create(action.data);
          results.push(`✅ Created estimate ${estimate.estimate_number} for ${estimate.customer_name} - Total: $${estimate.amount.toFixed(2)}`);
          queryClient.invalidateQueries({ queryKey: ['estimates'] });
        }
        else if (action.type === 'create_invoice') {
          const invoice = await base44.entities.Invoice.create(action.data);
          results.push(`✅ Created invoice ${invoice.invoice_number} for ${invoice.customer_name} - Total: $${invoice.amount.toFixed(2)}`);
          queryClient.invalidateQueries({ queryKey: ['invoices'] });
        }
        else if (action.type === 'create_proposal') {
          const proposal = await base44.entities.Proposal.create(action.data);
          results.push(`✅ Created proposal ${proposal.proposal_number || proposal.id} for ${proposal.customer_name || 'a customer'} - Total: $${proposal.amount ? proposal.amount.toFixed(2) : '0.00'}`);
          queryClient.invalidateQueries({ queryKey: ['proposals'] });
        }
      } catch (error) {
        console.error(`❌ Failed to execute ${action.type}:`, error);
        results.push(`❌ Failed to ${action.type}: ${error.message}`);
      }
    }
    
    return results.join('\n');
  };

  const quickSuggestions = [
    { icon: "📅", text: "Schedule a meeting tomorrow at 2pm", category: "calendar" },
    { icon: "👥", text: "Show me my hottest leads", category: "leads" },
    { icon: "💰", text: "What's my total revenue this month?", category: "analytics" },
    { icon: "📧", text: "Send follow-up email to recent leads", category: "communication" },
    { icon: "📊", text: "Create a sales report", category: "reports" },
    { icon: "✅", text: "What tasks are due today?", category: "tasks" }
  ];

  const handleSendMessage = async (textToSend = null, autoSpeakResponse = false) => {
    try {
      stopSpeaking(); 

      const messageText = textToSend || input;
      if (!messageText.trim() && attachedFiles.length === 0) return;

      const userMessage = { role: "user", content: messageText };
      setMessages(prev => [...prev, userMessage]);
      setInput("");
      setShowSuggestions(false);
      currentTranscriptRef.current = '';
      setLoading(true);

      // Build context
      const userContext = {
        name: user?.full_name || 'User',
        email: user?.email || '',
        role: user?.role || 'user',
        company_name: myCompany?.company_name || 'Your Company',
        company_id: myCompany?.id || null,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
        current_browser_time: new Date().toISOString(),
      };

      // Get CRM summary
// Removed the complex and slow logic for pre-fetching and filtering leads, tasks, and calendar events.
// This data is now fetched on demand in the backend function (lexiChat.js) if needed,
// or the frontend relies on the cached data (customers, leads, price list, templates)
// for context, which is much faster.

      // Build conversation history
      const conversationHistory = (messages || []).slice(-6).map(m => ({
        role: m.role,
        content: m.content
      }));

      conversationHistory.push({
        role: 'user',
        content: messageText
      });

      // GIVE LEXI UNLIMITED ACCESS - Remove all limits
      // Use cached data for context, which is pre-fetched and much faster.
      // The backend function will handle fetching other data if needed.
      const context = {
        user: userContext,
        price_list: cachedPriceList || [],
        email_templates: (cachedTemplates?.email || []).map(t => ({ name: t.template_name, subject: t.subject, content: t.body, category: t.category })),
        sms_templates: (cachedTemplates?.sms || []).map(t => ({ name: t.template_name, content: t.message, category: t.category })),
        // Use cached customer/lead data
        all_customers: cachedCustomers.map(c => ({
          id: c.id,
          customer_number: c.customer_number,
          name: c.name,
          email: c.email,
          phone: c.phone,
          phone_2: c.phone_2,
          company: c.company,
          address: `${c.street || ''} ${c.city || ''} ${c.state || ''} ${c.zip || ''}`.trim(),
          street: c.street,
          city: c.city,
          state: c.state,
          zip: c.zip,
          notes: c.notes
        })),
        all_leads: cachedLeads.map(l => ({
          id: l.id,
          name: l.name,
          email: l.email,
          phone: l.phone,
          phone_2: l.phone_2,
          company: l.company,
          status: l.status,
          value: l.value,
          notes: l.notes,
          assigned_to: l.assigned_to,
          address: `${l.street || ''} ${l.city || ''} ${l.state || ''} ${l.zip || ''}`.trim()
        })),
        // Removed other data points to reduce payload size and speed up the request
      };

      console.log('🤖 Calling lexiChat...');
      
      const payload = {
        messages: conversationHistory,
        context: context
      };
      
      if (attachedFiles.length > 0) {
        payload.file_urls = attachedFiles.map(f => f.url);
      }

      console.log('📦 Payload:', JSON.stringify(payload).substring(0, 500));

      const response = await base44.functions.invoke('lexiChat', payload);

      console.log('✅ Response:', response.data);

      if (!response.data || !response.data.success) {
        throw new Error(response.data?.error || 'Failed to get response from Lexi');
      }

      let assistantMessage = response.data.response;
      const allActions = response.data.actions || [];
      const insights = response.data.insights || [];

      // Define actions that need user confirmation
      const confirmableActionTypes = ['send_email', 'send_sms', 'create_calendar_event'];
      const confirmableActions = (allActions || []).filter(a => confirmableActionTypes.includes(a.type));
      const otherActions = (allActions || []).filter(a => !confirmableActionTypes.includes(a.type));

      if (insights.length > 0) {
        assistantMessage += "\n\n💡 **Key Insights:**\n" + insights.map(i => `• ${i}`).join('\n');
      }

      // Immediately execute non-confirmable actions
      if (otherActions.length > 0) {
        console.log('🎬 Executing non-confirmable actions immediately...');
        const otherActionResults = await executeActions(otherActions);
        assistantMessage += "\n\n" + otherActionResults;
      }
      
      const newAssistantMessage = { 
        role: "assistant", 
        content: assistantMessage,
        insights: insights,
        timestamp: new Date().toISOString(),
        pendingActions: confirmableActions.length > 0 ? confirmableActions : null,
        confirmationHandled: false,
      };

      setMessages(prev => [...prev, newAssistantMessage]);

      // NEW: Save conversation to history
      if (user && sessionId) {
          const recordsToSave = [
              {
                  user_email: user.email,
                  ai_assistant: 'lexi',
                  session_id: sessionId,
                  message_role: 'user',
                  message_content: messageText,
              },
              {
                  user_email: user.email,
                  ai_assistant: 'lexi',
                  session_id: sessionId,
                  message_role: 'assistant',
                  message_content: newAssistantMessage.content,
                  extracted_insights: newAssistantMessage.insights || [],
              }
          ];

          try {
              await base44.entities.ConversationHistory.bulkCreate(recordsToSave);
              console.log('✅ Conversation saved to history');
          } catch (saveError) {
              console.warn('Could not save conversation history:', saveError);
          }
      }
      
      // AFTER sending message, reset wake word processing flag
      isProcessingWakeWordRef.current = false;

      // Determine if auto-speak is active
      const shouldSpeak = autoSpeakResponse || autoSpeak; 
      const shouldRestartWakeWord = isListeningForWakeWord;

      // Only auto-speak the initial message if no pending actions
      if (shouldSpeak && !newAssistantMessage.pendingActions) {
        try {
          await speakText(assistantMessage);
        } catch (error) {
          console.error("Error auto-speaking:", error);
          await speakText(`Sorry, I had trouble speaking that out loud. ${assistantMessage}`);
        }
      } else if (shouldRestartWakeWord) { 
          if (isListeningForWakeWord && !isProcessingWakeWordRef.current) { 
            startWakeWordListening();
          }
      }
      
      setAttachedFiles([]);
    } catch (error) {
      console.error('💥 AI Error:', error);
      
      let errorMsg = 'Sorry, I encountered an error. Please try again.';
      
      if (error.message.includes('Unauthorized') || error.message.includes('401')) {
        errorMsg = 'Please log in to use Lexi AI.';
      } else if (error.message) {
        errorMsg = error.message;
      }
      
      setMessages(prev => [...prev, { 
        role: "assistant", 
        content: errorMsg,
        timestamp: new Date().toISOString()
      }]);
      
      const shouldSpeakError = autoSpeakResponse || autoSpeak;
      const shouldRestartWakeWordOnError = isListeningForWakeWord;

      if (shouldSpeakError) {
        try {
          await speakText(errorMsg);
        } catch (e) {
          console.error("Error speaking error message:", e);
        }
      } else if (shouldRestartWakeWordOnError) {
          isProcessingWakeWordRef.current = false;
          if (isListeningForWakeWord && !isProcessingWakeWordRef.current) { 
            startWakeWordListening();
          }
      }
    }

    setLoading(false);
  };

  // Pass messageIndex and the specific action object for identification
  const handleConfirmEvent = (messageIndex, action) => {
    // Ensure action.data has proper date
    const eventData = action.data;
    
    // Validate and fix date if needed
    let startTime = eventData.start_time;
    try {
      const testDate = new Date(startTime);
      if (isNaN(testDate.getTime())) {
        // Invalid date - use tomorrow at 10am
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        tomorrow.setHours(10, 0, 0, 0);
        startTime = tomorrow.toISOString();
        console.warn('⚠️ Fixed invalid date to:', startTime);
      }
    } catch (e) {
      // Error parsing - use tomorrow at 10am
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(10, 0, 0, 0);
      startTime = tomorrow.toISOString();
      console.error('❌ Date parsing error, using fallback:', startTime);
    }
    
    const eventDataWithTempId = { 
      ...eventData,
      start_time: startTime,
      _messageIndex: messageIndex, // Pass message index for tracking
      tempId: eventData.tempId || `temp-${Date.now()}-${Math.random().toString(36).substring(2, 9)}` // Generate if not present
    };
    
    eventCreateMutation.mutate(eventDataWithTempId);
  };

  const handleConfirmation = async (messageIndex, isConfirmed) => {
    // Optimistic UI update: Mark the relevant actions as handled immediately
    // and queue the actual execution/cancellation.
    let sendingActionsToHandle = [];
    setMessages(prev => {
        const newMessages = [...prev];
        if (newMessages[messageIndex]) {
            const messageToUpdate = { ...newMessages[messageIndex] };
            
            // Separate actions into those being handled by THIS function (sending: email/sms)
            // and those that are not (e.g., calendar events will be handled by ProposedEventCard)
            const remainingPendingActions = [];
            for (const action of messageToUpdate.pendingActions || []) {
                if (action.type === 'send_email' || action.type === 'send_sms') {
                    sendingActionsToHandle.push(action); // Collect these to process later
                } else {
                    remainingPendingActions.push(action); // Keep other types (like calendar events)
                }
            }
            
            messageToUpdate.pendingActions = remainingPendingActions.length > 0 ? remainingPendingActions : null;
            if (messageToUpdate.pendingActions === null) {
                messageToUpdate.confirmationHandled = true;
            }
            newMessages[messageIndex] = messageToUpdate;
        }
        return newMessages;
    });

    if (sendingActionsToHandle.length === 0) {
      console.warn("No email/SMS actions found for confirmation.");
      return;
    }

    if (isConfirmed) {
        setLoading(true);
        const results = await executeActions(sendingActionsToHandle); // Execute only the collected sending actions
        
        let confirmationSpeech = `Actions confirmed. ${results.replace(/[\n]/g, '. ')}`;
        if (confirmationSpeech.length > 200) { 
          confirmationSpeech = "Actions confirmed. I've successfully completed the tasks.";
        }

        setMessages(prev => [...prev, { 
            role: "assistant", 
            content: `✅ **Action Confirmed & Executed**\n${results}`,
            timestamp: new Date().toISOString()
        }]);
        
        if (autoSpeak) {
          await speakText(confirmationSpeech);
        } else if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
          startWakeWordListening();
        }

        setLoading(false);
    } else { // Cancelled
        const cancellationMessage = "Okay, I've cancelled the message sending. Nothing was sent.";
        setMessages(prev => [...prev, { 
            role: "assistant", 
            content: cancellationMessage,
            timestamp: new Date().toISOString()
        }]);
        if (autoSpeak) {
          speakText(cancellationMessage);
        } else if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
          startWakeWordListening();
        }
    }
  };


  const startRecording = async (fromWakeWord = false) => {
    try {
      stopSpeaking(); 

      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      
      if (!SpeechRecognition) {
        alert('Speech recognition is not supported in your browser. Please use Chrome, Edge, or Safari.');
        if (fromWakeWord) {
          isProcessingWakeWordRef.current = false;
          if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
            setTimeout(() => startWakeWordListening(), 1000);
          }
        }
        return;
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      let finalTranscript = '';

      recognition.onresult = (event) => {
        let interimTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          } else {
            interimTranscript += transcript;
          }
        }
        
        const fullTranscript = (finalTranscript + interimTranscript).trim();
        currentTranscriptRef.current = fullTranscript;
        setInput(fullTranscript);
      };

      recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
        setIsRecording(false);
        
        // Ignore 'aborted' errors
        if (event.error === 'aborted') {
          return;
        }
        
        // Remove the "Listening..." message
        setMessages(prev => prev.filter(m => m.content !== '🎤 **Listening...**'));
        
        // Restart wake word listening if it was active and the command was from wake word
        if (fromWakeWord) {
          isProcessingWakeWordRef.current = false; // Reset processing flag
          
          if (event.error === 'no-speech') {
            const noSpeechMessage = "I didn't hear anything. Try saying 'Hey Lexi' again!";
            setMessages(prev => [...prev, {
              role: 'assistant',
              content: noSpeechMessage,
              timestamp: new Date().toISOString()
            }]);
            if (autoSpeak) {
              speakText(noSpeechMessage); // speakText will handle restart
            } else if (isListeningForWakeWord && !isProcessingWakeWordRef.current) { // Manual restart if no speech was supposed to happen
              setTimeout(() => startWakeWordListening(), 2000);
            }
          } else { // For other errors, just restart listening
            if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
              setTimeout(() => startWakeWordListening(), 2000);
            }
          }
        } else if (event.error === 'not-allowed') {
          alert('Microphone access denied. Please enable microphone permissions.');
        }
      };

      recognition.onend = () => {
        setIsRecording(false);
        const transcript = currentTranscriptRef.current.trim();
        const lowercasedTranscript = transcript.toLowerCase();
        
        // Remove the "Listening..." message
        setMessages(prev => prev.filter(m => m.content !== '🎤 **Listening...'));
        
        if (lowercasedTranscript === 'scratch that' || 
            lowercasedTranscript === 'lexi scratch that' || 
            lowercasedTranscript.endsWith('scratch that')) {
          setInput('');
          currentTranscriptRef.current = '';
          const scratchThatMessage = "No problem! Starting fresh. What would you like me to help with?";
          setMessages(prev => [...prev, { 
            role: "assistant", 
            content: scratchThatMessage 
          }]);
          
          if (fromWakeWord || autoSpeak) {
            speakText(scratchThatMessage); // This will handle restart
          }
          // ELSE, if no speech, manually restart
          else if (isListeningForWakeWord) { 
            isProcessingWakeWordRef.current = false;
            if (!isProcessingWakeWordRef.current) {
              setTimeout(() => startWakeWordListening(), 2000);
            }
          }
          return;
        }
        
        if (transcript) {
          setTimeout(() => {
            handleSendMessage(transcript, fromWakeWord); // Pass fromWakeWord to autoSpeakResponse parameter
          }, 100);
        } else if (isListeningForWakeWord) { // If no transcript was captured and wake word is enabled, restart listening
          isProcessingWakeWordRef.current = false;
          if (!isProcessingWakeWordRef.current) {
            setTimeout(() => startWakeWordListening(), 2000);
          }
        }
      };

      mediaRecorderRef.current = recognition;
      recognition.start();
      setIsRecording(true);

    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Could not access microphone. Please check permissions.');
      setIsRecording(false);
      
      // If microphone access error occurs, and wake word is enabled, restart listening
      if (isListeningForWakeWord) { 
        isProcessingWakeWordRef.current = false;
        if (!isProcessingWakeWordRef.current) {
          setTimeout(() => startWakeWordListening(), 2000);
        }
      }
    }
  };

  const stopRecording = () => {
    try {
      if (mediaRecorderRef.current && isRecording) {
        mediaRecorderRef.current.stop();
        setIsRecording(false);
      }
    } catch (error) {
      console.warn('Error stopping recording (non-critical):', error);
      setIsRecording(false);
    }
  };

  const handleFileUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setUploadingFile(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        setAttachedFiles(prev => [...prev, { name: file.name, url: file_url }]);
      }
    } catch (error) {
      console.error('File upload error:', error);
      alert(`Failed to upload file: ${error.message}`);
    }
    setUploadingFile(false);
  };

  const removeFile = (index) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const initiateCall = () => {
    alert('📞 Voice calling feature coming soon! This will allow you to have voice conversations with Lexi.');
  };

  const updateAvatarMutation = useMutation({
    mutationFn: async ({ companyId, url }) => {
        return base44.entities.Company.update(companyId, { lexi_avatar_url: url });
    },
    onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ['companies'] });
    },
  });

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file || !myCompany) return;

    setIsUploadingAvatar(true);
    try {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        await updateAvatarMutation.mutateAsync({ companyId: myCompany.id, url: file_url });
    } catch (error) {
        console.error("Avatar upload error:", error);
        alert("Failed to upload new avatar.");
    } finally {
        setIsUploadingAvatar(false);
    }
  };


  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopWakeWordListening();
      stopSpeaking();
    };
  }, []);

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
       <input
        type="file"
        ref={avatarFileInputRef}
        onChange={handleAvatarUpload}
        className="hidden"
        accept="image/png,image/jpeg,image/gif"
      />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
             <div className="relative group">
                <img 
                  src={lexiPhotoUrl} 
                  alt="Lexi AI" 
                  className="w-10 h-10 rounded-full object-cover border-2 border-purple-500 group-hover:brightness-75 transition-all"
                />
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => avatarFileInputRef.current?.click()}
                  className="absolute inset-0 m-auto w-fit h-fit text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                  disabled={isUploadingAvatar}
                >
                    {isUploadingAvatar ? <Loader2 className="w-3 h-3 animate-spin"/> : <UploadCloud className="w-3 h-3 mr-1"/>}
                    {isUploadingAvatar ? '' : 'Upload'}
                </Button>
            </div>
            Lexi AI
            <Badge className="bg-green-100 text-green-700 border-green-200 text-xs">
              💰 Cost Optimized
            </Badge>
          </h1>
          <p className="text-gray-500 mt-1">
            {user ? `Hi ${user.full_name?.split(' ')[0]}, ` : ''}your intelligent AI assistant with FULL CRM access + Business Analytics
          </p>
          <div className="flex gap-2 mt-2 flex-wrap items-center">
            <Badge className="bg-green-100 text-green-700 border-green-200">
              <CheckCircle className="w-3 h-3 mr-1" />
              Can Create Events
            </Badge>
            <Badge className="bg-blue-100 text-blue-700 border-blue-200">
              <UserPlus className="w-3 h-3 mr-1" />
              Can Add Customers
            </Badge>
            <Badge className="bg-cyan-100 text-cyan-700 border-cyan-200">
              <Target className="w-3 h-3 mr-1" />
              Can Add Leads
            </Badge>
            <Badge className="bg-purple-100 text-purple-700 border-purple-200">
              <Briefcase className="w-3 h-3 mr-1" />
              Can Create Tasks
            </Badge>
            <Badge className="bg-orange-100 text-orange-700 border-orange-200">
              <TrendingUp className="w-3 h-3 mr-1" />
              Business Analytics
            </Badge>
          </div>
        </div>

        {/* COMPACT VOICE CONTROLS */}
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors">
            <input
              type="checkbox"
              checked={isListeningForWakeWord}
              onChange={(e) => {
                if (e.target.checked) {
                  startWakeWordListening();
                } else {
                  stopWakeWordListening();
                }
              }}
              className="w-4 h-4 rounded"
            />
            <Mic className={`w-4 h-4 ${isListeningForWakeWord ? 'text-blue-600 animate-pulse' : 'text-gray-600'}`} />
            <span className="text-sm font-medium text-gray-700">
              {isListeningForWakeWord ? '👂 Listening' : 'Hey Lexi'}
            </span>
          </label>
          
          <label className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 px-3 py-2 rounded-lg transition-colors">
            <input
              type="checkbox"
              checked={autoSpeak}
              onChange={(e) => setAutoSpeak(e.target.checked)}
              className="w-4 h-4 rounded"
            />
            <span className="text-sm font-medium text-gray-700">🔊 Auto-speak</span>
          </label>
        </div>
      </div>

      <Card className="bg-white shadow-lg">
        <CardHeader className="border-b bg-gradient-to-r from-purple-50 to-blue-50">
          <CardTitle className="flex items-center gap-3">
            <img 
              src={lexiPhotoUrl} 
              alt="Lexi" 
              className="w-8 h-8 rounded-full object-cover border-2 border-purple-400"
            />
            Chat with Lexi
            {isListeningForWakeWord && (
              <Badge className="bg-blue-100 text-blue-700 text-xs animate-pulse">
                Say "Hey Lexi" to start
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="h-[500px] overflow-y-auto p-6 space-y-4">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.role === 'assistant' && (
                  <img 
                    src={lexiPhotoUrl} 
                    alt="Lexi" 
                    className="w-8 h-8 rounded-full object-cover flex-shrink-0 border-2 border-purple-400"
                  />
                )}
                <div className={`max-w-[70%] rounded-lg p-4 ${
                  msg.role === 'user' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-900'
                }`}>
                  <div className="whitespace-pre-wrap text-sm">{msg.content}</div>

                  {msg.pendingActions && !msg.confirmationHandled && (
                    <div className="mt-4 space-y-3">
                      {/* Render ProposedEventCard for calendar events */}
                      {(msg.pendingActions || []).filter(a => a.type === 'create_calendar_event').map((action, actionIdx) => (
                        <ProposedEventCard
                          key={`event-${idx}-${actionIdx}`} // Use both message and action index for unique key
                          action={action}
                          onConfirm={() => handleConfirmEvent(idx, action)} // Pass message index and the full action
                          onCancel={() => { 
                            setMessages(prev => {
                              const newMessages = [...prev];
                              const messageToUpdate = { ...newMessages[idx] };
                              messageToUpdate.pendingActions = (messageToUpdate.pendingActions || []).filter((_, i) => i !== actionIdx);
                              if (messageToUpdate.pendingActions.length === 0) {
                                messageToUpdate.confirmationHandled = true;
                                messageToUpdate.pendingActions = null;
                              }
                              newMessages[idx] = messageToUpdate;
                              return newMessages;
                            });
                            const cancelMessage = "Okay, I've cancelled the event creation.";
                            if (autoSpeak) {
                              speakText(cancelMessage);
                            } else if (isListeningForWakeWord && !isProcessingWakeWordRef.current) {
                              setTimeout(() => startWakeWordListening(), 1000);
                            }
                            setMessages(prev => [...prev, { role: "assistant", content: cancelMessage, timestamp: new Date().toISOString() }]);
                          }}
                          isConfirming={eventCreateMutation.isPending}
                        />
                      ))}

                      {/* Render Confirmation Buttons for email/sms */}
                      {(msg.pendingActions || []).some(a => a.type === 'send_email' || a.type === 'send_sms') && (
                         <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                          <p className="text-sm font-medium text-yellow-800 mb-3">Please confirm to send messages:</p>
                          <div className="flex gap-3">
                            <Button
                              size="sm"
                              className="bg-green-600 hover:bg-green-700"
                              onClick={() => handleConfirmation(idx, true)}
                              disabled={loading || eventCreateMutation.isPending} // Disable if event is being confirmed
                            >
                              <ShieldCheck className="mr-2 h-4 w-4" /> Confirm & Send
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleConfirmation(idx, false)}
                              disabled={loading || eventCreateMutation.isPending}
                            >
                              <X className="mr-2 h-4 w-4" /> Cancel
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {msg.actions && msg.actions.length > 0 && (
                    <div className="mt-2 pt-2 border-t border-gray-300">
                      <p className="text-xs text-gray-600 mb-1">Actions performed:</p>
                      {(msg.actions || []).map((action, i) => (
                        <div key={i} className="flex items-center gap-1 text-xs text-gray-700">
                          {action.type === 'create_calendar_event' && <Calendar className="w-3 h-3" />}
                          {action.type === 'update_calendar_event' && <Calendar className="w-3 h-3" />}
                          {action.type === 'delete_calendar_event' && <Calendar className="w-3 h-3" />}
                          {action.type === 'create_lead' && <UserPlus className="w-3 h-3" />}
                          {action.type === 'create_task' && <FileText className="w-3 h-3" />}
                          <span>{action.type.replace(/_/g, ' ')}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {msg.role === 'assistant' && idx > 0 && (
                    <div className="mt-2 flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => isSpeaking ? stopSpeaking() : speakText(msg.content)}
                        className="text-xs h-7"
                      >
                        {isSpeaking ? '🔊 Stop' : '🔊 Listen'}
                      </Button>
                      <p className="text-xs opacity-75">
                        {msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString() : new Date().toLocaleTimeString()}
                      </p>
                    </div>
                  )}
                </div>
                {msg.role === 'user' && (
                  <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                    <User className="w-5 h-5 text-white" />
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex gap-3">
                <img 
                  src={lexiPhotoUrl} 
                  alt="Lexi" 
                  className="w-8 h-8 rounded-full object-cover border-2 border-purple-400"
                />
                <div className="bg-gray-100 rounded-lg p-4">
                  <Loader2 className="w-5 h-5 animate-spin text-gray-600" />
                </div>
              </div>
            )}

            {showSuggestions && messages.length <= 2 && !loading && (
              <div className="space-y-2 mt-4">
                <p className="text-sm text-gray-500 font-medium">💡 Try these:</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {quickSuggestions.map((suggestion, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setInput(suggestion.text);
                        setShowSuggestions(false);
                      }}
                      className="text-left p-3 bg-gray-50 hover:bg-gray-100 rounded-lg border border-gray-200 transition-colors text-sm"
                    >
                      <span className="mr-2">{suggestion.icon}</span>
                      {suggestion.text}
                    </button>
                  ))}
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {attachedFiles.length > 0 && (
            <div className="px-4 py-2 bg-gray-50 border-t border-b">
              <div className="flex flex-wrap gap-2">
                {attachedFiles.map((file, idx) => (
                  <div key={idx} className="flex items-center gap-2 bg-white border rounded px-3 py-1 text-sm">
                    <Paperclip className="w-3 h-3" />
                    <span className="max-w-[200px] truncate">{file.name}</span>
                    <button onClick={() => removeFile(idx)} className="text-gray-400 hover:text-red-600">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="border-t p-4">
            <div className="flex items-end gap-2">
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileUpload}
                className="hidden"
                accept="image/*,.pdf,.doc,.docx,.txt,.csv,.xls,.xlsx"
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploadingFile || loading}
                title="Upload file"
              >
                {uploadingFile ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Paperclip className="w-5 h-5" />
                )}
              </Button>

              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={isRecording ? stopRecording : () => startRecording(false)}
                disabled={loading}
                className={isRecording ? "text-red-600 animate-pulse" : ""}
                title={isRecording ? "Stop recording" : (isListeningForWakeWord ? "Or just say 'Hey Lexi'" : "Start recording")}
              >
                {isRecording ? (
                  <StopCircle className="w-5 h-5" />
                ) : (
                  <Mic className="w-5 h-5" />
                )}
              </Button>

              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={initiateCall}
                disabled={loading}
                title="Voice call"
              >
                <Phone className="w-5 h-5" />
              </Button>

              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder="Ask Lexi to add events, create leads, update tasks..."
                className="flex-1 min-h-[44px] max-h-[120px]"
                rows={1}
                disabled={loading || isRecording}
              />
              <Button 
                onClick={() => handleSendMessage()}
                disabled={loading || (!input.trim() && attachedFiles.length === 0) || isRecording}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              {isListeningForWakeWord 
                ? "👂 Say 'Hey Lexi' to activate voice control • Press Enter to send • 📎 to attach • Say 'scratch that' to cancel"
                : "🎤 Enable 'Hey Lexi' mode above for hands-free voice control • Press Enter to send • 🎤 to speak • 📎 to attach"
              }
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
