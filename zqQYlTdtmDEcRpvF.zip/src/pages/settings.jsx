// Lowercase alias for Settings page (fixes import case sensitivity)
import Settings from "./Settings";
export default Settings;