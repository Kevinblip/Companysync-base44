
import React, { useState, useRef, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Upload,
  Loader2,
  Sparkles,
  Send,
  Paperclip,
  FileText,
  Settings,
  Save
} from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import LineItemEditor from "../components/estimates/LineItemEditor";

export default function AIEstimator() {
  const [showConfig, setShowConfig] = useState(true);
  const [config, setConfig] = useState({
    specialty: "roofing",
    primaryMaterials: "laminated shingles, vinyl siding, 5\" gutters",
    defaultPricingSource: "xactimate",
    useFavorites: true
  });
  
  const [messages, setMessages] = useState([]);
  const [userInput, setUserInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState([]);
  const [currentEstimate, setCurrentEstimate] = useState(null);
  const [lineItems, setLineItems] = useState([]);
  const [pricingSource, setPricingSource] = useState("xactimate");

  // NEW: State for save dialog
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [saveForm, setSaveForm] = useState({
    customer_name: "",
    customer_email: "",
    property_address: "",
    claim_number: "",
    insurance_company: ""
  });
  
  const fileInputRef = useRef(null);
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // NEW: Update line items when they change in editor
  useEffect(() => {
    if (lineItems.length > 0 && currentEstimate) {
      const totalRcv = lineItems.reduce((sum, item) => sum + (item.rcv || 0), 0);
      setCurrentEstimate({
        ...currentEstimate,
        line_items: lineItems,
        total_rcv: totalRcv
      });
    } else if (lineItems.length === 0 && currentEstimate) { // If all line items are removed
      setCurrentEstimate(null); // Clear the current estimate
    }
  }, [lineItems]);

  const { data: user } = useQuery({
    queryKey: ['current-user'],
    queryFn: () => base44.auth.me(),
  });

  // 🧠 Load user's estimator memories
  const { data: estimatorMemories = [] } = useQuery({
    queryKey: ['estimator-memories', user?.email],
    queryFn: () => user ? base44.entities.AIMemory.filter({ 
      user_email: user.email, 
      category: 'estimator',
      is_active: true 
    }, '-importance', 20) : [],
    enabled: !!user,
    initialData: [],
  });

  const { data: xactimatePriceList = [] } = useQuery({
    queryKey: ['xactimate-prices'],
    queryFn: () => base44.entities.PriceListItem.filter({ source: "Xactimate" }, "-created_date", 10000),
    initialData: [],
  });

  const { data: customPriceList = [] } = useQuery({
    queryKey: ['custom-prices'],
    queryFn: () => base44.entities.PriceListItem.filter({ source: "Custom" }, "-created_date", 10000),
    initialData: [],
  });

  const { data: symbilityPriceList = [] } = useQuery({
    queryKey: ['symbility-prices'],
    queryFn: () => base44.entities.PriceListItem.filter({ source: "Symbility" }, "-created_date", 10000),
    initialData: [],
  });

  // NEW: Load formats
  const { data: formats = [] } = useQuery({
    queryKey: ['estimate-formats'],
    queryFn: () => base44.entities.EstimateFormat.list(),
    initialData: [],
  });

  // NEW: Find format based on pricing source
  const getFormatForSource = (source) => {
    // Try to find a matching format
    const lowerSource = source.toLowerCase();
    
    // Look for insurance company match
    const insuranceFormat = formats.find(f => 
      f.insurance_company?.toLowerCase().includes(lowerSource) ||
      f.insurance_company?.toLowerCase().includes(source === 'xactimate' ? 'xactimate' : source === 'symbility' ? 'symbility' : '')
    );
    
    if (insuranceFormat) return insuranceFormat;
    
    // Look for category match
    const categoryFormat = formats.find(f => 
      f.category === (source === 'custom' ? 'custom' : 'insurance')
    );
    
    if (categoryFormat) return categoryFormat;
    
    // Return default format based on source
    if (source === 'xactimate' || source === 'symbility') {
      return {
        format_name: source === 'xactimate' ? 'Xactimate Standard' : 'Symbility Standard',
        show_rcv_acv: true,
        show_depreciation: false,
        rcv_label: 'RCV',
        acv_label: 'ACV'
      };
    }
    
    // Custom format
    return {
      format_name: 'Custom',
      show_rcv_acv: false,
      show_depreciation: false,
      rcv_label: 'RCV', // Still include labels for potential use
      acv_label: 'ACV'
    };
  };

  const currentFormat = getFormatForSource(pricingSource);

  // Load config and memories on mount
  useEffect(() => {
    const savedConfig = localStorage.getItem('aiEstimatorConfig');
    if (savedConfig) {
      const parsed = JSON.parse(savedConfig);
      setConfig(parsed);
      setPricingSource(parsed.defaultPricingSource);
      setShowConfig(false);
      
      // Build memories text
      const memoriesText = estimatorMemories.length > 0
        ? '\n\n🧠 **What I Remember:**\n' + estimatorMemories.map(m => 
            `• ${m.description}: ${m.value}`
          ).join('\n')
        : '';
      
      setMessages([{
        role: 'assistant',
        content: `🏗️ **Welcome back!**

Your AI Estimator is configured for **${parsed.specialty}** with:
• Primary materials: ${parsed.primaryMaterials}
• Pricing source: ${parsed.defaultPricingSource}
• Using favorites: ${parsed.useFavorites ? 'Yes' : 'No'}${memoriesText}

Upload your files and I'll create estimates tailored to your business!`,
        timestamp: new Date().toISOString()
      }]);
    }
  }, [estimatorMemories]);

  const handleSaveConfig = () => {
    localStorage.setItem('aiEstimatorConfig', JSON.stringify(config));
    setPricingSource(config.defaultPricingSource);
    setShowConfig(false);
    
    setMessages([{
      role: 'assistant',
      content: `✅ **Configuration Saved!**

I'll now generate estimates for **${config.specialty}** using:
• ${config.primaryMaterials}
• ${config.defaultPricingSource} pricing
${config.useFavorites ? '• Your favorite items' : ''}

Upload a file or describe your project to get started!`,
      timestamp: new Date().toISOString()
    }]);
  };

  const lookupPriceByCode = (code, source = "xactimate") => {
    if (!code) return { found: false };

    let priceList = [];
    if (source === "xactimate") {
      priceList = xactimatePriceList;
    } else if (source === "custom") {
      priceList = customPriceList;
    } else if (source === "symbility") {
      priceList = symbilityPriceList;
    }

    if (priceList.length === 0) return { found: false };

    const cleanCode = (c) => c?.toUpperCase().trim().replace(/\s+/g, ' ');
    const searchCode = cleanCode(code);

    const exactMatch = priceList.find(item => cleanCode(item.code) === searchCode);
    if (exactMatch) {
      return {
        found: true,
        code: exactMatch.code,
        description: exactMatch.description,
        unit: exactMatch.unit,
        rate: exactMatch.price,
        category: exactMatch.category,
        source: exactMatch.source
      };
    }

    return { found: false };
  };

  const extractEstimate = async (fileUrls, fileName, userInstructions = "") => {
    setIsProcessing(true);
    
    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `🔍 Analyzing ${fileName} with your ${config.specialty} configuration...${userInstructions ? '\n\n📝 Your instructions: ' + userInstructions : ''}`,
      timestamp: new Date().toISOString()
    }]);

    try {
      const isPDF = fileName.toLowerCase().endsWith('.pdf');
      
      let priceList = [];
      if (pricingSource === 'xactimate') {
        priceList = xactimatePriceList;
      } else if (pricingSource === 'symbility') {
        priceList = symbilityPriceList;
      } else {
        priceList = customPriceList;
      }

      let pricingSamples = '';
      if (config.useFavorites && priceList.length > 0) {
        const favorites = priceList.filter(item => item.is_favorite);
        if (favorites.length > 0) {
          pricingSamples = '**YOUR FAVORITE ITEMS (use these first):**\n' + favorites.slice(0, 20).map(item => 
            `${item.code}: ${item.description} - $${item.price}/${item.unit}`
          ).join('\n') + '\n\n';
        }
      }

      if (priceList.length > 0) {
        pricingSamples += '**PRICING DATABASE:**\n' + priceList.slice(0, 50).map(item => 
          `${item.code}: ${item.description} - $${item.price}/${item.unit}`
        ).join('\n');
      }

      const prompt = `You are analyzing ${isPDF ? 'an ESTIMATE PDF' : 'an EAGLEVIEW REPORT'} for a ${config.specialty} company specializing in: ${config.primaryMaterials}.

${userInstructions ? `**USER'S SPECIFIC INSTRUCTIONS:**\n${userInstructions}\n\n` : ''}

${pricingSamples}

${isPDF ? `
CRITICAL INSTRUCTIONS FOR ESTIMATE PDFs:
1. **EXTRACT ALL LINE ITEMS** from the PDF - every single one
2. **READ THE QUANTITIES EXACTLY** as shown in the PDF
3. **MATCH TO PRICING CODES** from the database above
4. If you can't find a code match, use the description from the PDF
5. Preserve the EXACT quantities and units from the PDF
6. For each item, provide: code, description, quantity, unit, unit_price (rate per unit)
` : `
CRITICAL INSTRUCTIONS FOR EAGLEVIEW REPORTS:
1. **READ ALL MEASUREMENTS** from the report carefully
2. **CREATE COMPLETE ${config.specialty.toUpperCase()} ESTIMATE** with ALL items
3. For each item provide: code, description, quantity, unit, unit_price (rate per unit)
`}

Return ONLY valid JSON (no markdown, no extra text):
{
  "line_items": [
    {
      "code": "RFG SSSQ",
      "description": "Shingles, standard",
      "quantity": 24.5,
      "unit": "SQ",
      "unit_price": 125.00
    }
  ]
}`;

      console.log('🚀 Using GPT-4o for analysis:', fileUrls);

      let response;
      try {
        // ALWAYS use GPT-4o now (works for both PDFs and images)
        response = await base44.functions.invoke('chatGPT4o', {
          prompt,
          fileUrls: fileUrls, // Pass the array directly
          responseJsonSchema: {
            type: "object",
            properties: {
              line_items: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    code: { type: "string" },
                    description: { type: "string" },
                    quantity: { type: "number" },
                    unit: { type: "string" },
                    unit_price: { type: "number" }
                  },
                  required: ["description", "quantity", "unit"]
                }
              }
            },
            required: ["line_items"]
          }
        });
      } catch (functionError) {
        console.error('❌ Function call failed:', functionError);
        
        let errorMessage = '❌ **AI Processing Failed (Vision Function)**\n\n';
        
        if (functionError.response?.data?.error) {
          errorMessage += `**Error:** ${functionError.response.data.error}\n`;
          if (functionError.response.data.details) {
            errorMessage += `**Details:** ${functionError.response.data.details}\n`;
          }
        } else {
          errorMessage += `**Error:** ${functionError.message}\n`;
        }
        
        errorMessage += '\n**Possible causes:**\n';
        errorMessage += '• OpenAI API key not set or invalid\n';
        errorMessage += '• OpenAI account out of credits\n';
        errorMessage += '• Rate limit exceeded\n';
        errorMessage += '• File too large (max 20MB)\n';
        errorMessage += `\n**Check:** Dashboard → Code → Functions → chatGPT4o for detailed logs`;
        
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: errorMessage,
          timestamp: new Date().toISOString()
        }]);
        
        setIsProcessing(false);
        return;
      }

      console.log('✅ AI response:', response);

      const data = response.data || response;

      if (!data || !data.line_items || data.line_items.length === 0) {
        throw new Error('AI did not return any line items. Please try again or contact support.');
      }

      console.log(`✅ AI returned ${data.line_items.length} items`);

      // Match with price list and calculate amounts
      const matchedItems = data.line_items.map((item, index) => {
        const lookup = lookupPriceByCode(item.code, pricingSource);
        const quantity = parseFloat(item.quantity) || 1;
        const rate = item.unit_price || (lookup.found ? lookup.rate : 0); // Prioritize AI's unit_price, then lookup
        const amount = quantity * rate;

        return {
          line: index + 1,
          code: item.code || (lookup.found ? lookup.code : ''),
          description: item.description,
          quantity,
          unit: item.unit || (lookup.found ? lookup.unit : 'EA'),
          rate,
          amount,
          rcv: amount,
          depreciation: 0,
          acv: amount,
          source: lookup.found ? lookup.source : pricingSource,
          matched: lookup.found || rate > 0
        };
      });

      const totalRcv = matchedItems.reduce((sum, item) => sum + item.rcv, 0);

      const newEstimate = {
        line_items: matchedItems,
        total_rcv: totalRcv
      };

      setCurrentEstimate(newEstimate);
      setLineItems(matchedItems);

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ **Estimate Complete!**\n\n📊 Generated **${matchedItems.length} line items** for ${config.specialty}\n💰 Total RCV: **$${totalRcv.toFixed(2)}**\n\n${matchedItems.filter(i => !i.matched).length > 0 ? `⚠️ ${matchedItems.filter(i => !i.matched).length} items need price matching - click to edit\n\n` : ''}You can now:\n• Click any item to edit or replace\n• Ask me to modify (e.g., "Add 10% waste", "Add steep charges")\n• Save to Estimates when ready`,
        timestamp: new Date().toISOString()
      }]);

    } catch (error) {
      console.error("Extraction error:", error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `❌ **Error:** ${error.message}\n\n${error.response?.data?.error || ''}`,
        timestamp: new Date().toISOString()
      }]);
    }
    
    setIsProcessing(false);
  };

  const handleFileSelect = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    try {
      const uploadedFileUrls = [];
      
      // Upload files but DON'T analyze yet
      for (const file of files) {
        // Accept both images AND PDFs for EagleView reports
        const validTypes = [
          'image/png', 
          'image/jpeg', 
          'image/jpg', 
          'image/gif', 
          'image/webp',
          'application/pdf'
        ];
        
        if (!validTypes.includes(file.type)) {
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: `❌ **Invalid file type: ${file.type}**\n\n📸 Please upload:\n• PNG (.png)\n• JPEG (.jpg, .jpeg)\n• GIF (.gif)\n• WebP (.webp)\n• PDF (.pdf) - for EagleView reports`,
            timestamp: new Date().toISOString()
          }]);
          continue; // Skip this file and go to the next one
        }

        // Check file size (max 20MB for OpenAI)
        const maxSize = 20 * 1024 * 1024; // 20MB
        if (file.size > maxSize) {
          setMessages(prev => [...prev, {
            role: 'assistant',
            content: `❌ **File too large: ${(file.size / 1024 / 1024).toFixed(2)} MB**\n\n📦 Maximum file size for analysis is 20 MB.\n\nPlease compress the file and try again.`,
            timestamp: new Date().toISOString()
          }]);
          continue; // Skip this file and go to the next one
        }

        console.log('✅ Valid file:', file.name, file.type, (file.size / 1024 / 1024).toFixed(2), 'MB');

        const uploadResult = await base44.integrations.Core.UploadFile({ file });
        uploadedFileUrls.push({
          name: file.name,
          url: uploadResult.file_url,
          size: file.size,
          type: file.type // Store file type for display
        });
      }
      
      if (uploadedFileUrls.length === 0) {
        return; // No valid files uploaded after checks
      }

      // Just add to attached files (don't process yet)
      setUploadedFiles(prev => [...prev, ...uploadedFileUrls]);
      
      // Show user that files are attached and ready
      const filesList = uploadedFileUrls.map(f => `📎 ${f.name} (${(f.size / 1024 / 1024).toFixed(2)} MB, ${f.type.includes('pdf') ? 'PDF' : 'Image'})`).join('\n');
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ **Files attached and ready for analysis:**\n\n${filesList}\n\n💡 **What should I create?**\n\nTell me what you want:\n• "Create roofing estimate"\n• "Generate estimate with steep charges"\n• "Make estimate with 10% waste"\n\nOr just type "roofing estimate" and I'll handle it! 🚀`,
        timestamp: new Date().toISOString()
      }]);
      
    } catch (error) {
      console.error("Upload error:", error);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `❌ Error uploading files: ${error.message}`,
        timestamp: new Date().toISOString()
      }]);
    }
    
    if (fileInputRef.current) {
      fileInputRef.current.value = ''; // Clear the file input
    }
  };

  const processWithAI = async (userMessage) => {
    if (!currentEstimate) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `❌ Please upload a file first to create an estimate!`,
        timestamp: new Date().toISOString()
      }]);
      return;
    }

    setIsProcessing(true);
    
    // Add a placeholder message for AI thinking
    setMessages(prev => [...prev, {
      role: 'assistant',
      content: `🧠 Thinking about your request: "${userMessage}"...`,
      timestamp: new Date().toISOString()
    }]);

    try {
      let priceList = [];
      if (pricingSource === 'xactimate') {
        priceList = xactimatePriceList;
      } else if (pricingSource === 'symbility') {
        priceList = symbilityPriceList;
      } else {
        priceList = customPriceList;
      }
      
      const pricingSamples = priceList.slice(0, 50).map(item => 
        `${item.code}: ${item.description} - $${item.price}/${item.unit}`
      ).join('\n');

      // Build memories context
      const memoriesText = estimatorMemories.length > 0
        ? '**WHAT I REMEMBER:**\n' + estimatorMemories.map(m => 
            `• ${m.description}: ${m.value}`
          ).join('\n') + '\n\n'
        : '';

      const prompt = `You are modifying a ${config.specialty} estimate for a company specializing in: ${config.primaryMaterials}.

${memoriesText}

Current estimate has ${currentEstimate.line_items?.length || 0} items totaling $${currentEstimate.total_rcv?.toFixed(2) || '0.00'}

Available pricing database:
${pricingSamples}

User request: "${userMessage}"

CRITICAL INSTRUCTIONS:
1. Understand what the user wants:
   - "add 10% waste" → Increase material quantities by 10%
   - "add steep charges" → Add line items for steep roof work
   - "add high charges" → Add line items for high roof work (2+ stories)
   - "target $X per sq ft" → Adjust prices to hit target
   - "add O&P" or "overhead profit" → Add 15% O&P line item
   - "add [item name]" → Add specific line items from pricing database
   - "remember..." or "always use..." or "my preference is..." → Store this preference for future estimates

2. For WASTE: Multiply material quantities (shingles, underlayment, etc.) by 1.10 (10% waste)

3. For STEEP: Add these items from pricing database:
   - Steep roof charge (usually RFG STEEP or similar)
   - Additional labor charges

4. For HIGH: Add these items:
   - High roof charge (2-3 story)
   - Scaffolding if needed

5. For O&P: Add a line item with:
   - Description: "Overhead & Profit (15%)"
   - Quantity: 1
   - Rate: (current total * 0.15)

6. For MEMORY: If the user's request contains keywords like "remember", "always", "I prefer", "my standard is", extract the core preference (e.g., "always use 10% waste", "my standard is steep and high charges") and return it in the "remember" field. Do not store the entire user message.

7. Return the COMPLETE updated estimate with ALL existing items plus your additions.

Return JSON:
{
  "message": "Explain what you did",
  "remember": "What to remember (if applicable)",
  "estimate": {
    "line_items": [array of ALL items including new ones],
    "total_rcv": updated_total
  }
}`;

      let response;
      try {
        // Use lexiChat for conversational follow-ups, not the vision function
        const conversationalMessages = messages.map(m => ({ role: m.role, content: m.content }));
        
        const { data: companies = [] } = await queryClient.fetchQuery({
            queryKey: ['companies'],
            queryFn: () => base44.entities.Company.list(),
        });
        const myCompany = companies.find(c => c.created_by === user?.email);

        const context = {
            user: { 
                name: user?.full_name, // Make sure user is not null
                email: user?.email, // Make sure user is not null
                company_name: myCompany?.company_name || 'My Company',
                current_browser_time: new Date().toLocaleString()
            },
            total_invoices: 0,
            unpaid_invoices: 0,
            total_leads: 0,
            active_leads: 0,
            pending_tasks: 0,
        };

        response = await base44.functions.invoke('lexiChat', {
          messages: conversationalMessages,
          context: context,
          userMessage: prompt, // Pass the detailed prompt as userMessage for lexiChat to interpret instructions
        });

      } catch (functionError) {
        console.error('❌ Function call failed (lexiChat):', functionError);
        
        let errorMessage = '❌ **AI Processing Failed (Conversational Function)**\n\n';
        
        if (functionError.response?.data?.error) {
          errorMessage += `**Error:** ${functionError.response.data.error}\n`;
          if (functionError.response.data.details) {
            errorMessage += `**Details:** ${functionError.response.data.details}\n`;
          }
        } else {
          errorMessage += `**Error:** ${functionError.message}\n`;
        }
        
        errorMessage += '\n**Possible causes:**\n';
        errorMessage += '• ANTHROPIC_API_KEY not set or invalid\n';
        errorMessage += '• Anthropic account out of credits\n';
        errorMessage += `\n**Check:** Dashboard → Code → Functions → lexiChat for detailed logs`;
        
        setMessages(prev => prev.slice(0, -1).concat({ // Replace the "Thinking..." message
          role: 'assistant',
          content: errorMessage,
          timestamp: new Date().toISOString()
        }));
        
        setIsProcessing(false);
        return;
      }

      // The lexiChat function returns a different structure. We need to adapt.
      // It won't return `estimate` directly, it will return a text response.
      // For now, let's just display the text response. A more advanced version
      // would use tools to modify the estimate, but this at least stops the crash.
      
      const data = response.data || response;

      let responseMessage = data.response || "I've processed your request, but I'm unable to modify the estimate sheet directly yet. Here's my analysis:";
      const memoryNote = data.remember ? `\n\n🧠 I'll remember: "${data.remember}" for future estimates.` : '';

      // Since lexiChat doesn't return the structured estimate, we cannot update it here.
      // This is a limitation for now but prevents the crash.
      // We will just show the AI's text response.
      
      setMessages(prev => prev.slice(0, -1).concat({ // Replace the "Thinking..." message
        role: 'assistant',
        content: responseMessage + memoryNote,
        timestamp: new Date().toISOString(),
      }));

    } catch (error) {
      console.error("AI processing error:", error);
      setMessages(prev => prev.slice(0, -1).concat({ // Replace the "Thinking..." message
        role: 'assistant',
        content: `❌ Error: ${error.message}`,
        timestamp: new Date().toISOString()
      }));
    }
    
    setIsProcessing(false);
  };

  const handleSendMessage = async () => {
    const message = userInput.trim();
    
    // If there are attached files, analyze them with the user's message as context
    if (uploadedFiles.length > 0) {
      setUserInput("");
      
      // If no message, suggest adding instructions
      if (!message) {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: `📋 **File ready for analysis!**\n\nWhat would you like me to create?\n\nExamples:\n• "Create roofing estimate"\n• "Generate estimate for roof replacement"\n• "Add steep and high charges"\n• "Make roofing estimate with 10% waste"\n\nOr just type "roofing estimate" and I'll handle it! 🚀`,
          timestamp: new Date().toISOString()
        }]);
        return;
      }

      setMessages(prev => [...prev, {
        role: 'user',
        content: message,
        timestamp: new Date().toISOString()
      }]);
      
      // Analyze files with user's instructions
      // IMPORTANT FIX: Pass an array of URLs
      const urls = uploadedFiles.map(f => f.url);
      // Pass the name of the first file for display in the message
      await extractEstimate(urls, uploadedFiles[0].name, message);
      
      // Clear attached files after processing
      setUploadedFiles([]);
      return;
    }
    
    // If no files attached but there's a message, process as conversation
    if (message) {
      setUserInput("");
      
      setMessages(prev => [...prev, {
        role: 'user',
        content: message,
        timestamp: new Date().toISOString()
      }]);
      
      await processWithAI(message);
    }
  };

  const handleQuickAction = async (action) => {
    const actions = {
      'waste': "Add 10% waste factor to all roofing material quantities (shingles, underlayment, etc.)",
      'steep': "Add steep roof charges - this is a steep pitch roof requiring additional safety and labor",
      'high': "Add high roof charges - this is a 2+ story building requiring scaffolding and additional safety",
      'op': "Add 15% overhead and profit to the total",
      'target': "Adjust prices to target $5.50 per square foot for the total job"
    };
    
    const message = actions[action];
    if (message) {
      setMessages(prev => [...prev, {
        role: 'user',
        content: message,
        timestamp: new Date().toISOString()
      }]);
      
      await processWithAI(message);
    }
  };

  const handleSaveEstimate = async () => {
    if (!currentEstimate || !lineItems || lineItems.length === 0) {
      alert("No estimate to save");
      return;
    }

    if (!saveForm.customer_name || saveForm.customer_name.trim() === '') {
      alert("Please enter a customer name");
      return;
    }

    try {
      // Get ALL estimates (both regular EST- and AI-EST-) to find next sequential number
      const allEstimates = await base44.entities.Estimate.list();
      const existingNumbers = allEstimates
        .map(e => {
          const match = e.estimate_number?.match(/(?:AI-)?EST-(\d+)/);
          return match ? parseInt(match[1]) : 0;
        })
        .filter(n => n > 0);
      
      const nextNumber = existingNumbers.length > 0 
        ? Math.max(...existingNumbers) + 1 
        : 1800; // Start at 1800
      
      const estimateNumber = `AI-EST-${nextNumber}`;

      await base44.entities.Estimate.create({
        estimate_number: estimateNumber,
        customer_name: saveForm.customer_name.trim(),
        customer_email: saveForm.customer_email?.trim() || "",
        amount: currentEstimate.total_rcv || 0,
        status: "draft",
        items: lineItems, // Use lineItems from state, which is kept up-to-date by LineItemEditor
        project_name: saveForm.property_address?.trim() || "",
        insurance_company: saveForm.insurance_company?.trim() || "",
        claim_number: saveForm.claim_number?.trim() || "",
        notes: `Generated by AI Estimator for ${config.specialty}`
      });

      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ **Estimate ${estimateNumber} saved successfully!**\n\nYou can find it in your Estimates page.`,
        timestamp: new Date().toISOString()
      }]);

      queryClient.invalidateQueries({ queryKey: ['estimates'] });
      setShowSaveDialog(false); // Close dialog after saving
      setSaveForm({ // Reset form fields
        customer_name: "",
        customer_email: "",
        property_address: "",
        claim_number: "",
        insurance_company: ""
      });
      
      // Clear current estimate and line items after saving
      setCurrentEstimate(null);
      setLineItems([]);

    } catch (error) {
      console.error('Save error:', error);
      alert("Failed to save estimate: " + error.message);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-6">
      <div className="max-w-5xl mx-auto">
        <div className="mb-6">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <Sparkles className="w-8 h-8 text-purple-600" />
                AI Construction Estimator
              </h1>
              <p className="text-gray-500 mt-1">Upload reports, describe damage, and get professional estimates with AI analysis</p>
            </div>
            <Button variant="outline" onClick={() => setShowConfig(true)}>
              <Settings className="w-4 h-4 mr-2" />
              Configure
            </Button>
          </div>
        </div>

        {/* Configuration Dialog */}
        <Dialog open={showConfig} onOpenChange={setShowConfig}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>AI Estimator Configuration</DialogTitle>
              <DialogDescription>
                Tell me about your business so I can generate better estimates
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="specialty">Your Specialty</Label>
                <Select value={config.specialty} onValueChange={(value) => setConfig({...config, specialty: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="roofing">Roofing</SelectItem>
                    <SelectItem value="siding">Siding</SelectItem>
                    <SelectItem value="roofing_and_siding">Roofing & Siding</SelectItem>
                    <SelectItem value="gutters">Gutters</SelectItem>
                    <SelectItem value="full_exterior">Full Exterior</SelectItem>
                    <SelectItem value="general_contractor">General Contractor</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="materials">Primary Materials/Services</Label>
                <Textarea
                  id="materials"
                  value={config.primaryMaterials}
                  onChange={(e) => setConfig({...config, primaryMaterials: e.target.value})}
                  placeholder="e.g., laminated shingles, vinyl siding, 5&quot; gutters"
                  rows={3}
                />
                <p className="text-xs text-gray-500 mt-1">
                  Describe what materials you typically use
                </p>
              </div>

              <div>
                <Label htmlFor="pricing">Default Pricing Source</Label>
                <Select value={config.defaultPricingSource} onValueChange={(value) => setConfig({...config, defaultPricingSource: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="xactimate">Xactimate</SelectItem>
                    <SelectItem value="symbility">Symbility</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="useFavorites"
                  checked={config.useFavorites}
                  onChange={(e) => setConfig({...config, useFavorites: e.target.checked})}
                  className="w-4 h-4"
                />
                <Label htmlFor="useFavorites" className="cursor-pointer">
                  Prioritize my favorite items when generating estimates
                </Label>
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setShowConfig(false)}>
                Cancel
              </Button>
              <Button onClick={handleSaveConfig} className="bg-purple-600 hover:bg-purple-700">
                <Save className="w-4 h-4 mr-2" />
                Save Configuration
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Save Dialog - NEW! */}
        <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Save Estimate to CRM</DialogTitle>
              <DialogDescription>
                Add customer and project details
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="customer_name">Customer Name *</Label>
                <Input
                  id="customer_name"
                  value={saveForm.customer_name}
                  onChange={(e) => setSaveForm({...saveForm, customer_name: e.target.value})}
                  placeholder="John Smith"
                />
              </div>

              <div>
                <Label htmlFor="customer_email">Customer Email</Label>
                <Input
                  id="customer_email"
                  type="email"
                  value={saveForm.customer_email}
                  onChange={(e) => setSaveForm({...saveForm, customer_email: e.target.value})}
                  placeholder="john@example.com"
                />
              </div>

              <div>
                <Label htmlFor="property_address">Property Address</Label>
                <Input
                  id="property_address"
                  value={saveForm.property_address}
                  onChange={(e) => setSaveForm({...saveForm, property_address: e.target.value})}
                  placeholder="123 Main St, City, ST 12345"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="insurance_company">Insurance Company</Label>
                  <Input
                    id="insurance_company"
                    value={saveForm.insurance_company}
                    onChange={(e) => setSaveForm({...saveForm, insurance_company: e.target.value})}
                    placeholder="State Farm"
                  />
                </div>

                <div>
                  <Label htmlFor="claim_number">Claim Number</Label>
                  <Input
                    id="claim_number"
                    value={saveForm.claim_number}
                    onChange={(e) => setSaveForm({...saveForm, claim_number: e.target.value})}
                    placeholder="CLM-123456"
                  />
                </div>
              </div>

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <div className="text-sm font-semibold text-blue-900 mb-2">Estimate Summary</div>
                <div className="text-sm text-blue-700">
                  • {lineItems.length} line items
                  <br />
                  • Total RCV: ${currentEstimate?.total_rcv?.toFixed(2) || '0.00'}
                  <br />
                  • Source: {pricingSource}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setShowSaveDialog(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleSaveEstimate} 
                className="bg-green-600 hover:bg-green-700"
                disabled={!saveForm.customer_name || !currentEstimate || lineItems.length === 0} // Disable save if customer name is empty or no estimate/items
              >
                <Save className="w-4 h-4 mr-2" />
                Save to CRM
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <div className="space-y-6">
          {/* AI Chat Interface */}
          <Card className="bg-white shadow-lg">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white">
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  AI Estimator - Upload EagleView or Describe Project
                </CardTitle>
                <Select value={pricingSource} onValueChange={setPricingSource}>
                  <SelectTrigger className="w-32 bg-white/20 text-white border-white/30">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="xactimate">Xactimate</SelectItem>
                    <SelectItem value="symbility">Symbility</SelectItem>
                    <SelectItem value="custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            
            <CardContent className="p-0">
              <div className="h-[500px] overflow-y-auto p-6 space-y-4">
                {messages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] rounded-lg p-4 ${
                      msg.role === 'user' 
                        ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' 
                        : 'bg-gray-100 text-gray-900'
                    }`}>
                      <div className="whitespace-pre-wrap">{msg.content}</div>
                      {msg.estimate && (
                        <div className="mt-3 pt-3 border-t border-gray-200">
                          <div className="text-sm font-semibold mb-2">
                            📊 {msg.estimate.line_items?.length || 0} items • ${msg.estimate.total_rcv?.toFixed(2) || '0.00'} RCV
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {isProcessing && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 rounded-lg p-4">
                      <Loader2 className="w-5 h-5 animate-spin text-purple-600" />
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              <div className="p-4 border-t bg-white">
                {/* Show attached files ABOVE the input */}
                {uploadedFiles.length > 0 && (
                  <div className="mb-3 p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="text-sm font-semibold text-green-900 mb-2">✅ File attached and ready:</div>
                    {uploadedFiles.map((file, idx) => (
                      <div key={idx} className="flex items-center justify-between text-sm text-green-700">
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4" />
                          <span>{file.name}</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setUploadedFiles(prev => prev.filter((_, i) => i !== idx))}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50 h-6 px-2"
                        >
                          ✕
                        </Button>
                      </div>
                    ))}
                    <div className="mt-2 text-xs text-green-600">
                      💡 Now type what you want: "Create roofing estimate" or "Add steep charges"
                    </div>
                  </div>
                )}

                {currentEstimate && (
                  <div className="flex gap-2 mb-3 flex-wrap">
                    <Button size="sm" variant="outline" onClick={() => handleQuickAction('waste')}>
                      📦 Add 10% Waste
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleQuickAction('steep')}>
                      🏔️ Add Steep Charges
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleQuickAction('high')}>
                      🏢 Add High Charges
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleQuickAction('op')}>
                      📈 Add 15% O&P
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => handleQuickAction('target')}>
                      🎯 Target $5.50/sq ft
                    </Button>
                  </div>
                )}
                
                <div className="flex gap-2">
                  <input
                    ref={fileInputRef}
                    type="file"
                    onChange={handleFileSelect}
                    className="hidden"
                    accept="image/png,image/jpeg,image/jpg,image/gif,image/webp,application/pdf"
                    multiple
                  />
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isProcessing}
                    title="Upload EagleView report (PDF, PNG, JPG, GIF, WebP only)"
                  >
                    <Paperclip className="w-5 h-5" />
                  </Button>
                  <Input
                    placeholder={uploadedFiles.length > 0 ? 'Type: "Create roofing estimate" or "Add steep charges"' : "Upload EagleView report or type instructions..."}
                    value={userInput}
                    onChange={(e) => setUserInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && !isProcessing && handleSendMessage()}
                    disabled={isProcessing}
                    className="flex-1"
                  />
                  <Button 
                    onClick={handleSendMessage}
                    disabled={isProcessing}
                    className="bg-gradient-to-r from-blue-600 to-purple-600"
                  >
                    <Send className="w-5 h-5" />
                  </Button>
                </div>
                
                <p className="text-xs text-gray-500 mt-2">
                  📎 Upload EagleView report (PDF or PNG/JPG - max 20MB) → Tell me what to create → I'll generate estimate
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Current Estimate - Now with FULL LINE ITEM EDITOR! */}
          {currentEstimate && (
            <Card className="bg-white shadow-lg">
              <CardHeader className="bg-gradient-to-r from-green-600 to-green-700 text-white">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="w-5 h-5" />
                    Current Estimate
                  </CardTitle>
                  <Button 
                    onClick={() => setShowSaveDialog(true)} // Open save dialog
                    className="bg-white text-green-700 hover:bg-gray-100"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    Save to CRM
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                <div className="text-center p-6 bg-green-50 rounded-lg mb-6">
                  <div className="text-sm text-gray-600 mb-1">Total RCV</div>
                  <div className="text-4xl font-bold text-green-600">
                    ${currentEstimate.total_rcv?.toFixed(2) || '0.00'}
                  </div>
                  <div className="text-xs text-gray-500 mt-2">
                    {lineItems.filter(i => i.matched).length} matched • {lineItems.filter(i => !i.matched).length} unmatched
                  </div>
                </div>

                <LineItemEditor
                  items={lineItems}
                  onChange={setLineItems}
                  format={currentFormat}
                />
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
