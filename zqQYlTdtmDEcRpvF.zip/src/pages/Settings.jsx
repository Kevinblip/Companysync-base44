import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Settings as SettingsIcon,
  Building2,
  CreditCard,
  Zap,
  Mail,
  MessageSquare,
  AlertCircle,
  Calendar,
  Link as LinkIcon,
  RefreshCw,
  CheckCircle2,
  Phone,
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

// Import the new component
import TwilioSetup from "../components/settings/TwilioSetup";

export default function Settings() {
  const [user, setUser] = useState(null);
  const [syncingCalendar, setSyncingCalendar] = useState(false);
  const [googleCalendarConnected, setGoogleCalendarConnected] = useState(false);
  const [showTwilioSetup, setShowTwilioSetup] = useState(false);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  // Check if Google Calendar is connected
  useEffect(() => {
    const checkConnection = async () => {
      try {
        const response = await base44.functions.invoke('checkGoogleCalendarConnection', {});
        setGoogleCalendarConnected(response.data.connected);
      } catch (error) {
        setGoogleCalendarConnected(false);
      }
    };
    checkConnection();
  }, []);

  const { data: twilioConfig } = useQuery({
      queryKey: ['twilio-settings'],
      queryFn: async () => {
        const companies = await base44.entities.Company.list("-created_date", 1);
        if (!companies || companies.length === 0) return null;
        const myCompany = companies.find(c => c.created_by === user?.email);
        if (!myCompany) return null;
        const settings = await base44.entities.TwilioSettings.filter({ company_id: myCompany.id });
        return settings[0] || null;
      },
      enabled: !!user,
  });

  const handleConnectGoogleCalendar = async () => {
    setSyncingCalendar(true);
    try {
      const response = await base44.functions.invoke('connectGoogleCalendar', {});
      if (response.data.authUrl) {
        window.location.href = response.data.authUrl;
      }
    } catch (error) {
      alert("Failed to connect Google Calendar: " + error.message);
      setSyncingCalendar(false);
    }
  };

  const handleDisconnectGoogleCalendar = async () => {
    if (!confirm("Disconnect Google Calendar? Events will no longer sync.")) return;
    try {
      await base44.functions.invoke('disconnectGoogleCalendar', {});
      setGoogleCalendarConnected(false);
      alert("✅ Google Calendar disconnected");
    } catch (error) {
      alert("Failed to disconnect: " + error.message);
    }
  };

  const handleSyncNow = async () => {
    setSyncingCalendar(true);
    try {
      await base44.functions.invoke('syncGoogleCalendar', {});
      alert("✅ Calendar synced successfully!");
    } catch (error) {
      alert("Sync failed: " + error.message);
    }
    setSyncingCalendar(false);
  };


  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
          <SettingsIcon className="w-7 h-7 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-500 mt-1">Configure your CRM integrations and preferences</p>
        </div>
      </div>

      <Tabs defaultValue="integrations" className="space-y-6">
        <TabsList className="w-full justify-start md:justify-center">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="automations">Automations</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <Card className="bg-white shadow-md">
            <CardHeader className="border-b bg-gray-50">
              <CardTitle className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-gray-600" />
                Company Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-4">
              <Alert className="bg-purple-50 border-purple-200">
                <Building2 className="w-4 h-4 text-purple-600" />
                <AlertDescription>
                  Company profile settings have moved to the <strong>Company Setup</strong> page.
                </AlertDescription>
              </Alert>
              <Button onClick={() => window.open('/company-setup', '_blank')}>Go to Company Setup</Button>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md">
            <CardHeader className="border-b bg-gray-50">
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-gray-600" />
                Billing & Subscription
              </CardTitle>
            </CardHeader>
            <CardContent className="p-12 text-center text-gray-500">
              <CreditCard className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold mb-2">Billing & Subscription</h3>
              <p>Billing settings coming soon</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div className="flex items-center gap-3">
                <Phone className="w-6 h-6 text-blue-600" />
                <div>
                  <CardTitle>Twilio Communication</CardTitle>
                  <p className="text-sm text-gray-500">Enable calling and SMS features for your team.</p>
                </div>
              </div>
              <Dialog open={showTwilioSetup} onOpenChange={setShowTwilioSetup}>
                <DialogTrigger asChild>
                  <Button variant="outline">Manage</Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl h-[90vh]">
                  <DialogHeader>
                    <DialogTitle>Twilio Integration Setup</DialogTitle>
                  </DialogHeader>
                  <TwilioSetup />
                </DialogContent>
              </Dialog>
            </CardHeader>
            <CardContent>
              {twilioConfig && twilioConfig.account_sid ? (
                <Alert className="bg-green-50 border-green-200">
                  <CheckCircle2 className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-900">
                    Twilio is connected. Click 'Manage' to configure numbers and features.
                  </AlertDescription>
                </Alert>
              ) : (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Twilio is not connected. Click 'Manage' to enter your credentials and set up the integration.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
            
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                Google Calendar Integration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-gray-600">
                Connect your Google Calendar to automatically sync all CRM events with your Google Calendar. 
                Two-way sync keeps everything up to date.
              </p>

              {googleCalendarConnected ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg">
                    <CheckCircle2 className="w-6 h-6 text-green-600" />
                    <div className="flex-1">
                      <p className="font-semibold text-green-900">Connected to Google Calendar</p>
                      <p className="text-sm text-green-700">Your events are syncing automatically</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <Button
                      onClick={handleSyncNow}
                      disabled={syncingCalendar}
                      variant="outline"
                    >
                      {syncingCalendar ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Syncing...
                        </>
                      ) : (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2" />
                          Sync Now
                        </>
                      )}
                    </Button>
                    <Button
                      onClick={handleDisconnectGoogleCalendar}
                      variant="outline"
                      className="text-red-600 hover:text-red-700"
                    >
                      Disconnect
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <Alert className="bg-blue-50 border-blue-200">
                    <LinkIcon className="w-4 h-4 text-blue-600" />
                    <AlertDescription className="text-blue-900">
                      <strong>Not Connected.</strong> Click below to connect your Google Calendar for automatic two-way sync.
                    </AlertDescription>
                  </Alert>

                  <Button
                    onClick={handleConnectGoogleCalendar}
                    disabled={syncingCalendar}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Calendar className="w-4 h-4 mr-2" />
                    Connect Google Calendar
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-white shadow-md">
            <CardHeader className="border-b bg-gray-50">
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-gray-600" />
                Email Integration
              </CardTitle>
            </CardHeader>
            <CardContent className="p-12 text-center text-gray-500">
              <Mail className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold mb-2">Email Integration</h3>
              <p>Email settings coming soon</p>
            </CardContent>
          </Card>

        </TabsContent>

        <TabsContent value="automations" className="space-y-6">
          <Card className="bg-white shadow-md">
            <CardHeader className="border-b bg-gray-50">
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-purple-600" />
                Automated Background Jobs (Cron Setup)
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              <Alert className="bg-blue-50 border-blue-200">
                <AlertCircle className="w-4 h-4 text-blue-600" />
                <AlertDescription>
                  These background jobs need to run automatically for your CRM to work properly.
                  Set them up once and forget about them!
                </AlertDescription>
              </Alert>
              
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                  ⏰ Reminder Notifications
                </h3>
                <p className="text-sm text-gray-600 mb-4">Without this, reminders created by you or Lexi will not send notifications.</p>
                <div className="bg-white border border-gray-300 rounded p-4 space-y-3">
                  <div>
                    <p className="text-xs font-semibold text-gray-700 mb-1">🔗 URL to Call:</p>
                    <code className="block bg-gray-100 p-2 rounded text-xs break-all">
                      {typeof window !== 'undefined' ? `${window.location.origin}/api/functions/checkReminders` : ''}
                    </code>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-gray-700 mb-1">⏱️ Schedule:</p>
                    <code className="block bg-gray-100 p-2 rounded text-xs">
                      * * * * * (Every 1 minute)
                    </code>
                  </div>
                </div>
              </div>

              <div className="bg-gray-50 border border-gray-200 rounded-lg p-6">
                <h3 className="font-semibold text-lg mb-4 flex items-center gap-2">
                  🔄 Workflow Queue Processor
                </h3>
                <p className="text-sm text-gray-600 mb-4">Runs your delayed workflow actions (e.g., emails scheduled for "1 day later").</p>
                 <div className="bg-white border border-gray-300 rounded p-4 space-y-3">
                    <div>
                      <p className="text-xs font-semibold text-gray-700 mb-1">🔗 URL to Call:</p>
                      <code className="block bg-gray-100 p-2 rounded text-xs break-all">
                        {typeof window !== 'undefined' ? `${window.location.origin}/api/functions/processWorkflowQueue` : ''}
                      </code>
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-gray-700 mb-1">⏱️ Schedule:</p>
                      <code className="block bg-gray-100 p-2 rounded text-xs">
                        */5 * * * * (Every 5 minutes)
                      </code>
                    </div>
                  </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-4">
          <Card className="bg-white shadow-md">
            <CardHeader className="border-b bg-gray-50">
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-gray-600" />
                Notification Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="p-12 text-center text-gray-500">
              <MessageSquare className="w-16 h-16 mx-auto mb-4 text-gray-300" />
              <h3 className="text-lg font-semibold mb-2">Notification Settings</h3>
              <p>Notification preferences coming soon</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}