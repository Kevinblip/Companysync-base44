

import React, { useState, useEffect, useMemo } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutDashboard,
  Users,
  UserPlus,
  Calendar,
  MessageSquare,
  FileText,
  DollarSign,
  Briefcase,
  Sparkles,
  Settings,
  Bell,
  Search,
  ChevronDown,
  LogOut,
  Bot,
  Clock,
  Activity,
  ShoppingCart,
  UserCircle,
  MapPin,
  Video,
  UserCog,
  Wallet,
  Calculator,
  Mail,
  CreditCard,
  Receipt,
  Layout as LayoutIcon,
  FileSignature,
  Map as MapIcon,
  Headphones,
  ClipboardList,
  BookOpen,
  Wrench,
  BarChart3,
  Plug,
  Shield,
  ArrowLeft,
  Upload,
  Phone,
  MessageCircle,
  Cloud,
  Layers,
  Menu,
  Camera, // Added Camera icon
  Zap // Added Zap icon for Setup Wizard
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

import Dialer from "../components/communication/Dialer";
import EmailDialog from "../components/communication/EmailDialog";
import SMSDialog from "../components/communication/SMSDialog";
import MobileNav from "../components/MobileNav";
import FloatingActionButton from "../components/FloatingActionButton";

// Moved the hook directly into this file to fix the path error
function useMediaQuery(query) {
  const [matches, setMatches] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }

    const media = window.matchMedia(query);
    if (media.matches !== matches) {
      setMatches(media.matches);
    }

    const listener = () => setMatches(media.matches);
    media.addEventListener('change', listener);
    
    return () => media.removeEventListener('change', listener);
  }, [matches, query]);

  return matches;
}


export default function Layout({ children }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = React.useState(null);
  const [openMenus, setOpenMenus] = React.useState({});
  const [showDialer, setShowDialer] = React.useState(false);
  const [showEmailDialog, setShowEmailDialog] = React.useState(false);
  const [showSMSDialog, setShowSMSDialog] = React.useState(false);

  const isMobile = useMediaQuery("(max-width: 768px)");
  const [sidebarOpen, setSidebarOpen] = useState(!isMobile);

  const [setupBannerDismissed, setSetupBannerDismissed] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('setupBannerDismissed') === 'true';
    }
    return false;
  });

  useEffect(() => {
    // This logic ensures the sidebar is open on desktop and closed by default on mobile.
    setSidebarOpen(!isMobile);
  }, [isMobile]);

  React.useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  // Get staff profile to find company
  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['staff-profiles', user?.email],
    queryFn: () => user ? base44.entities.StaffProfile.filter({ user_email: user.email }) : [],
    enabled: !!user,
    initialData: [],
  });

  // Find company - either created by user or from staff profile
  const myCompany = React.useMemo(() => {
    if (!user) return null;
    
    const ownedCompany = companies.find(c => c.created_by === user.email);
    if (ownedCompany) return ownedCompany;
    
    const staffProfile = staffProfiles[0];
    if (staffProfile?.company_id) {
      return companies.find(c => c.id === staffProfile.company_id);
    }
    
    return null;
  }, [user, companies, staffProfiles]);

  const { data: menuSettings = [] } = useQuery({
    queryKey: ['menu-settings', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.MenuSettings.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const currentMenuSettings = menuSettings[0];

  // Check if setup is completed and if banner has been dismissed
  const showSetupBanner = myCompany && !myCompany.setup_completed && !setupBannerDismissed;

  // Default navigation structure
  const defaultNavigationItems = useMemo(() => [
    { id: 'dashboard', title: "Dashboard", url: createPageUrl("Dashboard"), icon: LayoutDashboard, order: 0 },
    { id: 'ai-estimator', title: "AI Estimator", url: createPageUrl("AIEstimator"), icon: Sparkles, order: 1 },
    { id: 'storm-tracking', title: "Storm Tracking", url: createPageUrl("StormTracking"), icon: Cloud, order: 2 },
    { id: 'property-importer', title: "Property Data Importer", url: createPageUrl("PropertyDataImporter"), icon: Upload, order: 3 },
    {
      id: 'inspections',
      title: "Inspections",
      icon: Camera,
      order: 4,
      submenu: [
        { id: 'inspections-dashboard', title: "Inspections Dashboard", url: createPageUrl("InspectionsDashboard") },
        { id: 'new-inspection', title: "New Inspection", url: createPageUrl("NewInspection") },
        { id: 'ai-damage', title: "AI Damage Analysis", url: createPageUrl("DroneInspections") },
        { id: 'inspection-reports', title: "Inspection Reports", url: createPageUrl("InspectionReports") },
        { id: 'inspectors', title: "Manage Inspectors", url: createPageUrl("Inspectors") },
      ]
    },
    { id: 'lexi', title: "Lexi AI", url: createPageUrl("AIAssistant"), icon: Bot, order: 5 },
    { id: 'calendar', title: "Calendar", url: createPageUrl("Calendar"), icon: Calendar, order: 6 },
    { id: 'activity', title: "Activity", url: createPageUrl("Activity"), icon: Activity, order: 7 },
    {
      id: 'lead-manager',
      title: "Lead Manager",
      icon: UserPlus,
      order: 8,
      submenu: [
        { id: 'all-leads', title: "All Leads", url: createPageUrl("Leads") },
        { id: 'lead-finder', title: "Lead Finder", url: createPageUrl("LeadFinder") },
        { id: 'lead-inspections', title: "Inspections", url: createPageUrl("LeadInspections") },
      ]
    },
    {
      id: 'customers',
      title: "Customers",
      icon: Users,
      order: 9,
      submenu: [
        { id: 'all-customers', title: "All Customers", url: createPageUrl("Customers") },
      ]
    },
    {
      id: 'sales',
      title: "Sales",
      icon: ShoppingCart,
      order: 10,
      submenu: [
        { id: 'sales-dashboard', title: "Sales Dashboard", url: createPageUrl("SalesDashboard") },
        { id: 'sales-tracking', title: "Sales Tracking", url: createPageUrl("SalesTracking") },
        { id: 'proposals', title: "Proposals", url: createPageUrl("Proposals") },
        { id: 'estimates', title: "Estimates", url: createPageUrl("Estimates") },
        { id: 'invoices', title: "Invoices", url: createPageUrl("Invoices") },
        { id: 'payments', title: "Payments", url: createPageUrl("Payments") },
        { id: 'items', title: "Items", url: createPageUrl("Items") },
        { id: 'custom-formats', title: "Custom Formats", url: createPageUrl("CustomFormats") },
      ]
    },
    { id: 'tasks', title: "Tasks", url: createPageUrl("Tasks"), icon: FileText, order: 11 },
    {
      id: 'communication',
      title: "Communication",
      icon: MessageSquare,
      order: 12,
      submenu: [
        { id: 'communication-hub', title: "Communication Hub", url: createPageUrl("Communication") },
        { id: 'ai-dashboard', title: "AI Dashboard", url: createPageUrl("CommunicationDashboard") },
      ]
    },
    {
      id: 'ai-staff',
      title: "AI Staff",
      icon: UserCircle,
      order: 13,
      submenu: [
        { id: 'ai-team', title: "AI Team", url: createPageUrl("AIStaff") },
      ]
    },
    { id: 'zoom', title: "Zoom Meeting", url: createPageUrl("ZoomMeeting"), icon: Video, order: 14 },
    { id: 'payroll', title: "Hr payroll", url: createPageUrl("Payroll"), icon: Wallet, order: 15 },
    {
      id: 'accounting',
      title: "Accounting",
      icon: Calculator,
      order: 16,
      submenu: [
        { id: 'accounting-overview', title: "Overview", url: createPageUrl("Accounting") },
      ]
    },
    { id: 'mailbox', title: "Mailbox", url: createPageUrl("Mailbox"), icon: Mail, order: 17 },
    { id: 'subscriptions', title: "Subscriptions", url: createPageUrl("Subscriptions"), icon: CreditCard, order: 18 },
    {
      id: 'expenses',
      title: "Expenses",
      icon: Receipt,
      order: 19,
      submenu: [
        { id: 'all-expenses', title: "All Expenses", url: createPageUrl("Expenses") },
      ]
    },
    { id: 'page-builder', title: "Page Builder", url: createPageUrl("PageBuilder"), icon: LayoutIcon, order: 20 },
    {
      id: 'contracts',
      title: "Contracts",
      icon: FileSignature,
      order: 21,
      submenu: [
        { id: 'all-contracts', title: "All Contracts", url: createPageUrl("Contracts") },
        { id: 'contract-templates', title: "Contract Templates", url: createPageUrl("ContractTemplates") },
        { id: 'contract-signing', title: "Contract Signing", url: createPageUrl("ContractSigning") },
      ]
    },
    {
      id: 'documents',
      title: "Documents",
      icon: Layers,
      order: 22,
      submenu: [
        { id: 'all-documents', title: "All Documents", url: createPageUrl("Documents") },
        { id: 'conversation-history', title: "Conversation History", url: createPageUrl("ConversationHistory") },
        { id: 'customer-portal', title: "Customer Portal", url: createPageUrl("CustomerPortal") },
        { id: 'messages', title: "Messages", url: createPageUrl("Messages") },
      ]
    },
    { id: 'projects', title: "Projects", url: createPageUrl("Projects"), icon: Briefcase, order: 23 },
    { id: 'map', title: "Map", url: createPageUrl("Map"), icon: MapIcon, order: 24 },
    { id: 'support', title: "Support", url: createPageUrl("Support"), icon: Headphones, order: 25 },
    { id: 'knowledge-base', title: "Knowledge Base", url: createPageUrl("KnowledgeBase"), icon: BookOpen, order: 26 },
    { id: 'utilities', title: "Utilities", url: createPageUrl("Utilities"), icon: Wrench, order: 27 },
    {
      id: 'reports',
      title: "Reports",
      icon: BarChart3,
      order: 28,
      submenu: [
        { id: 'analytics-dashboard', title: "Analytics Dashboard", url: createPageUrl("Analytics") },
        { id: 'report-builder', title: "Custom Report Builder", url: createPageUrl("ReportBuilder") },
        { id: 'sales-reports', title: "Sales Reports", url: createPageUrl("Reports") + "?category=sales" },
        { id: 'expenses-reports', title: "Expenses Reports", url: createPageUrl("Reports") + "?category=expenses" },
        { id: 'expenses-vs-income', title: "Expenses vs Income", url: createPageUrl("Reports") + "?category=expenses_vs_income" },
        { id: 'leads-reports', title: "Leads Reports", url: createPageUrl("Reports") + "?category=leads" },
        { id: 'timesheets-overview', title: "Timesheets Overview", url: createPageUrl("Reports") + "?category=timesheets" },
        { id: 'kb-articles', title: "KB Articles", url: createPageUrl("Reports") + "?category=kb_articles" },
      ]
    },
    { id: 'integration-manager', title: "Integration Manager", url: createPageUrl("IntegrationManager"), icon: Plug, order: 29 },
    {
      id: 'admin',
      title: "Admin",
      icon: Shield,
      order: 30,
      submenu: [
        { id: 'company-setup', title: "Company Setup", url: createPageUrl("CompanySetup") },
        { id: 'staff-management', title: "Staff Management", url: createPageUrl("StaffManagement") },
        { id: 'roles-management', title: "Roles Management", url: createPageUrl("RolesManagement") },
        { id: 'staff-bulk-import', title: "Staff Bulk Import", url: createPageUrl("DataImport") },
        { id: 'email-templates', title: "Email Templates", url: createPageUrl("EmailTemplates") },
        { id: 'sms-templates', title: "SMS Templates", url: createPageUrl("SMSTemplates") },
        { id: 'workflows', title: "Workflows", url: createPageUrl("Workflows") },
        { id: 'storm-alert-settings', title: "Storm Alert Settings", url: createPageUrl("StormAlertSettings") },
        { id: 'menu-setup', title: "Menu Setup", url: createPageUrl("MenuSetup") },
        { id: 'custom-fields', title: "Custom Fields", url: createPageUrl("CustomFields") },
        { id: 'data-import', title: "Data Import", url: createPageUrl("DataImport") },
        { id: 'estimate-importer', title: "Estimate Importer", url: createPageUrl("EstimateImporter") },
        { id: 'settings', title: "Settings", url: createPageUrl("Settings") },
      ]
    },
  ], []); // empty dependency array as defaultNavigationItems is a static structure

  // Apply custom menu settings
  const displayNavigationItems = useMemo(() => {
    if (!currentMenuSettings?.menu_items) {
      return defaultNavigationItems;
    }

    const customItems = currentMenuSettings.menu_items;
    
    // Map custom settings to navigation items
    return customItems
      .filter(customItem => customItem.enabled !== false) // Only include enabled top-level items
      .map(customItem => {
        const defaultItem = defaultNavigationItems.find(item => item.id === customItem.id);
        if (!defaultItem) return null; // If custom item ID doesn't match any default item, ignore it

        const item = {
          ...defaultItem,
          order: customItem.order ?? defaultItem.order, // Use custom order if available, otherwise default
          enabled: customItem.enabled ?? true, // Use custom enabled if available, otherwise true
        };

        if (item.submenu && customItem.submenuItems) {
          item.submenu = item.submenu.filter(sub => {
            const customSub = customItem.submenuItems.find(cs => cs.id === sub.id);
            return customSub?.enabled !== false; // Only include enabled sub-items
          });
        }
        
        return item;
      })
      .filter(Boolean) // Remove any nulls from items that didn't match
      .sort((a, b) => a.order - b.order); // Sort by order
  }, [currentMenuSettings, defaultNavigationItems]);


  const toggleMenu = (title) => {
    setOpenMenus(prev => ({ ...prev, [title]: !prev[title] }));
  };

  const handleBack = () => {
    if (location.key !== "default") {
      navigate(-1);
    } else {
      navigate(createPageUrl("Dashboard"));
    }
  };

  const handleMobileMenuClick = () => {
    setSidebarOpen(true);
  };

  const dismissSetupBanner = () => {
    localStorage.setItem('setupBannerDismissed', 'true');
    setSetupBannerDismissed(true);
  };

  return (
    <SidebarProvider open={sidebarOpen} onOpenChange={setSidebarOpen}>
      <style>{`
        [data-sidebar="sidebar"] {
          background: linear-gradient(180deg, #1e3a8a 0%, #1e40af 50%, #7c3aed 100%) !important;
        }
        
        /* Add padding to bottom of main content on mobile to account for bottom nav */
        @media (max-width: 768px) {
          main > div {
            padding-bottom: 5rem !important;
          }
        }
        
        /* Improve touch targets on mobile */
        @media (max-width: 768px) {
          button, a, [role="button"] {
            min-height: 44px;
            min-width: 44px;
          }
          
          /* Larger spacing on mobile */
          .space-y-2 {
            gap: 1rem;
          }
          
          .space-y-4 {
            gap: 1.5rem;
          }
          
          .space-y-6 {
            gap: 2rem;
          }
          
          /* Larger text on mobile */
          body {
            font-size: 16px;
          }
          
          h1 {
            font-size: 1.75rem !important;
          }
          
          h2 {
            font-size: 1.5rem !important;
          }
          
          h3 {
            font-size: 1.25rem !important;
          }
        }
      `}</style>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-blue-50 to-purple-50">
        <Sidebar className="border-r border-blue-700 data-[state=closed]:hidden md:data-[state=closed]:block">
          <SidebarHeader className="p-6 border-b border-blue-700">
            <div className="flex items-center gap-3">
              {myCompany?.logo_url ? (
                <img 
                  src={myCompany.logo_url} 
                  alt={myCompany.company_name || "Company Logo"} 
                  className="w-10 h-10 rounded-lg object-cover bg-white p-1"
                />
              ) : (
                <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-blue-600" />
                </div>
              )}
              <div>
                <h2 className="font-bold text-white text-lg">
                  {myCompany?.company_name || "AI CRM Pro"}
                </h2>
                <p className="text-xs text-blue-200">
                  {myCompany?.company_tagline || "Smart Business Management"}
                </p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent className="p-3">
            {/* Setup Wizard Quick Access - Now Dismissible */}
            {showSetupBanner && (
              <div className="mb-4 p-3 bg-yellow-400/20 border border-yellow-400/50 rounded-lg relative">
                <button
                  onClick={dismissSetupBanner}
                  className="absolute top-1 right-1 text-yellow-400/80 hover:text-yellow-400"
                  title="Dismiss"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
                <div className="flex items-center gap-2 mb-2 pr-6">
                  <Zap className="w-4 h-4 text-yellow-400" />
                  <p className="text-xs font-semibold text-white">Complete Setup</p>
                </div>
                <Button
                  onClick={() => navigate(createPageUrl('SetupWizard'))}
                  size="sm"
                  className="w-full bg-yellow-400 hover:bg-yellow-500 text-gray-900"
                >
                  Start Wizard
                </Button>
              </div>
            )}

            <SidebarGroup>
              <SidebarGroupContent>
                <SidebarMenu>
                  {displayNavigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      {item.submenu ? (
                        <Collapsible open={openMenus[item.title]} onOpenChange={() => toggleMenu(item.title)}>
                          <CollapsibleTrigger asChild>
                            <SidebarMenuButton
                              className="hover:bg-white/10 text-white transition-all duration-200 rounded-lg mb-1 w-full justify-between min-h-[44px]"
                            >
                              <div className="flex items-center gap-3">
                                {item.title === "Lexi AI" ? (
                                  <img 
                                    src="/path/to/lexi-ai-photo.png"
                                    alt="Lexi AI" 
                                    className="w-5 h-5 rounded-full object-cover" 
                                  />
                                ) : (
                                  item.icon && <item.icon className="w-5 h-5" />
                                )}
                                <span className="font-medium">{item.title}</span>
                              </div>
                              <ChevronDown className={`w-4 h-4 transition-transform ${openMenus[item.title] ? 'rotate-180' : ''}`} />
                            </SidebarMenuButton>
                          </CollapsibleTrigger>
                          <CollapsibleContent className="ml-8 mt-1 space-y-1">
                            {item.submenu.map((subitem) => (
                              <SidebarMenuButton
                                key={subitem.title}
                                asChild
                                className={`hover:bg-white/10 text-white text-sm transition-all duration-200 rounded-lg min-h-[44px] ${
                                  location.pathname + location.search === subitem.url ? 'bg-white/20' : ''
                                }`}
                              >
                                <Link to={subitem.url} className="flex items-center gap-3 px-3 py-2" onClick={() => isMobile && setSidebarOpen(false)}>
                                  <span>{subitem.title}</span>
                                </Link>
                              </SidebarMenuButton>
                            ))}
                          </CollapsibleContent>
                        </Collapsible>
                      ) : (
                        <SidebarMenuButton
                          asChild
                          className={`hover:bg-white/10 text-white transition-all duration-200 rounded-lg mb-1 min-h-[44px] ${
                            location.pathname === item.url ? 'bg-white/20 shadow-lg' : ''
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-3 py-3" onClick={() => isMobile && setSidebarOpen(false)}>
                            {item.title === "Lexi AI" ? (
                              <img 
                                src="/path/to/lexi-ai-photo.png"
                                alt="Lexi AI" 
                                className="w-5 h-5 rounded-full object-cover" 
                              />
                            ) : (
                              item.icon && <item.icon className="w-5 h-5" />
                            )}
                            <span className="font-medium">{item.title}</span>
                          </Link>
                        </SidebarMenuButton>
                      )}
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-gradient-to-r from-blue-600 via-blue-500 to-purple-600 border-b border-blue-400 px-4 md:px-6 py-3 md:py-4 shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 md:gap-4">
                <SidebarTrigger className="text-white hover:bg-white/10 p-2 rounded-lg transition-colors duration-200 md:hidden" />
                
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleBack}
                  className="text-white hover:bg-white/10 flex items-center gap-2 min-h-[44px]"
                  type="button"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span className="hidden md:inline">Back</span>
                </Button>

                <div className="relative hidden md:block">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search..."
                    className="pl-10 w-80 bg-white/90 border-0 focus:bg-white"
                  />
                </div>
              </div>

              <div className="flex items-center gap-1 md:gap-2">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:bg-white/10 min-h-[44px] min-w-[44px]"
                  onClick={() => setShowDialer(true)}
                  title="Make a call"
                >
                  <Phone className="w-5 h-5" />
                </Button>

                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:bg-white/10 min-h-[44px] min-w-[44px]"
                  onClick={() => setShowEmailDialog(true)}
                  title="Send email"
                >
                  <Mail className="w-5 h-5" />
                </Button>

                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="text-white hover:bg-white/10 min-h-[44px] min-w-[44px]"
                  onClick={() => setShowSMSDialog(true)}
                  title="Send SMS"
                >
                  <MessageCircle className="w-5 h-5" />
                </Button>

                <div className="w-px h-6 bg-white/20 mx-1 md:mx-2 hidden md:block"></div>

                <Button variant="ghost" size="icon" className="text-white hover:bg-white/10 min-h-[44px] min-w-[44px] hidden md:flex">
                  <Bell className="w-5 h-5" />
                </Button>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="text-white hover:bg-white/10 flex items-center gap-2 min-h-[44px]">
                      <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                        <span className="text-blue-600 font-semibold text-sm">
                          {user?.full_name?.[0] || 'U'}
                        </span>
                      </div>
                      <span className="hidden md:inline font-medium">{user?.full_name || 'User'}</span>
                      <ChevronDown className="w-4 h-4 hidden md:block" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    <DropdownMenuItem onClick={() => base44.auth.logout()}>
                      <LogOut className="w-4 h-4 mr-2" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
          
          {isMobile && <MobileNav onMenuClick={handleMobileMenuClick} />}
          
          {isMobile && <FloatingActionButton />}
        </main>
      </div>

      <Dialer
        open={showDialer}
        onOpenChange={setShowDialer}
      />
      <EmailDialog
        open={showEmailDialog}
        onOpenChange={setShowEmailDialog}
      />
      <SMSDialog
        open={showSMSDialog}
        onOpenChange={setShowSMSDialog}
      />
    </SidebarProvider>
  );
}

