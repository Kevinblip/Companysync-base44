import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { createPageUrl } from '@/utils';
import { Link, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Loader2, ArrowLeft } from 'lucide-react';

export default function InspectionReports() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const { data: jobs = [], isLoading: isLoadingJobs } = useQuery({
    queryKey: ['inspectionJobs'],
    queryFn: () => base44.entities.InspectionJob.list('-created_date'),
  });

  const { data: media = [] } = useQuery({
    queryKey: ['inspectionMedia'],
    queryFn: () => base44.entities.JobMedia.filter({ related_entity_type: 'InspectionJob' }),
    initialData: [],
  });
  
  const filteredJobs = jobs
    .filter(job => job.property_address?.toLowerCase().includes(searchTerm.toLowerCase()))
    .filter(job => statusFilter === 'all' || job.status === statusFilter);

  const getJobMediaCount = (jobId) => {
    return media.filter(m => m.related_entity_id === jobId).length;
  }

  const completedJobs = jobs.filter(j => j.status === 'completed').length;
  const totalPhotos = media.filter(m => m.file_type === 'photo').length;
  const totalVideos = media.filter(m => m.file_type === 'video').length;

  return (
    <div className="p-6 bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-6">
        <Button variant="ghost" onClick={() => navigate(createPageUrl('InspectionsDashboard'))} className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" /> Back to Dashboard
        </Button>
        <h1 className="text-3xl font-bold text-gray-800">Inspection Reports</h1>

        <Card>
            <CardHeader>
                <CardTitle>Report Summary</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-4">
                <div className="p-4 bg-gray-100 rounded-lg">
                    <h4 className="text-sm text-gray-600">Total Jobs</h4>
                    <p className="text-2xl font-bold">{jobs.length}</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="text-sm text-green-700">Completed</h4>
                    <p className="text-2xl font-bold">{completedJobs}</p>
                </div>
                <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="text-sm text-blue-700">Total Photos</h4>
                    <p className="text-2xl font-bold">{totalPhotos}</p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                    <h4 className="text-sm text-purple-700">Total Videos</h4>
                    <p className="text-2xl font-bold">{totalVideos}</p>
                </div>
            </CardContent>
        </Card>

        <div className="flex gap-4">
            <Input 
                placeholder="Search by address..." 
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                className="max-w-sm"
            />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
            </Select>
        </div>

        {isLoadingJobs ? (
            <div className="text-center"><Loader2 className="animate-spin inline-block"/></div>
        ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {filteredJobs.map(job => (
                    <Card key={job.id}>
                        <CardHeader>
                            <CardTitle className="text-base">{job.property_address}</CardTitle>
                            <p className="text-sm text-gray-500">{job.client_name}</p>
                            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${job.status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>{job.status}</span>
                        </CardHeader>
                        <CardContent className="flex justify-between items-center">
                            <div className="text-sm text-gray-600">
                                <p>{getJobMediaCount(job.id)} media items</p>
                                <p>Created: {new Date(job.created_date).toLocaleDateString()}</p>
                            </div>
                            <Button asChild variant="outline">
                                <Link to={createPageUrl(`InspectionCapture?id=${job.id}`)}>View Details</Link>
                            </Button>
                        </CardContent>
                    </Card>
                ))}
            </div>
        )}
      </div>
    </div>
  );
}