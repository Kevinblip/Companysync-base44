import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Mail, Inbox, Send, Archive, Trash2, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Mailbox() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Mailbox</h1>
          <p className="text-gray-500 mt-1">Manage your email communications</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Mail className="w-4 h-4 mr-2" />
          Compose
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Inbox className="w-5 h-5 text-blue-600" />
              <span className="font-medium">Inbox</span>
            </div>
            <Badge>0</Badge>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Send className="w-5 h-5 text-green-600" />
              <span className="font-medium">Sent</span>
            </div>
            <Badge variant="outline">0</Badge>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Star className="w-5 h-5 text-yellow-600" />
              <span className="font-medium">Starred</span>
            </div>
            <Badge variant="outline">0</Badge>
          </CardContent>
        </Card>

        <Card className="hover:shadow-md transition-shadow cursor-pointer">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Archive className="w-5 h-5 text-purple-600" />
              <span className="font-medium">Archive</span>
            </div>
            <Badge variant="outline">0</Badge>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Inbox</CardTitle>
        </CardHeader>
        <CardContent className="text-center py-12 text-gray-500">
          <Mail className="w-16 h-16 mx-auto mb-4 text-gray-300" />
          <p>No emails yet</p>
          <p className="text-sm mt-1">Connect your email account in Integration Manager</p>
        </CardContent>
      </Card>
    </div>
  );
}