
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch"; // This import is not used in the updated code, but preserving as it was in original
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import { GripVertical, Save, RotateCcw, Eye, EyeOff } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function MenuSetup() {
  const [user, setUser] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [hasChanges, setHasChanges] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  // Get staff profile to find company
  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['staff-profiles', user?.email],
    queryFn: () => user ? base44.entities.StaffProfile.filter({ user_email: user.email }) : [],
    enabled: !!user,
    initialData: [],
  });

  // Find company - either created by user or from staff profile
  const myCompany = React.useMemo(() => {
    if (!user) return null;
    
    // First try: user created the company
    const ownedCompany = companies.find(c => c.created_by === user.email);
    if (ownedCompany) return ownedCompany;
    
    // Second try: user is staff member
    const staffProfile = staffProfiles[0];
    if (staffProfile?.company_id) {
      return companies.find(c => c.id === staffProfile.company_id);
    }
    
    return null;
  }, [user, companies, staffProfiles]);

  const { data: menuSettings = [] } = useQuery({
    queryKey: ['menu-settings', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.MenuSettings.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const currentSettings = menuSettings[0];

  // Default menu structure
  const defaultMenuItems = [
    { id: 'dashboard', title: 'Dashboard', enabled: true, order: 0 },
    { id: 'ai-estimator', title: 'AI Estimator', enabled: true, order: 1 },
    { id: 'storm-tracking', title: 'Storm Tracking', enabled: true, order: 2 },
    { id: 'property-importer', title: 'Property Data Importer', enabled: true, order: 3 },
    { 
      id: 'inspections', 
      title: 'Inspections', 
      enabled: true, 
      order: 4,
      hasSubmenu: true,
      submenuItems: [
        { id: 'inspections-dashboard', title: 'Inspections Dashboard', enabled: true },
        { id: 'new-inspection', title: 'New Inspection', enabled: true },
        { id: 'ai-damage', title: 'AI Damage Analysis', enabled: true },
        { id: 'inspection-reports', title: 'Inspection Reports', enabled: true },
        { id: 'inspectors', title: 'Manage Inspectors', enabled: true },
      ]
    },
    { id: 'lexi', title: 'Lexi AI', enabled: true, order: 5 },
    { id: 'calendar', title: 'Calendar', enabled: true, order: 6 },
    { id: 'activity', title: 'Activity', enabled: true, order: 7 },
    { 
      id: 'lead-manager', 
      title: 'Lead Manager', 
      enabled: true, 
      order: 8,
      hasSubmenu: true,
      submenuItems: [
        { id: 'all-leads', title: 'All Leads', enabled: true },
        { id: 'lead-finder', title: 'Lead Finder', enabled: true },
      ]
    },
    { 
      id: 'customers', 
      title: 'Customers', 
      enabled: true, 
      order: 9,
      hasSubmenu: true,
      submenuItems: [
        { id: 'all-customers', title: 'All Customers', enabled: true },
      ]
    },
    { 
      id: 'sales', 
      title: 'Sales', 
      enabled: true, 
      order: 10,
      hasSubmenu: true,
      submenuItems: [
        { id: 'sales-dashboard', title: 'Sales Dashboard', enabled: true },
        { id: 'sales-tracking', title: 'Sales Tracking', enabled: true },
        { id: 'proposals', title: 'Proposals', enabled: true },
        { id: 'estimates', title: 'Estimates', enabled: true },
        { id: 'invoices', title: 'Invoices', enabled: true },
        { id: 'payments', title: 'Payments', enabled: true },
        { id: 'items', title: 'Items', enabled: true },
        { id: 'custom-formats', title: 'Custom Formats', enabled: true },
      ]
    },
    { id: 'tasks', title: 'Tasks', enabled: true, order: 11 },
    { 
      id: 'communication', 
      title: 'Communication', 
      enabled: true, 
      order: 12,
      hasSubmenu: true,
      submenuItems: [
        { id: 'communication-hub', title: 'Communication Hub', enabled: true },
        { id: 'ai-dashboard', title: 'AI Dashboard', enabled: true },
      ]
    },
    { 
      id: 'ai-staff', 
      title: 'AI Staff', 
      enabled: true, 
      order: 13,
      hasSubmenu: true,
      submenuItems: [
        { id: 'ai-team', title: 'AI Team', enabled: true },
      ]
    },
    { id: 'zoom', title: 'Zoom Meeting', enabled: true, order: 14 },
    { id: 'payroll', title: 'Hr payroll', enabled: true, order: 15 },
    { 
      id: 'accounting', 
      title: 'Accounting', 
      enabled: true, 
      order: 16,
      hasSubmenu: true,
      submenuItems: [
        { id: 'accounting-overview', title: 'Overview', enabled: true },
      ]
    },
    { id: 'mailbox', title: 'Mailbox', enabled: true, order: 17 },
    { id: 'subscriptions', title: 'Subscriptions', enabled: true, order: 18 },
    { 
      id: 'expenses', 
      title: 'Expenses', 
      enabled: true, 
      order: 19,
      hasSubmenu: true,
      submenuItems: [
        { id: 'all-expenses', title: 'All Expenses', enabled: true },
      ]
    },
    { id: 'page-builder', title: 'Page Builder', enabled: true, order: 20 },
    { 
      id: 'contracts', 
      title: 'Contracts', 
      enabled: true, 
      order: 21,
      hasSubmenu: true,
      submenuItems: [
        { id: 'all-contracts', title: 'All Contracts', enabled: true },
        { id: 'contract-templates', title: 'Contract Templates', enabled: true },
        { id: 'contract-signing', title: 'Contract Signing', enabled: true },
      ]
    },
    { 
      id: 'documents', 
      title: 'Documents', 
      enabled: true, 
      order: 22,
      hasSubmenu: true,
      submenuItems: [
        { id: 'all-documents', title: 'All Documents', enabled: true },
        { id: 'conversation-history', title: 'Conversation History', enabled: true },
        { id: 'customer-portal', title: 'Customer Portal', enabled: true },
        { id: 'messages', title: 'Messages', enabled: true },
      ]
    },
    { id: 'projects', title: 'Projects', enabled: true, order: 23 },
    { id: 'map', title: 'Map', enabled: true, order: 24 },
    { id: 'support', title: 'Support', enabled: true, order: 25 },
    { id: 'knowledge-base', title: 'Knowledge Base', enabled: true, order: 26 },
    { id: 'utilities', title: 'Utilities', enabled: true, order: 27 },
    { 
      id: 'reports', 
      title: 'Reports', 
      enabled: true, 
      order: 28,
      hasSubmenu: true,
      submenuItems: [
        { id: 'analytics-dashboard', title: 'Analytics Dashboard', enabled: true },
        { id: 'report-builder', title: 'Custom Report Builder', enabled: true },
        { id: 'sales-reports', title: 'Sales Reports', enabled: true },
        { id: 'expenses-reports', title: 'Expenses Reports', enabled: true },
        { id: 'expenses-vs-income', title: 'Expenses vs Income', enabled: true },
        { id: 'leads-reports', title: 'Leads Reports', enabled: true },
        { id: 'timesheets-overview', title: 'Timesheets Overview', enabled: true },
        { id: 'kb-articles', title: 'KB Articles', enabled: true },
      ]
    },
    { id: 'integration-manager', title: 'Integration Manager', enabled: true, order: 29 },
    { 
      id: 'admin', 
      title: 'Admin', 
      enabled: true, 
      order: 30,
      hasSubmenu: true,
      submenuItems: [
        { id: 'company-setup', title: 'Company Setup', enabled: true },
        { id: 'staff-management', title: 'Staff Management', enabled: true },
        { id: 'roles-management', title: 'Roles Management', enabled: true },
        { id: 'staff-bulk-import', title: 'Staff Bulk Import', enabled: true },
        { id: 'email-templates', title: 'Email Templates', enabled: true },
        { id: 'sms-templates', title: 'SMS Templates', enabled: true },
        { id: 'workflows', title: 'Workflows', enabled: true },
        { id: 'storm-alert-settings', title: 'Storm Alert Settings', enabled: true },
        { id: 'menu-setup', title: 'Menu Setup', enabled: true },
        { id: 'custom-fields', title: 'Custom Fields', enabled: true },
        { id: 'data-import', title: 'Data Import', enabled: true },
        { id: 'estimate-importer', title: 'Estimate Importer', enabled: true },
        { id: 'settings', title: 'Settings', enabled: true },
      ]
    },
  ];

  useEffect(() => {
    if (currentSettings?.menu_items) {
      setMenuItems(currentSettings.menu_items);
    } else {
      setMenuItems(defaultMenuItems);
    }
  }, [currentSettings]);

  const saveMenuMutation = useMutation({
    mutationFn: async (items) => {
      if (!myCompany) {
        throw new Error('No company found for user');
      }

      if (currentSettings) {
        return base44.entities.MenuSettings.update(currentSettings.id, {
          menu_items: items
        });
      } else {
        return base44.entities.MenuSettings.create({
          company_id: myCompany.id,
          menu_items: items
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['menu-settings'] });
      setHasChanges(false);
      alert('✅ Menu settings saved successfully!');
    },
  });

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = Array.from(menuItems);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    const reordered = items.map((item, index) => ({
      ...item,
      order: index
    }));

    setMenuItems(reordered);
    setHasChanges(true);
  };

  const toggleItem = (itemId, submenuId = null) => {
    const updated = menuItems.map(item => {
      if (item.id === itemId) {
        if (submenuId && item.hasSubmenu && item.submenuItems) {
          return {
            ...item,
            submenuItems: item.submenuItems.map(sub => 
              sub.id === submenuId ? { ...sub, enabled: !sub.enabled } : sub
            )
          };
        } else {
          return { ...item, enabled: !item.enabled };
        }
      }
      return item;
    });
    setMenuItems(updated);
    setHasChanges(true);
  };

  const handleSave = () => {
    saveMenuMutation.mutate(menuItems);
  };

  const handleReset = () => {
    if (window.confirm('Reset to default menu settings? This cannot be undone.')) {
      setMenuItems(defaultMenuItems);
      setHasChanges(true);
    }
  };

  if (!user) {
    return (
      <div className="p-6">
        <Alert>
          <AlertDescription>Loading user profile...</AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!myCompany) {
    return (
      <div className="p-6">
        <Alert variant="destructive">
          <AlertDescription>
            ⚠️ No company found for user {user.email}. Please set up your company profile first in Admin → Company Setup, or ensure you are associated with a company as a staff member.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Menu Setup</h1>
          <p className="text-gray-500 mt-1">
            Drag parent items to reorder. All submenu items move together.
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={handleReset}
            disabled={saveMenuMutation.isLoading}
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
          <Button
            onClick={handleSave}
            disabled={!hasChanges || saveMenuMutation.isLoading}
            className="bg-blue-600 hover:bg-blue-700"
          >
            <Save className="w-4 h-4 mr-2" />
            {saveMenuMutation.isLoading ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </div>

      {hasChanges && (
        <Alert className="bg-yellow-50 border-yellow-200">
          <AlertDescription className="text-yellow-800">
            ⚠️ You have unsaved changes
          </AlertDescription>
        </Alert>
      )}

      <Card className="bg-white shadow-md">
        <CardHeader>
          <CardTitle>Menu Items</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="menu-items">
              {(provided) => (
                <div
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                >
                  {menuItems.map((item, index) => (
                    <Draggable key={item.id} draggableId={item.id} index={index}>
                      {(provided, snapshot) => (
                        <div
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          className={`border-b last:border-b-0 ${
                            snapshot.isDragging ? 'bg-blue-50 shadow-lg' : 'bg-white'
                          }`}
                        >
                          {/* Parent Item */}
                          <div className="flex items-center gap-3 p-4 hover:bg-gray-50">
                            <div {...provided.dragHandleProps} className="cursor-move">
                              <GripVertical className="w-5 h-5 text-gray-400" />
                            </div>
                            
                            <div className="flex-1">
                              <div className="font-medium text-gray-900">
                                {item.hasSubmenu && '▸ '}
                                {item.title}
                              </div>
                              {item.hasSubmenu && (
                                <div className="text-xs text-gray-500 mt-0.5">
                                  {item.submenuItems?.length || 0} submenu items
                                </div>
                              )}
                            </div>

                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => toggleItem(item.id)}
                              className="text-gray-600 hover:text-gray-900"
                            >
                              {item.enabled ? (
                                <Eye className="w-4 h-4" />
                              ) : (
                                <EyeOff className="w-4 h-4 text-red-500" />
                              )}
                            </Button>
                          </div>

                          {/* Submenu Items - Indented Group */}
                          {item.hasSubmenu && item.submenuItems && (
                            <div className="bg-gray-50 border-t border-gray-200">
                              {item.submenuItems.map((subItem, subIndex) => (
                                <div
                                  key={subItem.id}
                                  className={`flex items-center gap-3 py-2.5 px-4 pl-16 hover:bg-gray-100 ${
                                    subIndex !== item.submenuItems.length - 1 ? 'border-b border-gray-200' : ''
                                  }`}
                                >
                                  <div className="w-1 h-1 rounded-full bg-gray-400" />
                                  
                                  <div className="flex-1 text-sm text-gray-700">
                                    {subItem.title}
                                  </div>

                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => toggleItem(item.id, subItem.id)}
                                    className="text-gray-500 hover:text-gray-900"
                                  >
                                    {subItem.enabled ? (
                                      <Eye className="w-4 h-4" />
                                    ) : (
                                      <EyeOff className="w-4 h-4 text-red-500" />
                                    )}
                                  </Button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </DragDropContext>
        </CardContent>
      </Card>

      <Alert className="bg-blue-50 border-blue-200">
        <AlertDescription className="text-blue-900 text-sm">
          <strong>💡 How it works:</strong>
          <ul className="mt-2 space-y-1 ml-4 list-disc">
            <li>Drag the <strong>≡</strong> handle to reorder menu items</li>
            <li>Items with <strong>▸</strong> are parent menus with submenu items</li>
            <li>When you move a parent, all its submenu items move together</li>
            <li>Click the <strong>👁</strong> icon to show/hide items</li>
          </ul>
        </AlertDescription>
      </Alert>
    </div>
  );
}
