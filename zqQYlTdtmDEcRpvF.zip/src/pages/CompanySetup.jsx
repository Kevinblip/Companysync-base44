
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Building2, Save, Upload, Loader2, Clock } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

const timezones = [
  "America/New_York", "America/Chicago", "America/Denver", "America/Los_Angeles", "America/Phoenix", "America/Anchorage", "Pacific/Honolulu"
];

export default function CompanySetup() {
  const [user, setUser] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [companyData, setCompanyData] = useState({
    company_name: "",
    company_tagline: "",
    logo_url: "",
    website: "",
    phone: "",
    email: "",
    address: "",
    city: "",
    state: "",
    zip: "",
    industry: "roofing",
    brand_primary_color: "#3b82f6",
    brand_secondary_color: "#8b5cf6",
    time_zone: "America/New_York",
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  useEffect(() => {
    if (myCompany) {
      setCompanyData({
        company_name: myCompany.company_name || "",
        company_tagline: myCompany.company_tagline || "",
        logo_url: myCompany.logo_url || "",
        website: myCompany.website || "",
        phone: myCompany.phone || "",
        email: myCompany.email || "",
        address: myCompany.address || "",
        city: myCompany.city || "",
        state: myCompany.state || "",
        zip: myCompany.zip || "",
        industry: myCompany.industry || "roofing",
        brand_primary_color: myCompany.brand_primary_color || "#3b82f6",
        brand_secondary_color: myCompany.brand_secondary_color || "#8b5cf6",
        time_zone: myCompany.settings?.time_zone || "America/New_York",
      });
    }
  }, [myCompany]);

  const saveCompanyMutation = useMutation({
    mutationFn: (data) => {
      // Extract time_zone and any other potential nested settings fields from the main data object
      const { time_zone, ...restOfCompanyData } = data;

      const settingsPayload = {
        ...(myCompany?.settings || {}), // Preserve existing settings
        time_zone: time_zone, // Update/set the time_zone
      };

      const finalPayload = {
        ...restOfCompanyData, // All top-level company fields
        settings: settingsPayload, // Nested settings object
      };

      if (myCompany) {
        return base44.entities.Company.update(myCompany.id, finalPayload);
      } else {
        return base44.entities.Company.create(finalPayload);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['companies'] });
      alert("Company profile saved successfully!");
    },
  });

  const handleLogoUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      setCompanyData({ ...companyData, logo_url: file_url });
    } catch (error) {
      alert("Failed to upload logo: " + error.message);
    }
    setUploading(false);
  };

  const handleSave = () => {
    if (!companyData.company_name || !companyData.email) {
      alert("Please fill in company name and email");
      return;
    }
    saveCompanyMutation.mutate(companyData);
  };

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
          <Building2 className="w-7 h-7 text-white" />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Company Setup</h1>
          <p className="text-gray-500 mt-1">Configure your company profile and branding</p>
        </div>
      </div>

      {!myCompany && (
        <Alert className="bg-blue-50 border-blue-200">
          <AlertDescription>
            <strong>Welcome!</strong> Let's set up your company profile. This information will be used throughout your CRM.
          </AlertDescription>
        </Alert>
      )}

      <Card className="bg-white shadow-md">
        <CardHeader className="border-b bg-gray-50">
          <CardTitle>Company Information</CardTitle>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2">
              <Label>Company Name *</Label>
              <Input
                value={companyData.company_name}
                onChange={(e) => setCompanyData({ ...companyData, company_name: e.target.value })}
                placeholder="ABC Roofing Company"
              />
            </div>

            <div className="md:col-span-2">
              <Label>Tagline</Label>
              <Input
                value={companyData.company_tagline}
                onChange={(e) => setCompanyData({ ...companyData, company_tagline: e.target.value })}
                placeholder="Quality Roofing Since 2010"
              />
            </div>

            <div className="md:col-span-2">
              <Label>Company Logo</Label>
              <div className="flex items-center gap-4">
                {companyData.logo_url && (
                  <img 
                    src={companyData.logo_url} 
                    alt="Company Logo" 
                    className="w-20 h-20 object-contain border rounded"
                  />
                )}
                <div className="flex-1">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                    id="logo-upload"
                    disabled={uploading}
                  />
                  <Button
                    variant="outline"
                    onClick={() => document.getElementById('logo-upload')?.click()}
                    disabled={uploading}
                  >
                    {uploading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Upload Logo
                      </>
                    )}
                  </Button>
                  <p className="text-xs text-gray-500 mt-1">PNG, JPG up to 5MB</p>
                </div>
              </div>
            </div>

            <div>
              <Label>Industry</Label>
              <Select value={companyData.industry} onValueChange={(v) => setCompanyData({ ...companyData, industry: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="roofing">Roofing</SelectItem>
                  <SelectItem value="construction">Construction</SelectItem>
                  <SelectItem value="hvac">HVAC</SelectItem>
                  <SelectItem value="plumbing">Plumbing</SelectItem>
                  <SelectItem value="electrical">Electrical</SelectItem>
                  <SelectItem value="general_contractor">General Contractor</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Time Zone</Label>
              <Select value={companyData.time_zone} onValueChange={(v) => setCompanyData({ ...companyData, time_zone: v })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {timezones.map(tz => (
                    <SelectItem key={tz} value={tz}>{tz.replace('America/', '').replace('_', ' ')}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Website</Label>
              <Input
                value={companyData.website}
                onChange={(e) => setCompanyData({ ...companyData, website: e.target.value })}
                placeholder="https://yourcompany.com"
              />
            </div>

            <div>
              <Label>Email *</Label>
              <Input
                type="email"
                value={companyData.email}
                onChange={(e) => setCompanyData({ ...companyData, email: e.target.value })}
                placeholder="info@yourcompany.com"
              />
            </div>

            <div>
              <Label>Phone</Label>
              <Input
                value={companyData.phone}
                onChange={(e) => setCompanyData({ ...companyData, phone: e.target.value })}
                placeholder="(555) 123-4567"
              />
            </div>

            <div className="md:col-span-2">
              <Label>Address</Label>
              <Input
                value={companyData.address}
                onChange={(e) => setCompanyData({ ...companyData, address: e.target.value })}
                placeholder="123 Main Street"
              />
            </div>

            <div>
              <Label>City</Label>
              <Input
                value={companyData.city}
                onChange={(e) => setCompanyData({ ...companyData, city: e.target.value })}
                placeholder="Dallas"
              />
            </div>

            <div>
              <Label>State</Label>
              <Input
                value={companyData.state}
                onChange={(e) => setCompanyData({ ...companyData, state: e.target.value })}
                placeholder="TX"
                maxLength={2}
              />
            </div>

            <div>
              <Label>ZIP Code</Label>
              <Input
                value={companyData.zip}
                onChange={(e) => setCompanyData({ ...companyData, zip: e.target.value })}
                placeholder="75201"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-white shadow-md">
        <CardHeader className="border-b bg-gray-50">
          <CardTitle>Brand Colors</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label>Primary Brand Color</Label>
              <div className="flex items-center gap-3">
                <Input
                  type="color"
                  value={companyData.brand_primary_color}
                  onChange={(e) => setCompanyData({ ...companyData, brand_primary_color: e.target.value })}
                  className="w-20 h-10"
                />
                <Input
                  value={companyData.brand_primary_color}
                  onChange={(e) => setCompanyData({ ...companyData, brand_primary_color: e.target.value })}
                  placeholder="#3b82f6"
                  className="flex-1"
                />
              </div>
            </div>

            <div>
              <Label>Secondary Brand Color</Label>
              <div className="flex items-center gap-3">
                <Input
                  type="color"
                  value={companyData.brand_secondary_color}
                  onChange={(e) => setCompanyData({ ...companyData, brand_secondary_color: e.target.value })}
                  className="w-20 h-10"
                />
                <Input
                  value={companyData.brand_secondary_color}
                  onChange={(e) => setCompanyData({ ...companyData, brand_secondary_color: e.target.value })}
                  placeholder="#8b5cf6"
                  className="flex-1"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          onClick={handleSave}
          className="bg-blue-600 hover:bg-blue-700"
          disabled={saveCompanyMutation.isLoading}
        >
          <Save className="w-4 h-4 mr-2" />
          {saveCompanyMutation.isLoading ? "Saving..." : myCompany ? "Update Company Profile" : "Create Company Profile"}
        </Button>
      </div>
    </div>
  );
}
