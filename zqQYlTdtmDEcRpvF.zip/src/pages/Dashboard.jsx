
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import {
  FileText,
  TrendingUp,
  Briefcase,
  CheckSquare,
  ChevronLeft,
  ChevronRight,
  DollarSign,
  AlertCircle,
  Settings,
  Trophy,
  GripVertical,
  Layers,
  Activity,
  CheckCircle2,
  Sparkles,
  ArrowRight
} from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, addMonths, subMonths } from "date-fns";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Checkbox } from "@/components/ui/checkbox";
import LeadLeaderboard from "../components/leads/LeadLeaderboard";

function MetricCard({ title, value, subtitle, icon: Icon, trend, color, onClick }) {
  const colorClasses = {
    orange: { border: "border-orange-400", text: "text-orange-600" },
    green: { border: "border-green-400", text: "text-green-600" },
    blue: { border: "border-blue-400", text: "text-blue-600" },
    purple: { border: "border-purple-400", text: "text-purple-600" },
    gray: { border: "border-gray-400", text: "text-gray-500" },
  };
  const selectedColor = colorClasses[color] || colorClasses.gray;

  return (
    <Card
      className={`bg-white hover:shadow-md transition-shadow duration-300 cursor-pointer border-l-4 ${selectedColor.border}`}
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
            <p className="text-sm font-medium text-gray-500">{title}</p>
            {Icon && <Icon className={`w-5 h-5 ${selectedColor.text}`} />}
        </div>
        <p className="text-3xl font-bold text-gray-900 mt-2">{value}</p>
        <p className="text-xs text-gray-500 mt-1">{subtitle}</p>
      </CardContent>
    </Card>
  );
}

const DEFAULT_LAYOUT = {
  topRow: [],
  financeRow: [
    { id: 'financeOverview', title: 'Finance Overview' }
  ],
  calendarRow: [],
  mainLeft: [
    { id: 'paymentRecords', title: 'Payment Records' }
  ],
  mainRight: [
    { id: 'commissions', title: 'Commissions' },
    { id: 'leaderboard', title: 'Leaderboard' },
    { id: 'contractsExpiring', title: 'Contracts Expiring Soon' }
  ],
  bottomRow: [
    { id: 'myTasks', title: 'My Tasks' }
  ]
};

const ALL_AVAILABLE_WIDGETS = [
  { id: 'financeOverview', title: 'Finance Overview' },
  { id: 'calendar', title: 'Calendar' },
  { id: 'paymentRecords', title: 'Payment Records' },
  { id: 'commissions', title: 'Commissions' },
  { id: 'contractsExpiring', title: 'Contracts Expiring Soon' },
  { id: 'myTasks', title: 'My Tasks' },
  { id: 'leaderboard', title: 'Leaderboard' },
  { id: 'leadLeaderboard', title: 'Hot Leads' },
  { id: 'projectsChart', title: 'Projects Chart' },
  { id: 'latestActivity', title: 'Latest Project Activity' }
];

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [setupBannerDismissed, setSetupBannerDismissed] = useState(() => {
    return localStorage.getItem('setupBannerDismissed') === 'true';
  });
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [showWidgetPanel, setShowWidgetPanel] = useState(false);
  const [layout, setLayout] = useState(() => {
    const saved = localStorage.getItem('dashboardLayout');
    if (saved) {
      try {
        const parsedLayout = JSON.parse(saved);
        const validatedLayout = {
          topRow: parsedLayout.topRow || [],
          financeRow: parsedLayout.financeRow || [],
          calendarRow: parsedLayout.calendarRow || [],
          mainLeft: parsedLayout.mainLeft || [],
          mainRight: parsedLayout.mainRight || [],
          bottomRow: parsedLayout.bottomRow || [],
        };
        if (!Object.values(validatedLayout).flat().some(w => w.id === 'financeOverview')) {
          validatedLayout.financeRow.unshift({ id: 'financeOverview', title: 'Finance Overview' });
        }
        return validatedLayout;
      } catch (e) {
        console.error('Error parsing saved layout from localStorage:', e);
        return DEFAULT_LAYOUT;
      }
    }
    return DEFAULT_LAYOUT;
  });

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [], isFetched: isCompaniesFetched } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  useEffect(() => {
    if (user && isCompaniesFetched) {
      if (!myCompany) {
        navigate(createPageUrl('SetupWizard'));
      } else if (!myCompany.setup_completed) {
        // Only navigate if the setup is not completed and the banner hasn't been dismissed
        // The banner is meant to give an option to dismiss, so we don't force navigation if dismissed.
        // The check for setup_completed is handled by showSetupPrompt for banner display.
      }
    }
  }, [user, myCompany, isCompaniesFetched, navigate]);

  const showSetupPrompt = myCompany && !myCompany.setup_completed && !setupBannerDismissed;

  const dismissSetupBanner = () => {
    localStorage.setItem('setupBannerDismissed', 'true');
    setSetupBannerDismissed(true);
  };

  useEffect(() => {
    localStorage.setItem('dashboardLayout', JSON.stringify(layout));
  }, [layout]);

  const { data: invoices = [] } = useQuery({
    queryKey: ['invoices'],
    queryFn: () => base44.entities.Invoice.list("-created_date", 500),
    initialData: [],
  });

  const { data: estimates = [] } = useQuery({
    queryKey: ['estimates'],
    queryFn: () => base44.entities.Estimate.list("-created_date"),
    initialData: [],
  });

  const { data: proposals = [] } = useQuery({
    queryKey: ['proposals'],
    queryFn: () => base44.entities.Proposal.list("-created_date", 500),
    initialData: [],
  });

  const { data: projects = [] } = useQuery({
    queryKey: ['projects'],
    queryFn: () => base44.entities.Project.list("-created_date", 500),
    initialData: [],
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads'],
    queryFn: () => base44.entities.Lead.list("-created_date", 500),
    initialData: [],
  });

  const { data: tasks = [] } = useQuery({
    queryKey: ['tasks'],
    queryFn: () => base44.entities.Task.list("-created_date", 100),
    initialData: [],
  });

  const { data: calendarEvents = [] } = useQuery({
    queryKey: ['calendar-events'],
    queryFn: () => base44.entities.CalendarEvent.list("-start_time", 500),
    initialData: [],
  });

  const { data: payments = [] } = useQuery({
    queryKey: ['payments'],
    queryFn: () => base44.entities.Payment.list("-payment_date", 100),
    initialData: [],
  });

  const { data: contracts = [] } = useQuery({
    queryKey: ['contracts'],
    queryFn: () => base44.entities.Contract.list("-created_date", 100),
    initialData: [],
  });

  const { data: leadScores = [] } = useQuery({
    queryKey: ['lead-scores'],
    queryFn: () => base44.entities.LeadScore.list("-total_score", 50),
    initialData: [],
  });

  const isWidgetEnabled = (widgetId) => {
    if (widgetId === 'quickStats') return false;
    return Object.values(layout).some(zone =>
      Array.isArray(zone) && zone.some(w => w.id === widgetId)
    );
  };

  const toggleWidget = (widgetId) => {
    if (widgetId === 'quickStats') return;
    const widget = ALL_AVAILABLE_WIDGETS.find(w => w.id === widgetId);
    if (!widget) return;

    if (isWidgetEnabled(widgetId)) {
      const newLayout = { ...layout };
      Object.keys(newLayout).forEach(zoneKey => {
        if (Array.isArray(newLayout[zoneKey])) {
          newLayout[zoneKey] = newLayout[zoneKey].filter(w => w.id !== widgetId);
        }
      });
      setLayout(newLayout);
    } else {
      setLayout(prev => ({
        ...prev,
        bottomRow: [...(prev.bottomRow || []), widget]
      }));
    }
  };

  const resetDashboard = () => {
    setLayout(DEFAULT_LAYOUT);
    localStorage.setItem('dashboardLayout', JSON.stringify(DEFAULT_LAYOUT));
    setShowWidgetPanel(false);
  };

  const handleDragEnd = (result) => {
    const { source, destination } = result;
    if (!destination) return;
    if (source.droppableId === destination.droppableId && source.index === destination.index) return;

    const sourceZone = source.droppableId;
    const destZone = destination.droppableId;
    const newLayout = { ...layout };

    if (!newLayout[sourceZone]) newLayout[sourceZone] = [];
    if (!newLayout[destZone]) newLayout[destZone] = [];

    const sourceItems = Array.from(newLayout[sourceZone]);
    const [movedItem] = sourceItems.splice(source.index, 1);

    if (sourceZone === destZone) {
      sourceItems.splice(destination.index, 0, movedItem);
      newLayout[sourceZone] = sourceItems;
    } else {
      const destItems = Array.from(newLayout[destZone]);
      destItems.splice(destination.index, 0, movedItem);
      newLayout[sourceZone] = sourceItems;
      newLayout[destZone] = destItems;
    }

    setLayout(newLayout);
  };

  const invoicesAwaitingPayment = invoices.filter(i => i.status !== 'paid' && i.status !== 'cancelled').length;
  const convertedLeads = leads.filter(l => l.status === 'won').length;
  const projectsInProgress = projects.filter(p => p.status === 'in_progress').length;
  const tasksNotFinished = tasks.filter(t => t.status !== 'job_completed').length;

  const draftEstimates = estimates.filter(e => !e.status || e.status === 'draft').length;
  const sentEstimates = estimates.filter(e => e.status === 'sent').length;
  const viewedEstimates = estimates.filter(e => e.status === 'viewed').length;
  const acceptedEstimates = estimates.filter(e => e.status === 'accepted').length;
  const declinedEstimates = estimates.filter(e => e.status === 'declined').length;
  const expiredEstimates = estimates.filter(e => e.status === 'expired').length;

  const totalEstimateValue = estimates.reduce((sum, est) => sum + (est.amount || 0), 0);
  const acceptedValue = estimates.filter(e => e.status === 'accepted').reduce((sum, est) => sum + (est.amount || 0), 0);

  const totalCommission = invoices.filter(i => i.status === 'paid').reduce((sum, inv) => sum + (inv.amount || 0), 0) * 0.05;
  const pendingCommission = invoices.filter(i => i.status !== 'paid' && i.status !== 'cancelled').reduce((sum, inv) => sum + (inv.amount || 0), 0) * 0.05;
  const paidCommission = totalCommission * 0.7;
  const commissionRate = 5;

  const leaderboardData = [
    { name: "John Smith", deals: 45, revenue: 125000, avatar: "JS" },
    { name: "Sarah Johnson", deals: 38, revenue: 98000, avatar: "SJ" },
    { name: "Mike Wilson", deals: 32, revenue: 87000, avatar: "MW" },
    { name: "Emily Davis", deals: 28, revenue: 72000, avatar: "ED" },
    { name: "David Brown", deals: 25, revenue: 65000, avatar: "DB" }
  ];

  const invoicesTotal = invoices.length;
  const invoiceBreakdown = {
    draft: invoices.filter(i => i.status === 'draft').length,
    not_sent: invoices.filter(i => i.status !== 'sent' && i.status !== 'viewed' && i.status !== 'draft' && i.status !== 'paid' && i.status !== 'partially_paid' && i.status !== 'overdue').length,
    unpaid: invoices.filter(i => i.status === 'sent' || i.status === 'viewed').length,
    partially_paid: invoices.filter(i => i.status === 'partially_paid').length,
    overdue: invoices.filter(i => i.status === 'overdue').length,
    paid: invoices.filter(i => i.status === 'paid').length
  };

  const estimatesTotal = estimates.length;
  const estimateBreakdown = {
    draft: draftEstimates,
    sent: sentEstimates,
    viewed: viewedEstimates,
    expired: expiredEstimates,
    declined: declinedEstimates,
    accepted: acceptedEstimates,
  };

  const proposalsTotal = proposals.length;
  const proposalBreakdown = {
    draft: proposals.filter(p => p.status === 'draft').length,
    sent: proposals.filter(p => p.status === 'sent').length,
    open: proposals.filter(p => p.status === 'viewed').length,
    revised: 0,
    declined: proposals.filter(p => p.status === 'declined').length,
    accepted: proposals.filter(p => p.status === 'accepted').length
  };

  const outstandingInvoices = invoices.filter(i => i.status !== 'paid' && i.status !== 'cancelled').reduce((sum, inv) => sum + (inv.amount || 0), 0);
  const pastDueInvoices = invoices.filter(i => i.status === 'overdue').reduce((sum, inv) => sum + (inv.amount || 0), 0);
  const paidInvoices = invoices.filter(i => i.status === 'paid').reduce((sum, inv) => sum + (inv.amount || 0), 0);

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const startDay = monthStart.getDay();

  const getEventsForDay = (date) => {
    return calendarEvents.filter(event => {
      const eventDate = new Date(event.start_time);
      return isSameDay(eventDate, date);
    });
  };

  const paymentsByDay = {
    Monday: 0,
    Tuesday: 0,
    Wednesday: 0,
    Thursday: 0,
    Friday: 0,
    Saturday: 0,
    Sunday: 0
  };

  payments.forEach(payment => {
    if (payment.payment_date) {
      const day = format(new Date(payment.payment_date), 'EEEE');
      paymentsByDay[day] += payment.amount || 0;
    }
  });

  const maxPayment = Math.max(...Object.values(paymentsByDay));

  const expiringContracts = contracts.filter(contract => {
    if (!contract.end_date) return false;
    const endDate = new Date(contract.end_date);
    const now = new Date();
    const daysUntilExpiry = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));
    return daysUntilExpiry > 0 && daysUntilExpiry <= 30;
  });

  const renderWidget = (widgetId) => {
    switch (widgetId) {
      case 'commissions':
        return (
          <Card className="bg-white">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-green-600" />
                <CardTitle className="text-lg">Commissions</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Total Commission</p>
                  <p className="text-2xl font-bold text-green-600">${totalCommission.toFixed(2)}</p>
                  <p className="text-xs text-gray-500 mt-1">0% from last month</p>
                </div>
                <div className="bg-orange-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Pending Commission</p>
                  <p className="text-2xl font-bold text-orange-600">${pendingCommission.toFixed(2)}</p>
                  <p className="text-xs text-gray-500 mt-1">0% from last month</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Paid Commission</p>
                  <p className="text-2xl font-bold text-blue-600">${paidCommission.toFixed(2)}</p>
                  <p className="text-xs text-gray-500 mt-1">57.04% from last quarter</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">Commission Rate</p>
                  <p className="text-2xl font-bold text-purple-600">{commissionRate}%</p>
                  <p className="text-xs text-gray-500 mt-1">0% from last quarter</p>
                </div>
              </div>
            </CardContent>
          </Card>
        );

      case 'leaderboard':
        return (
          <Card className="bg-white">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-yellow-500" />
                  <CardTitle className="text-lg">Top Performers</CardTitle>
                </div>
                <Button variant="ghost" size="sm" className="text-blue-600">
                  View All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboardData.map((person, index) => (
                  <div key={person.name} className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 text-white font-semibold text-sm flex-shrink-0">
                      {index + 1}
                    </div>
                    <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center text-sm font-semibold text-gray-700 flex-shrink-0">
                      {person.avatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{person.name}</p>
                      <p className="text-xs text-gray-500">{person.deals} deals closed</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="font-semibold text-sm text-green-600">${(person.revenue / 1000).toFixed(0)}K</p>
                      {index < 3 && (
                        <Trophy className={`w-4 h-4 ml-auto ${index === 0 ? 'text-yellow-500' : index === 1 ? 'text-gray-400' : 'text-orange-600'}`} />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );

      case 'financeOverview':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <Card className="bg-white">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-gray-600" />
                  <CardTitle className="text-base">Invoice overview</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(invoiceBreakdown).map(([key, count]) => (
                  <div key={key}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-600 capitalize">{count} {key.replace(/_/g, ' ')}</span>
                      <span className="text-gray-500">{invoicesTotal > 0 ? ((count / invoicesTotal) * 100).toFixed(1) : 0}%</span>
                    </div>
                    <Progress
                      value={invoicesTotal > 0 ? (count / invoicesTotal) * 100 : 0}
                      className={`h-2 ${key === 'paid' ? 'bg-green-500' : 'bg-gray-200'}`}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-white">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-gray-600" />
                  <CardTitle className="text-base">Estimate overview</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(estimateBreakdown).map(([key, count]) => (
                  <div key={key}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-600 capitalize">{count} {key.replace(/_/g, ' ')}</span>
                      <span className="text-gray-500">{estimatesTotal > 0 ? ((count / estimatesTotal) * 100).toFixed(1) : 0}%</span>
                    </div>
                    <Progress
                      value={estimatesTotal > 0 ? (count / estimatesTotal) * 100 : 0}
                      className={`h-2 ${key === 'accepted' ? 'bg-green-500' : key === 'sent' ? 'bg-blue-500' : key === 'viewed' ? 'bg-purple-500' : key === 'expired' ? 'bg-orange-500' : key === 'declined' ? 'bg-red-500' : 'bg-gray-200'}`}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-white">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-gray-600" />
                  <CardTitle className="text-base">Proposal overview</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(proposalBreakdown).map(([key, count]) => (
                  <div key={key}>
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-600 capitalize">{count} {key.replace(/_/g, ' ')}</span>
                      <span className="text-gray-500">{proposalsTotal > 0 ? ((count / proposalsTotal) * 100).toFixed(1) : 0}%</span>
                    </div>
                    <Progress
                      value={proposalsTotal > 0 ? (count / proposalsTotal) * 100 : 0}
                      className={`h-2 ${key === 'accepted' ? 'bg-green-500' : key === 'sent' ? 'bg-blue-500' : key === 'declined' ? 'bg-red-500' : 'bg-gray-200'}`}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="bg-white">
              <CardContent className="p-6 space-y-4">
                <div>
                  <h3 className="text-sm text-gray-600 mb-1">Outstanding Invoices</h3>
                  <p className="text-2xl font-bold text-orange-600">${outstandingInvoices.toFixed(2)}</p>
                </div>
                <div>
                  <h3 className="text-sm text-gray-600 mb-1">Past Due Invoices</h3>
                  <p className="text-2xl font-bold text-gray-900">${pastDueInvoices.toFixed(2)}</p>
                </div>
                <div>
                  <h3 className="text-sm text-gray-600 mb-1">Paid Invoices</h3>
                  <p className="text-2xl font-bold text-green-600">${paidInvoices.toFixed(2)}</p>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 'contractsExpiring':
        return (
          <Card className="bg-white">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Contracts Expiring Soon</CardTitle>
                <Button variant="link" size="sm" className="text-blue-600" onClick={() => navigate(createPageUrl('Contracts'))}>
                  View All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {expiringContracts.length === 0 ? (
                <div className="text-center py-8">
                  <AlertCircle className="w-12 h-12 mx-auto mb-3 text-yellow-500" />
                  <p className="text-gray-500">No contracts expiring in the next 30 days</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {expiringContracts.slice(0, 5).map((contract) => {
                    const endDate = new Date(contract.end_date);
                    const now = new Date();
                    const daysUntilExpiry = Math.ceil((endDate - now) / (1000 * 60 * 60 * 24));
                    return (
                      <div key={contract.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-gray-50">
                        <div>
                          <p className="font-medium text-sm">{contract.contract_name || 'Unnamed Contract'}</p>
                          <p className="text-xs text-gray-500">Expires: {format(endDate, 'MMM d, yyyy')}</p>
                        </div>
                        <Badge variant="outline" className="bg-orange-50 text-orange-600 border-orange-200">
                          {daysUntilExpiry} days left
                        </Badge>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        );

      case 'calendar':
        return (
          <Card className="bg-white">
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
                    <ChevronLeft className="w-5 h-5" />
                  </Button>
                  <CardTitle>{format(currentMonth, 'MMMM yyyy')}</CardTitle>
                  <Button variant="ghost" size="icon" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
                    <ChevronRight className="w-5 h-5" />
                  </Button>
                </div>
                <Button variant="outline" size="sm" onClick={() => navigate(createPageUrl('Calendar'))}>
                  View Full Calendar
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="grid grid-cols-7 border-b">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
                  <div key={day} className="p-2 text-center text-sm font-medium text-gray-600 border-r last:border-r-0">
                    {day}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7">
                {Array.from({ length: startDay === 0 ? 6 : startDay - 1 }).map((_, i) => (
                  <div key={`empty-${i}`} className="min-h-[100px] p-2 border-r border-b bg-gray-50" />
                ))}

                {daysInMonth.map((day, i) => {
                  const dayEvents = getEventsForDay(day);
                  const isToday = isSameDay(day, new Date());

                  return (
                    <div
                      key={i}
                      className={`min-h-[100px] p-2 border-r border-b ${isToday ? 'bg-blue-50' : 'bg-white'} hover:bg-gray-50`}
                    >
                      <div className={`text-sm font-medium mb-1 ${isToday ? 'text-blue-600 font-bold' : 'text-gray-700'}`}>
                        {format(day, 'd')}
                      </div>
                      <div className="space-y-1">
                        {dayEvents.slice(0, 3).map((event) => (
                          <div
                            key={event.id}
                            className="text-[10px] px-1.5 py-0.5 rounded truncate cursor-pointer"
                            style={{
                              backgroundColor: event.color || '#3b82f6',
                              color: 'white'
                            }}
                            title={event.title}
                          >
                            {event.title}
                          </div>
                        ))}
                        {dayEvents.length > 3 && (
                          <div className="text-[10px] text-gray-500 px-1">
                            +{dayEvents.length - 3} more
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        );

      case 'paymentRecords':
        return (
          <Card className="bg-white">
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <CardTitle>Payment Records</CardTitle>
                <div className="flex gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-pink-400" />
                    <span>This Week Payments</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-200" />
                    <span>Last Week Payments</span>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="flex items-end justify-between h-64 gap-4">
                {Object.entries(paymentsByDay).map(([day, amount]) => (
                  <div key={day} className="flex-1 flex flex-col items-center gap-2">
                    <div className="w-full flex flex-col justify-end h-full">
                      <div
                        className="w-full bg-pink-400 rounded-t"
                        style={{
                          height: maxPayment > 0 ? `${(amount / maxPayment) * 100}%` : '0%',
                          minHeight: amount > 0 ? '8px' : '0px'
                        }}
                      />
                    </div>
                    <span className="text-xs text-gray-600">{day.substring(0, 3)}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        );

      case 'myTasks':
        return (
          <Card className="bg-white">
            <CardHeader className="border-b">
              <div className="flex items-center justify-between">
                <CardTitle>My Tasks</CardTitle>
                <Button variant="link" size="sm" className="text-blue-600" onClick={() => navigate(createPageUrl('Tasks'))}>
                  View All
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b bg-gray-50">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-600">#</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-600">Name</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-600">Status</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-600">Priority</th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-600">Due Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tasks.slice(0, 10).map((task, idx) => (
                      <tr key={task.id} className="border-b hover:bg-gray-50">
                        <td className="px-4 py-3 text-sm">{idx + 1}</td>
                        <td className="px-4 py-3 text-sm font-medium">{task.name}</td>
                        <td className="px-4 py-3">
                          <Badge variant="outline" className="bg-blue-100 text-blue-700 border-blue-200">
                            {task.status?.replace(/_/g, ' ')}
                          </Badge>
                        </td>
                        <td className="px-4 py-3">
                          <Badge
                            variant="outline"
                            className={
                              task.priority === 'high' ? 'bg-red-100 text-red-700' :
                              task.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                              'bg-blue-100 text-blue-700'
                            }
                          >
                            {task.priority || 'medium'}
                          </Badge>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {task.due_date ? format(new Date(task.due_date), 'MMM d, yyyy') : '-'}
                        </td>
                      </tr>
                    ))}
                    {tasks.length === 0 && (
                      <tr>
                        <td colSpan={5} className="px-4 py-12 text-center text-gray-500">
                          No tasks yet
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        );

      case 'projectsChart':
        return (
          <Card className="bg-white">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-purple-600" />
                <CardTitle className="text-lg">Projects Overview Chart</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-gray-500 text-center py-12">
                Chart content for projects will go here.
              </div>
            </CardContent>
          </Card>
        );

      case 'latestActivity':
        return (
          <Card className="bg-white">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-cyan-600" />
                <CardTitle className="text-lg">Latest Project Activity</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-gray-500 text-center py-12">
                Recent activities related to projects will be listed here.
              </div>
            </CardContent>
          </Card>
        );

      case 'leadLeaderboard':
        return (
          <LeadLeaderboard
            leadScores={leadScores}
            leads={leads}
            onLeadClick={(lead) => navigate(createPageUrl('Leads'))}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="p-6 space-y-6 bg-gray-50 min-h-screen">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <Sheet open={showWidgetPanel} onOpenChange={setShowWidgetPanel}>
          <SheetTrigger asChild>
            <Button variant="outline">
              <Settings className="w-4 h-4 mr-2" />
              Dashboard Options
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto">
            <SheetHeader>
              <SheetTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Dashboard Widgets & Layout
              </SheetTitle>
            </SheetHeader>

            <div className="mt-6 space-y-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold text-lg">Available Widgets</h3>
                  <div className="flex gap-2">
                    <Button variant="link" size="sm" onClick={resetDashboard}>
                      Reset Layout
                    </Button>
                    <Button variant="link" size="sm" onClick={() => setShowWidgetPanel(false)}>
                      View Dashboard
                    </Button>
                  </div>
                </div>

                {ALL_AVAILABLE_WIDGETS.map(widget => (
                  <div key={widget.id} className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded">
                    <Checkbox
                      checked={isWidgetEnabled(widget.id)}
                      onCheckedChange={() => toggleWidget(widget.id)}
                      id={widget.id}
                    />
                    <label htmlFor={widget.id} className="flex-1 cursor-pointer font-medium">
                      {widget.title}
                    </label>
                  </div>
                ))}
              </div>

              <div className="border-t pt-6">
                <h3 className="font-semibold text-lg mb-4">Widget Zones Visualization</h3>
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 min-h-[80px] bg-gray-50">
                    <p className="text-xs text-gray-500 mb-2">Top Row (Full Width)</p>
                    <div className="flex flex-wrap gap-2">
                      {layout.topRow?.length > 0 ? (
                        layout.topRow.map(w => (
                          <Badge key={w.id} variant="secondary" className="bg-gray-200 text-gray-700">{w.title}</Badge>
                        ))
                      ) : (
                        <span className="text-sm text-gray-400">Empty</span>
                      )}
                    </div>
                  </div>

                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 min-h-[80px] bg-gray-50">
                    <p className="text-xs text-gray-500 mb-2">Finance Overview (Full Width)</p>
                    <div className="flex flex-wrap gap-2">
                      {layout.financeRow?.length > 0 ? (
                        layout.financeRow.map(w => (
                          <Badge key={w.id} variant="secondary" className="bg-gray-200 text-gray-700">{w.title}</Badge>
                        ))
                      ) : (
                        <span className="text-sm text-gray-400">Empty</span>
                      )}
                    </div>
                  </div>

                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 min-h-[80px] bg-gray-50">
                    <p className="text-xs text-gray-500 mb-2">Calendar (Full Width)</p>
                    <div className="flex flex-wrap gap-2">
                      {layout.calendarRow?.length > 0 ? (
                        layout.calendarRow.map(w => (
                          <Badge key={w.id} variant="secondary" className="bg-gray-200 text-gray-700">{w.title}</Badge>
                        ))
                      ) : (
                        <span className="text-sm text-gray-400">Empty</span>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 min-h-[120px] bg-gray-50">
                      <p className="text-xs text-gray-500 mb-2">Left Column</p>
                      <div className="flex flex-wrap gap-2">
                        {layout.mainLeft?.length > 0 ? (
                          layout.mainLeft.map(w => (
                            <Badge key={w.id} variant="secondary" className="bg-gray-200 text-gray-700 text-xs">{w.title}</Badge>
                          ))
                        ) : (
                          <span className="text-sm text-gray-400">Empty</span>
                        )}
                      </div>
                    </div>
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 min-h-[120px] bg-gray-50">
                      <p className="text-xs text-gray-500 mb-2">Right Column</p>
                      <div className="flex flex-wrap gap-2">
                        {layout.mainRight?.length > 0 ? (
                          layout.mainRight.map(w => (
                            <Badge key={w.id} variant="secondary" className="bg-gray-200 text-gray-700 text-xs">{w.title}</Badge>
                          ))
                        ) : (
                          <span className="text-sm text-gray-400">Empty</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 min-h-[80px] bg-gray-50">
                    <p className="text-xs text-gray-500 mb-2">Bottom Row (Full Width)</p>
                    <div className="flex flex-wrap gap-2">
                      {layout.bottomRow?.length > 0 ? (
                        layout.bottomRow.map(w => (
                          <Badge key={w.id} variant="secondary" className="bg-gray-200 text-gray-700">{w.title}</Badge>
                        ))
                      ) : (
                        <span className="text-sm text-gray-400">Empty</span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-800 mt-4">
                  <p className="font-semibold mb-2">💡 How to customize:</p>
                  <ul className="list-disc list-inside space-y-1 text-xs">
                    <li>Check/uncheck widgets to show/hide them instantly.</li>
                    <li>Drag widgets using the <strong>≡</strong> handle on the dashboard to reorder them within zones or move between areas.</li>
                    <li>Click "Reset Layout" to restore the dashboard to its default configuration.</li>
                  </ul>
                </div>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Setup Wizard Prompt - Now Dismissible */}
      {showSetupPrompt && (
        <div className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl p-6 text-white shadow-xl mb-6 relative">
          <button
            onClick={dismissSetupBanner}
            className="absolute top-4 right-4 text-white/80 hover:text-white"
            title="Dismiss (you can access setup wizard from Settings)"
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          <div className="flex items-center justify-between pr-12">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                <Sparkles className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-2xl font-bold">Welcome to AI CRM Pro! 🎉</h3>
                <p className="text-blue-100 mt-1">
                  Complete the quick setup wizard to get the most out of your CRM
                </p>
              </div>
            </div>
            <Button
              onClick={() => navigate(createPageUrl('SetupWizard'))}
              size="lg"
              className="bg-white text-blue-600 hover:bg-blue-50"
            >
              Start Setup <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <MetricCard
          title="Awaiting Payment"
          value={invoicesAwaitingPayment}
          subtitle={`${invoices.length} total invoices`}
          icon={FileText}
          color="orange"
          onClick={() => navigate(createPageUrl('Invoices'))}
        />
        <MetricCard
          title="Converted Leads"
          value={convertedLeads}
          subtitle={`${leads.length} total leads`}
          icon={TrendingUp}
          color="green"
          onClick={() => navigate(createPageUrl('Leads'))}
        />
        <MetricCard
          title="Projects In Progress"
          value={projectsInProgress}
          subtitle={`${projects.length} total projects`}
          icon={Briefcase}
          color="gray"
          onClick={() => navigate(createPageUrl('Projects'))}
        />
        <MetricCard
          title="Open Tasks"
          value={tasksNotFinished}
          subtitle={`${tasks.length} total tasks`}
          icon={CheckSquare}
          color="blue"
          onClick={() => navigate(createPageUrl('Tasks'))}
        />
        <MetricCard
          title="Active Estimates"
          value={estimates.length}
          subtitle={`$${totalEstimateValue.toFixed(2)} total value`}
          icon={FileText}
          trend={sentEstimates > 0 ? `${sentEstimates} sent` : undefined}
          color="purple"
          onClick={() => navigate(createPageUrl('Estimates'))}
        />
        <MetricCard
          title="Accepted Estimates"
          value={acceptedEstimates}
          subtitle={`$${acceptedValue.toFixed(2)} value`}
          icon={CheckCircle2}
          color="green"
          onClick={() => navigate(createPageUrl('Estimates'))}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Estimates Overview</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate(createPageUrl('Estimates'))}
            >
              View All
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-700">{draftEstimates}</div>
              <div className="text-sm text-gray-500">Draft</div>
            </div>
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-700">{sentEstimates}</div>
              <div className="text-sm text-gray-500">Sent</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-700">{viewedEstimates}</div>
              <div className="text-sm text-gray-500">Viewed</div>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-700">{expiredEstimates}</div>
              <div className="text-sm text-gray-500">Expired</div>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-700">{declinedEstimates}</div>
              <div className="text-sm text-gray-500">Declined</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-700">{acceptedEstimates}</div>
              <div className="text-sm text-gray-500">Accepted</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="text-sm text-gray-600 bg-blue-50 border border-blue-200 rounded-lg p-3 flex items-center gap-2">
        <GripVertical className="w-4 h-4 text-blue-600" />
        <span>Drag widgets using the <strong>≡</strong> handle to reorder them within zones or move between areas</span>
      </div>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="topRow" direction="horizontal">
          {(provided, snapshot) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className={`min-h-[100px] ${snapshot.isDraggingOver ? 'bg-blue-50 border-2 border-blue-300 border-dashed rounded-lg' : ''}`}
            >
              <div className="space-y-4">
                {(layout.topRow || []).map((widget, index) => (
                  <Draggable key={widget.id} draggableId={widget.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`relative ${snapshot.isDragging ? 'opacity-50' : ''}`}
                      >
                        <div
                          {...provided.dragHandleProps}
                          className="absolute -left-3 top-4 z-10 cursor-move hover:bg-gray-200 rounded p-1 bg-white shadow-md"
                          title="Drag to move"
                        >
                          <GripVertical className="w-5 h-5 text-gray-600" />
                        </div>
                        <div className="pl-4">
                          {renderWidget(widget.id)}
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
              </div>
              {provided.placeholder}
            </div>
          )}
        </Droppable>

        <Droppable droppableId="financeRow">
          {(provided, snapshot) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className={`min-h-[100px] ${snapshot.isDraggingOver ? 'bg-blue-50 border-2 border-blue-300 border-dashed rounded-lg p-4' : ''}`}
            >
              <div className="space-y-4">
                {(layout.financeRow || []).map((widget, index) => (
                  <Draggable key={widget.id} draggableId={widget.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`relative ${snapshot.isDragging ? 'opacity-50' : ''}`}
                      >
                        <div
                          {...provided.dragHandleProps}
                          className="absolute -left-3 top-4 z-10 cursor-move hover:bg-gray-200 rounded p-1 bg-white shadow-md"
                          title="Drag to move"
                        >
                          <GripVertical className="w-5 h-5 text-gray-600" />
                        </div>
                        <div className="pl-4">
                          {renderWidget(widget.id)}
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
              </div>
              {provided.placeholder}
            </div>
          )}
        </Droppable>

        <Droppable droppableId="calendarRow">
          {(provided, snapshot) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className={`min-h-[100px] ${snapshot.isDraggingOver ? 'bg-blue-50 border-2 border-blue-300 border-dashed rounded-lg p-4' : ''}`}
            >
              <div className="space-y-4">
                {(layout.calendarRow || []).map((widget, index) => (
                  <Draggable key={widget.id} draggableId={widget.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`relative ${snapshot.isDragging ? 'opacity-50' : ''}`}
                      >
                        <div
                          {...provided.dragHandleProps}
                          className="absolute -left-3 top-4 z-10 cursor-move hover:bg-gray-200 rounded p-1 bg-white shadow-md"
                          title="Drag to move"
                        >
                          <GripVertical className="w-5 h-5 text-gray-600" />
                        </div>
                        <div className="pl-4">
                          {renderWidget(widget.id)}
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
              </div>
              {provided.placeholder}
            </div>
          )}
        </Droppable>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Droppable droppableId="mainLeft">
            {(provided, snapshot) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className={`space-y-6 min-h-[200px] ${snapshot.isDraggingOver ? 'bg-blue-50 border-2 border-blue-300 border-dashed rounded-lg p-4' : ''}`}
              >
                {(layout.mainLeft || []).map((widget, index) => (
                  <Draggable key={widget.id} draggableId={widget.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`relative ${snapshot.isDragging ? 'opacity-50' : ''}`}
                      >
                        <div
                          {...provided.dragHandleProps}
                          className="absolute -left-3 top-4 z-10 cursor-move hover:bg-gray-200 rounded p-1 bg-white shadow-md"
                          title="Drag to move"
                        >
                          <GripVertical className="w-5 h-5 text-gray-600" />
                        </div>
                        <div className="pl-4">
                          {renderWidget(widget.id)}
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>

          <Droppable droppableId="mainRight">
            {(provided, snapshot) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
                className={`space-y-6 min-h-[200px] ${snapshot.isDraggingOver ? 'bg-blue-50 border-2 border-blue-300 border-dashed rounded-lg p-4' : ''}`}
              >
                {(layout.mainRight || []).map((widget, index) => (
                  <Draggable key={widget.id} draggableId={widget.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`relative ${snapshot.isDragging ? 'opacity-50' : ''}`}
                      >
                        <div
                          {...provided.dragHandleProps}
                          className="absolute -left-3 top-4 z-10 cursor-move hover:bg-gray-200 rounded p-1 bg-white shadow-md"
                          title="Drag to move"
                        >
                          <GripVertical className="w-5 h-5 text-gray-600" />
                        </div>
                        <div className="pl-4">
                          {renderWidget(widget.id)}
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </div>

        <Droppable droppableId="bottomRow">
          {(provided, snapshot) => (
            <div
              ref={provided.innerRef}
              {...provided.droppableProps}
              className={`space-y-6 min-h-[100px] ${snapshot.isDraggingOver ? 'bg-blue-50 border-2 border-blue-300 border-dashed rounded-lg p-4' : ''}`}
            >
              {(layout.bottomRow || []).map((widget, index) => (
                  <Draggable key={widget.id} draggableId={widget.id} index={index}>
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`relative ${snapshot.isDragging ? 'opacity-50' : ''}`}
                      >
                        <div
                          {...provided.dragHandleProps}
                          className="absolute -left-3 top-4 z-10 cursor-move hover:bg-gray-200 rounded p-1 bg-white shadow-md"
                          title="Drag to move"
                        >
                          <GripVertical className="w-5 h-5 text-gray-600" />
                        </div>
                        <div className="pl-4">
                          {renderWidget(widget.id)}
                        </div>
                      </div>
                    )}
                  </Draggable>
                ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
}
