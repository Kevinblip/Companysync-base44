
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, FileSignature, Send, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function SignContractRep() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [user, setUser] = useState(null);
  const [sessionId, setSessionId] = useState(null);
  const [formValues, setFormValues] = useState({});
  const [signatureData, setSignatureData] = useState(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const canvasRef = React.useRef(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    
    // Get sessionId from URL
    const params = new URLSearchParams(window.location.search);
    setSessionId(params.get('sessionId'));
  }, []);

  const { data: session } = useQuery({
    queryKey: ['signing-session', sessionId],
    queryFn: () => base44.entities.ContractSigningSession.get(sessionId),
    enabled: !!sessionId,
  });

  const { data: template } = useQuery({
    queryKey: ['contract-template', session?.template_id],
    queryFn: () => base44.entities.ContractTemplate.get(session.template_id),
    enabled: !!session?.template_id,
  });

  const saveRepFieldsMutation = useMutation({
    mutationFn: async ({ fields, signature }) => {
      return await base44.entities.ContractSigningSession.update(sessionId, {
        rep_fields: fields,
        rep_signature_url: signature,
        rep_signed_at: new Date().toISOString(),
        status: 'rep_signed',
        current_signer: 'customer'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['signing-session'] });
    },
  });

  const sendToCustomerMutation = useMutation({
    mutationFn: async () => {
      return await base44.functions.invoke('sendContractSigningLink', {
        sessionId: sessionId
      });
    },
    onSuccess: () => {
      alert('✅ Contract sent to customer!\n📧 ' + session?.customer_email);
      navigate('/contract-templates');
    },
  });

  useEffect(() => {
    if (template?.fillable_fields) {
      const repFields = template.fillable_fields.filter(f => f.filled_by === 'rep');
      const initialValues = {};
      repFields.forEach(field => {
        if (field.field_type === 'text' && field.field_name.includes('rep_name')) {
          initialValues[field.field_name] = user?.full_name || '';
        } else if (field.field_type === 'email' && field.field_name.includes('rep_email')) {
          initialValues[field.field_name] = user?.email || '';
        } else if (field.field_type === 'date') {
          initialValues[field.field_name] = new Date().toISOString().split('T')[0];
        }
      });
      setFormValues(initialValues);
    }
  }, [template, user]);

  // Signature canvas setup
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';

    let drawing = false;
    let lastX = 0;
    let lastY = 0;

    const startDrawing = (e) => {
      drawing = true;
      const rect = canvas.getBoundingClientRect();
      lastX = e.clientX - rect.left;
      lastY = e.clientY - rect.top;
    };

    const draw = (e) => {
      if (!drawing) return;
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      ctx.beginPath();
      ctx.moveTo(lastX, lastY);
      ctx.lineTo(x, y);
      ctx.stroke();

      lastX = x;
      lastY = y;
    };

    const stopDrawing = () => {
      drawing = false;
      setSignatureData(canvas.toDataURL());
    };

    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseleave', stopDrawing);

    return () => {
      canvas.removeEventListener('mousedown', startDrawing);
      canvas.removeEventListener('mousemove', draw);
      canvas.removeEventListener('mouseup', stopDrawing);
      canvas.removeEventListener('mouseleave', stopDrawing);
    };
  }, []);

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSignatureData(null);
  };

  const handleSaveAndSend = async () => {
    if (!signatureData) {
      alert('❌ Please sign the document first');
      return;
    }

    // Upload signature
    const blob = await (await fetch(signatureData)).blob();
    const file = new File([blob], 'signature.png', { type: 'image/png' });
    const { file_url } = await base44.integrations.Core.UploadFile({ file });

    // Save rep fields and signature
    await saveRepFieldsMutation.mutateAsync({
      fields: formValues,
      signature: file_url
    });

    // Send to customer
    await sendToCustomerMutation.mutateAsync();
  };

  if (!session || !template) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  const repFields = template.fillable_fields?.filter(f => f.filled_by === 'rep') || [];

  return (
    <div className="p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Sign Contract</h1>
        <p className="text-gray-500 mt-1">{template.template_name}</p>
        <Badge className="mt-2 bg-blue-100 text-blue-700">
          Step 1: Your Signature
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Form Side */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileSignature className="w-5 h-5" />
                Fill Your Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {repFields.map((field) => (
                <div key={field.field_name}>
                  <Label>{field.field_label} {field.required && <span className="text-red-500">*</span>}</Label>
                  <Input
                    type={field.field_type === 'date' ? 'date' : field.field_type === 'email' ? 'email' : field.field_type === 'phone' ? 'tel' : 'text'}
                    value={formValues[field.field_name] || ''}
                    onChange={(e) => setFormValues({...formValues, [field.field_name]: e.target.value})}
                    placeholder={field.placeholder}
                    required={field.required}
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Your Signature</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-2 bg-white">
                <canvas
                  ref={canvasRef}
                  width={400}
                  height={150}
                  className="w-full cursor-crosshair bg-white"
                />
              </div>
              <div className="flex gap-2">
                <Button type="button" variant="outline" onClick={clearSignature} className="flex-1">
                  Clear
                </Button>
                <Button
                  onClick={handleSaveAndSend}
                  disabled={!signatureData || saveRepFieldsMutation.isLoading || sendToCustomerMutation.isLoading}
                  className="flex-1 bg-blue-600 hover:bg-blue-700"
                >
                  {(saveRepFieldsMutation.isLoading || sendToCustomerMutation.isLoading) ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Sign & Send to Customer
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* PDF Preview Side - FIXED WITH GOOGLE VIEWER */}
        <div className="sticky top-6">
          <Card className="h-[800px]">
            <CardHeader className="border-b bg-gray-50">
              <div className="flex items-center justify-between">
                <CardTitle>Contract Preview</CardTitle>
                <a
                  href={template.original_file_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-blue-600 hover:underline"
                >
                  Open in new tab
                </a>
              </div>
            </CardHeader>
            <CardContent className="p-0 h-[720px]">
              <iframe
                src={`https://docs.google.com/viewer?url=${encodeURIComponent(template.original_file_url)}&embedded=true`}
                className="w-full h-full border-0"
                title="Contract Preview"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
