
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Phone, Mail, MessageSquare, Users, Calendar, Search, Filter, Settings } from "lucide-react";
import { format } from "date-fns";
import { useNavigate } from 'react-router-dom'; // Import useNavigate

export default function Communication() {
  const [user, setUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");

  const queryClient = useQueryClient();
  const navigate = useNavigate(); // Initialize useNavigate hook

  // Helper function for page navigation, as seen in the outline.
  // Assuming a simple conversion from pageName string to lowercase path.
  const createPageUrl = (pageName) => {
    return `/${pageName.toLowerCase()}`;
  };

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  const { data: rawCommunications = [] } = useQuery({
    queryKey: ['communications', myCompany?.id],
    queryFn: async () => {
      if (!myCompany) return [];
      try {
        const comms = await base44.entities.Communication.filter({ company_id: myCompany.id }, "-created_date");
        return Array.isArray(comms) ? comms : [];
      } catch (error) {
        console.error('Error fetching communications:', error);
        return [];
      }
    },
    enabled: !!myCompany,
    initialData: [],
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.Customer.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const { data: leads = [] } = useQuery({
    queryKey: ['leads', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.Lead.filter({ company_id: myCompany.id }) : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const getTypeIcon = (type) => {
    if (!type) return Calendar;
    const icons = {
      email: Mail,
      call: Phone,
      sms: MessageSquare,
      meeting: Users,
      note: Calendar
    };
    return icons[type] || Calendar;
  };

  const getTypeColor = (type) => {
    if (!type) return 'bg-gray-100 text-gray-700 border-gray-200';
    const colors = {
      email: 'bg-blue-100 text-blue-700 border-blue-200',
      call: 'bg-green-100 text-green-700 border-green-200',
      sms: 'bg-purple-100 text-purple-700 border-purple-200',
      meeting: 'bg-orange-100 text-orange-700 border-orange-200',
      note: 'bg-gray-100 text-gray-700 border-gray-200'
    };
    return colors[type] || 'bg-gray-100 text-gray-700 border-gray-200';
  };

  // Filter out invalid communications with comprehensive checks
  const validCommunications = React.useMemo(() => {
    if (!Array.isArray(rawCommunications)) return [];
    
    return rawCommunications.filter(comm => {
      // Must be an object
      if (!comm || typeof comm !== 'object') return false;
      // Must have communication_type
      if (!comm.communication_type) return false;
      // Must have contact_name
      if (!comm.contact_name) return false;
      // Must have id
      if (!comm.id) return false;
      
      return true;
    });
  }, [rawCommunications]);

  const filteredComms = React.useMemo(() => {
    return validCommunications.filter(comm => {
      const matchesSearch = 
        (comm.contact_name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (comm.message || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (comm.subject || '').toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesType = filterType === "all" || comm.communication_type === filterType;
      
      return matchesSearch && matchesType;
    });
  }, [validCommunications, searchTerm, filterType]);

  const groupedByContact = React.useMemo(() => {
    return filteredComms.reduce((acc, comm) => {
      if (!comm || !comm.contact_name) return acc;
      
      const key = comm.contact_name;
      if (!acc[key]) acc[key] = [];
      acc[key].push(comm);
      return acc;
    }, {});
  }, [filteredComms]);

  const stats = React.useMemo(() => {
    return {
      total: validCommunications.length,
      calls: validCommunications.filter(c => c && c.communication_type === 'call').length,
      sms: validCommunications.filter(c => c && c.communication_type === 'sms').length,
      emails: validCommunications.filter(c => c && c.communication_type === 'email').length,
      meetings: validCommunications.filter(c => c && c.communication_type === 'meeting').length
    };
  }, [validCommunications]);

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Communication Hub</h1>
          <p className="text-gray-500 mt-1">All customer interactions in one place</p>
        </div>

        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => navigate(createPageUrl('Settings'))}
            className="text-sm"
          >
            <Settings className="w-4 h-4 mr-2" />
            Twilio Setup
          </Button>
          <Button className="bg-green-600 hover:bg-green-700">
            <Phone className="w-4 h-4 mr-2" />
            Call
          </Button>
          <Button className="bg-purple-600 hover:bg-purple-700">
            <MessageSquare className="w-4 h-4 mr-2" />
            SMS
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700">
            <Mail className="w-4 h-4 mr-2" />
            Email
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card className="bg-white border-2 border-gray-200">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
            <div className="text-sm text-gray-600">Total Communications</div>
          </CardContent>
        </Card>
        <Card className="bg-green-50 border-2 border-green-200">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-700">{stats.calls}</div>
            <div className="text-sm text-green-600">Calls</div>
          </CardContent>
        </Card>
        <Card className="bg-purple-50 border-2 border-purple-200">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-purple-700">{stats.sms}</div>
            <div className="text-sm text-purple-600">Text Messages</div>
          </CardContent>
        </Card>
        <Card className="bg-blue-50 border-2 border-blue-200">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-700">{stats.emails}</div>
            <div className="text-sm text-blue-600">Emails</div>
          </CardContent>
        </Card>
        <Card className="bg-orange-50 border-2 border-orange-200">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-orange-700">{stats.meetings}</div>
            <div className="text-sm text-orange-600">Meetings</div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-white shadow-md">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search conversations..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button
                variant={filterType === "all" ? "default" : "outline"}
                onClick={() => setFilterType("all")}
                size="sm"
              >
                All
              </Button>
              <Button
                variant={filterType === "call" ? "default" : "outline"}
                onClick={() => setFilterType("call")}
                size="sm"
              >
                <Phone className="w-3 h-3 mr-1" />
                Calls
              </Button>
              <Button
                variant={filterType === "sms" ? "default" : "outline"}
                onClick={() => setFilterType("sms")}
                size="sm"
              >
                <MessageSquare className="w-3 h-3 mr-1" />
                SMS
              </Button>
              <Button
                variant={filterType === "email" ? "default" : "outline"}
                onClick={() => setFilterType("email")}
                size="sm"
              >
                <Mail className="w-3 h-3 mr-1" />
                Emails
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="timeline" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="timeline">Timeline View</TabsTrigger>
          <TabsTrigger value="grouped">Grouped by Contact</TabsTrigger>
        </TabsList>

        <TabsContent value="timeline" className="space-y-4 mt-4">
          {filteredComms.map((comm) => {
            if (!comm || !comm.id || !comm.communication_type) return null;
            
            const Icon = getTypeIcon(comm.communication_type);
            const typeColor = getTypeColor(comm.communication_type);
            
            return (
              <Card key={comm.id} className="bg-white shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${typeColor.replace('border-', '').replace('text-', 'bg-').split(' ')[0]}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-lg">{comm.contact_name || 'Unknown'}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className={typeColor}>
                              {comm.communication_type}
                            </Badge>
                            <Badge variant="outline">{comm.direction || 'outbound'}</Badge>
                            {comm.status && (
                              <Badge variant="outline" className="capitalize">
                                {comm.status}
                              </Badge>
                            )}
                          </div>
                        </div>
                        {comm.created_date && (
                          <div className="text-right text-sm text-gray-500">
                            {format(new Date(comm.created_date), 'MMM d, yyyy')}
                            <br />
                            {format(new Date(comm.created_date), 'h:mm a')}
                          </div>
                        )}
                      </div>
                      
                      {comm.subject && (
                        <p className="text-sm font-medium text-gray-700 mb-2">{comm.subject}</p>
                      )}
                      
                      {comm.message && <p className="text-gray-600 mb-3">{comm.message}</p>}
                      
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        {comm.contact_phone && (
                          <span className="flex items-center gap-1">
                            <Phone className="w-3 h-3" />
                            {comm.contact_phone}
                          </span>
                        )}
                        {comm.contact_email && (
                          <span className="flex items-center gap-1">
                            <Mail className="w-3 h-3" />
                            {comm.contact_email}
                          </span>
                        )}
                        {comm.duration_minutes > 0 && (
                          <span>{comm.duration_minutes} min</span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
          {filteredComms.length === 0 && (
            <Card className="bg-white">
              <CardContent className="p-12 text-center text-gray-500">
                <MessageSquare className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-semibold mb-2">No communications yet</h3>
                <p>Start calling, texting, or emailing your customers!</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="grouped" className="space-y-4 mt-4">
          {Object.entries(groupedByContact).map(([contactName, comms]) => {
            if (!contactName || !Array.isArray(comms)) return null;
            
            return (
              <Card key={contactName} className="bg-white shadow-sm">
                <CardHeader className="border-b bg-gray-50">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{contactName}</CardTitle>
                    <Badge variant="outline">{comms.length} interactions</Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {comms.map((comm) => {
                      if (!comm || !comm.id || !comm.communication_type) return null;
                      
                      const Icon = getTypeIcon(comm.communication_type);
                      const typeColor = getTypeColor(comm.communication_type);
                      
                      return (
                        <div key={comm.id} className="flex gap-3 pb-4 border-b last:border-b-0">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${typeColor.replace('border-', '').replace('text-', 'bg-').split(' ')[0]}`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <Badge variant="outline" className={typeColor}>
                                {comm.communication_type}
                              </Badge>
                              {comm.created_date && (
                                <span className="text-xs text-gray-500">
                                  {format(new Date(comm.created_date), 'MMM d, h:mm a')}
                                </span>
                              )}
                            </div>
                            {comm.subject && (
                              <p className="text-sm font-medium text-gray-700 mb-1">{comm.subject}</p>
                            )}
                            {comm.message && <p className="text-sm text-gray-600">{comm.message}</p>}
                            {comm.duration_minutes > 0 && (
                              <p className="text-xs text-gray-500 mt-1">{comm.duration_minutes} min call</p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            );
          })}
          {Object.keys(groupedByContact).length === 0 && (
            <Card className="bg-white">
              <CardContent className="p-12 text-center text-gray-500">
                <Users className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                <h3 className="text-lg font-semibold mb-2">No grouped conversations yet</h3>
                <p>Communications will be grouped by contact here</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
