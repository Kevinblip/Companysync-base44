
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Upload,
  FileSpreadsheet,
  CheckCircle2,
  XCircle,
  AlertCircle,
  ArrowRight,
  Download,
  Loader2
} from "lucide-react";

export default function DataImport() {
  const [user, setUser] = useState(null);
  const [file, setFile] = useState(null);
  const [csvData, setCsvData] = useState(null);
  const [headers, setHeaders] = useState([]);
  const [previewRows, setPreviewRows] = useState([]);
  const [entityType, setEntityType] = useState("Lead");
  const [columnMapping, setColumnMapping] = useState({});
  const [step, setStep] = useState(1);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState(null);
  const [errorDetails, setErrorDetails] = useState([]);

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: companies = [] } = useQuery({
    queryKey: ['companies'],
    queryFn: () => base44.entities.Company.list("-created_date"),
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email);

  const { data: importLogs = [] } = useQuery({
    queryKey: ['import-logs', myCompany?.id],
    queryFn: () => myCompany ? base44.entities.ImportLog.filter({ company_id: myCompany.id }, "-created_date") : [],
    enabled: !!myCompany,
    initialData: [],
  });

  const entityFields = {
    Staff: [
        { key: 'full_name', label: 'Full Name', required: true },
        { key: 'email', label: 'Email', required: true },
        { key: 'temporary_password', label: 'Temporary Password', required: false, help: 'Required ONLY for creating new users.' },
        { key: 'position', label: 'Position/Role', required: false },
        { key: 'phone', label: 'Phone Number', required: false },
        { key: 'hourly_rate', label: 'Hourly Rate', required: false },
    ],
    Lead: [
      { key: 'name', label: 'Name', required: true },
      { key: 'email', label: 'Email', required: false },
      { key: 'phone', label: 'Phone', required: false },
      { key: 'phone_2', label: 'Phone 2', required: false },
      { key: 'company', label: 'Company/Address', required: false },
      { key: 'status', label: 'Status', required: false },
      { key: 'source', label: 'Source', required: false },
      { key: 'value', label: 'Estimated Value', required: false },
      { key: 'notes', label: 'Notes', required: false },
    ],
    Customer: [
      { key: 'name', label: 'Name', required: true },
      { key: 'email', label: 'Email', required: false },
      { key: 'phone', label: 'Phone', required: false },
      { key: 'phone_2', label: 'Phone 2', required: false },
      { key: 'company', label: 'Company', required: false },
      { key: 'address', label: 'Address', required: false },
      { key: 'notes', label: 'Notes', required: false },
    ],
    Task: [
      { key: 'name', label: 'Task Name', required: true },
      { key: 'description', label: 'Description', required: false },
      { key: 'status', label: 'Status', required: false },
      { key: 'priority', label: 'Priority', required: false },
      { key: 'due_date', label: 'Due Date', required: false },
      { key: 'assigned_to', label: 'Assigned To (email)', required: false },
    ],
    Item: [
      { key: 'name', label: 'Item Name', required: true },
      { key: 'description', label: 'Description', required: false },
      { key: 'category', label: 'Category', required: false },
      { key: 'unit', label: 'Unit', required: false },
      { key: 'price', label: 'Price', required: true },
      { key: 'cost', label: 'Cost', required: false },
      { key: 'sku', label: 'SKU', required: false },
    ],
    EstimateWithLineItems: [
      { key: 'estimate_number', label: 'Estimate #', required: true },
      { key: 'customer_name', label: 'Customer Name', required: true },
      { key: 'status', label: 'Status', required: false },
      { key: 'valid_until', label: 'Expiry Date (YYYY-MM-DD)', required: false },
      { key: 'insurance_company', label: 'Insurance Company', required: false },
      { key: 'adjuster_name', label: 'Adjuster Name', required: false },
      { key: 'adjuster_phone', label: 'Adjuster Phone', required: false },
      { key: 'claim_number', label: 'Claim Number', required: false },
      { key: 'line_number', label: 'Line #', required: false },
      { key: 'code', label: 'Item Code', required: false },
      { key: 'description', label: 'Item Description', required: true },
      { key: 'quantity', label: 'Quantity', required: true },
      { key: 'unit', label: 'Unit', required: true },
      { key: 'unit_price', label: 'Unit Price', required: true },
      { key: 'tax_rate', label: 'Tax Rate %', required: false },
    ],
    Estimate: [
      { key: 'estimate_number', label: 'Estimate Number', required: true },
      { key: 'customer_name', label: 'Customer Name', required: true },
      { key: 'amount', label: 'Total Amount (NOT including tax)', required: true },
      { key: 'total_tax', label: 'Tax Amount (separate from total)', required: false },
      { key: 'status', label: 'Status (draft/sent/accepted/declined)', required: false },
      { key: 'valid_until', label: 'Valid Until Date (YYYY-MM-DD)', required: false },
      { key: 'project_name', label: 'Project Name', required: false },
      { key: 'reference_number', label: 'Reference Number', required: false },
      { key: 'insurance_company', label: 'Insurance Company', required: false },
      { key: 'adjuster_name', label: 'Adjuster Name', required: false },
      { key: 'adjuster_phone', label: 'Adjuster Phone', required: false },
      { key: 'claim_number', label: 'Claim Number', required: false },
      { key: 'notes', label: 'Notes', required: false },
    ],
    Invoice: [
      { key: 'invoice_number', label: 'Invoice Number', required: true },
      { key: 'customer_name', label: 'Customer Name', required: true },
      { key: 'customer_email', label: 'Customer Email', required: false },
      { key: 'amount', label: 'Total Amount', required: true },
      { key: 'status', label: 'Status (draft/sent/paid/overdue)', required: false },
      { key: 'issue_date', label: 'Issue Date (YYYY-MM-DD)', required: false },
      { key: 'due_date', label: 'Due Date (YYYY-MM-DD)', required: false },
      { key: 'notes', label: 'Notes', required: false },
    ],
    Project: [
      { key: 'name', label: 'Project Name', required: true },
      { key: 'customer_name', label: 'Customer Name', required: false },
      { key: 'status', label: 'Status (not_started/in_progress/completed)', required: false },
      { key: 'start_date', label: 'Start Date (YYYY-MM-DD)', required: false },
      { key: 'deadline', label: 'Deadline (YYYY-MM-DD)', required: false },
      { key: 'budget', label: 'Budget', required: false },
      { key: 'description', label: 'Description', required: false },
    ],
    Payment: [
      { key: 'payment_number', label: 'Payment Number', required: false },
      { key: 'invoice_number', label: 'Invoice Number', required: false },
      { key: 'customer_name', label: 'Customer Name', required: true },
      { key: 'amount', label: 'Payment Amount', required: true },
      { key: 'payment_method', label: 'Payment Method (cash/check/credit_card)', required: false },
      { key: 'payment_date', label: 'Payment Date (YYYY-MM-DD)', required: true },
      { key: 'status', label: 'Status (received/pending)', required: false },
      { key: 'reference_number', label: 'Reference/Check Number', required: false },
      { key: 'notes', label: 'Notes', required: false },
    ],
    Transaction: [
      { key: 'date', label: 'Date (YYYY-MM-DD)', required: true },
      { key: 'account', label: 'Account Name', required: true },
      { key: 'type', label: 'Type (debit/credit)', required: true },
      { key: 'description', label: 'Description', required: true },
      { key: 'amount', label: 'Amount', required: true },
    ],
    ChartOfAccount: [
      { key: 'account_name', label: 'Account Name', required: true },
      { key: 'account_number', label: 'Account Number', required: false },
      { key: 'account_type', label: 'Account Type', required: true, help: 'Asset, Liability, Equity, Revenue, or Expense' },
      { key: 'description', label: 'Description', required: false },
    ],
  };

  const parseCSV = (text) => {
    const lines = text.trim().split('\n');
    
    const parseLine = (line) => {
      const result = [];
      let current = '';
      let inQuotes = false;
      
      for (let i = 0; i < line.length; i++) {
        const char = line[i];
        
        if (char === '"') {
          inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
          result.push(current.trim().replace(/^["']|["']$/g, ''));
          current = '';
        } else {
          current += char;
        }
      }
      
      result.push(current.trim().replace(/^["']|["']$/g, ''));
      return result;
    };

    const headers = parseLine(lines[0]);
    const rows = [];
    
    for (let i = 1; i < Math.min(lines.length, 6); i++) {
      const values = parseLine(lines[i]);
      const row = {};
      headers.forEach((header, idx) => {
        row[header] = values[idx] || '';
      });
      rows.push(row);
    }

    return { headers, rows, totalRows: lines.length - 1 };
  };

  const smartAutoMap = (headers, entityType) => {
    const mapping = {};
    const fields = entityFields[entityType];
    
    const patterns = {
      name: ['name', 'contact', 'contact name', 'customer name', 'lead name', 'full name', 'person', 'client name'],
      full_name: ['full name', 'staff name', 'employee name', 'name'],
      email: ['email', 'e-mail', 'email address', 'contact email'],
      temporary_password: ['password', 'temp password', 'temporary_password'],
      position: ['position', 'role', 'job title'],
      hourly_rate: ['hourly rate', 'rate', 'pay rate'],
      phone: ['phone', 'telephone', 'phone number', 'cell', 'mobile', 'contact phone', 'primary phone'],
      phone_2: ['phone 2', 'phone2', 'secondary phone', 'alternate phone', 'mobile 2', 'cell 2'],
      company: ['company', 'business', 'organization', 'company name', 'business name', 'address', 'property address'],
      status: ['status', 'lead status', 'state', 'task status', 'project status', 'invoice status', 'estimate status', 'payment status'],
      source: ['source', 'lead source', 'origin'],
      value: ['value', 'estimated value', 'deal value', 'opportunity value', 'est value'],
      notes: ['notes', 'comments', 'description', 'details', 'remarks'],
      address: ['address', 'street', 'location', 'property address', 'full address', 'shipping address', 'billing address'],
      estimate_number: ['estimate #', 'estimate number', 'estimate no', 'est #', 'est no', 'estimate id', 'quote #', 'quote number', 'quote id'],
      invoice_number: ['invoice #', 'invoice number', 'invoice no', 'inv #', 'inv no', 'invoice id'],
      customer_name: ['customer', 'customer name', 'client', 'client name', 'name', 'contact', 'recipient'],
      customer_email: ['customer email', 'client email', 'email', 'contact email', 'recipient email'],
      amount: ['amount', 'total', 'total amount', 'price', 'total price', 'sum', 'value', 'grand total', 'subtotal', 'payment amount'],
      total_tax: ['tax', 'total tax', 'tax amount', 'vat'],
      valid_until: ['valid until', 'expiry', 'expiration', 'expires', 'valid through', 'expire date'],
      issue_date: ['issue date', 'date', 'invoice date', 'created date', 'date issued', 'bill date'],
      due_date: ['due date', 'payment due', 'due by', 'invoice due date', 'task due date', 'deadline'],
      project_name: ['project name', 'project'],
      reference_number: ['reference', 'reference number', 'ref #', 'invoice reference'],
      insurance_company: ['insurance company', 'insurer'],
      adjuster_name: ['adjuster name', 'adjuster'],
      adjuster_phone: ['adjuster phone', 'adjuster #'],
      claim_number: ['claim #', 'claim number', 'claim id'],
      description: ['description', 'item description', 'details', 'product description', 'service description', 'project description', 'line item description'],
      category: ['category', 'type', 'item type', 'group', 'product category'],
      unit: ['unit', 'uom', 'unit of measure', 'measurement', 'item unit'],
      price: ['price', 'rate', 'unit price', 'cost', 'amount', 'selling price'],
      cost: ['cost', 'unit cost', 'item cost', 'purchase price'],
      sku: ['sku', 'item code', 'product code', 'code', 'stock keeping unit'],
      line_number: ['line #', 'line number', 'item #', 'item number'],
      code: ['code', 'item code', 'product code', 'sku'],
      quantity: ['qty', 'quantity', 'count'],
      unit_price: ['unit price', 'rate', 'price per unit', 'price', 'item price'],
      tax_rate: ['tax rate', 'vat rate', 'tax %', 'vat %'],
      priority: ['priority', 'importance', 'level', 'task priority'],
      assigned_to: ['assigned to', 'assignee', 'assigned', 'owner', 'task owner'],
      start_date: ['start date', 'start', 'begin date', 'project start date'],
      deadline: ['deadline', 'due date', 'end date', 'completion date', 'project deadline', 'task deadline'],
      budget: ['budget', 'estimated budget', 'project budget', 'cost estimate'],
      payment_number: ['payment #', 'payment number', 'payment no', 'receipt #', 'receipt number', 'transaction #', 'transaction id'],
      payment_method: ['payment method', 'method', 'payment type', 'how paid', 'type'],
      payment_date: ['payment date', 'date paid', 'received date', 'date received', 'date'],
      date: ['date', 'transaction date'],
      account: ['account', 'account name'],
      type: ['type', 'transaction type'],
      account_name: ['account name', 'name'],
      account_number: ['account number', 'number', 'acct #'],
      account_type: ['account type', 'type', 'category'],
    };
    
    headers.forEach(header => {
      const headerLower = header.toLowerCase().trim();
      
      for (const field of fields) {
        const fieldPatterns = patterns[field.key];
        if (fieldPatterns) {
          const matches = fieldPatterns.some(pattern => {
            if (headerLower === pattern) return true;
            if (headerLower.replace(/\s/g, '') === pattern.replace(/\s/g, '')) return true;
            if (headerLower.includes(pattern) || pattern.includes(headerLower)) return true;
            return false;
          });
          
          if (matches && !Object.values(mapping).includes(field.key)) {
            mapping[header] = field.key;
            break;
          }
        }
      }
    });
    
    return mapping;
  };

  const handleFileUpload = (e) => {
    const uploadedFile = e.target.files[0];
    if (uploadedFile) {
      setFile(uploadedFile);
      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target.result;
        const parsed = parseCSV(text);
        setCsvData(text);
        setHeaders(parsed.headers);
        setPreviewRows(parsed.rows);

        const autoMapping = smartAutoMap(parsed.headers, entityType);
        setColumnMapping(autoMapping);
        
        const requiredFields = entityFields[entityType].filter(f => f.required);
        const mappedRequiredFields = requiredFields.filter(f => 
          Object.values(autoMapping).includes(f.key)
        );
        
        if (mappedRequiredFields.length === requiredFields.length) {
          console.log('✅ All required fields auto-mapped successfully!');
        } else {
          console.log('⚠️ Some required fields need manual mapping');
        }
        
        setStep(2);
      };
      reader.readAsText(uploadedFile);
    }
  };

  const handleImport = async () => {
    if (!myCompany) {
      alert("Please set up your company profile first!");
      return;
    }

    setImporting(true);
    setImportResult(null);
    setErrorDetails([]);

    try {
      const importStartTime = new Date();
      const lines = csvData.trim().split('\n');
      
      const parseLine = (line) => {
        const result = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
          const char = line[i];
          
          if (char === '"') {
            inQuotes = !inQuotes;
          } else if (char === ',' && !inQuotes) {
            result.push(current.trim().replace(/^["']|["']$/g, ''));
            current = '';
          } else {
            current += char;
          }
        }
        
        result.push(current.trim().replace(/^["']|["']$/g, ''));
        return result;
      };

      const csvHeaders = parseLine(lines[0]);

      // SPECIAL CASE FOR STAFF IMPORT
      if (entityType === 'Staff') {
        const staffRecords = [];
        for (let i = 1; i < lines.length; i++) {
          const values = parseLine(lines[i]);
          const record = {};
          csvHeaders.forEach((header, idx) => {
            const mappedField = columnMapping[header];
            if (mappedField && values[idx] !== undefined) {
              record[mappedField] = values[idx];
            }
          });
          staffRecords.push(record);
        }
        
        const response = await base44.functions.invoke('importStaff', { 
            records: staffRecords, 
            company_id: myCompany.id 
        });
        
        const result = response.data;
        
        if (result.success === false && !result.errors) {
            // Handle unexpected backend error format
            setImportResult({ success: false, error: result.error || "An unknown backend error occurred." });
            setErrorDetails(result.errorDetails || []);
        } else {
            setImportResult({
              success: result.errors === 0,
              imported: result.created + result.updated,
              skipped: 0,
              errors: result.errors
            });
            setErrorDetails(result.errorDetails);
        }

        if (result.errors > 0 || result.created > 0 || result.updated > 0) {
            await base44.entities.ImportLog.create({
              company_id: myCompany.id,
              import_name: file.name,
              entity_type: 'Staff',
              file_name: file.name,
              total_rows: lines.length - 1,
              imported_count: result.created + result.updated,
              skipped_count: 0,
              error_count: result.errors,
              status: result.errors > 0 ? 'completed_with_errors' : 'completed',
              column_mapping: columnMapping,
              preview_data: previewRows,
              start_time: importStartTime.toISOString(),
              end_time: new Date().toISOString()
            });
        }

        queryClient.invalidateQueries({ queryKey: ['staff-profiles'] });
        queryClient.invalidateQueries({ queryKey: ['all-users'] });
        queryClient.invalidateQueries({ queryKey: ['import-logs'] });
        
        setStep(4);
        setImporting(false);
        return;
      }


      if (entityType === 'EstimateWithLineItems') {
        const estimatesMap = new Map();
        let processingErrors = 0;
        let skippedRows = 0;
        const localErrorLog = [];

        for (let i = 1; i < lines.length; i++) {
          try {
            const values = parseLine(lines[i]);
            const currentRow = {};
            csvHeaders.forEach((header, idx) => {
              const mappedField = columnMapping[header];
              if (mappedField && values[idx] !== undefined) {
                currentRow[mappedField] = values[idx];
              }
            });

            const estimateNum = currentRow['estimate_number'];
            const customerName = currentRow['customer_name'];
            const itemDescription = currentRow['description'];
            const itemQuantity = parseFloat(currentRow['quantity']?.replace(/[$,\s]/g, '')) || 0;
            const itemUnitPrice = parseFloat(currentRow['unit_price']?.replace(/[$,\s]/g, '')) || 0;
            const itemUnit = currentRow['unit'];

            if (!estimateNum || !customerName || !itemDescription || itemQuantity <= 0 || itemUnitPrice <= 0 || !itemUnit) {
              skippedRows++;
              localErrorLog.push({
                row: i + 1,
                reason: `Missing critical line item data for Estimate ${estimateNum || '(N/A)'}`,
                data: currentRow
              });
              continue;
            }

            if (!estimatesMap.has(estimateNum)) {
              estimatesMap.set(estimateNum, {
                estimate_number: estimateNum,
                customer_name: customerName,
                status: currentRow['status'] || 'draft',
                valid_until: currentRow['valid_until'] || null,
                insurance_company: currentRow['insurance_company'] || '',
                adjuster_name: currentRow['adjuster_name'] || '',
                adjuster_phone: currentRow['adjuster_phone'] || '',
                claim_number: currentRow['claim_number'] || '',
                notes: currentRow['notes'] || '',
                items: [],
                company_id: myCompany.id
              });
            }

            const estimate = estimatesMap.get(estimateNum);
            const taxRate = parseFloat(currentRow['tax_rate']?.replace(/[%\s]/g, '')) || 0;
            
            estimate.items.push({
              line_number: currentRow['line_number'] || null,
              code: currentRow['code'] || '',
              description: itemDescription,
              quantity: itemQuantity,
              rate: itemUnitPrice,
              unit: itemUnit,
              amount: itemQuantity * itemUnitPrice,
              tax_rate: taxRate,
            });
          } catch (err) {
            console.error(`Error processing row ${i} for EstimateWithLineItems:`, err);
            processingErrors++;
            localErrorLog.push({
              row: i + 1,
              reason: `Processing error: ${err.message}`,
              data: lines[i]
            });
          }
        }

        let importedEstimates = 0;
        let failedEstimates = 0;
        
        for (const estimate of estimatesMap.values()) {
          try {
            const subtotal = estimate.items.reduce((sum, item) => sum + (item.amount || 0), 0);
            const totalTax = estimate.items.reduce((sum, item) => {
              const taxAmount = (item.amount || 0) * ((item.tax_rate || 0) / 100);
              return sum + taxAmount;
            }, 0);
            
            estimate.amount = subtotal;
            estimate.total_tax = totalTax;

            await base44.entities.Estimate.create(estimate);
            importedEstimates++;
          } catch (err) {
            console.error('Failed to import estimate:', estimate.estimate_number, err);
            failedEstimates++;
            localErrorLog.push({
              row: `Estimate: ${estimate.estimate_number}`,
              reason: `Failed to create estimate: ${err.message}`,
              data: estimate
            });
          }
        }

        setErrorDetails(localErrorLog);

        const importEndTime = new Date();

        await base44.entities.ImportLog.create({
          company_id: myCompany.id,
          import_name: file.name,
          entity_type: 'Estimate (with Line Items)',
          file_name: file.name,
          total_rows: lines.length - 1,
          imported_count: importedEstimates,
          skipped_count: skippedRows,
          error_count: processingErrors + failedEstimates,
          status: (skippedRows + processingErrors + failedEstimates) > 0 ? 'completed_with_errors' : 'completed',
          column_mapping: columnMapping,
          preview_data: previewRows,
          start_time: importStartTime.toISOString(),
          end_time: importEndTime.toISOString()
        });

        setImportResult({
          success: (skippedRows + processingErrors + failedEstimates) === 0,
          imported: importedEstimates,
          skipped: skippedRows,
          errors: processingErrors + failedEstimates
        });

        queryClient.invalidateQueries({ queryKey: ['estimates'] });
        queryClient.invalidateQueries({ queryKey: ['import-logs'] });

        setStep(4);
        setImporting(false);
        return;
      }

      const records = [];
      let skippedRequired = 0;
      let processingErrors = 0;
      const errorLog = [];
      
      const totalDataRows = lines.length - 1; // Total rows excluding header

      for (let i = 1; i < lines.length; i++) {
        try {
          const values = parseLine(lines[i]);
          const record = { company_id: myCompany.id };

          csvHeaders.forEach((header, idx) => {
            const mappedField = columnMapping[header];
            if (mappedField && values[idx] !== undefined) {
              let value = values[idx];

              if (['value', 'price', 'cost', 'amount', 'budget', 'total_tax', 'hourly_rate'].includes(mappedField)) {
                const cleanedValue = value.replace(/[$,\s]/g, '');
                value = parseFloat(cleanedValue) || 0;
              }

              record[mappedField] = value;
            }
          });

          if (!record.name && record.company && entityType !== 'ChartOfAccount' && entityType !== 'Staff') { // Exclude Staff and ChartOfAccount from this auto-fill
            record.name = record.company;
            console.log(`Auto-filled name from company: ${record.company}`);
          }
          
          if (entityType === 'ChartOfAccount' && record.account_name) {
              record.name = record.account_name; // Use account_name as 'name' for generic backend
          }


          if (entityType === 'Customer') {
            record.customer_number = totalDataRows - i + 1;
          }

          const requiredFields = entityFields[entityType].filter(f => f.required);
          const missingFields = requiredFields.filter(f => !record[f.key]);

          if (missingFields.length > 0) {
            skippedRequired++;
            errorLog.push({
              row: i + 1,
              reason: `Missing required fields: ${missingFields.map(f => f.label).join(', ')}`,
              data: record
            });
            continue;
          }

          records.push(record);
        } catch (err) {
          console.error(`Error processing row ${i}:`, err);
          processingErrors++;
          errorLog.push({
            row: i + 1,
            reason: `Processing error: ${err.message}`,
            data: lines[i]
          });
        }
      }

      setErrorDetails(errorLog);

      if (records.length === 0 && (lines.length - 1) > 0) {
        setImportResult({
          success: false,
          error: `No records were imported. All ${lines.length - 1} rows were skipped or had errors.`,
          imported: 0,
          skipped: skippedRequired,
          errors: processingErrors
        });
        setStep(4);
        setImporting(false);
        return;
      }

      console.log(`Attempting to import ${records.length} ${entityType} records...`);

      const batchSize = 50;
      let imported = 0;

      if (records.length > 0) {
        for (let i = 0; i < records.length; i += batchSize) {
          const batch = records.slice(i, i + batchSize);
          await base44.entities[entityType].bulkCreate(batch);
          imported += batch.length;
        }
      }

      const importEndTime = new Date();

      await base44.entities.ImportLog.create({
        company_id: myCompany.id,
        import_name: file.name,
        entity_type: entityType,
        file_name: file.name,
        total_rows: lines.length - 1,
        imported_count: imported,
        skipped_count: skippedRequired,
        error_count: processingErrors,
        status: (skippedRequired + processingErrors) > 0 ? 'completed_with_errors' : 'completed',
        column_mapping: columnMapping,
        preview_data: previewRows,
        start_time: importStartTime.toISOString(),
        end_time: importEndTime.toISOString()
      });

      setImportResult({
        success: true,
        imported: imported,
        skipped: skippedRequired,
        errors: processingErrors
      });

      queryClient.invalidateQueries({ queryKey: ['leads'] });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      queryClient.invalidateQueries({ queryKey: ['tasks'] });
      queryClient.invalidateQueries({ queryKey: ['items'] });
      queryClient.invalidateQueries({ queryKey: ['estimates'] });
      queryClient.invalidateQueries({ queryKey: ['invoices'] });
      queryClient.invalidateQueries({ queryKey: ['projects'] });
      queryClient.invalidateQueries({ queryKey: ['payments'] });
      queryClient.invalidateQueries({ queryKey: ['transactions'] });
      queryClient.invalidateQueries({ queryKey: ['chart-of-accounts'] });
      queryClient.invalidateQueries({ queryKey: ['import-logs'] });

      setStep(4);
    } catch (error) {
      console.error('Import error:', error);
      setImportResult({
        success: false,
        error: error.message,
        imported: 0,
        skipped: 0,
        errors: csvData.trim().split('\n').length - 1 // Assume all rows failed on general error
      });
      setErrorDetails([]);
      setStep(4);
    }

    setImporting(false);
  };

  const handleReset = () => {
    setFile(null);
    setCsvData(null);
    setHeaders([]);
    setPreviewRows([]);
    setColumnMapping({});
    setStep(1);
    setImportResult(null);
    setErrorDetails([]);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Data Import Tool</h1>
        <p className="text-gray-500 mt-1">Import data from your old CRM via CSV files</p>
      </div>

      <Card className="bg-white">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className={`flex items-center gap-2 ${step >= 1 ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
                1
              </div>
              <span className="font-medium">Upload CSV</span>
            </div>
            <ArrowRight className="text-gray-400" />
            <div className={`flex items-center gap-2 ${step >= 2 ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
                2
              </div>
              <span className="font-medium">Map Columns</span>
            </div>
            <ArrowRight className="text-gray-400" />
            <div className={`flex items-center gap-2 ${step >= 3 ? 'text-blue-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}>
                3
              </div>
              <span className="font-medium">Review & Import</span>
            </div>
            <ArrowRight className="text-gray-400" />
            <div className={`flex items-center gap-2 ${step >= 4 ? 'text-green-600' : 'text-gray-400'}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 4 ? 'bg-green-600 text-white' : 'bg-gray-200'}`}>
                ✓
              </div>
              <span className="font-medium">Complete</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {step === 1 && (
        <Card className="bg-white shadow-md">
          <CardHeader className="border-b">
            <CardTitle>Step 1: Upload Your CSV File</CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <Alert className="bg-blue-50 border-blue-200">
              <AlertDescription>
                <strong>💡 CSV Format Tips:</strong>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Save as CSV UTF-8 format in Excel</li>
                  <li>First row should be column headers</li>
                  <li>Make sure data is clean (no special characters in names)</li>
                  <li>Phone numbers can have dashes or spaces (we'll clean them)</li>
                  <li><strong>For Estimates with Line Items:</strong> Each row in your CSV should represent one line item. Multiple rows with the same "Estimate #" will be grouped into a single estimate.</li>
                </ul>
              </AlertDescription>
            </Alert>

            {entityType === 'EstimateWithLineItems' && (
              <Alert className="bg-green-50 border-green-200">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                <AlertDescription>
                  <strong>✅ Sample CSV Based On Your Estimate Format:</strong>
                  <div className="mt-3 space-y-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        const csv = `Estimate #,Customer Name,Status,Expiry Date,Line #,Description,Quantity,Unit,Unit Price,Tax Rate %
Estimate-1600,Edward Simmons,accepted,2025-06-07,1,Main Roof,1,EA,0.00,0
Estimate-1600,Edward Simmons,accepted,2025-06-07,2,"Tear off, haul, and dispose of comp. shingles - Laminated",13.5,SQ,72.26,0
Estimate-1600,Edward Simmons,accepted,2025-06-07,3,"Laminated - comp. shingle, rfg - w/ felt",14.9,SQ,186.00,0
Estimate-1600,Edward Simmons,accepted,2025-06-07,4,Ridge cap - Standard profile - composition shingles,99,LF,10.01,0
Estimate-1600,Edward Simmons,accepted,2025-06-07,5,Asphalt starter - universal starter course,148,LF,2.90,0
Estimate-1600,Edward Simmons,accepted,2025-06-07,6,Ice & water barrier,148,LF,3.65,0
Estimate-1600,Edward Simmons,accepted,2025-06-07,7,Roofing felt - 15 lb.,14.9,SQ,37.97,0
Estimate-1600,Edward Simmons,accepted,2025-06-07,8,Remove and replace drip edge,148,LF,2.94,0
Estimate-1600,Edward Simmons,accepted,2025-06-07,9,"Chimney flashing - small (24"" x 24"")",1,EA,234.00,0
Estimate-1600,Edward Simmons,accepted,2025-06-07,10,Roof vent - turtle type - Metal,3,EA,78.00,0
Estimate-1600,Edward Simmons,accepted,2025-06-07,11,Flashing - Pipe Jack,2,EA,87.20,0`;
                        
                        const blob = new Blob([csv], { type: 'text/csv' });
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'estimate-1600-sample.csv';
                        a.click();
                        window.URL.revokeObjectURL(url);
                      }}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download Estimate-1600 Sample CSV
                    </Button>
                    <p className="text-xs text-gray-600">
                      This CSV contains your Estimate-1600 with all 11 line items ready to import!
                    </p>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            <div>
              <Label>Select Entity Type to Import</Label>
              <Select value={entityType} onValueChange={setEntityType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Staff">Staff Members</SelectItem>
                  <SelectItem value="Lead">Leads</SelectItem>
                  <SelectItem value="Customer">Customers</SelectItem>
                  <SelectItem value="Task">Tasks</SelectItem>
                  <SelectItem value="Item">Items/Products</SelectItem>
                  <SelectItem value="EstimateWithLineItems">⭐ Estimates (WITH Line Items) - RECOMMENDED</SelectItem>
                  <SelectItem value="Estimate">Estimates (Simple - no line items)</SelectItem>
                  <SelectItem value="Invoice">Invoices</SelectItem>
                  <SelectItem value="Project">Projects</SelectItem>
                  <SelectItem value="Payment">Payments</SelectItem>
                  <SelectItem value="Transaction">Accounting - Transactions</SelectItem>
                  <SelectItem value="ChartOfAccount">Accounting - Chart of Accounts</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-blue-400 transition-colors">
              <input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
                id="csv-upload"
              />
              <label htmlFor="csv-upload" className="cursor-pointer">
                <FileSpreadsheet className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                <p className="text-lg font-medium text-gray-700">
                  {file ? file.name : 'Click to upload CSV file'}
                </p>
                <p className="text-sm text-gray-500 mt-2">
                  CSV files only • Max 10,000 rows recommended
                </p>
              </label>
            </div>
          </CardContent>
        </Card>
      )}

      {step === 2 && (
        <Card className="bg-white shadow-md">
          <CardHeader className="border-b">
            <CardTitle>Step 2: Map CSV Columns to {entityType} Fields</CardTitle>
            <p className="text-sm text-gray-500 mt-1">
              Tell us which CSV column goes to which {entityType} field. <strong>Red fields are required!</strong>
            </p>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle2 className="w-4 h-4 text-green-600" />
              <AlertDescription>
                Found {headers.length} columns in your CSV with {previewRows.length} preview rows. We've auto-matched some columns for you - please review!
              </AlertDescription>
            </Alert>

            <Alert className="bg-blue-50 border-blue-200">
              <AlertCircle className="w-4 h-4 text-blue-600" />
              <AlertDescription>
                <strong>⚠️ IMPORTANT:</strong> You must map the required fields (marked with *) or all rows will be skipped!
                <br />
                <strong>Required for {entityType}:</strong> {entityFields[entityType].filter(f => f.required).map(f => f.label).join(', ')}
              </AlertDescription>
            </Alert>

            {(() => {
              const requiredFields = entityFields[entityType].filter(f => f.required);
              const mappedRequiredFields = requiredFields.filter(f =>
                Object.values(columnMapping).includes(f.key)
              );
              const missingRequiredFields = requiredFields.filter(f =>
                !Object.values(columnMapping).includes(f.key)
              );

              if (missingRequiredFields.length > 0) {
                return (
                  <Alert variant="destructive">
                    <AlertCircle className="w-4 h-4" />
                    <AlertDescription>
                      <strong>❌ Missing Required Fields:</strong> {missingRequiredFields.map(f => f.label).join(', ')}
                      <br />
                      <span className="text-xs">Please map these fields or the corresponding rows will be skipped!</span>
                    </AlertDescription>
                  </Alert>
                );
              } else {
                return (
                  <Alert className="bg-green-50 border-green-200">
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                    <AlertDescription>
                      <strong>✅ All required fields are mapped!</strong> ({mappedRequiredFields.map(f => f.label).join(', ')})
                    </AlertDescription>
                  </Alert>
                );
              }
            })()}

            <div className="border rounded-lg overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Your CSV Column</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Sample Data</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-gray-700">Maps To {entityType} Field</th>
                  </tr>
                </thead>
                <tbody>
                  {headers.map((header, idx) => {
                    const mappedFieldKey = columnMapping[header];
                    const fieldInfo = entityFields[entityType].find(f => f.key === mappedFieldKey);
                    const isRequired = fieldInfo?.required;

                    return (
                      <tr key={idx} className={`border-t ${isRequired ? 'bg-red-50' : ''}`}>
                        <td className="px-4 py-3 font-medium">
                          {header}
                          {isRequired && <span className="ml-2 text-red-600 font-bold">*</span>}
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-600">
                          {previewRows[0]?.[header] || '-'}
                        </td>
                        <td className="px-4 py-3">
                          <Select
                            value={mappedFieldKey || 'skip'}
                            onValueChange={(value) => {
                              setColumnMapping(prev => ({
                                ...prev,
                                [header]: value === 'skip' ? undefined : value
                              }));
                            }}
                          >
                            <SelectTrigger className={`w-full ${isRequired ? 'border-red-300' : ''}`}>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="skip">❌ Skip this column</SelectItem>
                              {entityFields[entityType].map(field => (
                                <SelectItem key={field.key} value={field.key}>
                                  {field.label} {field.required && <span className="text-red-500">*</span>}
                                  {field.help && <span className="text-xs text-gray-500 ml-2">({field.help})</span>}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={handleReset}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  const requiredFields = entityFields[entityType].filter(f => f.required);
                  const missingRequiredFields = requiredFields.filter(f =>
                    !Object.values(columnMapping).includes(f.key)
                  );

                  if (missingRequiredFields.length > 0) {
                    alert(`Please map these required fields before continuing:\n\n${missingRequiredFields.map(f => f.label).join('\n')}`);
                    return;
                  }

                  setStep(3);
                }}
                className="bg-blue-600 hover:bg-blue-700"
              >
                Continue to Review
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {step === 3 && (
        <Card className="bg-white shadow-md">
          <CardHeader className="border-b">
            <CardTitle>Step 3: Review & Import</CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <Alert className="bg-yellow-50 border-yellow-200">
              <AlertCircle className="w-4 h-4 text-yellow-600" />
              <AlertDescription>
                <strong>Ready to import?</strong> This will create new {entityType} records. Duplicates will be skipped.
              </AlertDescription>
            </Alert>

            <div>
              <h3 className="font-semibold mb-3">Preview (First 5 rows)</h3>
              <div className="border rounded-lg overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50">
                    <tr>
                      {Object.keys(columnMapping).filter(k => columnMapping[k]).map(header => (
                        <th key={header} className="px-3 py-2 text-left font-medium text-gray-700">
                          {entityFields[entityType].find(f => f.key === columnMapping[header])?.label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {previewRows.map((row, idx) => (
                      <tr key={idx} className="border-t">
                        {Object.keys(columnMapping).filter(k => columnMapping[k]).map(header => (
                          <td key={header} className="px-3 py-2">
                            {row[header] || '-'}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setStep(2)}>
                Back to Mapping
              </Button>
              <Button
                onClick={handleImport}
                disabled={importing}
                className="bg-green-600 hover:bg-green-700"
              >
                {importing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Importing...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Start Import
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {step === 4 && importResult && (
        <Card className="bg-white shadow-md">
          <CardHeader className="border-b">
            <CardTitle>{importResult.imported > 0 && importResult.errors === 0 ? 'Import Complete! 🎉' : (importResult.errors > 0 ? 'Import Completed with Errors' : 'Import Failed ❌')}</CardTitle>

          </CardHeader>
          <CardContent className="p-6 space-y-6">
            {importResult.error ? (
                 <Alert variant="destructive">
                  <XCircle className="w-4 h-4" />
                  <AlertDescription>
                    <strong>Import Failed:</strong> {importResult.error}
                  </AlertDescription>
                </Alert>
            ) : (
              <>
                <Alert className={importResult.errors > 0 ? "bg-yellow-50 border-yellow-200" : "bg-green-50 border-green-200"}>
                  {importResult.errors > 0 ? <AlertCircle className="w-4 h-4 text-yellow-600" /> : <CheckCircle2 className="w-4 h-4 text-green-600" />}
                  <AlertDescription>
                    <strong>{importResult.errors > 0 ? 'Partial Success' : 'Success!'}</strong> Your data has been processed.
                  </AlertDescription>
                </Alert>

                <div className="grid grid-cols-3 gap-4">
                  <Card className="bg-green-50 border-green-200">
                    <CardContent className="p-4">
                      <div className="text-3xl font-bold text-green-700">{importResult.imported}</div>
                      <div className="text-sm text-green-600">Imported</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-yellow-50 border-yellow-200">
                    <CardContent className="p-4">
                      <div className="text-3xl font-bold text-yellow-700">{importResult.skipped}</div>
                      <div className="text-sm text-yellow-600">Skipped (Required Fields)</div>
                    </CardContent>
                  </Card>
                  <Card className="bg-red-50 border-red-200">
                    <CardContent className="p-4">
                      <div className="text-3xl font-bold text-red-700">{importResult.errors}</div>
                      <div className="text-sm text-red-600">Errors</div>
                    </CardContent>
                  </Card>
                </div>
              </>
            )}

            {errorDetails && errorDetails.length > 0 && (
              <Card className="bg-red-50 border-red-200">
                <CardHeader>
                  <CardTitle className="text-red-900">Error Details ({errorDetails.length} rows failed)</CardTitle>
                </CardHeader>
                <CardContent className="max-h-96 overflow-y-auto">
                  <div className="space-y-2">
                    {errorDetails.slice(0, 100).map((error, idx) => (
                      <div key={idx} className="p-3 bg-white rounded border text-sm">
                        <div className="font-semibold text-red-800">Row {typeof error.row === 'number' ? error.row : String(error.row)}: <span className="font-normal text-red-700">{error.reason}</span></div>
                        {error.data && (
                          <div className="text-xs text-gray-600 mt-1 bg-gray-50 p-2 rounded">
                            Data: {JSON.stringify(error.data)}
                          </div>
                        )}
                      </div>
                    ))}
                    {errorDetails.length > 100 && (
                      <div className="text-sm text-red-700 text-center py-2">
                        ... and {errorDetails.length - 100} more errors
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="flex gap-3 justify-end">
              <Button onClick={handleReset}>
                Import Another File
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card className="bg-white shadow-md">
        <CardHeader className="border-b">
          <CardTitle>Import History</CardTitle>
          <p className="text-sm text-gray-500 mt-1">View your past data imports</p>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-3">
            {importLogs.slice(0, 10).map((log) => (
              <div key={log.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <FileSpreadsheet className="w-5 h-5 text-gray-400" />
                    <div>
                      <p className="font-medium text-gray-900">{log.file_name}</p>
                      <p className="text-sm text-gray-600">
                        {log.entity_type} • {log.imported_count} imported, {log.skipped_count} skipped, {log.error_count} errors
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(log.created_date).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
                <Badge
                  variant={
                    log.status === 'completed'
                      ? 'default'
                      : (log.status === 'completed_with_errors'
                          ? 'secondary'
                          : 'destructive')
                  }
                  className="ml-4"
                >
                  {log.status === 'completed_with_errors' ? 'Partial Success' : log.status}
                </Badge>
              </div>
            ))}
            {importLogs.length === 0 && (
              <div className="text-center py-12">
                <FileSpreadsheet className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-500">No imports yet</p>
                <p className="text-sm text-gray-400 mt-1">Import history will appear here</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
