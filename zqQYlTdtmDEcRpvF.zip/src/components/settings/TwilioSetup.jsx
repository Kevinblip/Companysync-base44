import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Phone, MessageSquare, CheckCircle2, AlertCircle, Loader2, Plus, Trash2 } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function TwilioSetup() {
  const [user, setUser] = useState(null);
  const [accountSid, setAccountSid] = useState("");
  const [authToken, setAuthToken] = useState("");
  const [mainPhoneNumber, setMainPhoneNumber] = useState("");
  const [enableSMS, setEnableSMS] = useState(true);
  const [enableCalling, setEnableCalling] = useState(true);
  const [enableRecording, setEnableRecording] = useState(true);
  const [availableNumbers, setAvailableNumbers] = useState([]);
  const [testResult, setTestResult] = useState(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  // Get company
  const { data: companies = [] } = useQuery({
    queryKey: ['companies', user?.email],
    queryFn: () => base44.entities.Company.list("-created_date"),
    enabled: !!user,
    initialData: [],
  });

  const myCompany = companies.find(c => c.created_by === user?.email) || companies[0];

  // Get Twilio settings
  const { data: twilioSettings } = useQuery({
    queryKey: ['twilio-settings', myCompany?.id],
    queryFn: async () => {
      if (!myCompany) return null;
      const settings = await base44.entities.TwilioSettings.filter({ company_id: myCompany.id });
      return settings[0] || null;
    },
    enabled: !!myCompany,
  });

  // Get all staff to assign numbers
  const { data: staffProfiles = [] } = useQuery({
    queryKey: ['staff-profiles', myCompany?.id],
    queryFn: async () => {
      if (!myCompany) return [];
      return await base44.entities.StaffProfile.filter({ company_id: myCompany.id });
    },
    enabled: !!myCompany,
    initialData: [],
  });

  useEffect(() => {
    if (twilioSettings) {
      setAccountSid(twilioSettings.account_sid || "");
      setAuthToken(twilioSettings.auth_token || "");
      setMainPhoneNumber(twilioSettings.main_phone_number || "");
      setEnableSMS(twilioSettings.enable_sms !== false);
      setEnableCalling(twilioSettings.enable_calling !== false);
      setEnableRecording(twilioSettings.enable_recording !== false);
      setAvailableNumbers(twilioSettings.available_numbers || []);
    }
  }, [twilioSettings]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (twilioSettings) {
        return await base44.entities.TwilioSettings.update(twilioSettings.id, data);
      } else {
        return await base44.entities.TwilioSettings.create({
          ...data,
          company_id: myCompany.id
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['twilio-settings'] });
      alert("✅ Twilio settings saved successfully!");
    },
    onError: (error) => {
      alert("❌ Failed to save: " + error.message);
    }
  });

  const handleSave = () => {
    if (!accountSid || !authToken) {
      alert("Please enter Account SID and Auth Token");
      return;
    }

    if (!mainPhoneNumber) {
      alert("Please enter at least one Main Company Phone Number");
      return;
    }

    // Format phone number to E.164
    let formattedMain = mainPhoneNumber.replace(/\D/g, '');
    if (formattedMain.length === 10) {
      formattedMain = '+1' + formattedMain;
    } else if (!formattedMain.startsWith('+')) {
      formattedMain = '+' + formattedMain;
    }

    const data = {
      account_sid: accountSid.trim(),
      auth_token: authToken.trim(),
      main_phone_number: formattedMain,
      enable_sms: enableSMS,
      enable_calling: enableCalling,
      enable_recording: enableRecording,
      available_numbers: availableNumbers.map(n => ({
        ...n,
        phone_number: n.phone_number.startsWith('+') ? n.phone_number : '+1' + n.phone_number.replace(/\D/g, '')
      }))
    };

    saveMutation.mutate(data);
  };

  const addPhoneNumber = () => {
    setAvailableNumbers([
      ...availableNumbers,
      {
        phone_number: "",
        assigned_to: "",
        label: ""
      }
    ]);
  };

  const removePhoneNumber = (index) => {
    setAvailableNumbers(availableNumbers.filter((_, i) => i !== index));
  };

  const updatePhoneNumber = (index, field, value) => {
    const updated = [...availableNumbers];
    updated[index] = {
      ...updated[index],
      [field]: value
    };
    setAvailableNumbers(updated);
  };

  const testConnection = async () => {
    if (!accountSid || !authToken) {
      alert("Please enter Account SID and Auth Token first");
      return;
    }

    setTestResult({ testing: true });

    try {
      // Simple test - try to initialize Twilio client
      const response = await fetch('https://api.twilio.com/2010-04-01/Accounts/' + accountSid.trim() + '.json', {
        headers: {
          'Authorization': 'Basic ' + btoa(accountSid.trim() + ':' + authToken.trim())
        }
      });

      if (response.ok) {
        setTestResult({ success: true, message: "✅ Twilio connection successful!" });
      } else {
        setTestResult({ success: false, message: "❌ Invalid credentials. Please check your Account SID and Auth Token." });
      }
    } catch (error) {
      setTestResult({ success: false, message: "❌ Connection failed: " + error.message });
    }
  };

  if (!myCompany) {
    return (
      <div className="p-6">
        <Alert>
          <AlertCircle className="w-4 h-4" />
          <AlertDescription>
            Please complete company setup first before configuring Twilio.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const webhookUrl = typeof window !== 'undefined' ? `${window.location.origin}/api/functions/incomingSMS` : '';
  const callWebhookUrl = typeof window !== 'undefined' ? `${window.location.origin}/api/functions/incomingCall` : '';

  return (
    <div className="space-y-6 max-h-[calc(90vh-100px)] overflow-y-auto p-6">
      <div>
        <h2 className="text-2xl font-bold">Twilio Integration Setup</h2>
        <p className="text-sm text-gray-600 mt-1">
          Connect your Twilio account to enable calling and SMS features
        </p>
      </div>

      {/* Step 1: Credentials */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
              1
            </div>
            Twilio Credentials
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="bg-blue-50 border-blue-200">
            <AlertCircle className="w-4 h-4 text-blue-600" />
            <AlertDescription className="text-blue-900">
              Get your Account SID and Auth Token from{" "}
              <a
                href="https://console.twilio.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="underline font-medium"
              >
                Twilio Console
              </a>
            </AlertDescription>
          </Alert>

          <div>
            <Label htmlFor="account-sid">Account SID *</Label>
            <Input
              id="account-sid"
              placeholder="ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
              value={accountSid}
              onChange={(e) => setAccountSid(e.target.value)}
            />
          </div>

          <div>
            <Label htmlFor="auth-token">Auth Token *</Label>
            <Input
              id="auth-token"
              type="password"
              placeholder="Your Twilio Auth Token"
              value={authToken}
              onChange={(e) => setAuthToken(e.target.value)}
            />
          </div>

          <Button onClick={testConnection} variant="outline" className="w-full">
            {testResult?.testing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Testing Connection...
              </>
            ) : (
              "Test Connection"
            )}
          </Button>

          {testResult && !testResult.testing && (
            <Alert className={testResult.success ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}>
              {testResult.success ? (
                <CheckCircle2 className="w-4 h-4 text-green-600" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-600" />
              )}
              <AlertDescription className={testResult.success ? "text-green-900" : "text-red-900"}>
                {testResult.message}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Step 2: Phone Numbers */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
              2
            </div>
            Phone Numbers
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="bg-yellow-50 border-yellow-200">
            <Phone className="w-4 h-4 text-yellow-600" />
            <AlertDescription className="text-yellow-900">
              You must purchase a phone number from Twilio first:{" "}
              <a
                href="https://console.twilio.com/us1/develop/phone-numbers/manage/search"
                target="_blank"
                rel="noopener noreferrer"
                className="underline font-medium"
              >
                Buy a Number
              </a>
            </AlertDescription>
          </Alert>

          <div>
            <Label htmlFor="main-phone">Main Company Phone Number *</Label>
            <Input
              id="main-phone"
              placeholder="+1 (555) 123-4567"
              value={mainPhoneNumber}
              onChange={(e) => setMainPhoneNumber(e.target.value)}
            />
            <p className="text-xs text-gray-500 mt-1">
              This is the main number customers see when you call/text them
            </p>
          </div>

          <div className="border-t pt-4">
            <div className="flex items-center justify-between mb-3">
              <Label>Additional Numbers (Optional)</Label>
              <Button onClick={addPhoneNumber} size="sm" variant="outline">
                <Plus className="w-4 h-4 mr-1" />
                Add Number
              </Button>
            </div>

            {availableNumbers.map((number, index) => (
              <div key={index} className="grid grid-cols-12 gap-2 mb-3 p-3 bg-gray-50 rounded-lg">
                <div className="col-span-4">
                  <Input
                    placeholder="+1 (555) 123-4567"
                    value={number.phone_number}
                    onChange={(e) => updatePhoneNumber(index, 'phone_number', e.target.value)}
                  />
                </div>
                <div className="col-span-3">
                  <Select
                    value={number.assigned_to}
                    onValueChange={(value) => updatePhoneNumber(index, 'assigned_to', value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Assign to..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={null}>Unassigned</SelectItem>
                      {staffProfiles.map((staff) => (
                        <SelectItem key={staff.user_email} value={staff.user_email}>
                          {staff.full_name || staff.user_email}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-4">
                  <Input
                    placeholder="Label (e.g., Sales Line)"
                    value={number.label}
                    onChange={(e) => updatePhoneNumber(index, 'label', e.target.value)}
                  />
                </div>
                <div className="col-span-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => removePhoneNumber(index)}
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              </div>
            ))}

            {availableNumbers.length === 0 && (
              <p className="text-sm text-gray-500 text-center py-4">
                No additional numbers added
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Step 3: Configure Webhooks */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
              3
            </div>
            Configure Twilio Webhooks
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="bg-purple-50 border-purple-200">
            <Phone className="w-4 h-4 text-purple-600" />
            <AlertDescription className="text-purple-900">
              <strong>IMPORTANT:</strong> Configure these webhooks in your Twilio Console for each phone number:
            </AlertDescription>
          </Alert>

          <div className="space-y-3">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-semibold text-sm mb-2">📱 SMS Webhook</h4>
              <p className="text-xs text-gray-600 mb-2">
                Set this under: Phone Numbers → Active Numbers → [Your Number] → Messaging → Webhook
              </p>
              <div className="flex items-center gap-2">
                <Input value={webhookUrl} readOnly className="text-xs" />
                <Button
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(webhookUrl);
                    alert("Copied!");
                  }}
                >
                  Copy
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Method: <span className="font-mono bg-gray-200 px-1">POST</span>
              </p>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-semibold text-sm mb-2">📞 Voice Webhook</h4>
              <p className="text-xs text-gray-600 mb-2">
                Set this under: Phone Numbers → Active Numbers → [Your Number] → Voice → Webhook
              </p>
              <div className="flex items-center gap-2">
                <Input value={callWebhookUrl} readOnly className="text-xs" />
                <Button
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(callWebhookUrl);
                    alert("Copied!");
                  }}
                >
                  Copy
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Method: <span className="font-mono bg-gray-200 px-1">POST</span>
              </p>
            </div>

            <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
              <p className="text-xs text-blue-900">
                💡 <strong>Tip:</strong> After saving settings, go to{" "}
                <a
                  href="https://console.twilio.com/us1/develop/phone-numbers/manage/incoming"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline"
                >
                  Twilio Console
                </a>{" "}
                and paste these URLs for each phone number.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Step 4: Features */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold">
              4
            </div>
            Features
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-purple-600" />
              <div>
                <Label>Enable SMS</Label>
                <p className="text-xs text-gray-500">Send and receive text messages</p>
              </div>
            </div>
            <Switch checked={enableSMS} onCheckedChange={setEnableSMS} />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-green-600" />
              <div>
                <Label>Enable Calling</Label>
                <p className="text-xs text-gray-500">Make and receive phone calls</p>
              </div>
            </div>
            <Switch checked={enableCalling} onCheckedChange={setEnableCalling} />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-blue-600" />
              <div>
                <Label>Enable Call Recording</Label>
                <p className="text-xs text-gray-500">Automatically record all calls</p>
              </div>
            </div>
            <Switch checked={enableRecording} onCheckedChange={setEnableRecording} />
          </div>
        </CardContent>
      </Card>

      {/* Save Button */}
      <div className="flex justify-end gap-3 sticky bottom-0 bg-white pt-4 border-t">
        <Button
          onClick={handleSave}
          disabled={saveMutation.isLoading}
          size="lg"
          className="bg-green-600 hover:bg-green-700"
        >
          {saveMutation.isLoading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <CheckCircle2 className="w-4 h-4 mr-2" />
              Save Twilio Settings
            </>
          )}
        </Button>
      </div>
    </div>
  );
}