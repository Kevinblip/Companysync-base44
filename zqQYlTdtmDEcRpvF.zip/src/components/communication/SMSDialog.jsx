
import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useMutation, useQueryClient, useQuery } from "@tanstack/react-query";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { MessageSquare, Send, X, Loader2, Paperclip, File as FileIcon } from "lucide-react";
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function SMSDialog({ open, onOpenChange, defaultTo, defaultName }) {
  const [user, setUser] = useState(null);
  const [to, setTo] = useState('');
  const [contactName, setContactName] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState(null);
  const [attachments, setAttachments] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);

  const queryClient = useQueryClient();

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: twilioConfig, isLoading: isLoadingTwilioConfig } = useQuery({
    queryKey: ['twilio-settings', user?.email],
    queryFn: async () => {
      if (!user) return null;
      let companyId = null;

      // First, check if user is a staff member
      const staffProfiles = await base44.entities.StaffProfile.filter({ user_email: user.email });
      if (staffProfiles && staffProfiles.length > 0) {
        companyId = staffProfiles[0].company_id;
      } else {
        // If not a staff member, check if they are a company owner
        const companies = await base44.entities.Company.filter({ created_by: user.email });
        if (companies && companies.length > 0) {
          companyId = companies[0].id;
        }
      }

      if (!companyId) {
        console.error("Could not determine company for user:", user.email);
        return null;
      }
      
      // Get twilio settings for that company
      const settings = await base44.entities.TwilioSettings.filter({ company_id: companyId });
      return settings[0] || null;
    },
    enabled: !!user,
    staleTime: 5 * 60 * 1000, // 5 minutes
    cacheTime: 10 * 60 * 1000, // 10 minutes
  });

  useEffect(() => {
    if (open) {
      if (defaultTo) {
        setTo(defaultTo);
      }
      if (defaultName) {
        setContactName(defaultName);
      }
      setError(null);
      setAttachments([]); // Reset attachments when dialog opens
    }
  }, [defaultTo, defaultName, open]);

  const sendSMSMutation = useMutation({
    mutationFn: async (data) => {
      const response = await base44.functions.invoke('sendSMS', data);
      return response.data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['communications'] });
      
      if (data.success) {
        alert("✅ SMS sent successfully!\n\nCheck Twilio logs if it doesn't arrive: https://console.twilio.com/us1/monitor/logs/sms");
        setTo("");
        setContactName("");
        setMessage("");
        setAttachments([]);
        setError(null);
        onOpenChange(false);
      } else {
        setError(data.message || data.error || "Failed to send SMS due to an unknown issue.");
      }
    },
    onError: (error) => {
      const errorMsg = error.response?.data?.error || error.message || "An unexpected error occurred.";
      setError(errorMsg);
    }
  });

  const handleSend = () => {
    if (!to || !message) {
      setError("Please fill in phone number and message.");
      return;
    }

    if (!twilioConfig || !twilioConfig.company_id || !twilioConfig.account_sid || !twilioConfig.auth_token || !twilioConfig.main_phone_number) {
      setError("Twilio is not configured for your company. Please ensure your company has Twilio SID, Auth Token, and a valid Main Company Number.");
      return;
    }

    setError(null);

    // Format phone number to E.164 with +1 prefix for US numbers
    let formattedNumber = to.replace(/\D/g, '');
    
    // If it's a 10-digit number, add +1 prefix (US)
    if (formattedNumber.length === 10) {
      formattedNumber = '+1' + formattedNumber;
    } else if (formattedNumber.length === 11 && formattedNumber.startsWith('1')) {
      // If it's 11 digits starting with 1, just add +
      formattedNumber = '+' + formattedNumber;
    } else if (!formattedNumber.startsWith('+')) {
      // Otherwise, add + prefix
      formattedNumber = '+' + formattedNumber;
    }

    let finalMessage = message;
    if (attachments.length > 0) {
        finalMessage += '\n\n---\nFiles:\n';
        attachments.forEach(file => {
            finalMessage += `${file.name}: ${file.url}\n`;
        });
    }

    sendSMSMutation.mutate({
      to: formattedNumber,
      message: finalMessage,
      contactName: contactName || 'Unknown',
      companyId: twilioConfig.company_id
    });
  };

  const formatPhoneDisplay = (value) => {
    const cleaned = value.replace(/\D/g, '');
    
    if (cleaned.length === 0) return '';
    if (cleaned.length <= 3) return cleaned;
    if (cleaned.length <= 6) return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3)}`;
    if (cleaned.length <= 10) return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
    
    // For numbers longer than 10 digits (e.g., international, or +1 prefix already included)
    // We'll just show the cleaned number with a '+' if it had one, or if it's explicitly long
    if (value.startsWith('+') && cleaned.length > 10) return `+${cleaned}`;
    return `(${cleaned.slice(0, 3)}) ${cleaned.slice(3, 6)}-${cleaned.slice(6, 10)}`;
  };

  const handlePhoneChange = (e) => {
    const value = e.target.value;
    const cleaned = value.replace(/\D/g, '');
    setTo(cleaned);
  };

  const handleFileChange = async (e) => {
    const files = Array.from(e.target.files);
    if (files.length === 0) return;

    setIsUploading(true);
    try {
      for (const file of files) {
        const { file_url } = await base44.integrations.Core.UploadFile({ file });
        setAttachments(prev => [...prev, { name: file.name, url: file_url }]);
      }
    } catch (error) {
      console.error("File upload error:", error);
      setError("Failed to upload file. Please try again.");
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = ''; // Reset file input to allow re-uploading the same file
      }
    }
  };

  const removeAttachment = (index) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };


  const remainingChars = 160 - message.length;

  const isSendDisabled = sendSMSMutation.isLoading || isLoadingTwilioConfig || !twilioConfig?.main_phone_number || isUploading;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 mr-1 text-purple-600" />
            Send Text Message
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="sms-name">Contact Name</Label>
            <Input
              id="sms-name"
              placeholder="John Doe"
              value={contactName}
              onChange={(e) => setContactName(e.target.value)}
            />
          </div>

          <div>
            <Label htmlFor="sms-to">Phone Number *</Label>
            <Input
              id="sms-to"
              type="tel"
              placeholder="+1 (555) 123-4567"
              value={formatPhoneDisplay(to)}
              onChange={handlePhoneChange}
            />
            <p className="text-xs text-gray-500 mt-1">
              Automatically adds +1 for US numbers
            </p>
          </div>

          <div>
            <Label htmlFor="sms-message">Message *</Label>
            <Textarea
              id="sms-message"
              rows={6}
              placeholder="Type your message here..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
            <p className="text-xs text-gray-500 mt-1">
              {remainingChars > 0 ? `${remainingChars} characters remaining for first segment.` : `Message will be split into multiple segments.`}
            </p>
          </div>
          
          {/* Attachment Section */}
          <div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              multiple
            />
            <Button
              type="button"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
            >
              {isUploading ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Paperclip className="w-4 h-4 mr-2" />
              )}
              {isUploading ? 'Uploading...' : 'Attach File(s)'}
            </Button>
             <p className="text-xs text-gray-500 mt-1">
              Attachments are sent as links and may increase message cost.
            </p>
          </div>

          {attachments.length > 0 && (
            <div className="space-y-2 p-3 bg-gray-50 rounded-lg border">
              <p className="text-sm font-medium">Attachments:</p>
              {attachments.map((file, index) => (
                <div key={index} className="flex items-center justify-between text-sm bg-white p-2 rounded border">
                  <div className="flex items-center gap-2">
                    <FileIcon className="w-4 h-4 text-gray-500" />
                    <span className="truncate max-w-xs">{file.name}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeAttachment(index)}
                    className="h-6 w-6 p-0"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}


          {isLoadingTwilioConfig && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <p className="text-sm text-blue-800 flex items-center">
                <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Loading Twilio configuration...
              </p>
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm text-red-800">
                ❌ <strong>Error:</strong> {error}
              </p>
              {error.includes('verified') && (
                <a 
                  href="https://console.twilio.com/us1/develop/phone-numbers/manage/verified" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-xs text-blue-600 hover:underline mt-2 inline-block"
                >
                  → Verify phone numbers in Twilio Console
                </a>
              )}
            </div>
          )}

          {!error && !isLoadingTwilioConfig && twilioConfig && !twilioConfig.main_phone_number && (
             <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
             <p className="text-sm text-yellow-800">
               ⚠️ <strong>Twilio Not Fully Configured:</strong> To send SMS, please ensure your company's Twilio settings include a valid Main Company Number.
             </p>
           </div>
          )}

          {!error && !isLoadingTwilioConfig && twilioConfig?.main_phone_number && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <p className="text-sm text-green-800">
                ✅ <strong>Real Twilio SMS</strong> - Messages will send from {twilioConfig.main_phone_number}.
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              onClick={() => {
                setTo("");
                setContactName("");
                setMessage("");
                setAttachments([]);
                setError(null);
                onOpenChange(false);
              }}
              disabled={sendSMSMutation.isLoading}
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handleSend}
              disabled={isSendDisabled}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {sendSMSMutation.isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send SMS
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
