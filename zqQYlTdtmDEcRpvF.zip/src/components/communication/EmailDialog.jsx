import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Mail, Send, ExternalLink } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function EmailDialog({ open, onOpenChange }) {
  const [formData, setFormData] = useState({
    contactName: '',
    to: '',
    subject: '',
    message: ''
  });

  const handleSendEmail = () => {
    // Create mailto link with all the data
    const mailtoLink = `mailto:${formData.to}?subject=${encodeURIComponent(formData.subject)}&body=${encodeURIComponent(formData.message)}`;
    
    // Open user's default email client
    window.location.href = mailtoLink;
    
    // Close dialog
    onOpenChange(false);
    
    // Reset form
    setFormData({
      contactName: '',
      to: '',
      subject: '',
      message: ''
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            Send Email
          </DialogTitle>
        </DialogHeader>

        <Alert className="bg-blue-50 border-blue-200">
          <AlertDescription className="text-sm text-blue-800">
            💡 This will open your default email client (Gmail, Outlook, etc.) with the message pre-filled.
          </AlertDescription>
        </Alert>

        <div className="space-y-4">
          <div>
            <Label>Contact Name</Label>
            <Input
              placeholder="John Doe"
              value={formData.contactName}
              onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
            />
          </div>

          <div>
            <Label>To *</Label>
            <Input
              type="email"
              placeholder="customer@example.com"
              value={formData.to}
              onChange={(e) => setFormData({ ...formData, to: e.target.value })}
              required
            />
          </div>

          <div>
            <Label>Subject *</Label>
            <Input
              placeholder="Regarding your roofing estimate..."
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              required
            />
          </div>

          <div>
            <Label>Message *</Label>
            <Textarea
              placeholder="Hi [Name],

I hope this email finds you well..."
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              rows={8}
              required
            />
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSendEmail}
              disabled={!formData.to || !formData.subject || !formData.message}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Open in Email Client
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}