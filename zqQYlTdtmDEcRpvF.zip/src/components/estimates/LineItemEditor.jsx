
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trash2, Plus } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import ItemDropdown from "./ItemDropdown";

export default function LineItemEditor({ items = [], onChange, format = null }) {
  const [editingDescriptionIndex, setEditingDescriptionIndex] = useState(null);

  // Determine what to show based on format
  const showDepreciation = format?.show_depreciation || false;
  const showRcvAcv = format?.show_rcv_acv !== false; // Default true
  const showOverheadProfit = format?.show_overhead_profit || false;
  
  // Determine default filter based on format, but allow user to change it
  const getDefaultFilter = () => {
    if (format?.category === "insurance" && format?.insurance_company?.toLowerCase().includes("xactimate")) {
      return "xactimate";
    } else if (format?.category === "insurance" && format?.insurance_company?.toLowerCase().includes("symbility")) {
      return "symbility";
    } else if (format?.category === "custom" || !format) {
      return "custom";
    }
    return "all";
  };

  const [formatFilter, setFormatFilter] = useState(getDefaultFilter());

  // Update filter when format changes
  React.useEffect(() => {
    setFormatFilter(getDefaultFilter());
  }, [format?.id]);

  const handleAddItem = (selectedItemsOrSingleItem = null) => {
    let newItemsToAdd = [];

    const createItemObject = (selectedItem) => ({
      code: selectedItem?.code || "",
      description: selectedItem?.description || "",
      quantity: 1,
      unit: selectedItem?.unit || "EA",
      rate: selectedItem?.rate || 0,
      depreciation_rate: showDepreciation ? 0 : undefined,
      category: selectedItem?.category || "",
      amount: selectedItem?.rate || 0
    });

    if (Array.isArray(selectedItemsOrSingleItem)) {
      newItemsToAdd = selectedItemsOrSingleItem.map(createItemObject);
    } else if (selectedItemsOrSingleItem) {
      // Single item case (e.g., if ItemDropdown didn't allow multiple, or for existing logic)
      newItemsToAdd.push(createItemObject(selectedItemsOrSingleItem));
    } else {
      // Blank line case (when called with no arguments)
      newItemsToAdd.push({
        code: "",
        description: "",
        quantity: 1,
        unit: "EA",
        rate: 0,
        depreciation_rate: showDepreciation ? 0 : undefined,
        category: "",
        amount: 0
      });
    }
    
    onChange([...items, ...newItemsToAdd]);
  };

  const handleUpdateItem = (index, field, value) => {
    const updated = [...items];
    updated[index][field] = value;
    
    if (field === 'quantity' || field === 'rate') {
      const qty = parseFloat(updated[index].quantity) || 0;
      const rate = parseFloat(updated[index].rate) || 0;
      updated[index].amount = qty * rate;
    }
    
    onChange(updated);
  };

  const handleDeleteItem = (index) => {
    onChange(items.filter((_, i) => i !== index));
  };

  const handleSelectItemForRow = (index, selectedItem) => {
    const updated = [...items];
    const currentQuantity = updated[index].quantity || 1;
    updated[index] = {
      ...updated[index],
      code: selectedItem.code,
      description: selectedItem.description,
      unit: selectedItem.unit,
      rate: selectedItem.rate,
      category: selectedItem.category,
      amount: currentQuantity * selectedItem.rate
    };
    onChange(updated);
    setEditingDescriptionIndex(null); // Close the dropdown after selection
  };

  const calculateDepreciation = (item) => {
    if (!showDepreciation) return 0;
    const rcv = item.amount || 0;
    const deprRate = item.depreciation_rate || 0;
    return rcv * (deprRate / 100);
  };

  const calculateACV = (item) => {
    const rcv = item.amount || 0;
    const depr = calculateDepreciation(item);
    return rcv - depr;
  };

  const totalRCV = items.reduce((sum, item) => sum + (item.amount || 0), 0);
  const totalDepreciation = items.reduce((sum, item) => sum + calculateDepreciation(item), 0);
  const totalACV = totalRCV - totalDepreciation;

  return (
    <div className="border rounded-lg overflow-hidden bg-white">
      <div className="flex items-center justify-between p-4 bg-gray-50 border-b">
        <h3 className="font-semibold text-gray-700">
          Line Items {format && <span className="text-sm font-normal text-gray-500">({format.format_name})</span>}
        </h3>
        <div className="flex gap-2 items-center">
          <Select value={formatFilter} onValueChange={setFormatFilter}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Source Filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sources</SelectItem>
              <SelectItem value="favorites">⭐ Favorites Only</SelectItem>
              <SelectItem value="xactimate">Xactimate Only</SelectItem>
              <SelectItem value="symbility">Symbility Only</SelectItem>
              <SelectItem value="custom">Custom Only</SelectItem>
            </SelectContent>
          </Select>
          
          <div className="relative w-80">
            <ItemDropdown
              value=""
              onSelect={(selectedItems) => handleAddItem(selectedItems)}
              placeholder="Add Items - Start typing to search..."
              formatFilter={formatFilter}
              allowMultiple={true}
            />
          </div>
          <Button onClick={() => handleAddItem()} variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Blank Line
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-white border-b">
            <tr>
              <th className="text-left p-3 font-semibold text-gray-700 w-12">LINE</th>
              <th className="text-left p-3 font-semibold text-gray-700 w-28">CODE</th>
              <th className="text-left p-3 font-semibold text-gray-700">DESCRIPTION</th>
              <th className="text-center p-3 font-semibold text-gray-700 w-24">QTY</th>
              <th className="text-center p-3 font-semibold text-gray-700 w-20">UNIT</th>
              <th className="text-right p-3 font-semibold text-gray-700 w-28">UNIT PRICE</th>
              {showRcvAcv && (
                <th className="text-right p-3 font-semibold text-blue-600 w-28">
                  {format?.rcv_label || "RCV"}
                </th>
              )}
              {showDepreciation && (
                <th className="text-right p-3 font-semibold text-red-600 w-32">
                  {format?.depreciation_label || "DEPRECIATION"}
                </th>
              )}
              {showRcvAcv && (
                <th className="text-right p-3 font-semibold text-purple-600 w-28">
                  {format?.acv_label || "ACV"}
                </th>
              )}
              <th className="text-center p-3 font-semibold text-gray-700 w-24">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={index} className="border-b hover:bg-gray-50">
                <td className="p-3 text-gray-600">{index + 1}</td>
                <td className="p-3">
                  <code className="text-xs font-mono font-semibold text-blue-600">
                    {item.code || "-"}
                  </code>
                </td>
                <td className="p-3">
                  {editingDescriptionIndex === index ? (
                    <ItemDropdown
                      value={item.description}
                      onSelect={(selectedItem) => handleSelectItemForRow(index, selectedItem)}
                      placeholder="Search or type description..."
                      formatFilter={formatFilter}
                    />
                  ) : (
                    <div
                      onClick={() => setEditingDescriptionIndex(index)}
                      className="cursor-pointer hover:bg-blue-50 p-2 rounded min-h-[40px] flex items-center"
                    >
                      {item.description || <span className="text-gray-400">Click to add description...</span>}
                    </div>
                  )}
                </td>
                <td className="p-3">
                  <Input
                    type="number"
                    step="0.01"
                    value={item.quantity || ""}
                    onChange={(e) => handleUpdateItem(index, 'quantity', parseFloat(e.target.value))}
                    className="text-center border-gray-200 w-20"
                  />
                </td>
                <td className="p-3 text-center text-sm text-gray-600">{item.unit}</td>
                <td className="p-3">
                  <Input
                    type="number"
                    step="0.01"
                    value={item.rate || ""}
                    onChange={(e) => handleUpdateItem(index, 'rate', parseFloat(e.target.value))}
                    className="text-right border-gray-200 w-24"
                  />
                </td>
                {showRcvAcv && (
                  <td className="p-3 text-right text-blue-600 font-semibold">
                    ${(item.amount || 0).toFixed(2)}
                  </td>
                )}
                {showDepreciation && (
                  <td className="p-3 text-right text-red-600 font-semibold">
                    ${calculateDepreciation(item).toFixed(2)}
                  </td>
                )}
                {showRcvAcv && (
                  <td className="p-3 text-right text-purple-600 font-semibold">
                    ${calculateACV(item).toFixed(2)}
                  </td>
                )}
                <td className="p-3 text-center">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDeleteItem(index)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </td>
              </tr>
            ))}
            {items.length === 0 && (
              <tr>
                <td colSpan={showDepreciation && showRcvAcv ? 10 : showRcvAcv ? 8 : 7} className="p-12 text-center text-gray-500">
                  <p className="text-lg mb-2">No line items yet</p>
                  <p className="text-sm">Use "Add Items" above to search and add items from your price list</p>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {items.length > 0 && (
        <div className="p-4 bg-gray-50 border-t">
          <div className="flex justify-end gap-12 text-sm font-semibold">
            {showRcvAcv && (
              <div className="text-blue-600">
                Total {format?.rcv_label || "RCV"}: ${totalRCV.toFixed(2)}
              </div>
            )}
            {showDepreciation && (
              <div className="text-red-600">
                Total {format?.depreciation_label || "Depreciation"}: ${totalDepreciation.toFixed(2)}
              </div>
            )}
            {showRcvAcv && (
              <div className="text-purple-600">
                Total {format?.acv_label || "ACV"}: ${totalACV.toFixed(2)}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
