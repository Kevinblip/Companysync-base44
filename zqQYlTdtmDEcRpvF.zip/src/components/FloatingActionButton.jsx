import React, { useState } from "react";
import { Plus, X, UserPlus, Briefcase, FileText, Calendar } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { motion, AnimatePresence } from "framer-motion";

export default function FloatingActionButton() {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const actions = [
    { icon: UserPlus, label: "Add Lead", onClick: () => navigate(createPageUrl("Leads") + "?create=true"), color: "bg-blue-500" },
    { icon: Briefcase, label: "Add Customer", onClick: () => navigate(createPageUrl("Customers") + "?create=true"), color: "bg-green-500" },
    { icon: FileText, label: "New Estimate", onClick: () => navigate(createPageUrl("Estimates") + "?create=true"), color: "bg-purple-500" },
    { icon: Calendar, label: "Schedule", onClick: () => navigate(createPageUrl("Calendar")), color: "bg-orange-500" },
  ];

  return (
    <div className="fixed right-4 z-40" style={{ bottom: "180px" }}>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="flex flex-col gap-3 mb-3"
          >
            {actions.map((action, index) => (
              <motion.button
                key={action.label}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => {
                  action.onClick();
                  setIsOpen(false);
                }}
                className={`${action.color} text-white p-3 rounded-full shadow-lg hover:shadow-xl transition-all flex items-center gap-2 pr-4`}
              >
                <action.icon className="w-5 h-5" />
                <span className="text-sm font-medium whitespace-nowrap">{action.label}</span>
              </motion.button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
      </motion.button>
    </div>
  );
}